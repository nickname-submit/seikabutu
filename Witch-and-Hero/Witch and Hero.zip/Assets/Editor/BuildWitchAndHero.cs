using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// <summary>
/// Reproducible command-line build entry points for the downloadable macOS and Windows apps.
/// Usage:
/// Unity -batchmode -quit -projectPath "..." \
///   -executeMethod WitchAndHeroBuild.BuildMac \
///   -buildPath "/path/Witch and Hero.app"
/// </summary>
public static class WitchAndHeroBuild
{
    public static void BuildMac()
    {
        string outputPath = GetArgument("-buildPath");
        if (string.IsNullOrWhiteSpace(outputPath))
            outputPath = Path.Combine("Build", "Witch and Hero.app");

        outputPath = Path.GetFullPath(outputPath);
        string outputDirectory = Path.GetDirectoryName(outputPath);
        if (!string.IsNullOrEmpty(outputDirectory))
            Directory.CreateDirectory(outputDirectory);

        string[] scenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled && !string.IsNullOrEmpty(scene.path))
            .Select(scene => scene.path)
            .ToArray();

        if (scenes.Length == 0)
            throw new InvalidOperationException("No enabled scenes are configured in Build Settings.");

        BuildReport report = BuildPipeline.BuildPlayer(
            scenes,
            outputPath,
            BuildTarget.StandaloneOSX,
            BuildOptions.None);

        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new InvalidOperationException(
                $"macOS build failed: {report.summary.result}, errors={report.summary.totalErrors}");
        }

        Debug.Log($"Witch and Hero macOS build succeeded: {outputPath}");
    }

    public static void BuildWindows()
    {
        string outputPath = GetArgument("-buildPath");
        if (string.IsNullOrWhiteSpace(outputPath))
            outputPath = Path.Combine("Build", "Witch and Hero", "Witch and Hero.exe");

        outputPath = Path.GetFullPath(outputPath);
        string outputDirectory = Path.GetDirectoryName(outputPath);
        if (!string.IsNullOrEmpty(outputDirectory))
            Directory.CreateDirectory(outputDirectory);

        string[] scenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled && !string.IsNullOrEmpty(scene.path))
            .Select(scene => scene.path)
            .ToArray();

        if (scenes.Length == 0)
            throw new InvalidOperationException("No enabled scenes are configured in Build Settings.");

        BuildReport report = BuildPipeline.BuildPlayer(
            scenes,
            outputPath,
            BuildTarget.StandaloneWindows64,
            BuildOptions.None);

        if (report.summary.result != BuildResult.Succeeded)
        {
            throw new InvalidOperationException(
                $"Windows build failed: {report.summary.result}, errors={report.summary.totalErrors}");
        }

        Debug.Log($"Witch and Hero Windows build succeeded: {outputPath}");
    }

    private static string GetArgument(string name)
    {
        string[] args = Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length - 1; i++)
        {
            if (args[i] == name)
                return args[i + 1];
        }

        return null;
    }
}
