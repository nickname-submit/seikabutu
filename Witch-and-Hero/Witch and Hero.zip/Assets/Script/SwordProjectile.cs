using System.Collections.Generic;
using UnityEngine;

public class SwordProjectile : MonoBehaviour
{
    [SerializeField] private float speed = 8f;
    [SerializeField] private float lifetime = 1.5f;
    [SerializeField] private int hitsToDestroy = 1;
    [SerializeField] private int damage = 3;

    private GameObject[] swords;
    private SpriteRenderer[] swordRenderers;
    private SpriteRenderer rootRenderer;
    private Vector2 direction;
    private bool launched;
    private int hitCount;
    private HashSet<Monster> hitMonsters = new HashSet<Monster>();
    private Vector3 baseLocalScale;
    private float baseSpeed;
    private float baseLifetime;
    private float specialScale = 1f;
    private Color specialTint = Color.white;
    
    private void Awake()
    {
        baseLocalScale = transform.localScale;
        baseSpeed = speed;
        baseLifetime = lifetime;
        rootRenderer = GetComponent<SpriteRenderer>();
        if (rootRenderer != null)
        {
            rootRenderer.enabled = false;
            rootRenderer.sortingOrder = 100;
        }
        swords = new GameObject[4];
        swordRenderers = new SpriteRenderer[4];

        Transform swordUp = transform.Find("SwordUp");
        Transform swordDown = transform.Find("SwordDown");
        Transform swordLeft = transform.Find("SwordLeft");
        Transform swordRight = transform.Find("SwordRight");
        swords[0] = swordUp != null ? swordUp.gameObject : null;
        swords[1] = swordDown != null ? swordDown.gameObject : null;
        swords[2] = swordLeft != null ? swordLeft.gameObject : null;
        swords[3] = swordRight != null ? swordRight.gameObject : null;

        for (int i = 0; i < swords.Length; i++)
        {
            if (swords[i] == null) continue;

            swordRenderers[i] = swords[i].GetComponentInChildren<SpriteRenderer>(true);
            if (swordRenderers[i] != null)
            {
                // Child renderers are used as the source sprites. The root
                // renderer displays the selected sprite so the slash cannot
                // disappear when an inactive child is toggled at runtime.
                swordRenderers[i].sortingOrder = 100;
            }
        }

        SetActiveSword(-1);
    }

    public void SetWeaponStyle(bool isKunai)
    {
        if (isKunai)
        {
            // The kunai is a smaller, quicker projectile that travels much
            // farther than the normal close-range sword slash.
            speed = Mathf.Max(baseSpeed * 1.9f, 7.5f);
            lifetime = Mathf.Max(baseLifetime * 1.8f, 1.8f);
            transform.localScale = baseLocalScale * 0.55f;
        }
        else
        {
            speed = baseSpeed;
            lifetime = baseLifetime;
            transform.localScale = baseLocalScale;
        }
    }

    public void SetSpecialVisual(float scaleMultiplier, Color tint)
    {
        specialScale = Mathf.Max(0.1f, scaleMultiplier);
        specialTint = tint;
        transform.localScale *= specialScale;
    }

    public void Launch(Vector2 dir)
    {
        if (dir.sqrMagnitude == 0f)
        {
            Destroy(gameObject);
            return;
        }

        direction = dir.normalized;

        int index;

        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            index = direction.x > 0 ? 3 : 2;
        else
            index = direction.y > 0 ? 0 : 1;

        SetActiveSword(index);

        if (rootRenderer != null && swordRenderers[index] != null)
        {
            rootRenderer.sprite = swordRenderers[index].sprite;
            rootRenderer.flipX = swordRenderers[index].flipX;
            rootRenderer.flipY = swordRenderers[index].flipY;
            rootRenderer.sortingLayerID = swordRenderers[index].sortingLayerID;
            rootRenderer.sortingOrder = 100;
            rootRenderer.color = specialTint;
            rootRenderer.enabled = true;
        }

        launched = true;
        Destroy(gameObject, lifetime);
    }

    public void SetDamage(int value)
    {
        damage = Mathf.Max(1, value);
    }

    public void SetPiercingHits(int value)
    {
        // Each monster is counted only once by hitMonsters. This lets the
        // slash pass through different monsters without repeatedly damaging
        // the same monster while the projectile overlaps it.
        hitsToDestroy = Mathf.Max(1, value);
    }

    private void SetActiveSword(int activeIndex)
    {
        if (rootRenderer != null)
            rootRenderer.enabled = false;

        for (int i = 0; i < swords.Length; i++)
        {
            if (swords[i] != null)
                swords[i].SetActive(i == activeIndex);

            if (swordRenderers != null && swordRenderers[i] != null)
                swordRenderers[i].enabled = i == activeIndex;
        }
    }

    private void Update()
    {
        if (!launched) return;

        transform.position +=
            (Vector3)(direction * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Monster"))
            return;

        Monster monster = other.GetComponentInParent<Monster>();

        if (monster == null || hitMonsters.Contains(monster))
            return;

        hitMonsters.Add(monster);

        monster.TakeSwordHit(direction, damage);

        hitCount++;

        if (hitCount >= Mathf.Max(1, hitsToDestroy))
        {
            Destroy(gameObject);
        }
    }
}
