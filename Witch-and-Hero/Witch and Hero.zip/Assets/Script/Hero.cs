using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class Hero : MonoBehaviour
{
    private bool isPause;
    private bool isDead;
    private int hitCount;
    [SerializeField] private int maxHits = 10;
    [SerializeField] private float hitInvulnerabilityDuration = 0.5f;
    private float nextHitTime;
    [SerializeField] private float heroKnockbackInterval = 0.16f;
    private float nextHeroKnockbackTime;
    private Coroutine heroKnockbackRoutine;

    private bool isInputLocked;

    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private Rigidbody2D body;
    private Collider2D bodyCollider;
    private Vector2 lastDirection = Vector2.down;
    private bool deathAnimationFrozen;
    private bool walkingThisFrame;
    private float walkAnimationTime;
    private Coroutine attackSpriteRoutine;

    // Animator remains responsible for idle, attack, and death. These
    // references make the walk cycle deterministic in the Game view, where a
    // very short keyboard event can otherwise leave the Animator on one pose.
    [SerializeField] private Sprite[] runDownFrames;
    [SerializeField] private Sprite[] runLeftFrames;
    [SerializeField] private Sprite[] runRightFrames;
    [SerializeField] private Sprite[] runUpFrames;
    [SerializeField] private Sprite[] attackDownFrames;
    [SerializeField] private Sprite[] attackLeftFrames;
    [SerializeField] private Sprite[] attackRightFrames;
    [SerializeField] private Sprite[] attackUpFrames;
    [SerializeField, Range(0.06f, 0.3f)] private float walkFrameDuration = 0.12f;
    // Match the source attack clips: seven frames sampled at 12 fps.
    // Keeping one cadence for every direction makes the Space attack play at
    // the same speed as the Animator clips it replaced.
    [SerializeField, Range(0.06f, 0.3f)] private float attackFrameDuration = 0.08333333f;
    private static readonly float[] attackFrameTiming =
        { 1f, 1f, 1f, 1f, 1f, 1f, 1f };
    [SerializeField, Range(0.1f, 1f)]
    private float idleAnimationSpeed = 0.55f;
    private static readonly int DeathStateHash = Animator.StringToHash("Base Layer.death Blend Tree");
    private static readonly int AttackStateHash = Animator.StringToHash("Base Layer.attack Blend Tree");

    public bool IsDead => isDead;
    public Vector2 FacingDirection => lastDirection;
    public int Health => Mathf.Max(0, maxHits - hitCount);
    public int MaxHealth => Mathf.Max(1, maxHits);

    public void SetFacingDirection(Vector2 direction)
    {
        if (direction.sqrMagnitude < 0.01f)
            return;

        lastDirection = direction.normalized;
        if (Mathf.Abs(lastDirection.x) > Mathf.Abs(lastDirection.y))
            lastDirection = new Vector2(Mathf.Sign(lastDirection.x), 0f);
        else
            lastDirection = new Vector2(0f, Mathf.Sign(lastDirection.y));
    }

    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
        bodyCollider = GetComponent<Collider2D>();
        ConfigurePhysicsBody();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        if (animator == null)
            Debug.LogError("HeroにAnimatorが設定されていません。", this);
    }

    private void ConfigurePhysicsBody()
    {
        if (body == null) return;

        // Let the Hero use its real collider for wall contacts. The prefab was
        // originally a trigger, which made the witch impossible to treat as a
        // physical wall.
        body.bodyType = RigidbodyType2D.Dynamic;
        body.useFullKinematicContacts = false;
        body.gravityScale = 0f;
        body.linearDamping = 0f;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        body.constraints = RigidbodyConstraints2D.FreezeRotation;
        body.linearVelocity = Vector2.zero;
        body.angularVelocity = 0f;
        if (bodyCollider != null)
            bodyCollider.isTrigger = false;
    }

    public void ResetForStage(Vector3 startPosition)
    {
        maxHits = GameFlow.GetHeroMaxHealth();
        transform.position = startPosition;
        isDead = false;
        isPause = false;
        isInputLocked = false;
        hitCount = 0;
        nextHitTime = 0f;
        nextHeroKnockbackTime = 0f;
        heroKnockbackRoutine = null;
        lastDirection = Vector2.down;
        deathAnimationFrozen = false;
        walkingThisFrame = false;
        walkAnimationTime = 0f;
        if (attackSpriteRoutine != null)
            StopCoroutine(attackSpriteRoutine);
        attackSpriteRoutine = null;
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        body = GetComponent<Rigidbody2D>();
        bodyCollider = GetComponent<Collider2D>();
        ConfigurePhysicsBody();

        if (animator != null)
        {
            animator.enabled = true;
            animator.speed = Mathf.Clamp(idleAnimationSpeed, 0.1f, 1f);
            animator.Rebind();
            animator.ResetTrigger("Attack");
            animator.ResetTrigger("Death");
            animator.SetBool("IsDead", false);
            animator.SetBool("IsMoving", false);
            animator.SetFloat("X", 0f);
            animator.SetFloat("Y", -1f);
            animator.Update(0f);
        }

        PlayerSwordAttack swordAttack = GetComponent<PlayerSwordAttack>();
        if (swordAttack != null)
            swordAttack.ResetForStage();
    }

    private void Update()
    {
        if (GameFlow.IsBattleGameplayFrozen)
        {
            walkingThisFrame = false;
            if (body != null)
                body.linearVelocity = Vector2.zero;
            return;
        }

        if (isDead)
        {
            UpdateDeathAnimation();
            return;
        }

        walkingThisFrame = false;

        if (isPause || isInputLocked)
        {
            if (body != null)
                body.linearVelocity = Vector2.zero;
            return;
        }

        Vector2 movement = Vector2.zero;
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            // Keep held movement, but also accept a press that lasts less than
            // one rendered frame. This matters in the editor Game view and
            // makes a single keyboard press move the hero predictably.
            if (keyboard.aKey.isPressed || keyboard.aKey.wasPressedThisFrame ||
                keyboard.leftArrowKey.isPressed || keyboard.leftArrowKey.wasPressedThisFrame)
                movement.x -= 1;
            if (keyboard.dKey.isPressed || keyboard.dKey.wasPressedThisFrame ||
                keyboard.rightArrowKey.isPressed || keyboard.rightArrowKey.wasPressedThisFrame)
                movement.x += 1;
            if (keyboard.wKey.isPressed || keyboard.wKey.wasPressedThisFrame ||
                keyboard.upArrowKey.isPressed || keyboard.upArrowKey.wasPressedThisFrame)
                movement.y += 1;
            if (keyboard.sKey.isPressed || keyboard.sKey.wasPressedThisFrame ||
                keyboard.downArrowKey.isPressed || keyboard.downArrowKey.wasPressedThisFrame)
                movement.y -= 1;
        }

        if (movement != Vector2.zero)
        {
            movement.Normalize();
            if (body != null)
            {
                // Give the physics body a velocity. The non-trigger Hero
                // collider is then stopped by the witch collider itself.
                body.linearVelocity = movement * GameFlow.GetHeroMoveSpeed();
            }
            else
            {
                transform.position += new Vector3(movement.x, movement.y, 0) *
                    GameFlow.GetHeroMoveSpeed() * Time.deltaTime;
            }

            if (Mathf.Abs(movement.x) > Mathf.Abs(movement.y))
                lastDirection = new Vector2(Mathf.Sign(movement.x), 0);
            else
                lastDirection = new Vector2(0, Mathf.Sign(movement.y));

            walkingThisFrame = true;
            if (animator != null)
                animator.enabled = false;
        }
        else if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            if (animator != null && !animator.enabled && attackSpriteRoutine == null)
            {
                animator.enabled = true;
                animator.Rebind();
                animator.Update(0f);
            }
        }

        if (animator != null)
        {
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
            animator.SetBool("IsMoving", movement != Vector2.zero);
            // The idle sheet is intentionally slower than the action sheets.
            // This keeps the standing pose readable and avoids a strobing or
            // afterimage-like impression while leaving walk/attack at 1x.
            animator.speed = movement != Vector2.zero
                ? 1f
                : Mathf.Clamp(idleAnimationSpeed, 0.1f, 1f);
        }

    }

    private void LateUpdate()
    {
        if (!isDead && !isInputLocked && walkingThisFrame)
        {
            UpdateWalkSprite();
            return;
        }

        walkAnimationTime = 0f;

        if (!isDead || animator == null || deathAnimationFrozen)
            return;

        // Animator transitions are evaluated after Update. Re-assert death in
        // LateUpdate so an already queued Attack transition cannot be rendered
        // for one frame after the fatal hit.
        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.fullPathHash != DeathStateHash)
        {
            animator.ResetTrigger("Attack");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
        }
    }

    private void UpdateWalkSprite()
    {
        if (spriteRenderer == null) return;

        Sprite[] frames = GetWalkFrames(lastDirection);
        if (frames == null || frames.Length == 0) return;

        walkAnimationTime += Time.deltaTime;
        float frameDuration = Mathf.Max(0.06f, walkFrameDuration);
        int frameIndex = Mathf.FloorToInt(walkAnimationTime / frameDuration) % frames.Length;
        if (frames[frameIndex] != null)
        {
            spriteRenderer.sprite = frames[frameIndex];
        }
    }

    private Sprite[] GetWalkFrames(Vector2 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            return direction.x < 0f ? runLeftFrames : runRightFrames;

        return direction.y < 0f ? runDownFrames : runUpFrames;
    }

    private void Attack()
    {
        if (isDead) return;

        isInputLocked = true;
        if (animator != null)
        {
            animator.enabled = true;
            animator.SetBool("IsMoving", false);
            // Lock the exact facing direction used by this attack before the
            // state is sampled. This keeps the hand-sword animation and the
            // flying slash from flipping when the key press is very short.
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
        }
        PlayerSwordAttack swordAttack = GetComponent<PlayerSwordAttack>();
        if (swordAttack != null)
            swordAttack.SetAttackDirection(lastDirection);
        if (animator != null)
        {
            animator.ResetTrigger("Attack");
            animator.speed = 1f;
            animator.Play(AttackStateHash, 0, 0f);
        }
        Sprite[] directionalAttackFrames = GetAttackFrames(lastDirection);

        if (directionalAttackFrames != null && directionalAttackFrames.Length > 0)
        {
            if (attackSpriteRoutine != null)
                StopCoroutine(attackSpriteRoutine);
            attackSpriteRoutine = StartCoroutine(PlayDirectionalAttackSprites(directionalAttackFrames));
        }
        StartCoroutine(UnlockInput(GameFlow.GetHeroAttackInterval()));
    }

    public void PlayAttackAnimation()
    {
        // PlayerSwordAttack owns the attack cooldown. Once it accepts an
        // attack, do not let the Hero's movement lock reject only the visual
        // animation on the same frame that the projectile is fired.
        if (isDead) return;
        Attack();
    }

    private Sprite[] GetAttackFrames(Vector2 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            return direction.x < 0f ? attackLeftFrames : attackRightFrames;

        return direction.y < 0f ? attackDownFrames : attackUpFrames;
    }

    private IEnumerator PlayDirectionalAttackSprites(Sprite[] frames)
    {
        // Space attacks use the same imported frame arrays in every direction.
        // The Animator attack clips can otherwise show a different timing or
        // pose sequence from the sprites being reviewed in the editor.
        if (animator != null)
            animator.enabled = false;

        float frameDuration = Mathf.Clamp(attackFrameDuration, 0.06f, 0.3f);
        for (int i = 0; i < frames.Length; i++)
        {
            if (isDead)
                break;

            if (spriteRenderer != null && frames[i] != null)
            {
                spriteRenderer.sprite = frames[i];
            }
            float timing = attackFrameTiming[Mathf.Min(i, attackFrameTiming.Length - 1)];
            yield return new WaitForSeconds(frameDuration * timing);
        }

        attackSpriteRoutine = null;
        if (!isDead && animator != null)
        {
            animator.enabled = true;
            animator.Rebind();
            // Rebind resets blend-tree parameters. Restore the direction
            // used for the attack before the first idle frame is evaluated,
            // otherwise an up/down attack can snap to another direction.
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
            animator.SetBool("IsMoving", false);
            animator.Update(0f);
        }
    }

    private IEnumerator UnlockInput(float duration)
    {
        yield return new WaitForSeconds(duration);
        if (!isDead) isInputLocked = false;
    }

    private void Die()
    {
        if (isDead) return;

        isDead = true;
        isPause = false;
        StopAllCoroutines();
        attackSpriteRoutine = null;
        heroKnockbackRoutine = null;
        CancelInvoke();

        PlayerSwordAttack swordAttack = GetComponent<PlayerSwordAttack>();
        if (swordAttack != null)
            swordAttack.StopForDeath();

        if (animator != null)
        {
            animator.enabled = true;
            animator.ResetTrigger("Attack");
            animator.ResetTrigger("Death");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.speed = 1f;
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
        }
    }

    private void UpdateDeathAnimation()
    {
        if (animator == null || deathAnimationFrozen) return;

        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.fullPathHash != DeathStateHash)
        {
            // An attack transition may already have been queued at the exact
            // frame the fatal collision happened. Always force death back in
            // front before checking the end of the clip.
            animator.ResetTrigger("Attack");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
            stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        }

        if (stateInfo.fullPathHash == DeathStateHash && stateInfo.normalizedTime >= 1f)
        {
            animator.speed = 0f;
            deathAnimationFrozen = true;
        }
    }

    private void Pause()
    {
        isPause = true;
        Invoke(nameof(Resume), 0.1f);
    }

    private void Resume()
    {
        if (!isDead) isPause = false;
    }

    private IEnumerator MoveToPosition(Vector3 target)
    {
        Vector3 start = transform.position;
        float time = 0f;
        const float duration = 0.1f;

        while (time < duration)
        {
            time += Time.deltaTime;
            Vector3 nextPosition = Vector3.Lerp(start, target, time / duration);
            if (body != null)
                body.MovePosition(nextPosition);
            else
                transform.position = nextPosition;
            yield return null;
        }
        if (body != null)
            body.MovePosition(target);
        else
            transform.position = target;
        heroKnockbackRoutine = null;
    }

    public void StopForResult()
    {
        isPause = true;
        isInputLocked = true;
        StopHeroKnockback();
        if (attackSpriteRoutine != null)
            StopCoroutine(attackSpriteRoutine);
        attackSpriteRoutine = null;
        CancelInvoke();

        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
        }

        if (!isDead && animator != null)
        {
            animator.enabled = true;
            animator.SetBool("IsMoving", false);
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TryHitByMonster(collision.gameObject);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        TryHitByMonster(collision.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Witch")) return;
        TryHitByMonster(other.gameObject);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Witch")) return;
        TryHitByMonster(other.gameObject);
    }

    private void TryHitByMonster(GameObject monsterObject)
    {
        if (isDead || !monsterObject.CompareTag("Monster")) return;

        Monster monster = monsterObject.GetComponent<Monster>();
        if (monster != null && monster.IsDead)
            return;

        if (monster != null)
        {
            monster.TakeHeroContactHit();
        }

        // Damage invulnerability must not suppress the hero's knockback.
        // Otherwise the monster can be knocked back while the hero keeps
        // being pushed through it during the damage cooldown.
        if (Time.time >= nextHeroKnockbackTime)
        {
            nextHeroKnockbackTime = Time.time + heroKnockbackInterval;
            Pause();
            StopHeroKnockback();
            heroKnockbackRoutine = StartCoroutine(MoveToPosition(
                transform.position + (transform.position - monsterObject.transform.position).normalized));
        }

        if (Time.time < nextHitTime) return;

        nextHitTime = Time.time + hitInvulnerabilityDuration;
        hitCount++;
        if (hitCount >= maxHits)
        {
            Die();
            return;
        }

    }

    private void StopHeroKnockback()
    {
        if (heroKnockbackRoutine == null) return;

        StopCoroutine(heroKnockbackRoutine);
        heroKnockbackRoutine = null;
    }

}
