using UnityEngine;

/// <summary>
/// A low-frequency material drop used to level a specific equipment category.
/// The piece is magnetized by the hero just like coins and experience orbs.
/// </summary>
public class EquipmentPiecePickup : MonoBehaviour
{
    [SerializeField] private float pickupDistance = 0.75f;
    [SerializeField] private float bobHeight = 0.08f;
    [SerializeField] private float bobSpeed = 4f;

    private EquipmentSystem.Slot slot;
    private int pieceValue = 1;
    private Transform hero;
    private Vector3 startPosition;
    private bool collected;
    private GameFlow gameFlow;

    public void Initialize(GameFlow owner, Transform heroTarget,
        EquipmentSystem.Slot pieceSlot, int value)
    {
        gameFlow = owner;
        hero = heroTarget;
        slot = pieceSlot;
        pieceValue = Mathf.Max(1, value);
        startPosition = transform.position;
    }

    private void Awake()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        if (collected) return;

        float bobOffset = Mathf.Sin(Time.time * bobSpeed + 2f) * bobHeight;
        transform.position = startPosition + Vector3.up * bobOffset;

        if (hero == null)
        {
            Hero heroComponent = FindAnyObjectByType<Hero>();
            if (heroComponent != null)
                hero = heroComponent.transform;
        }

        if (hero != null && !hero.gameObject.activeInHierarchy) return;
        if (hero != null && Vector2.Distance(transform.position, hero.position) <=
            pickupDistance)
            Collect();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Hero"))
            Collect();
    }

    private void Collect()
    {
        if (collected) return;

        collected = true;
        if (gameFlow == null)
            gameFlow = FindAnyObjectByType<GameFlow>();
        if (gameFlow != null)
            gameFlow.CollectEquipmentPieces(slot, pieceValue);

        Destroy(gameObject);
    }

    public void CollectImmediately()
    {
        Collect();
    }
}
