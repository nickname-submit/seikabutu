using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Monster : MonoBehaviour
{
    // Apply the pacing adjustment to catalog entries as well, so newly added
    // monster types automatically use the same readable battle tempo.
    // Keep a new game intentionally calm. Catalog values remain easy to tune
    // per monster, while this shared multiplier keeps every type slow enough
    // to read before the player invests in upgrades.
    private const float MovementPacingMultiplier = 0.38f;
    private const float ContactCadenceMultiplier = 2f;
    private const float KnockbackDistanceMultiplier = 0.5f;
    private const float MonsterHitSoundMix = 0.8f;

    [SerializeField] private int maxHealth = 3;
    [SerializeField] private float moveSpeed = 0.9f;
    [SerializeField] private int monsterTypeId;
    [SerializeField] private float heroKnockbackInterval = 0.35f;
    [SerializeField] private float heroContactDamageInterval = 0.35f;
    [SerializeField] private int heroContactDamage = 1;
    private bool defeatsWitchInOneHit;
    [SerializeField] private float attackAnimationDuration = 0.45f;
    [SerializeField] private float deathAnimationDuration = 0.5f;
    private float knockbackDistance = 1f;

    private int hp;
    private bool isPause;
    private bool isDead;
    private bool movementStopped;
    private bool isAttacking;
    private Transform target;
    private Collider2D targetCollider;
    private Rigidbody2D body;
    private Animator animator;
    private SpriteRenderer spriteRenderer;
    private BoxCollider2D hitbox;
    private Sprite syncedSprite;
    private Coroutine knockbackRoutine;
    private float nextHeroKnockbackTime;
    private float nextHeroContactDamageTime;
    private bool customAnimationEnabled;
    private Sprite[] customAnimationFrames;
    private int customAnimationColumns = 4;
    private int customAnimationRows = 4;
    private float customAnimationFrameRate = 10f;
    private int customAnimationRow;
    private float customAnimationClock;
    private bool flipXWhenMovingRight;
    private bool disableAnimator;
    private bool isElite;
    private Vector3 baseLocalScale = Vector3.one;

    private static readonly Dictionary<Texture2D, Sprite[]> CustomAnimationCache =
        new Dictionary<Texture2D, Sprite[]>();
    private static readonly Dictionary<Texture2D, Texture2D> CleanedAnimationSheetCache =
        new Dictionary<Texture2D, Texture2D>();
    private static readonly Dictionary<string, Sprite> ResourceSpriteCache =
        new Dictionary<string, Sprite>();

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetAnimationCaches()
    {
        CustomAnimationCache.Clear();
        CleanedAnimationSheetCache.Clear();
        ResourceSpriteCache.Clear();
    }

    private static readonly int IdleStateHash = Animator.StringToHash("Base Layer.Idle");
    private static readonly int WalkStateHash = Animator.StringToHash("Base Layer.Walk");
    private static readonly int AttackStateHash = Animator.StringToHash("Base Layer.Attack");
    private static readonly int DeathStateHash = Animator.StringToHash("Base Layer.Death");

    public int TypeId => monsterTypeId;
    public int Health => Mathf.Max(0, hp);
    public int MaxHealth => Mathf.Max(1, maxHealth);
    public bool IsDead => isDead;
    public float HealthRatio => (float)Health / MaxHealth;
    public int WitchContactDamage => defeatsWitchInOneHit
        ? GameFlow.GetWitchMaxHealth()
        : Mathf.Max(1, heroContactDamage);
    public Bounds VisualBounds => spriteRenderer != null
        ? spriteRenderer.bounds
        : new Bounds(transform.position, Vector3.one);

    public void ApplyDefinition(MonsterDefinition definition)
    {
        if (definition == null) return;

        maxHealth = Mathf.Max(1, definition.maxHealth);
        moveSpeed = Mathf.Max(0f, definition.moveSpeed * MovementPacingMultiplier);
        monsterTypeId = definition.monsterId;
        heroContactDamage = Mathf.Max(1, definition.heroContactDamage);
        defeatsWitchInOneHit = definition.defeatsWitchInOneHit;
        heroContactDamageInterval = Mathf.Max(0.01f,
            definition.heroContactDamageInterval * ContactCadenceMultiplier);
        heroKnockbackInterval = Mathf.Max(0.01f,
            definition.heroKnockbackInterval * ContactCadenceMultiplier);
        knockbackDistance = Mathf.Max(0f,
            definition.knockbackDistance * KnockbackDistanceMultiplier *
            GameFlow.GetMonsterKnockbackUpgradeMultiplier());
        attackAnimationDuration = Mathf.Max(0f, definition.attackAnimationDuration);
        deathAnimationDuration = Mathf.Max(0f, definition.deathAnimationDuration);
        customAnimationEnabled = definition.animationSheet != null;
        customAnimationColumns = Mathf.Max(1, definition.animationColumns);
        customAnimationRows = Mathf.Max(1, definition.animationRows);
        customAnimationFrameRate = Mathf.Max(1f, definition.animationFrameRate);
        flipXWhenMovingRight = definition.flipXWhenMovingRight;
        disableAnimator = definition.disableAnimator;
        isElite = definition.isElite;
        transform.localScale = baseLocalScale * Mathf.Max(0.1f, definition.visualScale);

        if (spriteRenderer == null)
            spriteRenderer = GetComponent<SpriteRenderer>();
        if (animator == null)
            animator = GetComponent<Animator>();

        Sprite definitionSprite = definition.idleSprite;
        if (definitionSprite == null && !string.IsNullOrEmpty(
            definition.idleSpriteResource))
        {
            definitionSprite = GetResourceSprite(definition.idleSpriteResource);
        }

        if (spriteRenderer != null)
        {
            if (definitionSprite != null)
                spriteRenderer.sprite = definitionSprite;
            spriteRenderer.color = definition.tint;
        }

        if (customAnimationEnabled)
        {
            customAnimationFrames = GetCustomAnimationFrames(
                definition.animationSheet, customAnimationColumns, customAnimationRows);
            if (animator != null)
                animator.enabled = false;
            SetCustomAnimationState(0, true);
        }
        else
        {
            customAnimationFrames = null;
            if (animator != null)
            {
                animator.enabled = !disableAnimator;
                if (!disableAnimator && definition.animatorController != null)
                    animator.runtimeAnimatorController = definition.animatorController;
            }
        }

        syncedSprite = null;
        SyncHitboxToSprite();
    }

    private static Sprite GetResourceSprite(string resourcePath)
    {
        if (ResourceSpriteCache.TryGetValue(resourcePath,
            out Sprite cachedSprite) && cachedSprite != null)
            return cachedSprite;

        Texture2D texture = Resources.Load<Texture2D>(resourcePath);
        if (texture == null)
            return null;

        Sprite sprite = Sprite.Create(texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f), 768f);
        sprite.name = resourcePath.Replace('/', '_') + "_Full";
        ResourceSpriteCache[resourcePath] = sprite;
        return sprite;
    }

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        hitbox = GetComponent<BoxCollider2D>();
        baseLocalScale = transform.localScale;
        if (body != null)
            body.constraints = RigidbodyConstraints2D.FreezeRotation;
        IgnoreOtherMonsterCollisions();
        SyncHitboxToSprite();
    }

    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        hitbox = GetComponent<BoxCollider2D>();
        IgnoreOtherMonsterCollisions();
        hp = maxHealth;
        GameObject witch = GameObject.FindGameObjectWithTag("Witch");
        if (witch != null)
        {
            target = witch.transform;
            targetCollider = witch.GetComponent<Collider2D>();
        }
        if (customAnimationEnabled)
            SetCustomAnimationState(0, true);
        else
            PlayState(IdleStateHash);
        SyncHitboxToSprite();
    }

    private void IgnoreOtherMonsterCollisions()
    {
        if (hitbox == null) return;

        Monster[] otherMonsters = FindObjectsByType<Monster>(FindObjectsInactive.Include);
        for (int i = 0; i < otherMonsters.Length; i++)
        {
            Monster other = otherMonsters[i];
            if (other == null || other == this) continue;

            BoxCollider2D otherHitbox = other.GetComponent<BoxCollider2D>();
            if (otherHitbox != null)
                Physics2D.IgnoreCollision(hitbox, otherHitbox, true);
        }
    }

    private void Update()
    {
        if (GameFlow.IsBattleGameplayFrozen)
            return;

        if (!customAnimationEnabled || customAnimationFrames == null ||
            customAnimationFrames.Length == 0 || spriteRenderer == null ||
            (isDead && customAnimationRow != 3))
            return;

        customAnimationClock += Time.deltaTime * customAnimationFrameRate;
        int frame = Mathf.FloorToInt(customAnimationClock);
        if (customAnimationRow == 3)
            frame = Mathf.Min(frame, customAnimationColumns - 1);
        else
            frame %= customAnimationColumns;

        int frameIndex = customAnimationRow * customAnimationColumns + frame;
        if (frameIndex < 0 || frameIndex >= customAnimationFrames.Length)
            return;

        Sprite nextSprite = customAnimationFrames[frameIndex];
        if (nextSprite != null && spriteRenderer.sprite != nextSprite)
            spriteRenderer.sprite = nextSprite;
    }

    private void LateUpdate()
    {
        SyncHitboxToSprite();
    }

    private void SyncHitboxToSprite()
    {
        if (spriteRenderer == null || hitbox == null || spriteRenderer.sprite == null)
            return;

        Sprite currentSprite = spriteRenderer.sprite;
        if (currentSprite == syncedSprite)
            return;

        Bounds spriteBounds = currentSprite.bounds;
        hitbox.size = spriteBounds.size;
        hitbox.offset = spriteBounds.center;
        syncedSprite = currentSprite;
    }

    private void FixedUpdate()
    {
        if (GameFlow.IsBattleGameplayFrozen)
        {
            if (body != null)
                body.linearVelocity = Vector2.zero;
            return;
        }

        if (isDead || movementStopped) return;

        if (isPause || target == null)
        {
            PlayMovementAnimation(false);
            return;
        }

        SyncHitboxToSprite();

        Collider2D witchCollider = targetCollider != null
            ? targetCollider
            : target.GetComponent<Collider2D>();
        Vector2 currentCenter = hitbox != null ? hitbox.bounds.center : transform.position;
        Vector2 targetCenter = witchCollider != null ? witchCollider.bounds.center : target.position;
        Vector2 offset = targetCenter - currentCenter;
        bool touchingWitch = hitbox != null && witchCollider != null && hitbox.IsTouching(witchCollider);
        bool moving = !touchingWitch && offset.sqrMagnitude > 0.0001f;

        if (moving)
            UpdateFacing(offset);
        PlayMovementAnimation(moving);
        if (!moving) return;

        Vector2 bodyPosition = body != null ? body.position : (Vector2)transform.position;
        Vector2 nextPosition = bodyPosition + offset.normalized * moveSpeed * Time.fixedDeltaTime;
        if (body != null)
            body.MovePosition(nextPosition);
        else
            transform.position = nextPosition;
    }

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
        targetCollider = newTarget != null ? newTarget.GetComponent<Collider2D>() : null;
        movementStopped = false;
        body = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        hitbox = GetComponent<BoxCollider2D>();
        if (body != null)
        {
            body.simulated = true;
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
        }

        hp = maxHealth;
        isDead = false;
        isAttacking = false;
        isPause = false;
        nextHeroKnockbackTime = 0f;
        nextHeroContactDamageTime = 0f;
        CancelInvoke();
        if (animator != null && !customAnimationEnabled && !disableAnimator)
        {
            animator.enabled = true;
            PlayState(IdleStateHash);
        }
        else if (animator != null && disableAnimator)
        {
            animator.enabled = false;
        }
        if (customAnimationEnabled)
            SetCustomAnimationState(0, true);
        syncedSprite = null;
        SyncHitboxToSprite();
    }

    private void Pause()
    {
        isPause = true;
        CancelInvoke(nameof(Resume));
        Invoke(nameof(Resume), 0.3f);
    }

    private void Resume()
    {
        if (!isDead) isPause = false;
    }

    private IEnumerator MoveToPosition(Vector3 targetPosition)
    {
        Vector2 start = body != null ? body.position : (Vector2)transform.position;
        Vector2 targetPosition2D = targetPosition;
        UpdateFacing(targetPosition2D - start);
        float time = 0f;
        const float duration = 0.4f;

        while (time < duration && !isDead && !movementStopped)
        {
            time += Time.deltaTime;
            Vector2 nextPosition = Vector2.Lerp(start, targetPosition2D, time / duration);
            if (body != null)
                body.MovePosition(nextPosition);
            else
                transform.position = nextPosition;
            yield return null;
        }

        if (!isDead && !movementStopped)
        {
            if (body != null)
                body.position = targetPosition2D;
            else
                transform.position = targetPosition;
        }

        knockbackRoutine = null;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (movementStopped) return;
        if (collision.gameObject.CompareTag("Witch"))
            PlayAttackAnimation();
        TryKnockbackFromHero(collision.gameObject);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (movementStopped) return;
        if (collision.gameObject.CompareTag("Witch"))
            PlayAttackAnimation();
        TryKnockbackFromHero(collision.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (movementStopped) return;
        TryKnockbackFromHero(other.gameObject);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (movementStopped) return;
        TryKnockbackFromHero(other.gameObject);
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Hero"))
            nextHeroKnockbackTime = 0f;
    }

    private void TryKnockbackFromHero(GameObject heroObject)
    {
        if (isDead || movementStopped || !heroObject.CompareTag("Hero") || Time.time < nextHeroKnockbackTime)
            return;

        nextHeroKnockbackTime = Time.time + heroKnockbackInterval;
        StartKnockback((transform.position - heroObject.transform.position).normalized);
    }

    public void TakeSwordHit(Vector2 attackDirection, int damage)
    {
        if (isDead) return;

        hp -= Mathf.Max(1, damage);
        PlayHitSound();

        if (hp <= 0)
        {
            Die();
            return;
        }

        StopKnockback();
        StartKnockback(attackDirection.normalized);
    }

    public void TakeWitchSkillHit(int damage)
    {
        if (isDead || movementStopped)
            return;

        hp -= Mathf.Max(1, damage);
        PlayHitSound();

        if (hp <= 0)
            Die();
    }

    public void TakePetHit(int damage)
    {
        if (isDead || movementStopped)
            return;

        hp -= Mathf.Max(1, damage);
        PlayHitSound();

        if (hp <= 0)
            Die();
    }

    public void TakeHeroContactHit()
    {
        if (isDead || Time.time < nextHeroContactDamageTime)
            return;

        nextHeroContactDamageTime = Time.time + heroContactDamageInterval;
        hp -= Mathf.Max(1, heroContactDamage);
        if (hp <= 0)
            Die();
    }

    private void PlayHitSound()
    {
        AudioSource audioSource = GetComponent<AudioSource>();
        if (audioSource == null) return;

        // Monster prefabs previously kept this at 0.8, bypassing the title
        // volume control and making every contact/hit noticeably louder than
        // the rest of the game. Keep the hit cue deliberately quiet.
        audioSource.volume = GameFlow.GetWorldSfxVolume(MonsterHitSoundMix);
        audioSource.Play();
    }

    private void StartKnockback(Vector3 direction)
    {
        if (isDead || movementStopped) return;

        UpdateFacing(direction);
        StopKnockback();
        Pause();
        if (body != null)
            body.linearVelocity = Vector2.zero;
        knockbackRoutine = StartCoroutine(MoveToPosition(transform.position + direction * knockbackDistance));
    }

    private void UpdateFacing(Vector2 movement)
    {
        if (!flipXWhenMovingRight || spriteRenderer == null ||
            Mathf.Abs(movement.x) <= 0.001f)
            return;

        // Snake_Sheet is authored facing left. Keep that as the default and
        // mirror only when the actual movement goes to the right. This is
        // called for both pursuit and knockback, so the facing never lags
        // behind when a hit sends the monster in the opposite direction.
        spriteRenderer.flipX = movement.x > 0f;
    }

    private void StopKnockback()
    {
        if (knockbackRoutine == null) return;
        StopCoroutine(knockbackRoutine);
        knockbackRoutine = null;
    }

    public void StopMovement()
    {
        movementStopped = true;
        isPause = true;
        target = null;
        nextHeroKnockbackTime = 0f;
        CancelInvoke();
        StopAllCoroutines();
        knockbackRoutine = null;

        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
            body.simulated = false;
        }

        Collider2D[] colliders = GetComponents<Collider2D>();
        for (int i = 0; i < colliders.Length; i++)
            colliders[i].enabled = false;

        if (animator != null)
            animator.enabled = false;
    }

    private void PlayMovementAnimation(bool moving)
    {
        if (isDead || isAttacking) return;
        if (customAnimationEnabled)
        {
            SetCustomAnimationState(moving ? 1 : 0);
            return;
        }
        if (animator == null) return;
        PlayState(moving ? WalkStateHash : IdleStateHash);
    }

    private void PlayAttackAnimation()
    {
        if (isDead || movementStopped || isAttacking) return;
        if (!customAnimationEnabled && animator == null) return;

        isAttacking = true;
        if (customAnimationEnabled)
            SetCustomAnimationState(2, true);
        else
        {
            PlayState(AttackStateHash);
        }
        CancelInvoke(nameof(FinishAttackAnimation));
        Invoke(nameof(FinishAttackAnimation), attackAnimationDuration);
    }

    private void FinishAttackAnimation()
    {
        isAttacking = false;
        PlayMovementAnimation(false);
    }

    private void PlayState(int stateHash)
    {
        if (animator == null || !animator.isActiveAndEnabled) return;

        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.fullPathHash != stateHash)
            animator.Play(stateHash, 0, 0f);
    }

    private void Die()
    {
        if (isDead) return;

        isDead = true;
        isPause = true;
        target = null;
        isAttacking = false;
        CancelInvoke();
        StopKnockback();

        Collider2D[] colliders = GetComponents<Collider2D>();
        for (int i = 0; i < colliders.Length; i++)
            colliders[i].enabled = false;

        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
            body.simulated = false;
        }

        if (customAnimationEnabled)
            SetCustomAnimationState(3, true);
        else if (animator != null)
        {
            animator.enabled = true;
            animator.Play(DeathStateHash, 0, 0f);
        }

        GameFlow gameFlow = FindAnyObjectByType<GameFlow>();
        if (gameFlow != null)
        {
            gameFlow.SpawnExperienceOrb(transform.position);
            gameFlow.SpawnCoin(transform.position, isElite || monsterTypeId == 5);
            gameFlow.SpawnEquipmentPiece(transform.position,
                isElite || monsterTypeId == 5);
            if (monsterTypeId == 5)
                gameFlow.SpawnGachaTicket(transform.position);
        }

        Destroy(gameObject, deathAnimationDuration);
    }

    private void SetCustomAnimationState(int row, bool reset = false)
    {
        if (!customAnimationEnabled || customAnimationFrames == null ||
            customAnimationFrames.Length == 0 || spriteRenderer == null)
            return;

        int clampedRow = Mathf.Clamp(row, 0, customAnimationRows - 1);
        if (reset || customAnimationRow != clampedRow)
        {
            customAnimationRow = clampedRow;
            customAnimationClock = 0f;
        }

        int frameIndex = customAnimationRow * customAnimationColumns;
        if (frameIndex >= 0 && frameIndex < customAnimationFrames.Length)
            spriteRenderer.sprite = customAnimationFrames[frameIndex];
    }

    private static Sprite[] GetCustomAnimationFrames(Texture2D sheet, int columns, int rows)
    {
        // Snake cleanup is data-dependent. Do not reuse a sprite array made
        // before the cleanup rule changed while the editor stays open.
        bool isSnakeSheet = sheet.name.Contains("Snake");
        if (isSnakeSheet)
        {
            CustomAnimationCache.Remove(sheet);
            CleanedAnimationSheetCache.Remove(sheet);
        }

        Sprite[] cachedFrames;
        if (CustomAnimationCache.TryGetValue(sheet, out cachedFrames))
            return cachedFrames;

        Texture2D sourceSheet = isSnakeSheet
            ? GetCleanedSnakeSheet(sheet, columns, rows)
            : sheet;
        int cellWidth = Mathf.Max(1, sheet.width / columns);
        int cellHeight = Mathf.Max(1, sheet.height / rows);
        Sprite[] frames = new Sprite[columns * rows];
        for (int row = 0; row < rows; row++)
        {
            for (int column = 0; column < columns; column++)
            {
                int index = row * columns + column;
                Rect rect = new Rect(
                    column * cellWidth,
                    sheet.height - (row + 1) * cellHeight,
                    cellWidth,
                    cellHeight);
                frames[index] = Sprite.Create(sourceSheet, rect, new Vector2(0.5f, 0.5f), 100f);
                frames[index].name = sheet.name + "_Frame_" + index;
            }
        }

        CustomAnimationCache.Add(sheet, frames);
        return frames;
    }

    private static Texture2D GetCleanedSnakeSheet(Texture2D source, int columns, int rows)
    {
        Texture2D cachedSheet;
        if (CleanedAnimationSheetCache.TryGetValue(source, out cachedSheet))
            return cachedSheet;

        Color32[] pixels = source.GetPixels32();
        Color32[] cleanedPixels = (Color32[])pixels.Clone();
        int cellWidth = Mathf.Max(1, source.width / columns);
        int cellHeight = Mathf.Max(1, source.height / rows);

        for (int cellY = 0; cellY < rows; cellY++)
        {
            for (int cellX = 0; cellX < columns; cellX++)
            {
                bool[] visited = new bool[cellWidth * cellHeight];
                for (int localY = 0; localY < cellHeight; localY++)
                {
                    for (int localX = 0; localX < cellWidth; localX++)
                    {
                        int localIndex = localY * cellWidth + localX;
                        int globalX = cellX * cellWidth + localX;
                        int globalY = cellY * cellHeight + localY;
                        int globalIndex = globalY * source.width + globalX;

                        // GetPixels32 uses a bottom-left origin. The attack
                        // row is the third row from the bottom in the source
                        // sheet (cellY == 2), and its top two pixels contain
                        // a disconnected shadow strip above the snake.
                        if (cellY == 2 && localY >= cellHeight - 2)
                        {
                            cleanedPixels[globalIndex].a = 0;
                            visited[localIndex] = true;
                            continue;
                        }

                        if (visited[localIndex] || pixels[globalIndex].a <= 16)
                        {
                            if (pixels[globalIndex].a <= 16)
                                cleanedPixels[globalIndex].a = 0;
                            continue;
                        }

                        List<int> component = new List<int>();
                        Stack<Vector2Int> pending = new Stack<Vector2Int>();
                        pending.Push(new Vector2Int(localX, localY));
                        visited[localIndex] = true;

                        while (pending.Count > 0)
                        {
                            Vector2Int point = pending.Pop();
                            int pointIndex = point.y * cellWidth + point.x;
                            component.Add(pointIndex);

                            for (int offsetY = -1; offsetY <= 1; offsetY++)
                            {
                                for (int offsetX = -1; offsetX <= 1; offsetX++)
                                {
                                    if (offsetX == 0 && offsetY == 0)
                                        continue;

                                    int nextX = point.x + offsetX;
                                    int nextY = point.y + offsetY;
                                    if (nextX < 0 || nextX >= cellWidth ||
                                        nextY < 0 || nextY >= cellHeight)
                                        continue;

                                    int nextIndex = nextY * cellWidth + nextX;
                                    if (visited[nextIndex]) continue;

                                    int nextGlobalIndex =
                                        (cellY * cellHeight + nextY) * source.width +
                                        cellX * cellWidth + nextX;
                                    if (pixels[nextGlobalIndex].a <= 16) continue;

                                    visited[nextIndex] = true;
                                    pending.Push(new Vector2Int(nextX, nextY));
                                }
                            }
                        }

                        int componentMinY = cellHeight;
                        int componentMaxY = -1;
                        for (int i = 0; i < component.Count; i++)
                        {
                            int pointIndex = component[i];
                            int pointY = pointIndex / cellWidth;
                            componentMinY = Mathf.Min(componentMinY, pointY);
                            componentMaxY = Mathf.Max(componentMaxY, pointY);
                        }

                        // The sheet contains a thin, disconnected strip above
                        // several snake frames. It is an image artifact, not
                        // part of the snake, so remove it even though it is
                        // wider than the small-pixel cleanup threshold.
                        bool isFloatingTopArtifact = componentMinY <= 3 &&
                            componentMaxY <= 3 && component.Count <= 96;
                        if (component.Count <= 6 || isFloatingTopArtifact)
                        {
                            for (int i = 0; i < component.Count; i++)
                            {
                                int pointIndex = component[i];
                                int pointX = pointIndex % cellWidth;
                                int pointY = pointIndex / cellWidth;
                                int globalIndexToClear =
                                    (cellY * cellHeight + pointY) * source.width +
                                    cellX * cellWidth + pointX;
                                cleanedPixels[globalIndexToClear].a = 0;
                            }
                        }
                    }
                }
            }
        }

        Texture2D cleanedSheet = new Texture2D(
            source.width, source.height, TextureFormat.RGBA32, false, false);
        cleanedSheet.name = source.name + "_Cleaned";
        cleanedSheet.filterMode = source.filterMode;
        cleanedSheet.wrapMode = source.wrapMode;
        cleanedSheet.hideFlags = HideFlags.HideAndDontSave;
        cleanedSheet.SetPixels32(cleanedPixels);
        cleanedSheet.Apply(false, true);
        CleanedAnimationSheetCache.Add(source, cleanedSheet);
        return cleanedSheet;
    }
}
