using UnityEngine;

/// <summary>
/// Lightweight homing attack fired by an equipped pet. It uses direct
/// movement instead of a physics body so it cannot push the hero or monsters.
/// </summary>
public class PetProjectile : MonoBehaviour
{
    private Monster target;
    private int damage;
    private float speed;
    private float impactDistance;

    public void Initialize(Monster newTarget, int newDamage, float newSpeed)
    {
        target = newTarget;
        damage = Mathf.Max(1, newDamage);
        speed = Mathf.Max(0.1f, newSpeed);
        impactDistance = 0.18f;
        Destroy(gameObject, 3f);
    }

    private void Update()
    {
        if (target == null || target.IsDead)
        {
            Destroy(gameObject);
            return;
        }

        Vector3 toTarget = target.transform.position - transform.position;
        if (toTarget.sqrMagnitude <= impactDistance * impactDistance)
        {
            target.TakePetHit(damage);
            Destroy(gameObject);
            return;
        }

        transform.position += toTarget.normalized * speed * Time.deltaTime;
    }
}
