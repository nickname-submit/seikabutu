using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Persistent equipment definitions used by the front-end equipment page and
/// by the battle stat calculations. Ownership is stored separately from the
/// equipped item so a future gacha can unlock items without changing the
/// equipment screen.
/// </summary>
public static class EquipmentSystem
{
    public enum Rarity
    {
        Common,
        Rare,
        Epic,
        Legendary
    }

    public enum Slot
    {
        Weapon,
        Armor,
        Boots,
        Pet
    }

    public struct Item
    {
        public int id;
        public string name;
        public string description;
        public string effect;
        public int iconCell;
        public Color accent;
        public Rarity rarity;
        public int statValue;
        public string iconResource;

        public Item(int id, string name, string description, string effect,
            int iconCell, Color accent, Rarity rarity, int statValue,
            string iconResource = "")
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.effect = effect;
            this.iconCell = iconCell;
            this.accent = accent;
            this.rarity = rarity;
            this.statValue = statValue;
            this.iconResource = iconResource;
        }
    }

    private const string WeaponKey = "WitchHero.EquippedWeapon";
    private const string ArmorKey = "WitchHero.EquippedArmor";
    private const string BootsKey = "WitchHero.EquippedBoots";
    private const string PetKey = "WitchHero.EquippedPet";
    private const string OwnedWeaponKey = "WitchHero.OwnedWeapon";
    private const string OwnedArmorKey = "WitchHero.OwnedArmor";
    private const string OwnedBootsKey = "WitchHero.OwnedBoots";
    private const string OwnedPetKey = "WitchHero.OwnedPet";
    private const string EquipmentLevelPrefix = "WitchHero.EquipmentLevel.";
    private const string PiecePrefix = "WitchHero.EquipmentPiece.";
    private const int TicketWeaponFirstId = 4;
    private const int TicketWeaponLastId = 6;
    public const int MaxItemLevel = 5;

    private static bool ownershipDefaultsChecked;

    // The iron sword is the safe default weapon so a fresh save behaves like
    // the existing game. All other slots start empty.
    private static readonly Item[] Weapons =
    {
        new Item(0, "蒼星の鉄剣", "森の鍛冶屋で打たれた扱いやすい剣。",
            "斬撃攻撃力 +0", 0, new Color(0.25f, 0.78f, 1f),
            Rarity.Common, 0),
        new Item(1, "月影クナイ", "月明かりをまとった二振りの投刃。",
            "斬撃攻撃力 +1", 1, new Color(0.72f, 0.45f, 1f),
            Rarity.Rare, 1),
        new Item(2, "紅蓮の双刃", "火花を散らす、燃え盛る二本の刃。",
            "斬撃攻撃力 +2", 1, new Color(1f, 0.32f, 0.2f),
            Rarity.Epic, 2),
        new Item(3, "星喰らいの大剣", "夜空の欠片を鍛えた重厚な大剣。",
            "斬撃攻撃力 +3", 0, new Color(1f, 0.78f, 0.22f),
            Rarity.Legendary, 3),
        new Item(4, "蒼雷の長槍", "チケットガチャから出る、雷を帯びた長槍。",
            "斬撃攻撃力 +2", 0, new Color(0.28f, 0.75f, 1f),
            Rarity.Rare, 2, "Equipment/TicketWeapon_Spear"),
        new Item(5, "月蝕の大鎌", "月蝕の光を刃に宿した、静かな大鎌。",
            "斬撃攻撃力 +4", 0, new Color(0.65f, 0.46f, 1f),
            Rarity.Epic, 4, "Equipment/TicketWeapon_Scythe"),
        new Item(6, "紅蓮輪廻", "チケットガチャの最奥に眠る、灼熱の双刃輪。",
            "斬撃攻撃力 +25", 0, new Color(1f, 0.25f, 0.2f),
            Rarity.Legendary, 25, "Equipment/TicketWeapon_Chakram")
    };

    private static readonly Item[] Armors =
    {
        new Item(0, "森守りの外套", "葉と羽根を重ねた、魔女の森の旅装。",
            "ヒーローHP +2", 2, new Color(0.28f, 0.85f, 0.55f),
            Rarity.Rare, 2),
        new Item(1, "月紋のローブ", "月の紋章が刻まれた、魔力を宿すローブ。",
            "ヒーローHP +4", 2, new Color(0.42f, 0.54f, 1f),
            Rarity.Epic, 4),
        new Item(2, "星守の大外套", "星明かりを織り込んだ伝説の旅装。",
            "ヒーローHP +7", 2, new Color(1f, 0.78f, 0.22f),
            Rarity.Legendary, 7)
    };

    private static readonly Item[] Boots =
    {
        new Item(0, "革の旅靴", "ぬかるんだ森でも歩きやすい丈夫な靴。",
            "移動速度 +0.4", 3, new Color(0.95f, 0.62f, 0.26f),
            Rarity.Common, 0),
        new Item(1, "風渡りのブーツ", "風の精が祝福した軽やかなブーツ。",
            "移動速度 +0.7", 3, new Color(0.32f, 0.7f, 1f),
            Rarity.Rare, 1),
        new Item(2, "流星の足甲", "流星の尾を受け継ぐ、きらめく足甲。",
            "移動速度 +1.0", 3, new Color(0.78f, 0.42f, 1f),
            Rarity.Epic, 2)
    };

    private static readonly Item[] Pets =
    {
        new Item(0, "熾火のキツネ", "小さな火の尾で敵を追い払う森の友だち。",
            "1.8秒ごとに1ダメージ", 4, new Color(1f, 0.42f, 0.14f),
            Rarity.Rare, 1),
        new Item(1, "宵闇のカラス", "紫の瞳で敵を見つける静かな相棒。",
            "2.4秒ごとに2ダメージ", 5, new Color(0.64f, 0.4f, 1f),
            Rarity.Epic, 2),
        new Item(2, "星屑のグリフォン", "星屑の羽根で敵を追う、古代の相棒。",
            "2.8秒ごとに3ダメージ", 4, new Color(1f, 0.78f, 0.22f),
            Rarity.Legendary, 3)
    };

    public static int GetEquipped(Slot slot)
    {
        return Mathf.Max(-1, PlayerPrefs.GetInt(GetKey(slot),
            slot == Slot.Weapon ? 0 : -1));
    }

    public static bool IsEquipped(Slot slot, int itemId)
    {
        return GetEquipped(slot) == itemId;
    }

    public static void Equip(Slot slot, int itemId)
    {
        if (!IsOwned(slot, itemId)) return;
        PlayerPrefs.SetInt(GetKey(slot), itemId);
        PlayerPrefs.Save();
    }

    public static void Unequip(Slot slot)
    {
        PlayerPrefs.SetInt(GetKey(slot), -1);
        PlayerPrefs.Save();
    }

    public static void Reset()
    {
        PlayerPrefs.DeleteKey(WeaponKey);
        PlayerPrefs.DeleteKey(ArmorKey);
        PlayerPrefs.DeleteKey(BootsKey);
        PlayerPrefs.DeleteKey(PetKey);
        PlayerPrefs.DeleteKey(OwnedWeaponKey);
        PlayerPrefs.DeleteKey(OwnedArmorKey);
        PlayerPrefs.DeleteKey(OwnedBootsKey);
        PlayerPrefs.DeleteKey(OwnedPetKey);
        Slot[] resetSlots = { Slot.Weapon, Slot.Armor, Slot.Boots, Slot.Pet };
        for (int i = 0; i < resetSlots.Length; i++)
        {
            PlayerPrefs.DeleteKey(GetPieceKey(resetSlots[i]));
            Item[] items = GetItems(resetSlots[i]);
            for (int item = 0; item < items.Length; item++)
                PlayerPrefs.DeleteKey(GetLevelKey(resetSlots[i], items[item].id));
        }
        ownershipDefaultsChecked = false;
        PlayerPrefs.Save();
    }

    public static Item[] GetItems(Slot slot)
    {
        switch (slot)
        {
            case Slot.Weapon: return Weapons;
            case Slot.Armor: return Armors;
            case Slot.Boots: return Boots;
            case Slot.Pet: return Pets;
            default: return Array.Empty<Item>();
        }
    }

    public static Item GetItem(Slot slot, int itemId)
    {
        Item[] items = GetItems(slot);
        for (int i = 0; i < items.Length; i++)
        {
            if (items[i].id == itemId)
                return items[i];
        }

        return new Item(-999, "", "", "", -1, Color.white,
            Rarity.Common, 0);
    }

    public static bool IsTicketOnly(Slot slot, int itemId)
    {
        return slot == Slot.Weapon && itemId >= TicketWeaponFirstId &&
            itemId <= TicketWeaponLastId;
    }

    public static Item[] GetTicketGachaItems()
    {
        Item[] ticketItems = new Item[TicketWeaponLastId - TicketWeaponFirstId + 1];
        for (int i = 0; i < ticketItems.Length; i++)
            ticketItems[i] = GetItem(Slot.Weapon, TicketWeaponFirstId + i);
        return ticketItems;
    }

    /// <summary>
    /// Returns only items the player owns. The existing test equipment is
    /// migrated as owned the first time this is used, so the current save does
    /// not unexpectedly lose items. A gacha can call Unlock when it grants a
    /// new item.
    /// </summary>
    public static Item[] GetOwnedItems(Slot slot)
    {
        EnsureOwnershipDefaults();
        Item[] items = GetItems(slot);
        List<Item> owned = new List<Item>(items.Length);
        for (int i = 0; i < items.Length; i++)
        {
            if (IsOwnedWithoutInitialization(slot, items[i].id))
                owned.Add(items[i]);
        }

        return owned.ToArray();
    }

    public static bool IsOwned(Slot slot, int itemId)
    {
        EnsureOwnershipDefaults();
        return IsOwnedWithoutInitialization(slot, itemId);
    }

    /// <summary>Grants an item from a future gacha or reward.</summary>
    public static void Unlock(Slot slot, int itemId)
    {
        if (GetItem(slot, itemId).id != itemId) return;
        EnsureOwnershipDefaults();
        int mask = PlayerPrefs.GetInt(GetOwnedKey(slot), 0);
        PlayerPrefs.SetInt(GetOwnedKey(slot), mask | (1 << itemId));
        PlayerPrefs.Save();
    }

    public static void SetOwned(Slot slot, int itemId, bool owned)
    {
        if (GetItem(slot, itemId).id != itemId) return;
        EnsureOwnershipDefaults();
        int mask = PlayerPrefs.GetInt(GetOwnedKey(slot), 0);
        int bit = 1 << itemId;
        mask = owned ? mask | bit : mask & ~bit;
        PlayerPrefs.SetInt(GetOwnedKey(slot), mask);
        PlayerPrefs.Save();
    }

    public static int GetWeaponDamageBonus()
    {
        int equippedId = GetEquipped(Slot.Weapon);
        return equippedId >= 0 ? GetItem(Slot.Weapon, equippedId).statValue +
            Mathf.Max(0, GetItemLevel(Slot.Weapon, equippedId) - 1) : 0;
    }

    public static int GetHeroHealthBonus()
    {
        int equippedId = GetEquipped(Slot.Armor);
        return equippedId >= 0 ? GetItem(Slot.Armor, equippedId).statValue +
            Mathf.Max(0, GetItemLevel(Slot.Armor, equippedId) - 1) : 0;
    }

    public static float GetHeroSpeedBonus()
    {
        int equippedId = GetEquipped(Slot.Boots);
        if (equippedId < 0) return 0f;

        float baseBonus;
        switch (equippedId)
        {
            case 0: baseBonus = 0.4f; break;
            case 1: baseBonus = 0.7f; break;
            case 2: baseBonus = 1.0f; break;
            default: baseBonus = 0f; break;
        }

        return baseBonus + Mathf.Max(0, GetItemLevel(Slot.Boots, equippedId) - 1) * 0.1f;
    }

    public static int GetPetDamage()
    {
        int equippedId = GetEquipped(Slot.Pet);
        return equippedId >= 0 ? GetItem(Slot.Pet, equippedId).statValue +
            Mathf.Max(0, GetItemLevel(Slot.Pet, equippedId) - 1) : 0;
    }

    public static bool IsKunaiEquipped()
    {
        // Weapon id 1 is the Moonshadow Kunai. Keep the check centralized so
        // battle attack code does not depend on equipment screen text.
        return GetEquipped(Slot.Weapon) == 1;
    }

    public static Rarity GetEquippedWeaponRarity()
    {
        return GetItem(Slot.Weapon, GetEquipped(Slot.Weapon)).rarity;
    }

    public static int GetWeaponSkillAttackRequirement()
    {
        // Do not make the charge rhythm depend on the individual weapon.
        // Rarity changes the skill's spectacle and coverage, while every
        // non-common weapon shares the same readable four-hit rhythm.
        return GetEquippedWeaponRarity() == Rarity.Common ? 0 : 4;
    }

    public static bool HasWeaponSkill()
    {
        return GetWeaponSkillAttackRequirement() > 0;
    }

    public static string GetWeaponSkillName()
    {
        switch (GetEquipped(Slot.Weapon))
        {
            case 1: return "月影連刃";
            case 2: return "紅蓮輪舞";
            case 3: return "星喰いの一閃";
            case 4: return "蒼雷連槍";
            case 5: return "月蝕輪舞";
            case 6: return "紅蓮輪廻";
            default: return "強打";
        }
    }

    public static float GetPetAttackInterval()
    {
        int equippedId = GetEquipped(Slot.Pet);
        if (equippedId < 0) return 2.8f;

        float baseInterval = equippedId == 1 ? 2.4f :
            equippedId == 2 ? 2.8f : 1.8f;
        return Mathf.Max(0.7f, baseInterval -
            Mathf.Max(0, GetItemLevel(Slot.Pet, equippedId) - 1) * 0.1f);
    }

    public static int GetItemLevel(Slot slot, int itemId)
    {
        if (!IsOwned(slot, itemId)) return 0;
        return Mathf.Clamp(PlayerPrefs.GetInt(GetLevelKey(slot, itemId), 1),
            1, MaxItemLevel);
    }

    public static int GetPieceCount(Slot slot)
    {
        EnsureOwnershipDefaults();
        return Mathf.Max(0, PlayerPrefs.GetInt(GetPieceKey(slot), 0));
    }

    public static void AddPieces(Slot slot, int amount)
    {
        if (amount <= 0) return;
        EnsureOwnershipDefaults();
        PlayerPrefs.SetInt(GetPieceKey(slot), GetPieceCount(slot) + amount);
        PlayerPrefs.Save();
    }

    public static int GetUpgradePieceCost(Slot slot, int itemId)
    {
        int level = GetItemLevel(slot, itemId);
        if (level <= 0 || level >= MaxItemLevel) return 0;
        return 2 + (level - 1) * 3;
    }

    public static bool TryUpgrade(Slot slot, int itemId)
    {
        int currentLevel = GetItemLevel(slot, itemId);
        int cost = GetUpgradePieceCost(slot, itemId);
        if (currentLevel <= 0 || cost <= 0 || GetPieceCount(slot) < cost)
            return false;

        PlayerPrefs.SetInt(GetPieceKey(slot), GetPieceCount(slot) - cost);
        PlayerPrefs.SetInt(GetLevelKey(slot, itemId), currentLevel + 1);
        PlayerPrefs.Save();
        return true;
    }

    public static string GetPieceName(Slot slot)
    {
        switch (slot)
        {
            case Slot.Weapon: return "武器ピース";
            case Slot.Armor: return "服ピース";
            case Slot.Boots: return "靴ピース";
            case Slot.Pet: return "ペットピース";
            default: return "装備ピース";
        }
    }

    public static string GetItemEffectText(Slot slot, int itemId)
    {
        Item item = GetItem(slot, itemId);
        int level = GetItemLevel(slot, itemId);
        if (level <= 0) return item.effect;

        int levelBonus = Mathf.Max(0, level - 1);
        switch (slot)
        {
            case Slot.Weapon:
                return $"斬撃攻撃力 +{item.statValue + levelBonus}";
            case Slot.Armor:
                return $"ヒーローHP +{item.statValue + levelBonus}";
            case Slot.Boots:
                float baseSpeed = itemId == 0 ? 0.4f : itemId == 1 ? 0.7f : 1.0f;
                return $"移動速度 +{(baseSpeed + levelBonus * 0.1f):0.0}";
            case Slot.Pet:
                float baseInterval = itemId == 1 ? 2.4f : itemId == 2 ? 2.8f : 1.8f;
                float interval = Mathf.Max(0.7f,
                    baseInterval - levelBonus * 0.1f);
                return $"{interval:0.0}秒ごとに{item.statValue + levelBonus}ダメージ";
            default:
                return item.effect;
        }
    }

    public static string GetSlotName(Slot slot)
    {
        switch (slot)
        {
            case Slot.Weapon: return "武器";
            case Slot.Armor: return "服";
            case Slot.Boots: return "靴";
            case Slot.Pet: return "ペット";
            default: return "装備";
        }
    }

    public static string GetRarityName(Rarity rarity)
    {
        switch (rarity)
        {
            case Rarity.Common: return "コモン";
            case Rarity.Rare: return "レア";
            case Rarity.Epic: return "エピック";
            case Rarity.Legendary: return "レジェンド";
            default: return "不明";
        }
    }

    public static string GetRarityStars(Rarity rarity)
    {
        int starCount;
        switch (rarity)
        {
            case Rarity.Common: starCount = 1; break;
            case Rarity.Rare: starCount = 2; break;
            case Rarity.Epic: starCount = 3; break;
            case Rarity.Legendary: starCount = 4; break;
            default: starCount = 0; break;
        }

        return new string('★', starCount);
    }

    public static Color GetRarityColor(Rarity rarity)
    {
        switch (rarity)
        {
            case Rarity.Common: return new Color(0.25f, 0.32f, 0.38f);
            case Rarity.Rare: return new Color(0.14f, 0.32f, 0.55f);
            case Rarity.Epic: return new Color(0.35f, 0.18f, 0.5f);
            case Rarity.Legendary: return new Color(0.56f, 0.32f, 0.08f);
            default: return Color.gray;
        }
    }

    private static string GetKey(Slot slot)
    {
        switch (slot)
        {
            case Slot.Weapon: return WeaponKey;
            case Slot.Armor: return ArmorKey;
            case Slot.Boots: return BootsKey;
            case Slot.Pet: return PetKey;
            default: return WeaponKey;
        }
    }

    private static string GetOwnedKey(Slot slot)
    {
        switch (slot)
        {
            case Slot.Weapon: return OwnedWeaponKey;
            case Slot.Armor: return OwnedArmorKey;
            case Slot.Boots: return OwnedBootsKey;
            case Slot.Pet: return OwnedPetKey;
            default: return OwnedWeaponKey;
        }
    }

    private static string GetPieceKey(Slot slot)
    {
        return PiecePrefix + slot;
    }

    private static string GetLevelKey(Slot slot, int itemId)
    {
        return EquipmentLevelPrefix + slot + "." + itemId;
    }

    private static bool IsOwnedWithoutInitialization(Slot slot, int itemId)
    {
        if (itemId < 0 || itemId >= 31) return false;
        return (PlayerPrefs.GetInt(GetOwnedKey(slot), 0) & (1 << itemId)) != 0;
    }

    private static void EnsureOwnershipDefaults()
    {
        if (ownershipDefaultsChecked) return;

        Slot[] slots = { Slot.Weapon, Slot.Armor, Slot.Boots, Slot.Pet };
        bool changed = false;
        for (int i = 0; i < slots.Length; i++)
        {
            Slot slot = slots[i];
            string key = GetOwnedKey(slot);
            if (PlayerPrefs.HasKey(key)) continue;

            // Preserve the equipment that was already available on the old
            // equipment page. New IDs stay locked until the gacha grants
            // them through Unlock().
            Item[] items = GetItems(slot);
            int mask = 0;
            for (int item = 0; item < items.Length; item++)
            {
                bool wasAvailableBeforeGacha =
                    slot == Slot.Weapon && items[item].id <= 1 ||
                    slot == Slot.Armor && items[item].id == 0 ||
                    slot == Slot.Boots && items[item].id == 0 ||
                    slot == Slot.Pet && items[item].id <= 1;
                if (wasAvailableBeforeGacha)
                    mask |= 1 << items[item].id;
            }
            PlayerPrefs.SetInt(key, mask);
            changed = true;
        }

        if (changed) PlayerPrefs.Save();
        ownershipDefaultsChecked = true;
    }
}
