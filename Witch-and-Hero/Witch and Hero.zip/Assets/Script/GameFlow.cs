using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameFlow : MonoBehaviour
{
    private enum GameState { Title, Menu, Battle, Result, Upgrade, Equipment, Gacha }
    private enum DefeatReason { WitchDefeated, HeroDefeated }

    private struct EquipmentGachaResult
    {
        public EquipmentSystem.Slot slot;
        public int itemId;
        public bool isNew;
    }

    private sealed class MapStageGroup
    {
        public int groupId;
        public readonly List<StageDefinition> levels = new List<StageDefinition>();
    }

    private sealed class TitleButtonHoverRelay : MonoBehaviour,
        IPointerEnterHandler, IPointerExitHandler
    {
        public GameFlow owner;
        public Button button;

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (owner != null && button != null)
                owner.canvasHoveredButtons.Add(button);
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (owner != null && button != null)
                owner.canvasHoveredButtons.Remove(button);
        }

        private void OnDisable()
        {
            if (owner != null && button != null)
                owner.canvasHoveredButtons.Remove(button);
        }
    }

    // The front-end scene starts at the title screen.
    private GameState state = GameState.Title;
    private Witch witch;
    private Hero hero;
    private readonly Dictionary<int, GameObject> monsterSources = new Dictionary<int, GameObject>();
    private readonly List<Monster> spawnedMonsters = new List<Monster>();
    private StageCatalog catalog;
    private MonsterCatalog monsterCatalog;
    private StageDefinition currentStage;
    private Coroutine spawnRoutine;
    private int selectedStage;
    private bool stageInfoOpen;
    private int stageInfoStageId;
    private int stageInfoChoice;
    private bool stageGroupInfoOpen;
    private int stageGroupInfoMapPage;
    private int stageGroupInfoId;
    private int stageGroupInfoChoice;
    private bool spawning;
    private bool won;
    private DefeatReason defeatReason;
    private bool stageOneTutorialActive;
    private int stageOneTutorialStep;
    private int experience;
    private int coins;
    private int gachaTickets;
    private Sprite experienceOrbSprite;
    private Sprite coinSprite;
    private Sprite gachaTicketSprite;
    private readonly Dictionary<EquipmentSystem.Slot, Sprite> equipmentPieceSprites =
        new Dictionary<EquipmentSystem.Slot, Sprite>();
    private Texture2D mapCircleTexture;
    private Texture2D mapBackgroundTexture;
    private Texture2D mapRuinsBackgroundTexture;
    private Texture2D mapTravelBackgroundTexture;
    private Texture2D nodeBuildingTexture;
    private Texture2D nodeNatureTexture;
    private Texture2D nodeMonsterTexture;
    private Texture2D stageIconsTexture;
    private readonly Dictionary<string, Texture2D> equipmentIconTextures =
        new Dictionary<string, Texture2D>();
    private Sprite mapCircleSprite;
    private Sprite nodeBuildingSprite;
    private Sprite nodeNatureSprite;
    private Sprite nodeMonsterSprite;
    private readonly Dictionary<int, Sprite> stageIconSprites =
        new Dictionary<int, Sprite>();
    private readonly Dictionary<int, Sprite> stageLandmarkSprites =
        new Dictionary<int, Sprite>();
    private readonly HashSet<Button> canvasHoveredButtons =
        new HashSet<Button>();
    private Sprite uiWhiteSprite;
    private Texture2D guiButtonNormalBackground;
    private Texture2D guiButtonHoverBackground;
    private Texture2D guiButtonActiveBackground;
    private Vector2 mapScrollPosition;
    private Vector2 pendingMapScroll;
    private Vector2 pendingSkillTreeScroll;
    private Vector2 pendingMapDrag;
    private Vector2 pendingMapKeyboardPan;
    private bool lowLevelMapMouseHeld;
    private bool mapScrollInitialized;
    private bool mapDragging;
    private bool mapSuppressNodeClick;
    private Vector2 mapLastPointerPosition;
    private bool mapInputPointerHeld;
    private Vector2 mapInputLastPointerPosition;
    private int mapFooterHandledFrame = -1;
    private int mapScrollHandledFrame = -1;
    private Vector2 skillTreePan;
    private bool skillTreePointerHeld;
    private bool skillTreeSuppressNodeClick;
    private Vector2 skillTreeLastPointerPosition;
    private int skillTreeScrollHandledFrame = -1;
    private bool mapOnlyScene;
    // The map page is independent from the stage number. Stage 2 remains a
    // node on map 1; map 2 is a separate world page unlocked after map 1 is
    // completely cleared.
    private int currentMapPage = 1;
    private bool mapTravelMode;
    private int mapTravelToggleFrame = -1;
    private float mapTravelToggleTime = -10f;
    private float mapPageChangeTime = -10f;
    private GameObject titleButtonCanvasObject;
    private GameObject stageModalInputBlocker;
    private Button titleStageButton;
    private Button titleHelpButton;
    private Button titleHelpBackButton;
    private Button titleUpgradeButton;
    private Button mapTitleButton;
    private Button mapEquipmentButton;
    private Button mapGachaButton;
    private Button mapTravelButton;
    private Button mapPreviousPageButton;
    private Button mapNextPageButton;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
    private Button developmentDebugButton;
#endif
    private readonly Dictionary<Button, int> mapStageButtons = new Dictionary<Button, int>();
    private RectTransform titleStageButtonRect;
    private RectTransform titleHelpButtonRect;
    private RectTransform titleHelpBackButtonRect;
    private RectTransform titleUpgradeButtonRect;
    private RectTransform mapTitleButtonRect;
    private RectTransform mapEquipmentButtonRect;
    private RectTransform mapGachaButtonRect;
    private RectTransform mapTravelButtonRect;
    private RectTransform mapPreviousPageButtonRect;
    private RectTransform mapNextPageButtonRect;
    private GameObject titleVisualRoot;
    private GameObject titleHelpVisualRoot;
    private GameObject mapVisualRoot;
    private GameObject upgradeVisualRoot;
    private GameObject equipmentVisualRoot;
    private GameObject mapWorldBackground;
    private Sprite mapWorldBackgroundSprite;
    private GameObject mapVisualPanel;
    private Text mapPageLabel;
    private Text mapTravelButtonLabel;
    private GameObject mapPanOverlay;
    private ScrollRect mapPanScrollRect;
    private RectTransform mapPanContent;
    private readonly List<Button> mapPanNodeButtons = new List<Button>();
    private bool updatingMapPanOverlay;
    private GameObject skillTreePanOverlay;
    private ScrollRect skillTreePanScrollRect;
    private RectTransform skillTreePanContent;
    private readonly List<Button> skillTreePanNodeButtons = new List<Button>();
    private bool updatingSkillTreePanOverlay;
    private ScrollRect mapCanvasScrollRect;
    private RectTransform mapCanvasContent;
    private bool updatingMapCanvasScroll;
    private Camera mapCamera;
    private Vector3 mapCameraHomePosition;
    private Vector2 mapCameraPan;
    private bool mapCameraConfigured;
    private int titleSelection;
    private bool titleHelpOpen;
    private bool resetProgressConfirm;
    private bool titleOverlayWasVisible;
    private static bool battleLoadRequested;
    private static AsyncOperation battleScenePreloadOperation;
    private static Scene preloadedBattleScene;
    private static bool battleScenePreloaded;
    private static bool returnToStageSelectRequested;
    private static bool sceneLoadHooked;
    private static GameFlow runtimeInstance;
    private bool mapVisualBuildPending;
    private Texture2D equipmentIconsTexture;
    private int equipmentFocusSlot;
    private int equipmentFocusItem;
    private bool equipmentListOpen;
    private Vector2 equipmentListScroll;
    private int equipmentInputFrame = -1;
    private KeyCode equipmentLastHandledKey = KeyCode.None;
    private float equipmentLastHandledKeyTime = -1f;
    private int gachaResultItemId = -1;
    private EquipmentSystem.Slot gachaResultSlot = EquipmentSystem.Slot.Weapon;
    private int gachaSlotFilter = -1;
    private bool gachaRatesOpen;
    private bool gachaResultPopupOpen;
    private Vector2 gachaLineupScroll;
    private Vector2 gachaRatesScroll;
    private string gachaMessage = "装備を引いて、所持品を増やそう";
    private float gachaMessageTimer;
    private bool gachaResultIsNew;
    private bool ticketGachaSelected;
    private Texture2D gachaNormalBackgroundTexture;
    private readonly List<EquipmentGachaResult> gachaResults =
        new List<EquipmentGachaResult>();
    private readonly List<GameObject> heroEquipmentVisualObjects =
        new List<GameObject>();
    private GameObject petCompanionObject;
    private SpriteRenderer petCompanionRenderer;
    private float nextPetAttackTime;
    private float petOrbitAngle;
    private float petAttackStopUntil;
    private Monster pendingPetAttackTarget;
    private Vector3 petWanderTarget;
    private float nextPetWanderChangeTime;
    private bool petHasWanderTarget;
    // Do not let OnGUI render partial title controls before Start() has
    // finished constructing the Canvas overlay. Otherwise the IMGUI volume
    // button appears a frame before the Canvas stage button.
    private bool runtimeInitialized;
    // Development-only state. The UI and operations that use it are compiled
    // out of release builds so saved progress cannot be changed by a hidden
    // production control.
    private bool developmentDebugPanelOpen;
    private bool developmentDirectStageStart;
    private bool battlePaused;
    private bool battleStartFreeze;
    private float battleStartFreezeUntil;
    private GameObject witchSkillEffectObject;
    private LineRenderer witchSkillRing;
    private Material witchSkillEffectMaterial;
    private float witchSkillEffectTimer;
    private float nextWitchSkillTime;
    private BgmLibrary bgmLibrary;
    private AudioSource bgmAudioSource;
    private AudioSource sfxAudioSource;
    private AudioClip activeBgmClip;
    private bool bgmLookupAttempted;
#if UNITY_EDITOR
    private Vector2 editorGameViewOrigin;
    private Vector2 editorGameViewSize;
#endif

    private const string MapSceneName = "MapScene";
    private const string BattleSceneName = "SampleScene";
    private const string PendingStageKey = "WitchHero.PendingStage";
    private const string PendingStageInfoKey = "WitchHero.PendingStageInfo";
    private const string CoinBalanceKey = "WitchHero.CoinBalance";
    private const string GachaTicketBalanceKey = "WitchHero.GachaTicketBalance";
    private const int EquipmentGachaCost = 10;
    private const int EquipmentTenGachaCost = 90;
    private const int EquipmentTenGachaCount = 10;
    private const int TicketGachaCost = 1;
    private const float GachaMessageDuration = 2.2f;
    private const int StageOneTutorialStageId = 1;
    private const int StageOneTutorialStepCount = 5;
    private const string SlashDamageLevelKey = "WitchHero.SlashDamageLevel";
    private const string HeroHealthLevelKey = "WitchHero.HeroHealthLevel";
    private const string WitchHealthLevelKey = "WitchHero.WitchHealthLevel";
    private const string HeroSpeedLevelKey = "WitchHero.HeroSpeedLevel";
    private const string SlashPierceLevelKey = "WitchHero.SlashPierceLevel";
    private const string AttackSpeedLevelKey = "WitchHero.AttackSpeedLevel";
    private const string MonsterKnockbackLevelKey = "WitchHero.MonsterKnockbackLevel";
    private const string CurrentMapStageKey = "WitchHero.CurrentMapStage";
    private const string CurrentMapPageKey = "WitchHero.CurrentMapPage";
    private const string HighestClearedStageKey = "WitchHero.HighestClearedStage";
    private const string ClearedStageKeyPrefix = "WitchHero.ClearedStage.";
    private const int BaseHeroHealth = 10;
    private const int BaseWitchHealth = 10;
    // The initial battle should feel deliberately slow and readable. Upgrade
    // nodes still raise the pace, but a fresh save gets plenty of reaction
    // time before enemies or attacks become hectic.
    private const float BaseHeroMoveSpeed = 2f;
    private const float BaseHeroAttackInterval = 0.8f;
    private const float AttackSpeedUpgradeAmount = 0.06f;
    private const float MonsterKnockbackUpgradeAmount = 0.2f;
    private const float MinimumHeroAttackInterval = 0.4f;
    // A slash survives its first hit and disappears after the second unique
    // monster. The hitMonsters set prevents the same monster being hit twice.
    // No piercing before the first penetration upgrade. A fresh save should
    // destroy a slash on its first monster hit.
    private const int BaseSlashPiercingHits = 1;
    private const int HealthUpgradeAmount = 2;
    private const float SpeedUpgradeAmount = 0.4f;
    // One is the minimum meaningful hit. Make the fresh-game attack feel
    // weaker by giving the larger waves more time to survive each hit.
    private const int BaseSlashDamage = 1;
    // A clear should not immediately buy an upgrade. With one coin per
    // defeated monster, the first node now takes several completed runs even
    // on the later unlocked stages, making repeated clears meaningful.
    // Make the complete tree a long-term goal. The first node is reachable
    // after a few clears, while later nodes become progressively more costly.
    private const int SlashDamageUpgradeBaseCost = 25;
    private const int UpgradeCostStep = 8;
    private const int WitchSkillExperienceCost = 25;
    private const int WitchSkillDamage = 1;
    private const float WitchSkillCooldown = 0.8f;
    private const float WitchSkillEffectDuration = 0.24f;
    private const string BgmLibraryResourcePath = "BgmLibrary";
    private const string VolumeLevelKey = "WitchHero.VolumeLevel";
    private int volumeLevel = 1;
    private const float PetFollowDistance = 0.72f;
    private const float PetMoveSpeed = 1.75f;
    private const float PetAttackRange = 1.35f;
    private const float PetHeroReturnRadius = 1.15f;
    private const float PetMaxDistanceFromHero = 2.25f;
    private const float PetCombatDetectionRange = 4.0f;
    private const float PetWanderRadius = 1.25f;
    private const float PetWanderSpeed = 0.9f;
    private const float PetHeroClearance = 0.92f;
    private const float PetWitchClearance = 0.92f;
    private const float PetMonsterClearance = 0.82f;
    private const float PetPositionGap = 0.08f;
    private const float PetAttackWindup = 0.18f;
    private const float PetOrbitSpeed = 1.8f;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetRuntimeState()
    {
        battleLoadRequested = false;
        battleScenePreloadOperation = null;
        preloadedBattleScene = default;
        battleScenePreloaded = false;
        returnToStageSelectRequested = false;
        sceneLoadHooked = false;
        runtimeInstance = null;
    }

    private const float MinX = -9.5f;
    private const float MaxX = 9.5f;
    private const float MinY = -5f;
    private const float MaxY = 5f;
    private const float MonsterHealthBarYOffset = 0.72f;
    // Character bars stay attached to the root transform. Reading the
    // current animation frame's bounds makes them jump between frames.
    private const float WitchHealthBarWorldYOffset = 1.32f;
    private const float HeroHealthBarWorldYOffset = 1.08f;
    private const int ExperiencePerOrb = 10;
    private const int ExperienceToNextLevel = 100;
    private const int CoinsPerDrop = 1;
    // More monsters should not turn a single clear into a large payday.
    private const float CoinDropChance = 0.35f;
    private const float EquipmentPieceDropChance = 0.08f;
    private const float EliteEquipmentPieceDropChance = 0.2f;
    private const float BossGachaTicketDropChance = 0.05f;
    private const float MapCanvasScale = 0.01f;
    private const float MapCameraPanPixelsToWorld = 0.01f;
    private static readonly Vector2 MapCameraPanLimit = new Vector2(2.4f, 1.35f);

    // Front-end layout is authored at the same 1280x720 design resolution as
    // the CanvasScaler. Keep the title and world map large enough to use the
    // available Game view instead of leaving a small card in the middle.
    private const float TitlePanelWidth = 1000f;
    private const float TitlePanelHeight = 650f;
    private const float MapPanelWidth = 1180f;
    private const float MapPanelHeight = 680f;
    private const float MapViewportWidth = 1128f;
    private const float MapViewportHeight = 560f;
    private const float MapContentWidth = 1280f;
    private const float MapContentHeight = 800f;
    private const float MapNodeSize = 88f;
    private static readonly Vector2[] MapRoutePoints =
    {
        new Vector2(0.12f, 0.24f),
        new Vector2(0.23f, 0.32f),
        new Vector2(0.36f, 0.41f),
        new Vector2(0.49f, 0.38f),
        new Vector2(0.58f, 0.30f),
        new Vector2(0.72f, 0.32f),
        new Vector2(0.85f, 0.45f),
        new Vector2(0.78f, 0.61f),
        new Vector2(0.64f, 0.72f),
        new Vector2(0.43f, 0.67f)
    };
    // The ruins route uses a different path from the grassland route.  Keep
    // the same number of levels, but place them along the visible temple,
    // aqueduct and lower-ruins landmarks so Stage 2 is not a copy of Stage 1.
    private static readonly Vector2[] RuinsRoutePoints =
    {
        new Vector2(0.12f, 0.31f),
        new Vector2(0.25f, 0.18f),
        new Vector2(0.40f, 0.27f),
        new Vector2(0.55f, 0.18f),
        new Vector2(0.70f, 0.29f),
        new Vector2(0.84f, 0.20f),
        new Vector2(0.78f, 0.47f),
        new Vector2(0.63f, 0.61f),
        new Vector2(0.47f, 0.72f),
        new Vector2(0.29f, 0.63f)
    };
    // Give the skill tree a little more virtual space than the visible
    // viewport. The nodes stay centered, while drag/trackpad/WASD movement
    // can travel farther in every direction without changing the layout.
    private const float SkillTreeContentWidth = 1750f;
    private const float SkillTreeContentHeight = 1500f;
    // Each branch is made of separate purchase nodes. The saved integer for a
    // branch remains the number of purchased nodes, so old progress continues
    // to work while the UI now exposes level 1, 2, 3 and 4 individually.
    // Keep this data-driven so adding another branch later only needs new data.
    private const int AttackSpeedNodeIndex = 30;
    private const int AttackSpeedUnlockRequiredNodes = 8;
    private const int MonsterKnockbackNodeIndex = 33;
    private const int MonsterKnockbackUnlockRequiredNodes = 10;
    private const float SkillTreeNodeSize = 112f;
    private const int SkillTreeGridColumns = 5;
    private const int SkillTreeGridRows = 6;
    // Keep the grid regular so every node has clear space around it and the
    // connecting segments are visually consistent in both directions.
    // Seven visible branches fit in the 1128px tree viewport when the
    // columns are compact. Keeping the whole tree on-screen is clearer than
    // sending the rightmost branches beyond the initial viewport.
    private const float SkillTreeGridSpacingX = 120f;
    private const float SkillTreeGridSpacingY = 150f;
    // Leave a little breathing room below the header so the first row never
    // competes with the title or the coin counter.
    private static readonly Vector2 SkillTreeCenterOffset = new Vector2(0f, 180f);
    private static readonly Vector2 SkillTreeRootOffset = new Vector2(0f, -480f);
    private const float FrontendReferenceWidth = 1280f;
    private const float FrontendReferenceHeight = 720f;
    private const float FrontendCanvasMatch = 0.5f;
    private static readonly string[] SkillUpgradeKeys =
    {
        SlashDamageLevelKey,
        HeroHealthLevelKey,
        WitchHealthLevelKey,
        HeroSpeedLevelKey,
        SlashPierceLevelKey,
        AttackSpeedLevelKey,
        MonsterKnockbackLevelKey
    };
    private static readonly string[] SkillUpgradeNames =
    {
        "斬撃攻撃力",
        "ヒーロー体力",
        "魔女体力",
        "歩く速度",
        "斬撃貫通",
        "攻撃速度",
        "ノックバック"
    };
    // Keep one attribute in each column so six purchase nodes form a long
    // vertical upgrade path. The final three nodes form the attack-speed branch.
    private static readonly int[] SkillNodeBranches =
    {
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        5, 5, 5,
        6, 6, 6
    };
    private static readonly int[] SkillNodeLevels =
    {
        0, 0, 0, 0, 0,
        1, 1, 1, 1, 1,
        2, 2, 2, 2, 2,
        3, 3, 3, 3, 3,
        4, 4, 4, 4, 4,
        5, 5, 5, 5, 5,
        0, 1, 2,
        0, 1, 2
    };
    // The first row is the set of entry nodes. Each later row depends on the
    // node directly above it, so the lines stay short, vertical, and easy to
    // follow while still allowing a different stat branch to be the gate.
    private static readonly int[] SkillNodePrerequisites =
    {
        -1, -1, -1, -1, -1,
        0, 1, 2, 3, 4,
        5, 6, 7, 8, 9,
        10, 11, 12, 13, 14,
        15, 16, 17, 18, 19,
        20, 21, 22, 23, 24,
        9, 30, 31,
        -1, 33, 34
    };
    private const float MapHeroTokenSize = 76f;
    private const float MapHeroRunFrameDuration = 0.09f;
    private const float MapFocusMoveDuration = 0.65f;
    private const float BattleStartMonsterDelay = 1f;
    private const float BattleStartFreezeDuration = 0.15f;

    private Image mapHeroTokenImage;
    private RectTransform mapHeroTokenRect;
    private Coroutine mapHeroMoveRoutine;
    private Coroutine mapFocusRoutine;
    private int mapHeroStageId;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void CreateAtRuntime()
    {
        if (!sceneLoadHooked)
        {
            SceneManager.sceneLoaded += EnsureGameFlowForScene;
            sceneLoadHooked = true;
        }

        EnsureGameFlowForScene(SceneManager.GetActiveScene(), LoadSceneMode.Single);
    }

    private static void EnsureGameFlowForScene(Scene scene, LoadSceneMode mode)
    {
        if (FindAnyObjectByType<GameFlow>() != null) return;

        GameObject gameFlowObject = new GameObject("GameFlow");
        gameFlowObject.AddComponent<GameFlow>();
    }

    private void Awake()
    {
        if (runtimeInstance != null && runtimeInstance != this)
        {
            Destroy(gameObject);
            return;
        }

        runtimeInstance = this;

        // SampleScene is the battle scene. When the editor starts Play mode
        // from that scene without a requested stage, redirect before the
        // battle camera gets a chance to render its green field for one frame.
        // A real stage launch sets battleLoadRequested before loading this
        // scene, so that path continues into battle normally.
        if (SceneManager.GetActiveScene().name == BattleSceneName &&
            !battleLoadRequested)
        {
            SceneManager.LoadScene(MapSceneName);
            return;
        }
    }

    private void OnEnable()
    {
        InputSystem.onEvent += CaptureMapScrollEvent;
    }

    private void OnDisable()
    {
        InputSystem.onEvent -= CaptureMapScrollEvent;
    }

    private void CaptureMapScrollEvent(InputEventPtr eventPtr, InputDevice device)
    {
        if (device is Keyboard keyboard)
        {
            if (!eventPtr.IsA<StateEvent>() && !eventPtr.IsA<DeltaStateEvent>())
                return;

            if (keyboard.aKey.ReadValueFromEvent(eventPtr, out float aValue) && aValue > 0.5f)
                pendingMapKeyboardPan.x -= 1f;
            if (keyboard.dKey.ReadValueFromEvent(eventPtr, out float dValue) && dValue > 0.5f)
                pendingMapKeyboardPan.x += 1f;
            if (keyboard.wKey.ReadValueFromEvent(eventPtr, out float wValue) && wValue > 0.5f)
                pendingMapKeyboardPan.y -= 1f;
            if (keyboard.sKey.ReadValueFromEvent(eventPtr, out float sValue) && sValue > 0.5f)
                pendingMapKeyboardPan.y += 1f;
            return;
        }

        if (!(device is Mouse mouse)) return;

        if (mouse.leftButton.ReadValueFromEvent(eventPtr, out float leftButton))
            lowLevelMapMouseHeld = leftButton > 0.5f;

        if (lowLevelMapMouseHeld &&
            mouse.delta.ReadValueFromEvent(eventPtr, out Vector2 dragDelta) &&
            dragDelta.sqrMagnitude > 0.0001f)
        {
            pendingMapDrag += dragDelta;
        }

        if (mouse.scroll.ReadValueFromEvent(eventPtr, out Vector2 scroll) &&
            scroll.sqrMagnitude > 0.0001f)
        {
            pendingMapScroll += scroll;
            pendingSkillTreeScroll += scroll;
        }
    }

    private void Start()
    {
        if (runtimeInstance != this)
            return;

        coins = PlayerPrefs.GetInt(CoinBalanceKey, 0);
        gachaTickets = PlayerPrefs.GetInt(GachaTicketBalanceKey, 0);
        volumeLevel = Mathf.Clamp(PlayerPrefs.GetInt(VolumeLevelKey, 1), 0, 3);
        witch = FindAnyObjectByType<Witch>(FindObjectsInactive.Include);
        hero = FindAnyObjectByType<Hero>(FindObjectsInactive.Include);

        Monster[] sceneMonsters = FindObjectsByType<Monster>(FindObjectsInactive.Include);
        for (int i = 0; i < sceneMonsters.Length; i++)
        {
            Monster sceneMonster = sceneMonsters[i];
            if (!monsterSources.ContainsKey(sceneMonster.TypeId))
                monsterSources.Add(sceneMonster.TypeId, sceneMonster.gameObject);
        }

        catalog = Resources.Load<StageCatalog>("StageCatalog");
        monsterCatalog = Resources.Load<MonsterCatalog>("MonsterCatalog");
        selectedStage = PlayerPrefs.GetInt(CurrentMapStageKey, 0);
        currentMapPage = Mathf.Max(1, PlayerPrefs.GetInt(CurrentMapPageKey, 1));
        ClampCurrentMapPageToUnlocked();
        ClampSelectedStageToUnlocked();
        ClampSelectedStageToCurrentMap();

        // MapScene is always the front-end map, even when battle objects from
        // another editor session are still discoverable during a scene reload.
        mapOnlyScene = SceneManager.GetActiveScene().name == MapSceneName ||
            witch == null || hero == null || monsterSources.Count == 0;
        if (mapOnlyScene)
        {
            bool openStageSelect = returnToStageSelectRequested;
            int pendingStageInfo = PlayerPrefs.GetInt(PendingStageInfoKey, 0);
            returnToStageSelectRequested = false;
            PlayerPrefs.DeleteKey(PendingStageKey);
            PlayerPrefs.DeleteKey(PendingStageInfoKey);
            PlayerPrefs.Save();
            // MapScene is the front end. Start at the title screen and open
            // the world map only after the player confirms.
            state = openStageSelect ? GameState.Menu : GameState.Title;
            ConfigureMapCamera();
            CreateMapWorldBackground();
            mapVisualBuildPending = false;
            mapScrollInitialized = false;
            GameObject[] staleOverlays = Resources.FindObjectsOfTypeAll<GameObject>();
            for (int i = 0; i < staleOverlays.Length; i++)
            {
                if (staleOverlays[i] != null && staleOverlays[i].name.StartsWith("TitleButtonOverlay"))
                {
                    staleOverlays[i].SetActive(false);
                    Destroy(staleOverlays[i]);
                }
            }
            CreateTitleButtonOverlay();
            CreateMapPanOverlay();
            if (openStageSelect)
            {
                if (titleVisualRoot != null)
                    titleVisualRoot.SetActive(false);
                if (mapVisualRoot != null)
                    mapVisualRoot.SetActive(true);
                CreateMapVisual();
                if (pendingStageInfo > 0)
                    OpenStageInfo(pendingStageInfo, false);
            }
            // Apply the final visibility state before enabling OnGUI. This
            // keeps the title, volume control, and map background from being
            // displayed in separate initialization passes.
            UpdateTitleButtonOverlay();
            // Start loading the battle scene while the title/map is visible,
            // not only after the player opens a stage detail popup. This
            // removes most of the scene-load wait from the challenge click.
            BeginBattleScenePreload();
            runtimeInitialized = true;
            RequestEditorRepaint();
            return;
        }

        // Keep the boss as a Resources prefab instead of a visible scene
        // object. StageCatalog can then add monsterId 5 without cluttering
        // the battle scene or changing the normal monster source setup.
        GameObject bossSource = Resources.Load<GameObject>("BossMonster");
        if (bossSource != null && !monsterSources.ContainsKey(5))
            monsterSources.Add(5, bossSource);

        ClearBattleObjects();
        witch.gameObject.SetActive(false);
        hero.gameObject.SetActive(false);
        foreach (GameObject source in monsterSources.Values)
        {
            if (source != null && source.scene.IsValid())
                source.SetActive(false);
        }
        if (!battleLoadRequested)
        {
            PlayerPrefs.DeleteKey(PendingStageKey);
            PlayerPrefs.Save();
            SceneManager.LoadScene(MapSceneName);
            return;
        }

        battleLoadRequested = false;
        // The preload operation has just activated this battle scene. Clear
        // the static handle so the next return to the map can preload a fresh
        // battle scene for the next stage attempt.
        battleScenePreloadOperation = null;
        int stageToStart = PlayerPrefs.GetInt(PendingStageKey, 0);
        PlayerPrefs.DeleteKey(PendingStageKey);
        PlayerPrefs.Save();
        if (stageToStart > 0)
        {
            // BattleSceneへ渡されたステージは、マップ上のボタン操作ではなく
            // シーン初期化から開始するため、StartStageの通常入力ガードを通す。
            state = GameState.Menu;
            mapVisualBuildPending = false;
            StartStage(stageToStart);
            runtimeInitialized = true;
        }
        else
        {
            SceneManager.LoadScene(MapSceneName);
        }
    }

    private float GetConfiguredBgmVolume()
    {
        switch (volumeLevel)
        {
            case 0: return 0f;
            case 1: return 0.09f;
            case 2: return 0.16f;
            default: return 0.24f;
        }
    }

    private float GetConfiguredSfxVolume()
    {
        switch (volumeLevel)
        {
            case 0: return 0f;
            case 1: return 0.14f;
            case 2: return 0.22f;
            default: return 0.30f;
        }
    }

    // World objects such as monsters own their AudioSource, so expose the
    // same volume setting to them instead of letting those cues bypass the
    // title-screen volume control.
    public static float GetWorldSfxVolume(float mix = 1f)
    {
        float configuredVolume = runtimeInstance != null
            ? runtimeInstance.GetConfiguredSfxVolume()
            : 0.14f;
        return configuredVolume * Mathf.Clamp01(mix);
    }

    public static bool IsBattleGameplayFrozen
    {
        get
        {
            return runtimeInstance != null &&
                runtimeInstance.state == GameState.Battle &&
                (runtimeInstance.battlePaused || runtimeInstance.battleStartFreeze);
        }
    }

    private string GetVolumeLabel()
    {
        switch (volumeLevel)
        {
            case 0: return "音量：OFF";
            case 1: return "音量：小";
            case 2: return "音量：中";
            default: return "音量：大";
        }
    }

    private void CycleVolume()
    {
        volumeLevel = (volumeLevel + 1) % 4;
        PlayerPrefs.SetInt(VolumeLevelKey, volumeLevel);
        PlayerPrefs.Save();
        if (bgmAudioSource != null)
            bgmAudioSource.volume = GetConfiguredBgmVolume();
        if (sfxAudioSource != null)
            sfxAudioSource.volume = GetConfiguredSfxVolume();
        RequestEditorRepaint();
    }

    private void UpdateBackgroundMusic()
    {
        if (bgmAudioSource != null)
            bgmAudioSource.volume = GetConfiguredBgmVolume();

        if (!bgmLookupAttempted)
        {
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
            bgmLookupAttempted = true;
        }

        if (bgmLibrary == null)
            return;

        AudioClip desiredClip = GetDesiredBackgroundMusic();
        if (desiredClip == activeBgmClip)
        {
            if (desiredClip != null && bgmAudioSource != null && !bgmAudioSource.isPlaying)
                bgmAudioSource.Play();
            return;
        }

        if (bgmAudioSource == null)
        {
            GameObject bgmObject = new GameObject("BackgroundMusic");
            bgmObject.transform.SetParent(transform, false);
            bgmAudioSource = bgmObject.AddComponent<AudioSource>();
            bgmAudioSource.playOnAwake = false;
            bgmAudioSource.loop = true;
            bgmAudioSource.volume = GetConfiguredBgmVolume();
            bgmAudioSource.spatialBlend = 0f;
        }

        bgmAudioSource.Stop();
        bgmAudioSource.clip = desiredClip;
        activeBgmClip = desiredClip;
        if (desiredClip != null)
            bgmAudioSource.Play();
    }

    private AudioClip GetDesiredBackgroundMusic()
    {
        bool isMapScene = mapOnlyScene || SceneManager.GetActiveScene().name == MapSceneName;
        if (isMapScene)
        {
            if (state == GameState.Title)
                return bgmLibrary.titleMusic;
            if (state == GameState.Menu || state == GameState.Upgrade ||
                state == GameState.Equipment || state == GameState.Gacha)
                return bgmLibrary.menuMusic;
            return null;
        }

        return state == GameState.Battle ? bgmLibrary.battleMusic : null;
    }

    private void PlaySfx(AudioClip clip)
    {
        if (clip == null) return;

        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);

        if (sfxAudioSource == null)
        {
            GameObject sfxObject = new GameObject("SoundEffects");
            sfxObject.transform.SetParent(transform, false);
            sfxAudioSource = sfxObject.AddComponent<AudioSource>();
            sfxAudioSource.playOnAwake = false;
            sfxAudioSource.loop = false;
            sfxAudioSource.volume = GetConfiguredSfxVolume();
            sfxAudioSource.spatialBlend = 0f;
        }

        sfxAudioSource.volume = GetConfiguredSfxVolume();
        sfxAudioSource.PlayOneShot(clip);
    }

    private void PlayConfirmSound()
    {
        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
        PlaySfx(bgmLibrary != null ? bgmLibrary.confirmSound : null);
    }

    private void PlayResultSound(bool isWin)
    {
        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
        PlaySfx(bgmLibrary != null
            ? (isWin ? bgmLibrary.levelUpSound : bgmLibrary.defeatBell)
            : null);
    }

    private void BeginBattleStartFreeze()
    {
        battlePaused = false;
        battleStartFreeze = true;
        battleStartFreezeUntil = Time.unscaledTime + BattleStartFreezeDuration;
        Time.timeScale = 0f;
    }

    private void ResumeBattleTime()
    {
        battlePaused = false;
        battleStartFreeze = false;
        battleStartFreezeUntil = 0f;
        Time.timeScale = 1f;
    }

    private void ToggleBattlePause()
    {
        if (battleStartFreeze) return;

        battlePaused = !battlePaused;
        Time.timeScale = battlePaused ? 0f : 1f;
        RequestEditorRepaint();
    }

    private void HandleBattlePauseInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame)
            ToggleBattlePause();
    }

    private bool UpdateBattleStartFreeze()
    {
        if (!battleStartFreeze)
            return false;

        if (Time.unscaledTime < battleStartFreezeUntil)
            return true;

        battleStartFreeze = false;
        Time.timeScale = 1f;
        return false;
    }

    private void Update()
    {
        if (runtimeInstance != this)
            return;

        if (state == GameState.Battle)
        {
            HandleBattlePauseInput();
            if (UpdateBattleStartFreeze() || battlePaused)
                return;
        }

        UpdateBackgroundMusic();

        if (gachaMessageTimer > 0f)
        {
            gachaMessageTimer -= Time.unscaledDeltaTime;
            if (gachaMessageTimer <= 0f)
                gachaMessageTimer = 0f;
            if (state == GameState.Gacha)
                RequestEditorRepaint();
        }

        // The editor Game view can stop repainting while this runtime-only
        // front end is driven by generated UI. Keep the actual preview and
        // camera movement visible while testing in Play mode.
        if (mapOnlyScene)
            RequestEditorRepaint();

        if (SceneManager.GetActiveScene().name == MapSceneName)
        {
            mapOnlyScene = true;
        }

        if (mapOnlyScene && !mapCameraConfigured)
            ConfigureMapCamera();

        if (mapOnlyScene && mapWorldBackground == null)
            CreateMapWorldBackground();

        EnsureMapVisualInitialized();
        EnsureMapHeroTokenVisible();
        UpdateTitleButtonOverlay();
        UpdateWitchSkillEffect();
        if (state == GameState.Title)
        {
            HandleTitleInput();
            return;
        }

        if (state == GameState.Menu)
        {
            if (stageGroupInfoOpen)
            {
                HandleStageGroupInfoInput();
                return;
            }
            if (stageInfoOpen)
            {
                HandleStageInfoInput();
                return;
            }

            HandleMapPointerInput();
            HandleMapNodeInput();
            return;
        }

        if (state == GameState.Upgrade)
        {
            HandleUpgradeInput();
            return;
        }

        if (state == GameState.Equipment)
        {
            HandleEquipmentInput();
            return;
        }

        if (state == GameState.Gacha)
        {
            HandleGachaInput();
            return;
        }

        if (state != GameState.Battle) return;

        spawnedMonsters.RemoveAll(monster => monster == null);
        UpdatePetCompanion();
        HandleWitchSkillInput();
        UpdateStageOneTutorial();

        if (witch == null || witch.IsDead)
        {
            Finish(false, DefeatReason.WitchDefeated);
            return;
        }

        if (hero == null || hero.IsDead)
        {
            Finish(false, DefeatReason.HeroDefeated);
            return;
        }

        if (!spawning && spawnedMonsters.Count == 0)
            Finish(true);
    }

    private void HandleWitchSkillInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null || !keyboard.eKey.wasPressedThisFrame)
            return;

        TryCastWitchSkill();
    }

    private void UpdateStageOneTutorial()
    {
        if (!stageOneTutorialActive || stageOneTutorialStep >= StageOneTutorialStepCount)
            return;

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        bool moved = keyboard.wKey.isPressed || keyboard.wKey.wasPressedThisFrame ||
            keyboard.aKey.isPressed || keyboard.aKey.wasPressedThisFrame ||
            keyboard.sKey.isPressed || keyboard.sKey.wasPressedThisFrame ||
            keyboard.dKey.isPressed || keyboard.dKey.wasPressedThisFrame ||
            keyboard.upArrowKey.isPressed || keyboard.upArrowKey.wasPressedThisFrame ||
            keyboard.leftArrowKey.isPressed || keyboard.leftArrowKey.wasPressedThisFrame ||
            keyboard.downArrowKey.isPressed || keyboard.downArrowKey.wasPressedThisFrame ||
            keyboard.rightArrowKey.isPressed || keyboard.rightArrowKey.wasPressedThisFrame;

        switch (stageOneTutorialStep)
        {
            case 0:
                if (moved)
                    stageOneTutorialStep = 1;
                break;

            case 1:
                if (keyboard.spaceKey.wasPressedThisFrame)
                    stageOneTutorialStep = 2;
                break;

            case 2:
                if (experience > 0)
                    stageOneTutorialStep = 3;
                break;

            case 3:
                if (experience >= WitchSkillExperienceCost)
                    stageOneTutorialStep = 4;
                break;

            case 4:
                if (keyboard.eKey.wasPressedThisFrame)
                    stageOneTutorialStep = StageOneTutorialStepCount;
                break;
        }
    }

    private void TryCastWitchSkill()
    {
        if (experience < WitchSkillExperienceCost ||
            Time.time < nextWitchSkillTime ||
            witch == null || witch.IsDead)
            return;

        Camera gameCamera = Camera.main;
        int targetCount = 0;
        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (IsMonsterOnScreen(monster, gameCamera))
                targetCount++;
        }

        // Do not consume experience when there is nothing on screen to hit.
        if (targetCount == 0)
            return;

        experience -= WitchSkillExperienceCost;
        nextWitchSkillTime = Time.time + WitchSkillCooldown;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (IsMonsterOnScreen(monster, gameCamera))
                monster.TakeWitchSkillHit(WitchSkillDamage);
        }

        CreateWitchSkillEffect();
        witch.PlaySkillAnimation();
    }

    private bool IsMonsterOnScreen(Monster monster, Camera gameCamera)
    {
        if (monster == null || monster.IsDead || !monster.gameObject.activeInHierarchy)
            return false;

        if (gameCamera == null)
            return true;

        Vector3 viewport = gameCamera.WorldToViewportPoint(monster.transform.position);
        return viewport.z > 0f &&
            viewport.x >= -0.05f && viewport.x <= 1.05f &&
            viewport.y >= -0.05f && viewport.y <= 1.05f;
    }

    private void CreateWitchSkillEffect()
    {
        DestroyWitchSkillEffect();
        if (witch == null) return;

        witchSkillEffectObject = new GameObject("WitchSkillEffect");
        witchSkillEffectObject.transform.position = witch.transform.position;

        Shader effectShader = Shader.Find("Sprites/Default");
        if (effectShader == null) return;

        witchSkillEffectMaterial = new Material(effectShader)
        {
            hideFlags = HideFlags.HideAndDontSave
        };

        GameObject ringObject = new GameObject("Ring");
        ringObject.transform.SetParent(witchSkillEffectObject.transform, false);
        witchSkillRing = ringObject.AddComponent<LineRenderer>();
        ConfigureWitchSkillLine(witchSkillRing);

        witchSkillEffectTimer = WitchSkillEffectDuration;
        UpdateWitchSkillEffect();
    }

    private void ConfigureWitchSkillLine(LineRenderer line)
    {
        line.useWorldSpace = false;
        line.loop = true;
        line.positionCount = 65;
        line.widthMultiplier = 0.1f;
        line.numCapVertices = 3;
        line.numCornerVertices = 3;
        line.material = witchSkillEffectMaterial;
        line.sortingOrder = 50;
    }

    private void UpdateWitchSkillEffect()
    {
        if (witchSkillEffectObject == null)
            return;

        witchSkillEffectTimer -= Time.deltaTime;
        if (witchSkillEffectTimer <= 0f || witch == null || witch.IsDead)
        {
            DestroyWitchSkillEffect();
            return;
        }

        witchSkillEffectObject.transform.position = witch.transform.position;
        float progress = 1f - witchSkillEffectTimer / WitchSkillEffectDuration;
        Camera gameCamera = Camera.main;
        float halfHeight = gameCamera != null && gameCamera.orthographic
            ? gameCamera.orthographicSize
            : 5f;
        float halfWidth = gameCamera != null && gameCamera.orthographic
            ? halfHeight * gameCamera.aspect
            : 8f;
        float screenRadius = Mathf.Sqrt(halfWidth * halfWidth + halfHeight * halfHeight) + 1f;
        float radius = Mathf.Lerp(0.2f, screenRadius, progress);
        float alpha = Mathf.Clamp01(1f - progress) * 0.78f;
        Color ringColor = new Color(0.38f, 0.9f, 1f, alpha);

        if (witchSkillRing != null)
        {
            witchSkillRing.widthMultiplier = Mathf.Lerp(0.11f, 0.035f, progress);
            witchSkillRing.startColor = ringColor;
            witchSkillRing.endColor = ringColor;
            for (int i = 0; i < 65; i++)
            {
                float angle = Mathf.PI * 2f * i / 64f;
                witchSkillRing.SetPosition(i, new Vector3(
                    Mathf.Cos(angle) * radius,
                    Mathf.Sin(angle) * radius,
                    -0.12f));
            }
        }

    }

    private void DestroyWitchSkillEffect()
    {
        if (witchSkillEffectObject != null)
            Destroy(witchSkillEffectObject);
        witchSkillEffectObject = null;
        witchSkillRing = null;

        if (witchSkillEffectMaterial != null)
            Destroy(witchSkillEffectMaterial);
        witchSkillEffectMaterial = null;
        witchSkillEffectTimer = 0f;
    }

    private void EnsureMapVisualInitialized()
    {
        bool mapPanelExists = mapVisualRoot != null &&
            mapVisualRoot.transform.Find("MapPanel") != null;
        if (state != GameState.Menu ||
            (mapVisualRoot != null && mapVisualPanel != null && mapPanelExists))
            return;

        if (!mapPanelExists)
            mapVisualPanel = null;

        GameObject existingOverlay = GameObject.Find("TitleButtonOverlay");
        if (existingOverlay != null)
        {
            Transform existingMap = existingOverlay.transform.Find("MapVisual");
            Transform existingPanel = existingMap != null
                ? existingMap.Find("MapPanel")
                : null;
            if (existingMap != null && existingPanel != null)
            {
                titleButtonCanvasObject = existingOverlay;
                mapVisualRoot = existingMap.gameObject;
                mapVisualPanel = existingPanel.gameObject;
                titleVisualRoot = existingOverlay.transform.Find("TitleVisual")?.gameObject;
                titleHelpVisualRoot = existingOverlay.transform.Find("TitleHelpVisual")?.gameObject;
                upgradeVisualRoot = existingOverlay.transform.Find("UpgradeVisual")?.gameObject;
                equipmentVisualRoot = existingOverlay.transform.Find("EquipmentVisual")?.gameObject;
                titleStageButton = existingOverlay.transform.Find("StageButton")?.GetComponent<Button>();
                titleHelpButton = existingOverlay.transform.Find("HelpButton")?.GetComponent<Button>();
                titleHelpBackButton = existingOverlay.transform.Find("HelpBackButton")?.GetComponent<Button>();
                titleUpgradeButton = existingOverlay.transform.Find("UpgradeButton")?.GetComponent<Button>();
                mapTitleButton = existingOverlay.transform.Find("MapTitleButton")?.GetComponent<Button>();
                mapEquipmentButton = existingOverlay.transform.Find("EquipmentButton")?.GetComponent<Button>();
                mapGachaButton = existingOverlay.transform.Find("GachaButton")?.GetComponent<Button>();
                mapTravelButton = existingOverlay.transform.Find("MapTravelButton")?.GetComponent<Button>();
                mapPreviousPageButton = existingOverlay.transform.Find("MapPreviousPageButton")?.GetComponent<Button>();
                mapNextPageButton = existingOverlay.transform.Find("MapNextPageButton")?.GetComponent<Button>();
                stageModalInputBlocker = existingOverlay.transform.Find(
                    "StageModalInputBlocker")?.gameObject;
                if (mapTravelButton != null)
                {
                    // Reused editor overlays can contain an old button with
                    // no listener. Always bind the current map-selection
                    // action when the overlay is recovered.
                    mapTravelButton.onClick.RemoveAllListeners();
                    mapTravelButton.onClick.AddListener(ToggleMapTravelMode);
                }
                if (mapGachaButton == null)
                {
                    mapGachaButton = CreateTitleButton("GachaButton", OpenGachaMenu,
                        out mapGachaButtonRect);
                    mapGachaButton.transform.SetParent(titleButtonCanvasObject.transform,
                        false);
                    SetTitleButtonRect(mapGachaButtonRect, 500f, 650f, 220f, 42f);
                    CreateUiText(mapGachaButton.transform, "装備ガチャ", 20,
                        Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
                }
                if (mapPreviousPageButton == null)
                {
                    mapPreviousPageButton = CreateTitleButton("MapPreviousPageButton",
                        () => OpenMapPage(currentMapPage - 1), out mapPreviousPageButtonRect);
                    mapPreviousPageButton.transform.SetParent(titleButtonCanvasObject.transform,
                        false);
                    SetTitleButtonRect(mapPreviousPageButtonRect, 70f, 18f, 190f, 38f);
                    CreateUiText(mapPreviousPageButton.transform, "前のマップ", 16,
                        Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
                }
                if (mapNextPageButton == null)
                {
                    mapNextPageButton = CreateTitleButton("MapNextPageButton",
                        () => OpenMapPage(currentMapPage + 1), out mapNextPageButtonRect);
                    mapNextPageButton.transform.SetParent(titleButtonCanvasObject.transform,
                        false);
                    SetTitleButtonRect(mapNextPageButtonRect, 850f, 18f, 190f, 38f);
                    CreateUiText(mapNextPageButton.transform, "次のマップ", 16,
                        Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
                }
                if (mapTravelButton == null)
                {
                    mapTravelButton = CreateTitleButton("MapTravelButton",
                        ToggleMapTravelMode, out mapTravelButtonRect);
                    mapTravelButton.transform.SetParent(titleButtonCanvasObject.transform,
                        false);
                    SetTitleButtonRect(mapTravelButtonRect, 70f, 64f, 180f, 42f);
                    mapTravelButtonLabel = CreateUiText(mapTravelButton.transform,
                        "マップ選択", 18, Color.white, TextAnchor.MiddleCenter,
                        Vector2.zero, Vector2.zero);
                }
                titleStageButtonRect = titleStageButton != null
                    ? titleStageButton.GetComponent<RectTransform>() : null;
                titleHelpButtonRect = titleHelpButton != null
                    ? titleHelpButton.GetComponent<RectTransform>() : null;
                titleHelpBackButtonRect = titleHelpBackButton != null
                    ? titleHelpBackButton.GetComponent<RectTransform>() : null;
                titleUpgradeButtonRect = titleUpgradeButton != null
                    ? titleUpgradeButton.GetComponent<RectTransform>() : null;
                mapTitleButtonRect = mapTitleButton != null
                    ? mapTitleButton.GetComponent<RectTransform>() : null;
                mapEquipmentButtonRect = mapEquipmentButton != null
                    ? mapEquipmentButton.GetComponent<RectTransform>() : null;
                mapGachaButtonRect = mapGachaButton != null
                    ? mapGachaButton.GetComponent<RectTransform>() : null;
                mapTravelButtonRect = mapTravelButton != null
                    ? mapTravelButton.GetComponent<RectTransform>() : null;
                if (mapTravelButton != null && mapTravelButtonLabel == null)
                    mapTravelButtonLabel = mapTravelButton.transform.Find("Text")?.GetComponent<Text>();
                mapPreviousPageButtonRect = mapPreviousPageButton != null
                    ? mapPreviousPageButton.GetComponent<RectTransform>() : null;
                mapNextPageButtonRect = mapNextPageButton != null
                    ? mapNextPageButton.GetComponent<RectTransform>() : null;
                mapPanOverlay = existingOverlay.transform.Find("MapPanInput")?.gameObject;
                skillTreePanOverlay = existingOverlay.transform.Find("SkillTreePanInput")?.gameObject;
                Transform existingMapArea = existingMap.Find("MapPanel/MapArea");
                mapCanvasScrollRect = existingMapArea != null
                    ? existingMapArea.GetComponent<ScrollRect>()
                    : null;
                Transform existingMapContent = existingMap.Find(
                    "MapPanel/MapArea/MapContent");
                mapCanvasContent = existingMapContent != null
                    ? existingMapContent.GetComponent<RectTransform>()
                    : null;
                Transform existingMapHero = existingMap.Find(
                    "MapPanel/MapArea/MapContent/MapHeroToken");
                if (existingMapHero != null)
                {
                    mapHeroTokenRect = existingMapHero.GetComponent<RectTransform>();
                    mapHeroTokenImage = existingMapHero.GetComponent<Image>();
                    RestoreMapHeroTokenVisual();
                }
                if (mapPanOverlay != null)
                {
                    mapPanScrollRect = mapPanOverlay.GetComponent<ScrollRect>();
                    mapPanContent = mapPanScrollRect != null
                        ? mapPanScrollRect.content
                        : null;
                }
                if (skillTreePanOverlay != null)
                {
                    skillTreePanScrollRect = skillTreePanOverlay.GetComponent<ScrollRect>();
                    skillTreePanContent = skillTreePanScrollRect != null
                        ? skillTreePanScrollRect.content
                        : null;
                    ConfigureSkillTreePanOverlayGeometry();
                }
                else
                {
                    CreateSkillTreePanOverlay();
                }
                if (mapHeroTokenRect == null && mapCanvasContent != null)
                    CreateMapHeroToken(GetCurrentMapStages());
                return;
            }
        }

        // A previous scene reload can leave a runtime overlay object behind
        // while the new GameFlow has lost its private references. Rebuild the
        // whole runtime UI so the visible map and its input ScrollRect always
        // belong to this GameFlow instance.
        GameObject staleOverlay = GameObject.Find("TitleButtonOverlay");
        if (staleOverlay != null)
            Destroy(staleOverlay);

        titleButtonCanvasObject = null;
        titleVisualRoot = null;
        titleHelpVisualRoot = null;
        mapVisualRoot = null;
        upgradeVisualRoot = null;
        equipmentVisualRoot = null;
        titleStageButton = null;
        titleHelpButton = null;
        titleHelpBackButton = null;
        titleUpgradeButton = null;
        mapTitleButton = null;
        mapEquipmentButton = null;
        mapGachaButton = null;
        mapTravelButton = null;
        mapPreviousPageButton = null;
        mapNextPageButton = null;
        titleStageButtonRect = null;
        titleHelpButtonRect = null;
        titleHelpBackButtonRect = null;
        titleUpgradeButtonRect = null;
        mapTitleButtonRect = null;
        mapEquipmentButtonRect = null;
        mapGachaButtonRect = null;
        mapTravelButtonRect = null;
        mapPreviousPageButtonRect = null;
        mapNextPageButtonRect = null;
        mapVisualPanel = null;
        mapPageLabel = null;
        mapTravelButtonLabel = null;
        mapPanOverlay = null;
        mapPanScrollRect = null;
        mapPanContent = null;
        skillTreePanOverlay = null;
        skillTreePanScrollRect = null;
        skillTreePanContent = null;
        skillTreePanNodeButtons.Clear();
        mapCanvasScrollRect = null;
        mapCanvasContent = null;
        CreateTitleButtonOverlay();
        CreateMapVisual();
        CreateMapPanOverlay();
        CreateSkillTreePanOverlay();
    }

    private void HandleTitleInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (titleHelpOpen)
        {
            bool closeWithKeyboard = keyboard != null &&
                (keyboard.escapeKey.wasPressedThisFrame ||
                 keyboard.enterKey.wasPressedThisFrame ||
                 keyboard.numpadEnterKey.wasPressedThisFrame ||
                 keyboard.spaceKey.wasPressedThisFrame);
            if (closeWithKeyboard)
                CloseTitleHelp();
            return;
        }

        HandleTitleKeyboardNavigation();
        if (keyboard != null && keyboard.vKey.wasPressedThisFrame)
        {
            CycleVolume();
            return;
        }
        bool confirmPressed = keyboard != null &&
            (keyboard.enterKey.wasPressedThisFrame ||
             keyboard.numpadEnterKey.wasPressedThisFrame ||
             keyboard.spaceKey.wasPressedThisFrame);
        // Mouse clicks are handled by the transparent IMGUI targets in
        // DrawOverlayInputTargets. Handling the global mouse button here
        // would make clicking the help button open the stage map first.
        if (confirmPressed)
        {
            ActivateTitleSelection();
        }
    }

    private void HandleTitleKeyboardNavigation()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        bool movedUp = keyboard.upArrowKey.wasPressedThisFrame ||
            keyboard.wKey.wasPressedThisFrame;
        bool movedDown = keyboard.downArrowKey.wasPressedThisFrame ||
            keyboard.sKey.wasPressedThisFrame;

        if (movedUp || movedDown)
        {
            // Title menu entries are stage select and operation help.
            titleSelection = titleSelection == 0 ? 1 : 0;
            EventSystem.current?.SetSelectedGameObject(
                titleSelection == 0 ? titleStageButton?.gameObject : titleHelpButton?.gameObject);
        }
    }

    private void ActivateTitleSelection()
    {
        if (state != GameState.Title) return;
        if (titleSelection == 0)
            OpenStageMenu();
        else
            OpenTitleHelp();
    }

    private void OpenTitleHelp()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = true;
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(false);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(true);
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void CloseTitleHelp()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = false;
        titleSelection = 0;
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(false);
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(true);
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void HandleMapNodeInput()
    {
        List<StageDefinition> stages = GetCurrentMapStages();
        if (stages.Count == 0) return;

        List<StageDefinition> allStages = GetStages();

        if (selectedStage <= 0)
            selectedStage = stages[0].stageId;

        int lastUnlockedIndex = -1;
        for (int i = 0; i < stages.Count; i++)
        {
            if (IsStageUnlocked(stages[i].stageId, allStages))
                lastUnlockedIndex = i;
        }
        int selectedIndex = stages.FindIndex(stage =>
            stage.stageId == selectedStage);
        if (selectedIndex < 0 || selectedIndex > lastUnlockedIndex)
        {
            selectedIndex = Mathf.Clamp(lastUnlockedIndex, 0, stages.Count - 1);
            selectedStage = stages[selectedIndex].stageId;
        }

        Vector2 lowLevelKeyboardDirection = pendingMapKeyboardPan;
        pendingMapKeyboardPan = Vector2.zero;
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.mKey.wasPressedThisFrame)
            {
                ToggleMapTravelMode();
                return;
            }

            int pressedMapNumber = GetPressedMapNumber(keyboard);
            if (mapTravelMode)
            {
                List<MapStageGroup> selectionGroups =
                    GetMapStageGroups(currentMapPage);
                if (pressedMapNumber >= 0 && pressedMapNumber < selectionGroups.Count)
                    SelectStageGroupFromSelectionScreen(
                        selectionGroups[pressedMapNumber].groupId);
                return;
            }

            if (keyboard.eKey.wasPressedThisFrame)
            {
                OpenEquipmentMenu();
                return;
            }
            if (keyboard.nKey.wasPressedThisFrame &&
                currentMapPage < GetHighestUnlockedMapPage())
            {
                OpenMapPage(currentMapPage + 1);
                return;
            }
            if (keyboard.bKey.wasPressedThisFrame && currentMapPage > 1)
            {
                OpenMapPage(currentMapPage - 1);
                return;
            }
            if (pressedMapNumber >= 0 && pressedMapNumber < stages.Count)
            {
                StageDefinition numberedStage = stages[pressedMapNumber];
                if (IsStageUnlocked(numberedStage.stageId, allStages))
                {
                    selectedStage = numberedStage.stageId;
                    MoveMapHeroToStage(selectedStage);
                    OpenStageInfo(selectedStage);
                }
                return;
            }

            if (stages.Count > 0)
            {
                bool moveNext = keyboard.rightArrowKey.wasPressedThisFrame ||
                    keyboard.downArrowKey.wasPressedThisFrame ||
                    keyboard.dKey.wasPressedThisFrame ||
                    keyboard.sKey.wasPressedThisFrame ||
                    lowLevelKeyboardDirection.x > 0.5f ||
                    lowLevelKeyboardDirection.y > 0.5f;
                bool movePrevious = keyboard.leftArrowKey.wasPressedThisFrame ||
                    keyboard.upArrowKey.wasPressedThisFrame ||
                    keyboard.aKey.wasPressedThisFrame ||
                    keyboard.wKey.wasPressedThisFrame ||
                    lowLevelKeyboardDirection.x < -0.5f ||
                    lowLevelKeyboardDirection.y < -0.5f;
                if (moveNext || movePrevious)
                {
                    int direction = moveNext ? 1 : -1;
                    int nextIndex = selectedIndex + direction;
                    if (nextIndex >= 0 && nextIndex < stages.Count &&
                        IsStageUnlocked(stages[nextIndex].stageId, allStages))
                    {
                        selectedStage = stages[nextIndex].stageId;
                        MoveMapHeroToStage(selectedStage);
                        RequestEditorRepaint();
                    }
                    return;
                }

                bool confirmStage = keyboard.enterKey.wasPressedThisFrame ||
                    keyboard.numpadEnterKey.wasPressedThisFrame ||
                    keyboard.spaceKey.wasPressedThisFrame;
                if (confirmStage)
                    OpenStageInfo(selectedStage);
            }
            return;

        }

        // Pointer selection and panning are handled by HandleMapPointerInput
        // so the map has one input path and never needs a second click.
    }

    private int GetPressedMapNumber(Keyboard keyboard)
    {
        if (keyboard.digit1Key.wasPressedThisFrame || keyboard.numpad1Key.wasPressedThisFrame)
            return 0;
        if (keyboard.digit2Key.wasPressedThisFrame || keyboard.numpad2Key.wasPressedThisFrame)
            return 1;
        if (keyboard.digit3Key.wasPressedThisFrame || keyboard.numpad3Key.wasPressedThisFrame)
            return 2;
        if (keyboard.digit4Key.wasPressedThisFrame || keyboard.numpad4Key.wasPressedThisFrame)
            return 3;
        if (keyboard.digit5Key.wasPressedThisFrame || keyboard.numpad5Key.wasPressedThisFrame)
            return 4;
        if (keyboard.digit6Key.wasPressedThisFrame || keyboard.numpad6Key.wasPressedThisFrame)
            return 5;
        if (keyboard.digit7Key.wasPressedThisFrame || keyboard.numpad7Key.wasPressedThisFrame)
            return 6;
        if (keyboard.digit8Key.wasPressedThisFrame || keyboard.numpad8Key.wasPressedThisFrame)
            return 7;
        if (keyboard.digit9Key.wasPressedThisFrame || keyboard.numpad9Key.wasPressedThisFrame)
            return 8;
        if (keyboard.digit0Key.wasPressedThisFrame || keyboard.numpad0Key.wasPressedThisFrame)
            return 9;
        return -1;
    }

    private void OpenStageGroupInfo(int mapPage, int groupId,
        bool playConfirmSound = true)
    {
        if (state != GameState.Menu || mapVisualBuildPending)
            return;

        MapStageGroup group = GetMapStageGroup(mapPage, groupId);
        if (!IsMapStageGroupUnlocked(group))
            return;

        if (playConfirmSound)
            PlayConfirmSound();
        stageGroupInfoMapPage = mapPage;
        stageGroupInfoId = groupId;
        stageGroupInfoChoice = 0;
        int selectedIndex = group.levels.FindIndex(level =>
            level != null && level.stageId == selectedStage);
        if (selectedIndex >= 0)
            stageGroupInfoChoice = selectedIndex;
        stageGroupInfoOpen = true;
        mapDragging = false;
        mapInputPointerHeld = false;
        mapSuppressNodeClick = true;
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void HandleStageGroupInfoInput()
    {
        if (!stageGroupInfoOpen)
            return;

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
            return;

        if (keyboard.escapeKey.wasPressedThisFrame ||
            keyboard.backspaceKey.wasPressedThisFrame)
        {
            CloseStageGroupInfo();
            return;
        }

        MapStageGroup group = GetMapStageGroup(stageGroupInfoMapPage,
            stageGroupInfoId);
        if (group == null || group.levels.Count == 0)
        {
            CloseStageGroupInfo();
            return;
        }

        int pressedLevel = GetPressedMapNumber(keyboard);
        if (pressedLevel >= 0 && pressedLevel < group.levels.Count)
            stageGroupInfoChoice = pressedLevel;

        bool moveNext = keyboard.rightArrowKey.wasPressedThisFrame ||
            keyboard.downArrowKey.wasPressedThisFrame ||
            keyboard.dKey.wasPressedThisFrame ||
            keyboard.sKey.wasPressedThisFrame;
        bool movePrevious = keyboard.leftArrowKey.wasPressedThisFrame ||
            keyboard.upArrowKey.wasPressedThisFrame ||
            keyboard.aKey.wasPressedThisFrame ||
            keyboard.wKey.wasPressedThisFrame;
        if (moveNext || movePrevious)
        {
            int direction = moveNext ? 1 : -1;
            stageGroupInfoChoice = Mathf.Clamp(stageGroupInfoChoice + direction,
                0, group.levels.Count - 1);
            RequestEditorRepaint();
            return;
        }

        if (keyboard.enterKey.wasPressedThisFrame ||
            keyboard.numpadEnterKey.wasPressedThisFrame ||
            keyboard.spaceKey.wasPressedThisFrame)
        {
            StageDefinition level = group.levels[
                Mathf.Clamp(stageGroupInfoChoice, 0, group.levels.Count - 1)];
            if (IsStageUnlocked(level.stageId, GetStages()))
            {
                stageGroupInfoOpen = false;
                OpenStageInfo(level.stageId);
            }
        }
    }

    private void CloseStageGroupInfo()
    {
        stageGroupInfoOpen = false;
        stageGroupInfoMapPage = 0;
        stageGroupInfoId = 0;
        stageGroupInfoChoice = 0;
        RequestEditorRepaint();
    }

    private void HandleStageInfoInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.escapeKey.wasPressedThisFrame)
            {
                CloseStageInfo();
                return;
            }

            bool moveLeft = keyboard.leftArrowKey.wasPressedThisFrame ||
                keyboard.aKey.wasPressedThisFrame;
            bool moveRight = keyboard.rightArrowKey.wasPressedThisFrame ||
                keyboard.dKey.wasPressedThisFrame;
            if (moveLeft || moveRight)
            {
                stageInfoChoice = stageInfoChoice == 0 ? 1 : 0;
                RequestEditorRepaint();
                return;
            }

            bool confirmPressed = keyboard.enterKey.wasPressedThisFrame ||
                keyboard.numpadEnterKey.wasPressedThisFrame ||
                keyboard.spaceKey.wasPressedThisFrame;
            if (confirmPressed)
            {
                if (stageInfoChoice == 0)
                    ConfirmStageInfo();
                else
                    CloseStageInfo();
                return;
            }
        }

        Mouse mouse = Mouse.current;
        if (mouse == null || !mouse.leftButton.wasPressedThisFrame) return;

        Vector2 guiPoint = mouse.position.ReadValue();
        guiPoint.y = Screen.height - guiPoint.y;
        GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect);
        if (challengeRect.Contains(guiPoint))
            ConfirmStageInfo();
        else if (cancelRect.Contains(guiPoint))
            CloseStageInfo();
    }

    private void BeginBattleScenePreload()
    {
        if (!mapOnlyScene ||
            SceneManager.GetActiveScene().name != MapSceneName ||
            battleScenePreloaded || battleScenePreloadOperation != null)
            return;

        battleScenePreloadOperation = SceneManager.LoadSceneAsync(
            BattleSceneName, LoadSceneMode.Additive);
        if (battleScenePreloadOperation != null)
            battleScenePreloadOperation.completed += HandleBattleScenePreloaded;
    }

    private void HandleBattleScenePreloaded(AsyncOperation operation)
    {
        battleScenePreloadOperation = null;
        preloadedBattleScene = SceneManager.GetSceneByName(BattleSceneName);
        battleScenePreloaded = preloadedBattleScene.IsValid() &&
            preloadedBattleScene.isLoaded;
        if (!battleScenePreloaded)
            return;

        PreparePreloadedBattleScene();
        if (battleLoadRequested)
        {
            int stageId = PlayerPrefs.GetInt(PendingStageKey, 0);
            if (stageId > 0)
                ActivatePreloadedBattleScene(stageId);
        }
    }

    private void PreparePreloadedBattleScene()
    {
        if (!battleScenePreloaded || !preloadedBattleScene.IsValid())
            return;

        // Run the expensive scene activation while the map is still visible.
        // The battle camera and actors remain disabled, so this cannot leak a
        // green field or allow the hidden battle to start early.
        SetBattleSceneRootsActive(preloadedBattleScene, true);

        List<Camera> cameras = FindComponentsInScene<Camera>(preloadedBattleScene);
        for (int i = 0; i < cameras.Count; i++)
        {
            if (cameras[i] != null)
                cameras[i].enabled = false;
        }

        List<AudioListener> listeners =
            FindComponentsInScene<AudioListener>(preloadedBattleScene);
        for (int i = 0; i < listeners.Count; i++)
        {
            if (listeners[i] != null)
                listeners[i].enabled = false;
        }

        Hero preloadedHero = FindComponentInScene<Hero>(preloadedBattleScene);
        Witch preloadedWitch = FindComponentInScene<Witch>(preloadedBattleScene);
        if (preloadedHero != null)
            preloadedHero.gameObject.SetActive(false);
        if (preloadedWitch != null)
            preloadedWitch.gameObject.SetActive(false);

        List<Monster> sceneMonsters = FindComponentsInScene<Monster>(preloadedBattleScene);
        for (int i = 0; i < sceneMonsters.Count; i++)
        {
            if (sceneMonsters[i] != null)
                sceneMonsters[i].gameObject.SetActive(false);
        }
    }

    private static void SetBattleSceneRootsActive(Scene scene, bool active)
    {
        if (!scene.IsValid() || !scene.isLoaded) return;

        GameObject[] roots = scene.GetRootGameObjects();
        for (int i = 0; i < roots.Length; i++)
        {
            if (roots[i] != null)
                roots[i].SetActive(active);
        }
    }

    private static T FindComponentInScene<T>(Scene scene) where T : Component
    {
        if (!scene.IsValid() || !scene.isLoaded)
            return null;

        GameObject[] roots = scene.GetRootGameObjects();
        for (int i = 0; i < roots.Length; i++)
        {
            if (roots[i] == null) continue;
            T component = roots[i].GetComponentInChildren<T>(true);
            if (component != null)
                return component;
        }

        return null;
    }

    private static List<T> FindComponentsInScene<T>(Scene scene) where T : Component
    {
        List<T> components = new List<T>();
        if (!scene.IsValid() || !scene.isLoaded)
            return components;

        GameObject[] roots = scene.GetRootGameObjects();
        for (int i = 0; i < roots.Length; i++)
        {
            if (roots[i] == null) continue;
            T[] rootComponents = roots[i].GetComponentsInChildren<T>(true);
            for (int j = 0; j < rootComponents.Length; j++)
            {
                if (rootComponents[j] != null)
                    components.Add(rootComponents[j]);
            }
        }

        return components;
    }

    private void ActivatePreloadedBattleScene(int stageId)
    {
        if (!battleScenePreloaded || !preloadedBattleScene.IsValid())
            return;

        battleLoadRequested = false;
        PlayerPrefs.DeleteKey(PendingStageKey);
        PlayerPrefs.Save();

        // Make the battle scene the active scene before enabling its roots.
        // This prevents the first active frame from using the map scene's
        // camera/input context and guarantees that the references below come
        // from this battle scene, not from an object in another loaded scene.
        SceneManager.SetActiveScene(preloadedBattleScene);
        SetBattleSceneRootsActive(preloadedBattleScene, true);
        if (mapCamera != null)
            mapCamera.gameObject.SetActive(false);
        if (titleButtonCanvasObject != null)
            titleButtonCanvasObject.SetActive(false);
        if (mapWorldBackground != null)
            mapWorldBackground.SetActive(false);

        mapOnlyScene = false;
        Camera battleCamera = FindComponentInScene<Camera>(preloadedBattleScene);
        if (battleCamera != null)
        {
            battleCamera.gameObject.SetActive(true);
            battleCamera.enabled = true;
        }
        List<AudioListener> battleListeners =
            FindComponentsInScene<AudioListener>(preloadedBattleScene);
        for (int i = 0; i < battleListeners.Count; i++)
        {
            if (battleListeners[i] != null)
                battleListeners[i].enabled = true;
        }
        witch = FindComponentInScene<Witch>(preloadedBattleScene);
        hero = FindComponentInScene<Hero>(preloadedBattleScene);
        monsterSources.Clear();
        List<Monster> sceneMonsters = FindComponentsInScene<Monster>(preloadedBattleScene);
        for (int i = 0; i < sceneMonsters.Count; i++)
        {
            Monster sceneMonster = sceneMonsters[i];
            if (sceneMonster != null && sceneMonster.gameObject.scene == preloadedBattleScene &&
                !monsterSources.ContainsKey(sceneMonster.TypeId))
            {
                sceneMonster.gameObject.SetActive(false);
                monsterSources.Add(sceneMonster.TypeId, sceneMonster.gameObject);
            }
        }

        GameObject bossSource = Resources.Load<GameObject>("BossMonster");
        if (bossSource != null && !monsterSources.ContainsKey(5))
            monsterSources.Add(5, bossSource);

        state = GameState.Menu;
        StartStage(stageId);
    }

    private void OpenStageInfo(int stageId, bool playConfirmSound = true)
    {
        // A stage detail dialog owns the map until the player chooses 挑む or
        // やめる.  Guard this method as well as disabling the buttons so a
        // late Canvas/IMGUI click cannot change the selected level behind the
        // dialog.
        if (state != GameState.Menu || mapVisualBuildPending ||
            stageInfoOpen || stageGroupInfoOpen || mapTravelMode)
            return;

        List<StageDefinition> stages = GetStages();
        int stageIndex = stages.FindIndex(stage => stage.stageId == stageId);
        if (stageIndex < 0 || !IsStageUnlocked(stages, stageIndex)) return;

        if (playConfirmSound)
            PlayConfirmSound();

        currentMapPage = Mathf.Max(1, stages[stageIndex].mapPage);
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        selectedStage = stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, stageId);
        PlayerPrefs.Save();
        MoveMapHeroToStage(stageId);
        stageInfoStageId = stageId;
        stageInfoChoice = 0;
        stageInfoOpen = true;
        BeginBattleScenePreload();
        mapDragging = false;
        mapInputPointerHeld = false;
        mapSuppressNodeClick = true;
        EventSystem.current?.SetSelectedGameObject(null);
        UpdateTitleButtonOverlay();
        if (stageModalInputBlocker != null)
            stageModalInputBlocker.SetActive(true);
        RequestEditorRepaint();
    }

    private void ConfirmStageInfo()
    {
        if (!stageInfoOpen) return;

        PlayConfirmSound();
        int stageId = stageInfoStageId;
        stageInfoOpen = false;
        stageInfoStageId = 0;
        StartStage(stageId);
    }

    private void CloseStageInfo()
    {
        PlayConfirmSound();
        stageInfoOpen = false;
        stageInfoStageId = 0;
        stageInfoChoice = 0;
        mapSuppressNodeClick = false;
        EventSystem.current?.SetSelectedGameObject(null);
        if (stageModalInputBlocker != null)
            stageModalInputBlocker.SetActive(false);
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private StageDefinition GetStageInfoDefinition()
    {
        List<StageDefinition> stages = GetStages();
        return stages.Find(stage => stage.stageId == stageInfoStageId);
    }

    private void GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect)
    {
        const float popupWidth = 560f;
        const float popupHeight = 380f;
        float popupX = (Screen.width - popupWidth) * 0.5f;
        float popupY = (Screen.height - popupHeight) * 0.5f;
        float buttonWidth = popupWidth - 110f;
        float buttonHeight = 64f;
        float buttonX = popupX + 55f;
        challengeRect = new Rect(buttonX, popupY + 198f, buttonWidth, buttonHeight);
        cancelRect = new Rect(buttonX, popupY + 274f, buttonWidth, buttonHeight);
    }

    private void HandleMapPointerInput()
    {
        if (HandleMapTouchInput())
            return;

        Mouse mouse = Mouse.current;
        if (mouse == null) return;

        if (mouse.leftButton.wasPressedThisFrame)
        {
        }

        // Keep page navigation independent from the map-drag ScrollRect. The
        // top controls sit outside the map viewport, but handling their click
        // here also keeps them reliable in the Unity Editor Game view where
        // Canvas pointer events can be swallowed by the transparent pan layer.
        if (mouse.leftButton.wasPressedThisFrame &&
            TryGetGuiPointerPosition(out Vector2 frontendPointer))
        {
            if (GetMapTravelButtonDesignRect().Contains(frontendPointer))
            {
                ToggleMapTravelMode();
                return;
            }

            if (!mapTravelMode && currentMapPage > 1 &&
                GetMapPreviousPageButtonDesignRect().Contains(frontendPointer))
            {
                OpenMapPage(currentMapPage - 1);
                return;
            }

            if (!mapTravelMode && currentMapPage < GetHighestUnlockedMapPage() &&
                GetMapNextPageButtonDesignRect().Contains(frontendPointer))
            {
                OpenMapPage(currentMapPage + 1);
                return;
            }
        }

        Vector2 lowLevelDrag = pendingMapDrag;
        pendingMapDrag = Vector2.zero;

        float panelWidth = Mathf.Min(MapPanelWidth, Screen.width - 20f);
        float panelHeight = Mathf.Min(MapPanelHeight, Screen.height - 20f);
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            (Screen.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
        Rect viewport = GetMapViewportScreenRect();
        Rect content = new Rect(0f, 0f, 1280f, 800f);

        Vector2 pointer = mouse.position.ReadValue();
        pointer.y = Screen.height - pointer.y;
        bool inside = viewport.Contains(pointer);
        Vector2 pointerDelta = mouse.delta.ReadValue();

        // Keep the last idle position as a fallback for editor/GameView
        // backends that deliver a complete drag as one pressed+released
        // frame and omit Mouse.delta.
        if (!mapInputPointerHeld && !mouse.leftButton.wasPressedThisFrame)
            mapInputLastPointerPosition = pointer;

        if (mouse.leftButton.wasPressedThisFrame && inside)
        {
            mapInputPointerHeld = true;
            mapSuppressNodeClick = false;
            mapInputLastPointerPosition = pointer;
        }

        if (lowLevelDrag.sqrMagnitude > 0.01f && (inside || mapInputPointerHeld))
        {
            mapSuppressNodeClick = true;
            // A left-drag moves the map together with the pointer. Convert
            // pointer movement to the content scroll offset on both axes.
            ApplyMapScroll(-lowLevelDrag, content, viewport);
        }

        if (mapInputPointerHeld && mouse.leftButton.isPressed)
        {
            Vector2 delta = pointer - mapInputLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                mapSuppressNodeClick = true;
                ApplyMapScroll(-delta, content, viewport);
                mapInputLastPointerPosition = pointer;
            }
        }

        // Some editor/GameView input backends deliver a complete drag as a
        // press and release in the same frame. Use the Input System delta as
        // a fallback so that drag still pans the map in that case.
        if (mouse.leftButton.wasPressedThisFrame &&
            mouse.leftButton.wasReleasedThisFrame &&
            pointerDelta.sqrMagnitude > 0.01f && inside)
        {
            mapSuppressNodeClick = true;
            ApplyMapScroll(-pointerDelta, content, viewport);
        }

        if (mapInputPointerHeld && mouse.leftButton.wasReleasedThisFrame)
        {
            if (!mapSuppressNodeClick && inside)
            {
                Vector2 contentPoint = pointer - viewport.position + mapScrollPosition;
                if (mapTravelMode)
                {
                    List<MapStageGroup> selectionGroups =
                        GetMapStageGroups(currentMapPage);
                    for (int i = 0; i < selectionGroups.Count; i++)
                    {
                        Vector2 mapPosition = GetMapSelectionNodePosition(content,
                            i + 1);
                        Rect nodeRect = new Rect(mapPosition.x - 90f,
                            mapPosition.y - 90f, 180f, 180f);
                        if (nodeRect.Contains(contentPoint))
                        {
                            SelectStageGroupFromSelectionScreen(
                                selectionGroups[i].groupId);
                            break;
                        }
                    }
                }
                else
                {
                    List<StageDefinition> stages = GetCurrentMapStages();
                    for (int i = 0; i < stages.Count; i++)
                    {
                        Vector2 nodePosition = GetMapNodePosition(content, stages[i], i,
                            stages.Count);
                        Rect nodeRect = new Rect(nodePosition.x - MapNodeSize * 0.5f,
                            nodePosition.y - MapNodeSize * 0.5f, MapNodeSize, MapNodeSize);
                        if (nodeRect.Contains(contentPoint))
                        {
                            OpenStageInfo(stages[i].stageId);
                            break;
                        }
                    }
                }
            }
            mapInputPointerHeld = false;
        }

        Vector2 wheel = pendingMapScroll;
        pendingMapScroll = Vector2.zero;
        if (wheel.sqrMagnitude <= 0.0001f)
            wheel = mouse.scroll.ReadValue();
        if (wheel.sqrMagnitude <= 0.0001f)
        {
            // macOS trackpads can appear as a separate Mouse device from the
            // device returned by Mouse.current. Check every connected Mouse
            // so their scroll events reach the same map position.
            for (int i = 0; i < InputSystem.devices.Count; i++)
            {
                Mouse otherMouse = InputSystem.devices[i] as Mouse;
                if (otherMouse == null || otherMouse == mouse) continue;

                wheel = otherMouse.scroll.ReadValue();
                if (wheel.sqrMagnitude > 0.0001f)
                    break;
            }
        }

        if (wheel.sqrMagnitude > 0.0001f &&
            mapScrollHandledFrame != Time.frameCount)
        {
            // Trackpad horizontal scrolling has the opposite sign from the
            // vertical scroll convention used by the map camera.
            ApplyMapScroll(new Vector2(wheel.x, -wheel.y) * 24f,
                content, viewport);
        }
    }

    private bool HandleMapTouchInput()
    {
        Touchscreen touchscreen = Touchscreen.current;
        if (touchscreen == null)
            return false;

        var touch = touchscreen.primaryTouch;
        if (touch == null || !touch.press.wasPressedThisFrame)
            return false;

        // Input System touch coordinates use a bottom-left origin. The map
        // hit rectangles use the same top-left GUI coordinates as the mouse
        // path after this conversion.
        Vector2 pointer = touch.position.ReadValue();
        pointer.y = Screen.height - pointer.y;
        Vector2 frontendPointer = PhysicalGuiPointToFrontendPoint(pointer);

        if (GetMapTravelButtonDesignRect().Contains(frontendPointer))
        {
            ToggleMapTravelMode();
            return true;
        }

        if (!mapTravelMode && currentMapPage > 1 &&
            GetMapPreviousPageButtonDesignRect().Contains(frontendPointer))
        {
            OpenMapPage(currentMapPage - 1);
            return true;
        }

        if (!mapTravelMode && currentMapPage < GetHighestUnlockedMapPage() &&
            GetMapNextPageButtonDesignRect().Contains(frontendPointer))
        {
            OpenMapPage(currentMapPage + 1);
            return true;
        }

        Rect viewport = GetMapViewportScreenRect();
        if (!viewport.Contains(pointer))
            return true;

        Rect content = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        Vector2 contentPoint = pointer - viewport.position + mapScrollPosition;
        if (mapTravelMode)
        {
            List<MapStageGroup> selectionGroups =
                GetMapStageGroups(currentMapPage);
            for (int i = 0; i < selectionGroups.Count; i++)
            {
                Vector2 mapPosition = GetMapSelectionNodePosition(content, i + 1);
                Rect nodeRect = new Rect(mapPosition.x - 90f,
                    mapPosition.y - 90f, 180f, 180f);
                if (nodeRect.Contains(contentPoint))
                {
                    SelectStageGroupFromSelectionScreen(
                        selectionGroups[i].groupId);
                    break;
                }
            }
            return true;
        }

        List<StageDefinition> stages = GetCurrentMapStages();
        for (int i = 0; i < stages.Count; i++)
        {
            Vector2 nodePosition = GetMapNodePosition(content, stages[i], i,
                stages.Count);
            Rect nodeRect = new Rect(nodePosition.x - MapNodeSize * 0.5f,
                nodePosition.y - MapNodeSize * 0.5f, MapNodeSize, MapNodeSize);
            if (!nodeRect.Contains(contentPoint))
                continue;

            OpenStageInfo(stages[i].stageId);
            break;
        }

        return true;
    }

    private void ApplyMapScroll(Vector2 delta, Rect content, Rect viewport)
    {
        if (delta.sqrMagnitude <= 0.0001f) return;

        // The map is a world-space canvas. Panning changes the actual MapScene
        // camera, so the whole map moves together instead of only changing a
        // UI content offset.
        if (mapCameraConfigured)
        {
            ApplyMapCameraPan(delta);
            mapScrollHandledFrame = Time.frameCount;
            RequestEditorRepaint();
            return;
        }

        if (mapCanvasScrollRect != null && mapVisualRoot != null &&
            mapVisualRoot.activeInHierarchy)
        {
            float maxX = Mathf.Max(0f, mapCanvasContent.rect.width - MapViewportWidth);
            float maxY = Mathf.Max(0f, mapCanvasContent.rect.height - MapViewportHeight);
            Vector2 normalized = mapCanvasScrollRect.normalizedPosition;
            normalized.x = maxX <= 0f
                ? 0.5f
                : Mathf.Clamp01(normalized.x + delta.x / maxX);
            normalized.y = maxY <= 0f
                ? 0.5f
                : Mathf.Clamp01(normalized.y - delta.y / maxY);

            updatingMapCanvasScroll = true;
            mapCanvasScrollRect.normalizedPosition = normalized;
            updatingMapCanvasScroll = false;
            mapScrollPosition = new Vector2(
                normalized.x * maxX,
                (1f - normalized.y) * maxY);
            mapScrollInitialized = true;
            mapScrollHandledFrame = Time.frameCount;
            RequestEditorRepaint();
            return;
        }

        mapScrollPosition += delta;
        ClampMapScroll(content, viewport);
        SyncMapPanOverlayFromPosition();
        mapScrollHandledFrame = Time.frameCount;
        RequestEditorRepaint();
    }

    private void HandleMapKeyboardPan()
    {
        // WASD and the arrow keys select the adjacent stage. Keep map
        // panning on pointer/trackpad input so one key press cannot move the
        // map and the hero in different directions at the same time.
        pendingMapKeyboardPan = Vector2.zero;
    }

    private void ConfigureMapCamera()
    {
        mapCamera = FindActiveSceneCamera();
        if (mapCamera == null)
            mapCamera = FindAnyObjectByType<Camera>(FindObjectsInactive.Include);
        if (mapCamera == null)
        {
            Camera[] sceneCameras = FindObjectsByType<Camera>(
                FindObjectsInactive.Include);
            if (sceneCameras.Length > 0)
                mapCamera = sceneCameras[0];
        }
        if (mapCamera == null) return;

        Camera[] allCameras = FindObjectsByType<Camera>(
            FindObjectsInactive.Include);
        for (int i = 0; i < allCameras.Length; i++)
        {
            if (allCameras[i] != null && allCameras[i] != mapCamera)
                allCameras[i].enabled = false;
        }

        mapCamera.orthographic = true;
        mapCamera.orthographicSize = 3.6f;
        mapCamera.enabled = true;
        mapCamera.targetTexture = null;
        mapCamera.targetDisplay = 0;
        mapCamera.forceIntoRenderTexture = false;
        mapCamera.rect = new Rect(0f, 0f, 1f, 1f);
        mapCamera.depth = 100f;
        mapCamera.clearFlags = CameraClearFlags.SolidColor;
        mapCamera.backgroundColor = new Color(0.025f, 0.06f, 0.10f, 1f);
        mapCamera.cullingMask = ~0;
        mapCamera.transform.position = new Vector3(0f, 0f, -10f);
        mapCamera.transform.rotation = Quaternion.identity;
        mapCameraHomePosition = mapCamera.transform.position;
        mapCameraPan = Vector2.zero;
        mapCameraConfigured = true;
    }

    private void CreateMapWorldBackground()
    {
        if (mapWorldBackground != null) return;

        Texture2D texture = GetMapBackgroundTexture();
        if (texture == null) return;

        mapWorldBackground = new GameObject("MapWorldBackground");
        mapWorldBackground.transform.position = new Vector3(0f, 0f, 1f);
        SpriteRenderer renderer = mapWorldBackground.AddComponent<SpriteRenderer>();
        float pixelsPerUnit = texture.width / 12.8f;
        mapWorldBackgroundSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            pixelsPerUnit);
        mapWorldBackgroundSprite.name = "RuntimeMapBackgroundSprite";
        renderer.sprite = mapWorldBackgroundSprite;
        // MapScene has no 2D light. Sprite-Lit-Default therefore renders the
        // background black in the Editor Game view; use an unlit shader.
        Shader unlitShader = Shader.Find("Universal Render Pipeline/2D/Sprite-Unlit-Default");
        if (unlitShader == null)
            unlitShader = Shader.Find("Sprites/Default");
        if (unlitShader != null)
        {
            Material unlitMaterial = new Material(unlitShader)
            {
                name = "RuntimeMapBackgroundUnlit",
                hideFlags = HideFlags.HideAndDontSave
            };
            renderer.sharedMaterial = unlitMaterial;
        }
        renderer.sortingOrder = -10;
        // The map background belongs to the stage-select state. Keep it
        // disabled while the title screen is being initialized so the first
        // rendered frame cannot expose the green map behind the UI.
        mapWorldBackground.SetActive(state == GameState.Menu);
    }

    private Camera FindActiveSceneCamera()
    {
        Scene activeScene = SceneManager.GetActiveScene();
        Camera[] cameras = FindObjectsByType<Camera>(
            FindObjectsInactive.Include);
        Camera fallback = null;
        for (int i = 0; i < cameras.Length; i++)
        {
            Camera candidate = cameras[i];
            if (candidate == null || candidate.gameObject.scene != activeScene)
                continue;
            if (fallback == null)
                fallback = candidate;
            if (candidate.gameObject.name == "Main Camera")
                return candidate;
        }

        return fallback;
    }

    private void ApplyMapCameraPan(Vector2 screenDelta)
    {
        if (!mapCameraConfigured || mapCamera == null) return;

        mapCameraPan += screenDelta * MapCameraPanPixelsToWorld;
        mapCameraPan.x = Mathf.Clamp(mapCameraPan.x,
            -MapCameraPanLimit.x, MapCameraPanLimit.x);
        mapCameraPan.y = Mathf.Clamp(mapCameraPan.y,
            -MapCameraPanLimit.y, MapCameraPanLimit.y);
        mapCamera.transform.position = mapCameraHomePosition +
            new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);

        // Apply the same input delta to the visible map immediately. The
        // visible map is drawn in the Game view, so this keeps its movement
        // deterministic even while the Editor is repainting the camera.
        mapScrollPosition += screenDelta;
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f,
            MapContentWidth - MapViewportWidth);
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f,
            MapContentHeight - MapViewportHeight);
        mapScrollInitialized = true;
        ApplyMapCanvasContentOffset();
    }

    private void ApplyMapCanvasContentOffset()
    {
        if (mapCanvasContent == null || mapVisualRoot == null) return;

        Canvas canvas = mapVisualRoot.GetComponentInParent<Canvas>();
        if (canvas == null || canvas.renderMode != RenderMode.ScreenSpaceOverlay)
            return;

        mapCanvasContent.anchoredPosition = new Vector2(
            -mapScrollPosition.x, mapScrollPosition.y);
    }

    private void SyncMapVisualToCamera()
    {
        Camera activeSceneCamera = FindActiveSceneCamera();
        if (activeSceneCamera != null)
            mapCamera = activeSceneCamera;

        if (!mapCameraConfigured || mapCamera == null) return;

        const float contentWidth = MapContentWidth;
        const float contentHeight = MapContentHeight;
        const float viewportWidth = MapViewportWidth;
        const float viewportHeight = MapViewportHeight;
        float maxScrollX = contentWidth - viewportWidth;
        float maxScrollY = contentHeight - viewportHeight;

        Vector2 cameraOffset = new Vector2(
            mapCamera.transform.position.x - mapCameraHomePosition.x,
            mapCameraHomePosition.y - mapCamera.transform.position.y);
        mapScrollPosition = new Vector2(
            maxScrollX * 0.5f + cameraOffset.x / MapCameraPanLimit.x * maxScrollX * 0.5f,
            maxScrollY * 0.5f + cameraOffset.y / MapCameraPanLimit.y * maxScrollY * 0.5f);
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f, maxScrollX);
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f, maxScrollY);
        mapScrollInitialized = true;
        ApplyMapCanvasContentOffset();
    }

    private Rect GetMapViewportScreenRect()
    {
        Canvas mapCanvas = mapVisualRoot != null
            ? mapVisualRoot.GetComponentInParent<Canvas>()
            : null;
        if (mapCanvas != null && mapCanvas.renderMode == RenderMode.WorldSpace &&
            mapCamera != null && mapVisualRoot != null && mapVisualRoot.activeInHierarchy)
        {
            Transform viewportTransform = mapVisualRoot.transform.Find("MapPanel/MapArea");
            RectTransform viewportRect = viewportTransform != null
                ? viewportTransform.GetComponent<RectTransform>()
                : null;
            if (viewportRect != null)
            {
                Vector3[] corners = new Vector3[4];
                viewportRect.GetWorldCorners(corners);
                float minX = float.MaxValue;
                float maxX = float.MinValue;
                float minY = float.MaxValue;
                float maxY = float.MinValue;
                for (int i = 0; i < corners.Length; i++)
                {
                    Vector3 screen = mapCamera.WorldToScreenPoint(corners[i]);
                    float guiY = Screen.height - screen.y;
                    minX = Mathf.Min(minX, screen.x);
                    maxX = Mathf.Max(maxX, screen.x);
                    minY = Mathf.Min(minY, guiY);
                    maxY = Mathf.Max(maxY, guiY);
                }

                return Rect.MinMaxRect(minX, minY, maxX, maxY);
            }
        }

        float panelWidth = Mathf.Min(MapPanelWidth, Screen.width - 20f);
        float panelHeight = Mathf.Min(MapPanelHeight, Screen.height - 20f);
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            (Screen.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
        return new Rect(panel.x + 22f, panel.y + 58f,
            panel.width - 44f, panel.height - 76f);
    }

    private void CreateTitleButtonOverlay()
    {
        if (titleButtonCanvasObject != null) return;

        GameObject eventSystemObject = FindAnyObjectByType<EventSystem>()?.gameObject;
        if (eventSystemObject == null)
        {
            eventSystemObject = new GameObject("UI EventSystem");
            eventSystemObject.AddComponent<EventSystem>();
        }

        InputSystemUIInputModule inputModule =
            eventSystemObject.GetComponent<InputSystemUIInputModule>();
        if (inputModule == null)
            inputModule = eventSystemObject.AddComponent<InputSystemUIInputModule>();
        inputModule.AssignDefaultActions();
        inputModule.enabled = true;

        BaseInputModule[] otherInputModules =
            eventSystemObject.GetComponents<BaseInputModule>();
        for (int i = 0; i < otherInputModules.Length; i++)
        {
            if (otherInputModules[i] != inputModule)
                otherInputModules[i].enabled = false;
        }

        titleButtonCanvasObject = new GameObject("TitleButtonOverlay");
        Canvas canvas = titleButtonCanvasObject.AddComponent<Canvas>();
        // Screen-space rendering is reliable in the Unity Editor Game view.
        // Camera panning is mirrored to MapContent so the visible map moves
        // together with the real MapScene camera.
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;
        CanvasScaler scaler = titleButtonCanvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        RectTransform canvasRect = titleButtonCanvasObject.GetComponent<RectTransform>();
        canvasRect.sizeDelta = new Vector2(1280f, 720f);
        titleButtonCanvasObject.transform.position = Vector3.zero;
        titleButtonCanvasObject.transform.rotation = Quaternion.identity;
        titleButtonCanvasObject.transform.localScale = Vector3.one;
        titleButtonCanvasObject.AddComponent<GraphicRaycaster>();

        // The detail dialog is rendered by IMGUI, so place an invisible
        // Canvas raycast shield over the map while it is open.  This prevents
        // Canvas node buttons from receiving a click through the dialog.
        stageModalInputBlocker = new GameObject("StageModalInputBlocker",
            typeof(RectTransform), typeof(Image));
        stageModalInputBlocker.transform.SetParent(
            titleButtonCanvasObject.transform, false);
        RectTransform blockerRect = stageModalInputBlocker.GetComponent<RectTransform>();
        blockerRect.anchorMin = Vector2.zero;
        blockerRect.anchorMax = Vector2.one;
        blockerRect.offsetMin = Vector2.zero;
        blockerRect.offsetMax = Vector2.zero;
        Image blockerImage = stageModalInputBlocker.GetComponent<Image>();
        blockerImage.color = new Color(0f, 0f, 0f, 0f);
        blockerImage.raycastTarget = true;
        stageModalInputBlocker.SetActive(false);

        titleStageButton = CreateTitleButton("StageButton", OpenStageMenu, out titleStageButtonRect);
        titleHelpButton = CreateTitleButton("HelpButton", OpenTitleHelp, out titleHelpButtonRect);
        titleHelpBackButton = CreateTitleButton("HelpBackButton", CloseTitleHelp,
            out titleHelpBackButtonRect);
        titleUpgradeButton = CreateTitleButton("UpgradeButton", OpenUpgradeMenu, out titleUpgradeButtonRect);
        mapTitleButton = CreateTitleButton("MapTitleButton", ReturnToTitle,
            out mapTitleButtonRect);
        mapEquipmentButton = CreateTitleButton("EquipmentButton", OpenEquipmentMenu,
            out mapEquipmentButtonRect);
        mapGachaButton = CreateTitleButton("GachaButton", OpenGachaMenu,
            out mapGachaButtonRect);
        mapTravelButton = CreateTitleButton("MapTravelButton", ToggleMapTravelMode,
            out mapTravelButtonRect);
        mapPreviousPageButton = CreateTitleButton("MapPreviousPageButton",
            () => OpenMapPage(currentMapPage - 1), out mapPreviousPageButtonRect);
        mapNextPageButton = CreateTitleButton("MapNextPageButton",
            () => OpenMapPage(currentMapPage + 1), out mapNextPageButtonRect);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        developmentDebugButton = CreateTitleButton("DevelopmentDebugButton", null,
            out RectTransform developmentDebugButtonRect);
#endif
        titleStageButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleHelpButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleHelpBackButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleUpgradeButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapTitleButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapEquipmentButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapGachaButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapTravelButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapPreviousPageButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapNextPageButton.transform.SetParent(titleButtonCanvasObject.transform, false);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        developmentDebugButton.transform.SetParent(titleButtonCanvasObject.transform, false);
#endif
        SetTitleButtonRect(titleStageButtonRect, 240f, 335f, 800f, 86f);
        SetTitleButtonRect(titleHelpButtonRect, 240f, 435f, 800f, 70f);
        SetTitleButtonRect(titleHelpBackButtonRect, 240f, 570f, 800f, 58f);
        SetTitleButtonRect(titleUpgradeButtonRect, 980f, 650f, 220f, 42f);
        SetTitleButtonRect(mapTitleButtonRect, 80f, 650f, 220f, 42f);
        SetTitleButtonRect(mapEquipmentButtonRect, 740f, 650f, 220f, 42f);
        SetTitleButtonRect(mapGachaButtonRect, 500f, 650f, 220f, 42f);
        SetTitleButtonRect(mapTravelButtonRect, 70f, 64f, 180f, 42f);
        SetTitleButtonRect(mapPreviousPageButtonRect, 70f, 18f, 190f, 38f);
        SetTitleButtonRect(mapNextPageButtonRect, 850f, 18f, 190f, 38f);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        SetTitleButtonRect(developmentDebugButtonRect, 1070f, 18f, 190f, 38f);
        Image developmentDebugImage = developmentDebugButton.GetComponent<Image>();
        developmentDebugImage.color = new Color(0.24f, 0.20f, 0.08f, 0.96f);
#endif


        Navigation stageNavigation = new Navigation { mode = Navigation.Mode.Explicit };
        stageNavigation.selectOnDown = titleHelpButton;
        titleStageButton.navigation = stageNavigation;

        Navigation helpNavigation = new Navigation { mode = Navigation.Mode.Explicit };
        helpNavigation.selectOnUp = titleStageButton;
        titleHelpButton.navigation = helpNavigation;

        CreateUiText(titleStageButton.transform, "ステージを選ぶ", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleHelpButton.transform, "操作説明", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleHelpBackButton.transform, "タイトルへ戻る", 18, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleUpgradeButton.transform, "強化画面", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapTitleButton.transform, "タイトルへ戻る", 18, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapEquipmentButton.transform, "装備", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapGachaButton.transform, "装備ガチャ", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        mapTravelButtonLabel = CreateUiText(mapTravelButton.transform, "マップ選択", 18,
            Color.white, TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapPreviousPageButton.transform, "前のマップ", 16, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapNextPageButton.transform, "次のマップ", 16, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        CreateUiText(developmentDebugButton.transform, "開発デバッグ", 14,
            new Color(1f, 0.86f, 0.36f, 1f), TextAnchor.MiddleCenter,
            Vector2.zero, Vector2.zero);
#endif

        titleVisualRoot = CreateUiRoot("TitleVisual");
        titleHelpVisualRoot = CreateUiRoot("TitleHelpVisual");
        mapVisualRoot = CreateUiRoot("MapVisual");
        RectTransform mapRootRect = mapVisualRoot.GetComponent<RectTransform>();
        mapRootRect.anchorMin = new Vector2(0.5f, 0.5f);
        mapRootRect.anchorMax = new Vector2(0.5f, 0.5f);
        mapRootRect.sizeDelta = new Vector2(1280f, 720f);
        mapRootRect.anchoredPosition = Vector2.zero;
        upgradeVisualRoot = CreateUiRoot("UpgradeVisual");
        equipmentVisualRoot = CreateUiRoot("EquipmentVisual");
        CreateTitleVisual(titleVisualRoot.transform);
        CreateTitleHelpVisual(titleHelpVisualRoot.transform);
        CreateUpgradeVisual(upgradeVisualRoot.transform);
        CreateEquipmentVisual(equipmentVisualRoot.transform);
        CreateSkillTreePanOverlay();
        // Keep the title background behind the two visible button objects.
        titleVisualRoot.transform.SetAsFirstSibling();
        titleHelpVisualRoot.transform.SetAsFirstSibling();
        titleHelpVisualRoot.SetActive(false);
    }

    private GameObject CreateUiRoot(string objectName)
    {
        GameObject root = new GameObject(objectName, typeof(RectTransform));
        root.transform.SetParent(titleButtonCanvasObject.transform, false);
        RectTransform rect = root.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        return root;
    }

    private void CreateTitleVisual(Transform root)
    {
        CreateUiImage(root, "TitleBackground", Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);

        GameObject panel = CreateUiImage(root, "TitlePanel", Vector2.zero,
            new Vector2(TitlePanelWidth, TitlePanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        CreateUiImage(panel.transform, "TitlePanelTopLine", new Vector2(0f, 313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "TitlePanelBottomLine", new Vector2(0f, -313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiText(panel.transform, "WITCH & HERO", 52, Color.white,
            TextAnchor.MiddleCenter, new Vector2(0f, 148f), new Vector2(860f, 80f));
        CreateUiText(panel.transform, "魔女と勇者の小さな冒険", 22,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, 82f), new Vector2(860f, 42f));
        CreateUiText(panel.transform, "↑↓で選択 / ENTER・SPACEで決定 / V：音量", 18,
            new Color(0.72f, 0.82f, 0.88f), TextAnchor.MiddleCenter,
            new Vector2(0f, -276f), new Vector2(860f, 34f));
    }

    private void CreateTitleHelpVisual(Transform root)
    {
        CreateUiImage(root, "HelpBackground", Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);

        GameObject panel = CreateUiImage(root, "HelpPanel", Vector2.zero,
            new Vector2(TitlePanelWidth, TitlePanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        CreateUiImage(panel.transform, "HelpPanelTopLine", new Vector2(0f, 313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "HelpPanelBottomLine", new Vector2(0f, -313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiText(panel.transform, "操作説明", 42, Color.white,
            TextAnchor.MiddleCenter, new Vector2(0f, 235f), new Vector2(860f, 64f));
        CreateUiText(panel.transform, "タイトル画面・ワールドマップ", 18,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, 190f), new Vector2(860f, 34f));

        CreateUiText(panel.transform, "WASD / 矢印キー", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, 115f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "メニューの移動・ステージ選択", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, 115f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "ENTER / SPACE", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, 55f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "決定・ステージ情報を開く", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, 55f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "クリック / ドラッグ", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, -5f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "ノードを選ぶ・マップを動かす", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, -5f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "戦闘中", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, -65f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "WASD / 矢印キー：ヒーロー移動　 E：魔女スキル",
            18, new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, -65f), new Vector2(560f, 42f));

        CreateUiText(panel.transform, "ESC：前の画面へ戻る", 20,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, -145f), new Vector2(860f, 34f));
    }

    private void CreateUpgradeVisual(Transform root)
    {
        CreateUiImage(root, "UpgradeBackground", Vector2.zero, Vector2.zero,
            new Color(0.018f, 0.045f, 0.075f, 0.98f), true);
        GameObject panel = CreateUiImage(root, "UpgradePanel", Vector2.zero,
            new Vector2(MapPanelWidth, MapPanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.96f), true);
        CreateUiImage(panel.transform, "UpgradePanelTopLine", new Vector2(0f, 338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "UpgradePanelBottomLine", new Vector2(0f, -338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
    }

    private void CreateEquipmentVisual(Transform root)
    {
        CreateUiImage(root, "EquipmentBackground", Vector2.zero, Vector2.zero,
            new Color(0.015f, 0.035f, 0.06f, 0.99f), true);
        GameObject panel = CreateUiImage(root, "EquipmentPanel", Vector2.zero,
            new Vector2(MapPanelWidth, MapPanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), true);
        CreateUiImage(panel.transform, "EquipmentPanelTopLine", new Vector2(0f, 338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "EquipmentPanelBottomLine", new Vector2(0f, -338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
    }

    private GameObject CreateUiImage(Transform parent, string objectName,
        Vector2 anchoredPosition, Vector2 size, Color color, bool stretchToParent)
    {
        GameObject imageObject = new GameObject(objectName, typeof(RectTransform), typeof(Image));
        imageObject.transform.SetParent(parent, false);
        RectTransform rect = imageObject.GetComponent<RectTransform>();
        rect.anchorMin = stretchToParent ? Vector2.zero : new Vector2(0.5f, 0.5f);
        rect.anchorMax = stretchToParent ? Vector2.one : new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        if (stretchToParent)
        {
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }
        else
        {
            rect.sizeDelta = size;
            rect.anchoredPosition = anchoredPosition;
        }
        Image image = imageObject.GetComponent<Image>();
        image.sprite = GetUiWhiteSprite();
        image.color = color;
        image.raycastTarget = false;
        return imageObject;
    }

    private Sprite GetUiWhiteSprite()
    {
        if (uiWhiteSprite == null)
        {
            uiWhiteSprite = Sprite.Create(Texture2D.whiteTexture,
                new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 1f);
            uiWhiteSprite.name = "RuntimeUIWhiteSprite";
        }

        return uiWhiteSprite;
    }

    private Text CreateUiText(Transform parent, string textValue, int fontSize,
        Color color, TextAnchor alignment, Vector2 anchoredPosition, Vector2 size)
    {
        GameObject textObject = new GameObject("Text", typeof(RectTransform), typeof(Text));
        textObject.transform.SetParent(parent, false);
        RectTransform rect = textObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.sizeDelta = size == Vector2.zero ? new Vector2(360f, 58f) : size;
        rect.anchoredPosition = anchoredPosition;
        Text text = textObject.GetComponent<Text>();
        text.text = textValue;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.fontSize = fontSize;
        text.alignment = alignment;
        text.color = color;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.raycastTarget = false;
        return text;
    }

    private Button CreateTitleButton(string objectName, UnityEngine.Events.UnityAction onClick,
        out RectTransform buttonRect)
    {
        GameObject buttonObject = new GameObject(objectName, typeof(RectTransform), typeof(Image), typeof(Button));
        buttonRect = buttonObject.GetComponent<RectTransform>();
        buttonRect.anchorMin = new Vector2(0.5f, 0.5f);
        buttonRect.anchorMax = new Vector2(0.5f, 0.5f);
        buttonRect.pivot = new Vector2(0.5f, 0.5f);

        Image image = buttonObject.GetComponent<Image>();
        image.color = new Color(0.12f, 0.34f, 0.48f, 0.96f);
        image.raycastTarget = true;

        Button button = buttonObject.GetComponent<Button>();
        button.targetGraphic = image;
        button.transition = Selectable.Transition.None;
        button.navigation = new Navigation { mode = Navigation.Mode.None };
        TitleButtonHoverRelay hoverRelay =
            buttonObject.AddComponent<TitleButtonHoverRelay>();
        hoverRelay.owner = this;
        hoverRelay.button = button;
        // Visual-only button. Input is handled by the single OnGUI target so
        // the same click cannot be delivered to both title and map buttons.
        button.interactable = false;
        return button;
    }

    private Texture2D GetGuiButtonBackground(ref Texture2D cache, Color color,
        string textureName)
    {
        if (cache != null) return cache;

        cache = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        cache.name = textureName;
        cache.hideFlags = HideFlags.HideAndDontSave;
        cache.SetPixel(0, 0, color);
        cache.Apply();
        return cache;
    }

    private GUIStyle CreateHoverButtonStyle(int fontSize, FontStyle fontStyle = FontStyle.Normal)
    {
        GUIStyle style = new GUIStyle(GUI.skin.button)
        {
            fontSize = fontSize,
            fontStyle = fontStyle,
            alignment = TextAnchor.MiddleCenter
        };
        style.border = new RectOffset(6, 6, 6, 6);
        style.normal.background = GetGuiButtonBackground(ref guiButtonNormalBackground,
            // Keep IMGUI buttons visually identical to the runtime Canvas
            // buttons used by the map footer, including the gacha button.
            new Color(0.12f, 0.34f, 0.48f, 0.96f), "GuiButtonNormal");
        style.hover.background = GetGuiButtonBackground(ref guiButtonHoverBackground,
            new Color(0.25f, 0.55f, 0.68f, 1f), "GuiButtonHover");
        style.active.background = GetGuiButtonBackground(ref guiButtonActiveBackground,
            new Color(0.85f, 0.62f, 0.20f, 1f), "GuiButtonActive");
        style.focused.background = style.hover.background;
        style.normal.textColor = Color.white;
        style.hover.textColor = new Color(1f, 0.95f, 0.62f);
        style.active.textColor = Color.white;
        style.focused.textColor = style.hover.textColor;
        return style;
    }

    private bool IsGuiRectHovered(Rect rect)
    {
        return TryGetGuiPointerPosition(out Vector2 pointer) &&
            rect.Contains(pointer);
    }

    private bool TryGetGuiPointerPosition(out Vector2 pointer)
    {
        pointer = Vector2.zero;

        bool hasPointerEvent = Event.current != null &&
            (Event.current.type == EventType.MouseMove ||
             Event.current.type == EventType.MouseDown ||
             Event.current.type == EventType.MouseUp ||
             Event.current.type == EventType.MouseDrag ||
             Event.current.type == EventType.ScrollWheel);
        if (hasPointerEvent)
        {
            // Convert the editor's local IMGUI event through the actual Game
            // view bounds. This remains correct when the Game view is scaled,
            // docked, or shown on a Retina display.
            Vector2 screenPoint = GUIUtility.GUIToScreenPoint(
                Event.current.mousePosition);
            pointer = GetPointerScreenPoint(screenPoint);
            pointer.y = Screen.height - pointer.y;
            pointer = PhysicalGuiPointToFrontendPoint(pointer);
            return true;
        }

        Mouse mouse = Mouse.current;
        if (mouse == null) return false;

        // Input System mouse coordinates are already relative to the Game
        // view and use a bottom-left origin. Do not subtract the Editor
        // window origin here; that conversion is only for IMGUI event
        // coordinates obtained through GUIToScreenPoint above.
        pointer = mouse.position.ReadValue();
        pointer.y = Screen.height - pointer.y;
        pointer = PhysicalGuiPointToFrontendPoint(pointer);
        return true;
    }

    private bool IsPhysicalFrontendRectPressed(Mouse mouse, Rect designRect)
    {
        if (mouse == null)
            return false;

        GetFrontendGuiMetrics(out float scale, out Vector2 offset,
            out _, out _);
        Vector2 physicalPointer = mouse.position.ReadValue();
        physicalPointer.y = Screen.height - physicalPointer.y;
        Rect physicalRect = new Rect(
            offset.x + designRect.x * scale,
            offset.y + (FrontendReferenceHeight - designRect.y - designRect.height) * scale,
            designRect.width * scale,
            designRect.height * scale);
        return physicalRect.Contains(physicalPointer);
    }

    private void UpdateTitleButtonHover(Button button, Rect designRect, bool selected)
    {
        if (button == null) return;

        Image image = button.GetComponent<Image>();
        if (image == null) return;

        // The visible Canvas is authored in the 1280x720 frontend coordinate
        // system. Use the same converted pointer as the IMGUI hit tests; the
        // old code compared a physical Screen rect with an editor-local
        // mouse position, which could make the highlight appear mirrored or
        // offset when the Game view was scaled/docked.
        // Derive the state from the current pointer every frame. The Canvas
        // buttons are intentionally non-interactable visual controls, so a
        // pointer-enter relay can remain latched to the button that was under
        // the cursor when the screen opened and make the hover color look
        // frozen. The live pointer check keeps map/stage navigation buttons
        // responsive while the cursor moves.
        bool hovered = TryGetGuiPointerPosition(out Vector2 pointer) &&
            designRect.Contains(pointer);

        // The Canvas button is visual-only, so do not depend on Unity's
        // Selectable hover state.  Check its real screen-space rectangle too;
        // this remains correct when the Game view is docked or scaled in the
        // Editor, where the design-coordinate conversion can be offset.
        RectTransform buttonRect = button.GetComponent<RectTransform>();
        Mouse mouse = Mouse.current;
        if (buttonRect != null && mouse != null)
        {
            Vector2 screenPointer = mouse.position.ReadValue();
            hovered |= RectTransformUtility.RectangleContainsScreenPoint(
                buttonRect, screenPointer, null);
        }

        image.color = hovered
            ? new Color(0.25f, 0.55f, 0.68f, 1f)
            : selected
                ? new Color(0.18f, 0.43f, 0.58f, 1f)
                : new Color(0.12f, 0.34f, 0.48f, 0.96f);
    }

    private void UpdateTitleButtonOverlay()
    {
        if (titleButtonCanvasObject == null) return;

        // Stage selection is driven by GameFlow so WASD/arrow selection and
        // Enter confirmation always use the same selectedStage value. Pointer
        // clicks still reach the node Buttons, but Unity's automatic submit
        // navigation must not activate a stale node behind the map.
        if (EventSystem.current != null)
            EventSystem.current.sendNavigationEvents = state != GameState.Menu &&
                state != GameState.Equipment;

        // The canvas is visual-only. Input is handled by OnGUI so the same
        // pointer event cannot be delivered to both title and map controls.
        bool overlayVisible = state == GameState.Title ||
            state == GameState.Menu || state == GameState.Upgrade ||
            state == GameState.Equipment || state == GameState.Gacha;
        titleButtonCanvasObject.SetActive(overlayVisible);
        if (stageModalInputBlocker != null)
        {
            bool blockMapInput = state == GameState.Menu &&
                (stageInfoOpen || stageGroupInfoOpen);
            stageModalInputBlocker.SetActive(blockMapInput);
            if (blockMapInput)
                stageModalInputBlocker.transform.SetAsLastSibling();
        }
        bool showingTitle = state == GameState.Title && !titleHelpOpen;
        bool showingTitleHelp = state == GameState.Title && titleHelpOpen;
        if (titleVisualRoot != null) titleVisualRoot.SetActive(showingTitle);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(showingTitleHelp);
        if (titleStageButton != null)
        {
            titleStageButton.gameObject.SetActive(showingTitle);
            UpdateTitleButtonHover(titleStageButton, GetTitleStageButtonDesignRect(),
                false);
        }
        if (titleHelpButton != null)
        {
            titleHelpButton.gameObject.SetActive(showingTitle);
            UpdateTitleButtonHover(titleHelpButton, GetTitleHelpButtonDesignRect(),
                false);
        }
        if (titleHelpBackButton != null)
        {
            titleHelpBackButton.gameObject.SetActive(showingTitleHelp);
            UpdateTitleButtonHover(titleHelpBackButton,
                GetTitleHelpBackButtonDesignRect(), false);
        }
        if (titleUpgradeButton != null)
        {
            bool showMapUpgradeButton = state == GameState.Menu;
            titleUpgradeButton.gameObject.SetActive(showMapUpgradeButton);
            if (showMapUpgradeButton)
                titleUpgradeButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(titleUpgradeButton, GetMapUpgradeButtonDesignRect(),
                false);
        }
        if (mapTitleButton != null)
        {
            bool showMapTitleButton = state == GameState.Menu;
            mapTitleButton.gameObject.SetActive(showMapTitleButton);
            if (showMapTitleButton)
                mapTitleButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapTitleButton, GetMapTitleButtonDesignRect(),
                false);
            UpdateTitleButtonHover(mapEquipmentButton,
                GetMapEquipmentButtonDesignRect(), false);
        }
        if (mapEquipmentButton != null)
        {
            bool showEquipmentButton = state == GameState.Menu;
            mapEquipmentButton.gameObject.SetActive(showEquipmentButton);
            if (showEquipmentButton)
                mapEquipmentButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapEquipmentButton,
                GetMapEquipmentButtonDesignRect(), false);
        }
        if (mapGachaButton != null)
        {
            // Render this with the same Canvas button as the other map
            // controls. The IMGUI layer below is only a transparent click
            // target, so its hover style cannot make this button brighter.
            bool showMapGachaButton = state == GameState.Menu;
            mapGachaButton.gameObject.SetActive(showMapGachaButton);
            if (showMapGachaButton)
                mapGachaButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapGachaButton,
                GetMapGachaButtonDesignRect(), false);
        }
        if (mapTravelButton != null)
        {
            // Keep the map-selection screen available from the route map.
            // It selects STAGE groups; it is not a fake MAP1/MAP2 page.
            bool showMapTravelButton = state == GameState.Menu &&
                !stageInfoOpen && !stageGroupInfoOpen;
            mapTravelButton.gameObject.SetActive(showMapTravelButton);
            if (showMapTravelButton)
                mapTravelButton.transform.SetAsLastSibling();
            if (mapTravelButtonLabel != null)
                mapTravelButtonLabel.text = mapTravelMode ? "ステージ選択へ" : "マップ選択";
            UpdateTitleButtonHover(mapTravelButton,
                GetMapTravelButtonDesignRect(), false);
        }

        // The stage info popup owns all input while it is open.  Disable the
        // map's node buttons so a click cannot select another LEVEL behind
        // the 「挑む / やめる」 dialog.
        bool allowMapNodeInput = state == GameState.Menu &&
            !stageInfoOpen && !stageGroupInfoOpen && !mapTravelMode;
        List<StageDefinition> allMapStages = GetStages();
        foreach (KeyValuePair<Button, int> entry in mapStageButtons)
        {
            if (entry.Key == null) continue;
            bool unlocked = IsStageUnlocked(entry.Value, allMapStages);
            // The transparent hit target is the only control that needs to be
            // disabled behind a modal.  Keep the visible StageNode button
            // interactable so Unity never applies its disabled tint to the
            // artwork and makes the node disappear.
            bool isTransparentHitTarget = entry.Key.gameObject.name
                .StartsWith("StageHitTarget_");
            entry.Key.interactable = isTransparentHitTarget
                ? allowMapNodeInput && unlocked
                : unlocked;
        }
        int highestUnlockedMapPage = GetHighestUnlockedMapPage();
        bool showMapPageControls = state == GameState.Menu &&
            !stageInfoOpen && !stageGroupInfoOpen &&
            !mapTravelMode;
        if (mapPreviousPageButton != null)
        {
            bool showPrevious = showMapPageControls && currentMapPage > 1;
            mapPreviousPageButton.gameObject.SetActive(showPrevious);
            if (showPrevious)
                mapPreviousPageButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapPreviousPageButton,
                new Rect(70f, 18f, 190f, 38f), false);
        }
        if (mapNextPageButton != null)
        {
            // Keep the next-map control hidden until the current map is
            // cleared. Once unlocked, the player can move back and forth
            // between map pages and the last page is restored on reopen.
            bool showNext = showMapPageControls && currentMapPage < highestUnlockedMapPage;
            mapNextPageButton.gameObject.SetActive(showNext);
            if (showNext)
                mapNextPageButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapNextPageButton,
                new Rect(850f, 18f, 190f, 38f), false);
        }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (developmentDebugButton != null)
        {
            bool showDevelopmentDebugButton =
                (state == GameState.Title || state == GameState.Menu) &&
                !developmentDebugPanelOpen;
            developmentDebugButton.gameObject.SetActive(showDevelopmentDebugButton);
            if (showDevelopmentDebugButton)
                developmentDebugButton.transform.SetAsLastSibling();
        }

        if (developmentDebugPanelOpen)
        {
            titleButtonCanvasObject.SetActive(false);
            if (titleVisualRoot != null)
                titleVisualRoot.SetActive(false);
            if (titleHelpVisualRoot != null)
                titleHelpVisualRoot.SetActive(false);
            if (mapVisualRoot != null)
                mapVisualRoot.SetActive(false);
            if (titleStageButton != null)
                titleStageButton.gameObject.SetActive(false);
            if (titleHelpButton != null)
                titleHelpButton.gameObject.SetActive(false);
            if (titleHelpBackButton != null)
                titleHelpBackButton.gameObject.SetActive(false);
            if (titleUpgradeButton != null)
                titleUpgradeButton.gameObject.SetActive(false);
            if (mapTitleButton != null)
                mapTitleButton.gameObject.SetActive(false);
            if (mapEquipmentButton != null)
                mapEquipmentButton.gameObject.SetActive(false);
            if (mapGachaButton != null)
                mapGachaButton.gameObject.SetActive(false);
            if (mapTravelButton != null)
                mapTravelButton.gameObject.SetActive(false);
            if (developmentDebugButton != null)
                developmentDebugButton.gameObject.SetActive(false);
        }
#endif
        // The map is both rendered and interacted with by the same Canvas
        // ScrollRect. Keeping a separate transparent input overlay here made
        // it possible for the editor to send the drag to one surface while
        // the visible map was drawn by another surface.
        // MapScene uses the single IMGUI map below so camera movement and
        // the visible map always share one rendering path.
        // The map has a world-space background as well as the Canvas map.
        // Hide both while showing equipment/gacha so the front-end panel is
        // not composited over the stage-select artwork.
        if (mapVisualRoot != null) mapVisualRoot.SetActive(state == GameState.Menu);
        if (mapWorldBackground != null)
            mapWorldBackground.SetActive(state == GameState.Menu);
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (developmentDebugPanelOpen && mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
#endif
        if (mapPanOverlay != null) mapPanOverlay.SetActive(false);
        if (upgradeVisualRoot != null) upgradeVisualRoot.SetActive(state == GameState.Upgrade);
        if (equipmentVisualRoot != null)
            equipmentVisualRoot.SetActive(state == GameState.Equipment);
        if (skillTreePanOverlay != null)
        {
            bool showSkillTreeInput = state == GameState.Upgrade;
            skillTreePanOverlay.SetActive(showSkillTreeInput);
            if (showSkillTreeInput)
            {
                skillTreePanOverlay.transform.SetAsLastSibling();
                SyncSkillTreePanOverlayFromPosition();
            }
        }

        if (state == GameState.Menu && mapVisualBuildPending)
        {
            mapVisualBuildPending = false;
            CreateMapVisual();
        }
    }

    private void SetTitleButtonRect(RectTransform buttonRect, float x, float y,
        float width, float height)
    {
        const float designWidth = 1280f;
        const float designHeight = 720f;
        buttonRect.sizeDelta = new Vector2(width, height);
        buttonRect.anchoredPosition = new Vector2(
            x + width * 0.5f - designWidth * 0.5f,
            designHeight * 0.5f - (y + height * 0.5f));
    }

    private void OpenStageMenu()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = false;
        state = GameState.Menu;
        mapTravelMode = false;
        ClampCurrentMapPageToUnlocked();
        ClampSelectedStageToUnlocked();
        ClampSelectedStageToCurrentMap();
        mapVisualBuildPending = false;
        if (titleVisualRoot != null) titleVisualRoot.SetActive(false);
        if (mapVisualRoot != null) mapVisualRoot.SetActive(true);
        CreateMapVisual();
        // Reopen the map around the currently selected LEVEL node so the
        // original route's first nodes are not left outside the viewport.
        List<StageDefinition> mapStages = GetCurrentMapStages();
        if (mapStages.Count > 0)
            FocusMapOnStage(GetStageIndex(selectedStage, mapStages), mapStages.Count);
        RefreshMapStagePresentation();
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void ToggleMapTravelMode()
    {
        if (state != GameState.Menu || stageInfoOpen || stageGroupInfoOpen)
            return;

        // A single tap can reach both the InputSystem path and the
        // transparent OnGUI hit target during the same frame. Prevent the
        // second callback from switching the mode straight back.
        if (mapTravelToggleFrame == Time.frameCount)
            return;
        if (Time.unscaledTime - mapTravelToggleTime < 0.35f)
            return;
        mapTravelToggleFrame = Time.frameCount;
        mapTravelToggleTime = Time.unscaledTime;

        PlayConfirmSound();
        mapTravelMode = !mapTravelMode;
        RebuildMapVisualForCurrentPage();
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void ReturnToTitle()
    {
        if (state != GameState.Menu) return;

        PlayConfirmSound();
        if (mapHeroMoveRoutine != null)
        {
            StopCoroutine(mapHeroMoveRoutine);
            mapHeroMoveRoutine = null;
        }
        if (mapFocusRoutine != null)
        {
            StopCoroutine(mapFocusRoutine);
            mapFocusRoutine = null;
        }

        stageInfoOpen = false;
        stageInfoStageId = 0;
        stageGroupInfoOpen = false;
        stageGroupInfoMapPage = 0;
        stageGroupInfoId = 0;
        stageGroupInfoChoice = 0;
        titleHelpOpen = false;
        titleSelection = 0;
        state = GameState.Title;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
        if (titleStageButton != null)
            titleStageButton.gameObject.SetActive(false);
        if (titleHelpButton != null)
            titleHelpButton.gameObject.SetActive(false);
        if (titleHelpBackButton != null)
            titleHelpBackButton.gameObject.SetActive(false);
        if (titleUpgradeButton != null)
            titleUpgradeButton.gameObject.SetActive(false);
        if (mapTitleButton != null)
            mapTitleButton.gameObject.SetActive(false);
        if (mapEquipmentButton != null)
            mapEquipmentButton.gameObject.SetActive(false);
        if (mapGachaButton != null)
            mapGachaButton.gameObject.SetActive(false);
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(true);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(false);
        EventSystem.current?.SetSelectedGameObject(null);
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void OpenUpgradeMenu()
    {
        PlayConfirmSound();
        state = GameState.Upgrade;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
        resetProgressConfirm = false;
        skillTreePan = Vector2.zero;
        pendingSkillTreeScroll = Vector2.zero;
        skillTreePointerHeld = false;
        skillTreeSuppressNodeClick = false;
        FocusSkillTreeOnFirstAvailableNode();
        SyncSkillTreePanOverlayFromPosition();
        // Apply the page visibility immediately. This method can be called
        // from an IMGUI click while the stage-select buttons are still being
        // drawn in the same frame.
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void OpenEquipmentMenu()
    {
        if (state != GameState.Menu) return;

        PlayConfirmSound();
        state = GameState.Equipment;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
        equipmentFocusSlot = 0;
        equipmentFocusItem = 0;
        // Open directly on the weapon list. The equipment page should be
        // immediately usable instead of showing an extra "select a slot"
        // instruction screen first.
        equipmentListOpen = true;
        equipmentListScroll = Vector2.zero;
        equipmentLastHandledKey = KeyCode.None;
        equipmentLastHandledKeyTime = -1f;
        EventSystem.current?.SetSelectedGameObject(null);
        // Hide the world-map controls in the same frame as the transition.
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void OpenGachaMenu()
    {
        if (state != GameState.Menu) return;

        PlayConfirmSound();
        state = GameState.Gacha;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
        gachaResultItemId = -1;
        gachaResultSlot = EquipmentSystem.Slot.Weapon;
        gachaSlotFilter = -1;
        ticketGachaSelected = false;
        gachaRatesOpen = false;
        gachaResultPopupOpen = false;
        gachaLineupScroll = Vector2.zero;
        gachaRatesScroll = Vector2.zero;
        gachaResultIsNew = false;
        gachaResults.Clear();
        gachaMessage = "装備を引いて、所持品を増やそう";
        gachaMessageTimer = 0f;
        EventSystem.current?.SetSelectedGameObject(null);
        // Hide the world-map controls in the same frame as the transition.
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void HandleGachaInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        if ((gachaRatesOpen || gachaResultPopupOpen) &&
            (keyboard.escapeKey.wasPressedThisFrame ||
                keyboard.bKey.wasPressedThisFrame))
        {
            gachaRatesOpen = false;
            gachaResultPopupOpen = false;
            RequestEditorRepaint();
            return;
        }

        if (gachaRatesOpen || gachaResultPopupOpen)
            return;

        if (keyboard.escapeKey.wasPressedThisFrame ||
            keyboard.bKey.wasPressedThisFrame)
        {
            ReturnToMenu();
            return;
        }

        if (keyboard.enterKey.wasPressedThisFrame ||
            keyboard.numpadEnterKey.wasPressedThisFrame ||
            keyboard.spaceKey.wasPressedThisFrame)
        {
            if (ticketGachaSelected)
                TryPullTicketGacha();
            else
                TryPullEquipmentGacha();
            return;
        }

        if (keyboard.tKey.wasPressedThisFrame)
            TryPullEquipmentGachaTen();
    }

    private void TryPullEquipmentGacha()
    {
        gachaResults.Clear();
        if (coins < EquipmentGachaCost)
        {
            gachaResultItemId = -1;
            gachaResultIsNew = false;
            gachaMessage = "コインが足りません";
            gachaMessageTimer = GachaMessageDuration;
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        EquipmentGachaResult result;
        if (!TryRollEquipmentGachaResult(out result))
        {
            gachaResultItemId = -1;
            gachaResultIsNew = false;
            gachaMessage = "排出できる装備がありません";
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        gachaResultIsNew = result.isNew;
        coins -= EquipmentGachaCost;
        PlayerPrefs.SetInt(CoinBalanceKey, Mathf.Max(0, coins));
        PlayerPrefs.Save();

        gachaResults.Add(result);
        EquipmentSystem.Item resultItem = EquipmentSystem.GetItem(
            result.slot, result.itemId);
        gachaResultSlot = result.slot;
        gachaResultItemId = result.itemId;
        gachaMessage = result.isNew
            ? $"{EquipmentSystem.GetRarityStars(resultItem.rarity)}  {EquipmentSystem.GetSlotName(result.slot)}を獲得！"
            : "すでに持っている装備が出ました";
        gachaResultPopupOpen = true;
        PlayConfirmSound();
        RequestEditorRepaint();
    }

    private void TryPullEquipmentGachaTen()
    {
        gachaResults.Clear();
        gachaResultItemId = -1;
        gachaResultIsNew = false;

        if (coins < EquipmentTenGachaCost)
        {
            gachaMessage = "コインが足りません";
            gachaMessageTimer = GachaMessageDuration;
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        List<EquipmentSystem.Slot> poolSlots;
        List<EquipmentSystem.Item> poolItems;
        GetGachaPool(out poolSlots, out poolItems);
        if (poolItems.Count == 0)
        {
            gachaMessage = "排出できる装備がありません";
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        int newItemCount = 0;
        for (int i = 0; i < EquipmentTenGachaCount; i++)
        {
            EquipmentGachaResult result;
            if (!TryRollEquipmentGachaResult(out result))
                break;

            gachaResults.Add(result);
            if (result.isNew)
                newItemCount++;
        }

        coins -= EquipmentTenGachaCost;
        PlayerPrefs.SetInt(CoinBalanceKey, Mathf.Max(0, coins));
        PlayerPrefs.Save();
        gachaMessage = $"10連完了！新規装備 {newItemCount}個";
        gachaResultPopupOpen = true;
        PlayConfirmSound();
        RequestEditorRepaint();
    }

    private void TryPullTicketGacha()
    {
        gachaResults.Clear();
        gachaResultItemId = -1;
        gachaResultIsNew = false;

        if (gachaTickets < TicketGachaCost)
        {
            gachaMessage = "ガチャチケットが足りません";
            gachaMessageTimer = GachaMessageDuration;
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        EquipmentGachaResult result;
        if (!TryRollTicketGachaResult(out result))
        {
            gachaMessage = "排出できる装備がありません";
            PlayConfirmSound();
            RequestEditorRepaint();
            return;
        }

        gachaTickets -= TicketGachaCost;
        PlayerPrefs.SetInt(GachaTicketBalanceKey, Mathf.Max(0, gachaTickets));
        PlayerPrefs.Save();

        gachaResultIsNew = result.isNew;
        gachaResults.Add(result);
        EquipmentSystem.Item resultItem = EquipmentSystem.GetItem(
            result.slot, result.itemId);
        gachaResultSlot = result.slot;
        gachaResultItemId = result.itemId;
        gachaMessage = result.isNew
            ? $"{EquipmentSystem.GetRarityStars(resultItem.rarity)}  チケット限定装備を獲得！"
            : "すでに持っている装備が出ました";
        gachaResultPopupOpen = true;
        PlayConfirmSound();
        RequestEditorRepaint();
    }

    private bool TryRollEquipmentGachaResult(out EquipmentGachaResult result)
    {
        List<EquipmentSystem.Slot> poolSlots;
        List<EquipmentSystem.Item> poolItems;
        GetGachaPool(out poolSlots, out poolItems);
        return TryRollGachaResultFromPool(poolSlots, poolItems, out result);
    }

    private bool TryRollTicketGachaResult(out EquipmentGachaResult result)
    {
        List<EquipmentSystem.Slot> poolSlots;
        List<EquipmentSystem.Item> poolItems;
        GetTicketGachaPool(out poolSlots, out poolItems);
        return TryRollGachaResultFromPool(poolSlots, poolItems, out result);
    }

    private bool TryRollGachaResultFromPool(
        List<EquipmentSystem.Slot> poolSlots,
        List<EquipmentSystem.Item> poolItems,
        out EquipmentGachaResult result)
    {
        result = new EquipmentGachaResult
        {
            slot = EquipmentSystem.Slot.Weapon,
            itemId = -1,
            isNew = false
        };

        if (poolItems.Count == 0)
            return false;

        EquipmentSystem.Rarity rarity = RollGachaRarity(poolItems);
        List<int> rarityCandidates = new List<int>();
        for (int i = 0; i < poolItems.Count; i++)
        {
            if (poolItems[i].rarity == rarity)
                rarityCandidates.Add(i);
        }

        List<int> unownedCandidates = new List<int>();
        for (int i = 0; i < rarityCandidates.Count; i++)
        {
            int poolIndex = rarityCandidates[i];
            if (!EquipmentSystem.IsOwned(poolSlots[poolIndex],
                poolItems[poolIndex].id))
                unownedCandidates.Add(poolIndex);
        }

        List<int> selectionPool = unownedCandidates.Count > 0
            ? unownedCandidates
            : rarityCandidates;
        int selectedPoolIndex = selectionPool[Random.Range(0, selectionPool.Count)];
        result.slot = poolSlots[selectedPoolIndex];
        result.itemId = poolItems[selectedPoolIndex].id;
        result.isNew = !EquipmentSystem.IsOwned(result.slot, result.itemId);
        if (result.isNew)
            EquipmentSystem.Unlock(result.slot, result.itemId);

        return true;
    }

    private void GetTicketGachaPool(out List<EquipmentSystem.Slot> slots,
        out List<EquipmentSystem.Item> items)
    {
        slots = new List<EquipmentSystem.Slot>();
        items = new List<EquipmentSystem.Item>();
        EquipmentSystem.Item[] ticketItems = EquipmentSystem.GetTicketGachaItems();
        for (int i = 0; i < ticketItems.Length; i++)
        {
            slots.Add(EquipmentSystem.Slot.Weapon);
            items.Add(ticketItems[i]);
        }
    }

    private void GetGachaPool(out List<EquipmentSystem.Slot> slots,
        out List<EquipmentSystem.Item> items)
    {
        slots = new List<EquipmentSystem.Slot>();
        items = new List<EquipmentSystem.Item>();
        EquipmentSystem.Slot[] allSlots =
        {
            EquipmentSystem.Slot.Weapon,
            EquipmentSystem.Slot.Armor,
            EquipmentSystem.Slot.Boots,
            EquipmentSystem.Slot.Pet
        };

        for (int slotIndex = 0; slotIndex < allSlots.Length; slotIndex++)
        {
            if (gachaSlotFilter >= 0 && gachaSlotFilter != slotIndex)
                continue;

            EquipmentSystem.Item[] slotItems = EquipmentSystem.GetItems(
                allSlots[slotIndex]);
            for (int itemIndex = 0; itemIndex < slotItems.Length; itemIndex++)
            {
                if (EquipmentSystem.IsTicketOnly(allSlots[slotIndex],
                    slotItems[itemIndex].id))
                    continue;
                slots.Add(allSlots[slotIndex]);
                items.Add(slotItems[itemIndex]);
            }
        }

        // Keep the visual lineup easy to scan: common items first, then
        // rare, epic and legendary items. The same ordered pool is still
        // used for the draw, so this changes presentation only and does not
        // alter the configured probabilities.
        List<int> order = new List<int>();
        for (int i = 0; i < items.Count; i++)
            order.Add(i);
        List<EquipmentSystem.Slot> poolSlots = slots;
        List<EquipmentSystem.Item> poolItems = items;
        order.Sort((left, right) =>
        {
            int rarityOrder = ((int)poolItems[left].rarity).CompareTo(
                (int)poolItems[right].rarity);
            if (rarityOrder != 0)
                return rarityOrder;

            int slotOrder = ((int)poolSlots[left]).CompareTo(
                (int)poolSlots[right]);
            if (slotOrder != 0)
                return slotOrder;

            return poolItems[left].id.CompareTo(poolItems[right].id);
        });

        List<EquipmentSystem.Slot> sortedSlots =
            new List<EquipmentSystem.Slot>(slots.Count);
        List<EquipmentSystem.Item> sortedItems =
            new List<EquipmentSystem.Item>(items.Count);
        for (int i = 0; i < order.Count; i++)
        {
            sortedSlots.Add(slots[order[i]]);
            sortedItems.Add(items[order[i]]);
        }

        slots = sortedSlots;
        items = sortedItems;
    }

    private static EquipmentSystem.Rarity RollGachaRarity(
        List<EquipmentSystem.Item> poolItems)
    {
        // 70% common / 22% rare / 7% epic / 1% legendary. If a slot filter
        // does not contain one rarity, its weight is removed and the other
        // available rarities are normalized instead of making a high rarity
        // item unexpectedly common.
        EquipmentSystem.Rarity[] rarities =
        {
            EquipmentSystem.Rarity.Common,
            EquipmentSystem.Rarity.Rare,
            EquipmentSystem.Rarity.Epic,
            EquipmentSystem.Rarity.Legendary
        };
        int[] weights = { 70, 22, 7, 1 };
        int totalWeight = 0;
        for (int i = 0; i < rarities.Length; i++)
        {
            bool present = false;
            for (int item = 0; item < poolItems.Count; item++)
            {
                if (poolItems[item].rarity == rarities[i])
                {
                    present = true;
                    break;
                }
            }
            if (present)
                totalWeight += weights[i];
        }

        int roll = Random.Range(0, Mathf.Max(1, totalWeight));
        for (int i = 0; i < rarities.Length; i++)
        {
            bool present = false;
            for (int item = 0; item < poolItems.Count; item++)
            {
                if (poolItems[item].rarity == rarities[i])
                {
                    present = true;
                    break;
                }
            }
            if (!present)
                continue;
            if (roll < weights[i])
                return rarities[i];
            roll -= weights[i];
        }

        return poolItems[Random.Range(0, poolItems.Count)].rarity;
    }

    private static int GetGachaRarityWeight(EquipmentSystem.Rarity rarity)
    {
        switch (rarity)
        {
            case EquipmentSystem.Rarity.Common: return 70;
            case EquipmentSystem.Rarity.Rare: return 22;
            case EquipmentSystem.Rarity.Epic: return 7;
            case EquipmentSystem.Rarity.Legendary: return 1;
            default: return 0;
        }
    }

    private static float GetGachaItemProbabilityPercent(
        List<EquipmentSystem.Item> poolItems, EquipmentSystem.Item item)
    {
        int totalWeight = 0;
        int sameRarityCount = 0;
        for (int i = 0; i < poolItems.Count; i++)
        {
            bool firstOfRarity = true;
            for (int previous = 0; previous < i; previous++)
            {
                if (poolItems[previous].rarity == poolItems[i].rarity)
                {
                    firstOfRarity = false;
                    break;
                }
            }

            if (firstOfRarity)
                totalWeight += GetGachaRarityWeight(poolItems[i].rarity);
            if (poolItems[i].rarity == item.rarity)
                sameRarityCount++;
        }

        if (totalWeight <= 0 || sameRarityCount <= 0)
            return 0f;

        return GetGachaRarityWeight(item.rarity) * 100f /
            (totalWeight * sameRarityCount);
    }

    private void RequestProgressReset()
    {
        PlayConfirmSound();
        resetProgressConfirm = true;
        RequestEditorRepaint();
    }

    private void ResetSavedProgress()
    {
        PlayConfirmSound();
        coins = 0;
        gachaTickets = 0;
        PlayerPrefs.DeleteKey(CoinBalanceKey);
        PlayerPrefs.DeleteKey(GachaTicketBalanceKey);
        PlayerPrefs.DeleteKey(SlashDamageLevelKey);
        PlayerPrefs.DeleteKey(HeroHealthLevelKey);
        PlayerPrefs.DeleteKey(WitchHealthLevelKey);
        PlayerPrefs.DeleteKey(HeroSpeedLevelKey);
        PlayerPrefs.DeleteKey(SlashPierceLevelKey);
        PlayerPrefs.DeleteKey(AttackSpeedLevelKey);
        PlayerPrefs.DeleteKey(MonsterKnockbackLevelKey);
        PlayerPrefs.DeleteKey(CurrentMapStageKey);
        PlayerPrefs.DeleteKey(CurrentMapPageKey);
        PlayerPrefs.DeleteKey(HighestClearedStageKey);
        PlayerPrefs.DeleteKey(PendingStageInfoKey);
        List<StageDefinition> resetStages = GetStages();
        for (int i = 0; i < resetStages.Count; i++)
        {
            if (resetStages[i] != null)
                PlayerPrefs.DeleteKey(ClearedStageKeyPrefix +
                    resetStages[i].stageId);
        }
        EquipmentSystem.Reset();
        PlayerPrefs.Save();
        resetProgressConfirm = false;
        RequestEditorRepaint();
    }

    private Rect GetUpgradePanelRect()
    {
        GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
            out float logicalHeight);
        float panelWidth = Mathf.Min(MapPanelWidth, Mathf.Max(0f, logicalWidth - 20f));
        float panelHeight = Mathf.Min(MapPanelHeight, Mathf.Max(0f, logicalHeight - 20f));
        return new Rect(
            (logicalWidth - panelWidth) * 0.5f,
            (logicalHeight - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
    }

    private Rect GetSkillTreeViewport(Rect panel)
    {
        GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
            out float logicalHeight);
        float viewportWidth = Mathf.Min(MapViewportWidth,
            Mathf.Max(0f, panel.width - 52f));
        float viewportHeight = Mathf.Min(425f,
            Mathf.Max(0f, panel.height - 250f));
        float viewportX = panel.x + (panel.width - viewportWidth) * 0.5f;
        float viewportY = panel.y + 145f;

        // Keep every edge inside the actual logical Game view, including
        // narrow or unusually tall aspect ratios.
        viewportX = Mathf.Clamp(viewportX, 0f,
            Mathf.Max(0f, logicalWidth - viewportWidth));
        viewportY = Mathf.Clamp(viewportY, 0f,
            Mathf.Max(0f, logicalHeight - viewportHeight));
        return new Rect(viewportX, viewportY, viewportWidth, viewportHeight);
    }

    private void GetFrontendGuiMetrics(out float scale, out Vector2 offset,
        out float logicalWidth, out float logicalHeight)
    {
        float widthScale = Mathf.Max(0.0001f,
            Screen.width / FrontendReferenceWidth);
        float heightScale = Mathf.Max(0.0001f,
            Screen.height / FrontendReferenceHeight);
        // Match CanvasScaler.MatchWidthOrHeight using its logarithmic
        // interpolation. This keeps IMGUI and the Canvas on one coordinate
        // system instead of making the skill-tree frame smaller than the UI.
        scale = Mathf.Exp(Mathf.Lerp(Mathf.Log(widthScale),
            Mathf.Log(heightScale), FrontendCanvasMatch));
        logicalWidth = Screen.width / scale;
        logicalHeight = Screen.height / scale;
        offset = new Vector2(
            (Screen.width - FrontendReferenceWidth * scale) * 0.5f,
            (Screen.height - FrontendReferenceHeight * scale) * 0.5f);
    }

    private Vector2 PhysicalGuiPointToFrontendPoint(Vector2 physicalPoint)
    {
        GetFrontendGuiMetrics(out float scale, out Vector2 offset,
            out _, out _);
        return (physicalPoint - offset) / Mathf.Max(scale, 0.0001f);
    }

    private static int GetSkillNodeCount()
    {
        return SkillNodeBranches != null ? SkillNodeBranches.Length : 0;
    }

    private static int GetSkillBranchIndex(int nodeIndex)
    {
        if (SkillNodeBranches == null || SkillNodeBranches.Length == 0)
            return 0;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodeBranches.Length - 1);
        return SkillNodeBranches[index];
    }

    private static int GetSkillLevelIndex(int nodeIndex)
    {
        if (SkillNodeLevels == null || SkillNodeLevels.Length == 0)
            return 0;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodeLevels.Length - 1);
        return SkillNodeLevels[index];
    }

    private static Vector2 GetSkillTreeNodePosition(Vector2 treeCenter, int nodeIndex)
    {
        int safeIndex = Mathf.Clamp(nodeIndex, 0, GetSkillNodeCount() - 1);
        int branchIndex = GetSkillBranchIndex(safeIndex);
        if (branchIndex == 4)
        {
            // Put the piercing branch in the former attack-speed column.
            int piercingRow = safeIndex / SkillTreeGridColumns;
            float y = (piercingRow - (SkillTreeGridRows - 1) * 0.5f) *
                SkillTreeGridSpacingY;
            return treeCenter + new Vector2(
                SkillTreeGridSpacingX * 3f, y);
        }

        if (branchIndex == 5)
        {
            // Put the attack-speed branch immediately to the right of the
            // five main branches, while keeping it inside the viewport.
            int attackSpeedRow = safeIndex - AttackSpeedNodeIndex + 1;
            float y = (attackSpeedRow - (SkillTreeGridRows - 1) * 0.5f) *
                SkillTreeGridSpacingY;
            return treeCenter + new Vector2(
                SkillTreeGridSpacingX * 3f, y);
        }

        if (branchIndex == 6)
        {
            int knockbackRow = safeIndex - MonsterKnockbackNodeIndex;
            float y = (knockbackRow - 1f) * SkillTreeGridSpacingY;
            return treeCenter + new Vector2(
                SkillTreeGridSpacingX * 1.5f, y);
        }

        int column = safeIndex % SkillTreeGridColumns;
        int row = safeIndex / SkillTreeGridColumns;
        Vector2 gridOffset = new Vector2(
            (column - (SkillTreeGridColumns - 1) * 0.5f) * SkillTreeGridSpacingX,
            (row - (SkillTreeGridRows - 1) * 0.5f) * SkillTreeGridSpacingY);
        return treeCenter + gridOffset;
    }

    private static int GetSkillNodePrerequisite(int nodeIndex)
    {
        if (SkillNodePrerequisites == null || SkillNodePrerequisites.Length == 0)
            return -1;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodePrerequisites.Length - 1);
        return SkillNodePrerequisites[index];
    }

    private static bool IsSkillNodePurchased(int nodeIndex)
    {
        string key = SkillUpgradeKeys[GetSkillBranchIndex(nodeIndex)];
        return GetUpgradeLevel(key) > GetSkillLevelIndex(nodeIndex);
    }

    private static bool IsSkillNodeUnlocked(int nodeIndex)
    {
        if (IsSkillNodePurchased(nodeIndex)) return true;

        int branchIndex = GetSkillBranchIndex(nodeIndex);
        string key = SkillUpgradeKeys[branchIndex];
        if (branchIndex == 5 &&
            GetPurchasedSkillNodeCount() < AttackSpeedUnlockRequiredNodes)
            return false;
        if (branchIndex == 6 &&
            GetPurchasedSkillNodeCount() < MonsterKnockbackUnlockRequiredNodes)
            return false;

        int levelIndex = GetSkillLevelIndex(nodeIndex);
        // A branch still advances one level at a time, while the prerequisite
        // below can come from any other branch.
        if (GetUpgradeLevel(key) != levelIndex) return false;

        int prerequisite = GetSkillNodePrerequisite(nodeIndex);
        return prerequisite < 0 || IsSkillNodePurchased(prerequisite);
    }

    // Show purchased nodes and only the next available node. Future nodes
    // stay hidden until the previous node has been purchased, so the tree
    // reveals one step at a time instead of showing all locked nodes.
    private static bool IsSkillNodeVisible(int nodeIndex)
    {
        if (IsSkillNodePurchased(nodeIndex) || IsSkillNodeUnlocked(nodeIndex))
            return true;

        // Keep the first knockback node visible as a locked destination so
        // the player can see that the branch exists before the unlock
        // requirement is met. Later levels still reveal one at a time.
        return GetSkillBranchIndex(nodeIndex) == 6 &&
            GetSkillLevelIndex(nodeIndex) == 0;
    }

    private static int GetHighestVisibleUnpurchasedSkillNode()
    {
        int candidate = -1;
        Vector2 candidatePosition = Vector2.zero;
        for (int i = 0; i < GetSkillNodeCount(); i++)
        {
            if (!IsSkillNodeVisible(i) || IsSkillNodePurchased(i))
                continue;

            Vector2 position = GetSkillTreeNodePosition(Vector2.zero, i);
            if (candidate < 0 || position.y < candidatePosition.y ||
                (Mathf.Approximately(position.y, candidatePosition.y) &&
                 position.x < candidatePosition.x))
            {
                candidate = i;
                candidatePosition = position;
            }
        }

        return candidate;
    }

    private static int GetPurchasedSkillNodeCount()
    {
        int purchasedCount = 0;
        for (int i = 0; i < GetSkillNodeCount(); i++)
        {
            if (GetSkillBranchIndex(i) == 5) continue;
            if (IsSkillNodePurchased(i))
                purchasedCount++;
        }
        return purchasedCount;
    }

    private string GetSkillBranchValue(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return $"{GetHeroSlashDamage()}";
            case 1: return $"HP {GetHeroMaxHealth()}";
            case 2: return $"HP {GetWitchMaxHealth()}";
            case 3: return $"{GetHeroMoveSpeed():0.0}";
            case 4: return $"{GetSlashPiercingHits()}体まで";
            case 5: return $"間隔 {GetHeroAttackInterval():0.00}秒";
            case 6: return $"x{GetMonsterKnockbackUpgradeMultiplier():0.00}";
            default: return string.Empty;
        }
    }

    private static string GetSkillBranchIcon(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return "剣";
            case 1: return "体";
            case 2: return "魔";
            case 3: return "速";
            case 4: return "貫";
            case 5: return "連";
            case 6: return "押";
            default: return "?";
        }
    }

    private static Color GetSkillBranchAccent(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return new Color(1f, 0.62f, 0.22f, 1f);
            case 1: return new Color(0.95f, 0.35f, 0.38f, 1f);
            case 2: return new Color(0.72f, 0.46f, 0.95f, 1f);
            case 3: return new Color(0.25f, 0.82f, 0.9f, 1f);
            case 4: return new Color(0.48f, 0.85f, 0.36f, 1f);
            case 5: return new Color(1f, 0.52f, 0.22f, 1f);
            case 6: return new Color(0.82f, 0.68f, 0.28f, 1f);
            default: return Color.white;
        }
    }

    private static string GetSkillEffectText(int branchIndex)
    {
        switch (branchIndex)
        {
            // Keep node effects compact. The node title and the legend
            // already identify the stat, so repeating it here only makes the
            // small circular node wrap and clip its text.
            case 0: return "+1";
            case 1: return "+2";
            case 2: return "+2";
            case 3: return "+0.5";
            case 4: return "+1";
            case 5: return "+0.06";
            case 6: return "+20%";
            default: return "+0";
        }
    }

    private void ClampSkillTreePan(Rect viewport)
    {
        // Keep a generous content area for panning. The tree is rendered
        // inside the clipped viewport group, so anything beyond its frame is
        // intentionally hidden.
        float maxPanX = Mathf.Max(0f, (SkillTreeContentWidth - viewport.width) * 0.5f);
        float maxPanY = Mathf.Max(0f, (SkillTreeContentHeight - viewport.height) * 0.5f);
        skillTreePan.x = Mathf.Clamp(skillTreePan.x, -maxPanX, maxPanX);
        skillTreePan.y = Mathf.Clamp(skillTreePan.y, -maxPanY, maxPanY);
    }

    private void FocusSkillTreeOnFirstAvailableNode()
    {
        int targetNode = GetHighestVisibleUnpurchasedSkillNode();
        if (targetNode < 0)
            return;

        Rect viewport = GetSkillTreeViewport(GetUpgradePanelRect());
        Vector2 treeCenter = new Vector2(
            viewport.width * 0.5f, viewport.height * 0.5f) +
            SkillTreeCenterOffset;
        Vector2 targetPosition = GetSkillTreeNodePosition(treeCenter, targetNode);

        // Keep the highest remaining node near the upper third of the
        // viewport when the page opens, while preserving the tree's normal
        // horizontal layout.
        float desiredY = viewport.height * 0.32f;
        skillTreePan.y += desiredY - targetPosition.y;
        ClampSkillTreePan(viewport);
    }

    private void HandleUpgradeInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame)
        {
            ReturnToMenu();
            return;
        }

        Rect viewport = GetSkillTreeViewport(GetUpgradePanelRect());
        Vector2 wheel = pendingSkillTreeScroll;
        pendingSkillTreeScroll = Vector2.zero;
        Mouse mouse = Mouse.current;
        if (wheel.sqrMagnitude <= 0.0001f && mouse != null)
            wheel = mouse.scroll.ReadValue();

        if (wheel.sqrMagnitude > 0.0001f)
        {
            // Match the stage map's two-finger direction: scrolling upward
            // moves the visible tree downward, and vice versa.
            skillTreePan += new Vector2(-wheel.x, wheel.y) * 24f;
            skillTreeScrollHandledFrame = Time.frameCount;
            ClampSkillTreePan(viewport);
            SyncSkillTreePanOverlayFromPosition();
            RequestEditorRepaint();
        }

        if (keyboard == null) return;

        Vector2 direction = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) direction.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) direction.x += 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) direction.y -= 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) direction.y += 1f;
        if (direction.sqrMagnitude <= 0.0001f) return;

        skillTreePan += direction.normalized * 6f;
        ClampSkillTreePan(viewport);
        // Keyboard panning changes the visible IMGUI tree immediately. Keep
        // the transparent Canvas hitboxes on that exact same offset instead
        // of leaving them at the previous frame's positions.
        SyncSkillTreePanOverlayFromPosition();
        RequestEditorRepaint();
    }

    private void HandleEquipmentInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        KeyCode pressedKey = KeyCode.None;
        if (keyboard.escapeKey.wasPressedThisFrame)
            pressedKey = KeyCode.Escape;
        else if (keyboard.upArrowKey.wasPressedThisFrame)
            pressedKey = KeyCode.UpArrow;
        else if (keyboard.downArrowKey.wasPressedThisFrame)
            pressedKey = KeyCode.DownArrow;
        else if (keyboard.leftArrowKey.wasPressedThisFrame)
            pressedKey = KeyCode.LeftArrow;
        else if (keyboard.rightArrowKey.wasPressedThisFrame)
            pressedKey = KeyCode.RightArrow;
        else if (keyboard.wKey.wasPressedThisFrame)
            pressedKey = KeyCode.W;
        else if (keyboard.sKey.wasPressedThisFrame)
            pressedKey = KeyCode.S;
        else if (keyboard.aKey.wasPressedThisFrame)
            pressedKey = KeyCode.A;
        else if (keyboard.dKey.wasPressedThisFrame)
            pressedKey = KeyCode.D;
        else if (keyboard.uKey.wasPressedThisFrame)
            pressedKey = KeyCode.U;
        else if (keyboard.enterKey.wasPressedThisFrame ||
            keyboard.numpadEnterKey.wasPressedThisFrame)
            pressedKey = KeyCode.Return;
        else if (keyboard.spaceKey.wasPressedThisFrame)
            pressedKey = KeyCode.Space;

        if (pressedKey != KeyCode.None &&
            WasEquipmentInputAlreadyHandled(pressedKey))
            return;

        bool hasKeyboardInput = keyboard.escapeKey.wasPressedThisFrame ||
            keyboard.upArrowKey.wasPressedThisFrame ||
            keyboard.downArrowKey.wasPressedThisFrame ||
            keyboard.leftArrowKey.wasPressedThisFrame ||
            keyboard.rightArrowKey.wasPressedThisFrame ||
            keyboard.wKey.wasPressedThisFrame ||
            keyboard.aKey.wasPressedThisFrame ||
            keyboard.sKey.wasPressedThisFrame ||
            keyboard.dKey.wasPressedThisFrame ||
            keyboard.enterKey.wasPressedThisFrame ||
            keyboard.numpadEnterKey.wasPressedThisFrame ||
            keyboard.spaceKey.wasPressedThisFrame ||
            keyboard.uKey.wasPressedThisFrame;
        if (hasKeyboardInput)
            equipmentInputFrame = Time.frameCount;

        if (keyboard.escapeKey.wasPressedThisFrame)
        {
            if (equipmentListOpen)
            {
                equipmentListOpen = false;
                equipmentFocusItem = 0;
                equipmentListScroll = Vector2.zero;
                equipmentListScroll = Vector2.zero;
                RequestEditorRepaint();
                return;
            }

            ReturnToMenu();
            return;
        }

        if (keyboard.upArrowKey.wasPressedThisFrame || keyboard.wKey.wasPressedThisFrame)
        {
            equipmentFocusSlot = Mathf.Max(0, equipmentFocusSlot - 1);
            equipmentFocusItem = 0;
            equipmentListScroll = Vector2.zero;
            RequestEditorRepaint();
        }
        else if (keyboard.downArrowKey.wasPressedThisFrame || keyboard.sKey.wasPressedThisFrame)
        {
            equipmentFocusSlot = Mathf.Min(3, equipmentFocusSlot + 1);
            equipmentFocusItem = 0;
            equipmentListScroll = Vector2.zero;
            RequestEditorRepaint();
        }

        EquipmentSystem.Item[] ownedItems = EquipmentSystem.GetOwnedItems(
            (EquipmentSystem.Slot)equipmentFocusSlot);
        if (!equipmentListOpen)
        {
            if (keyboard.enterKey.wasPressedThisFrame ||
                keyboard.numpadEnterKey.wasPressedThisFrame ||
                keyboard.spaceKey.wasPressedThisFrame)
            {
                equipmentListOpen = true;
                equipmentFocusItem = 0;
                equipmentListScroll = Vector2.zero;
                RequestEditorRepaint();
            }

            return;
        }

        if (ownedItems.Length == 0) return;

        if (keyboard.leftArrowKey.wasPressedThisFrame || keyboard.aKey.wasPressedThisFrame)
        {
            equipmentFocusItem = (equipmentFocusItem - 1 + ownedItems.Length) % ownedItems.Length;
            RequestEditorRepaint();
        }
        else if (keyboard.rightArrowKey.wasPressedThisFrame || keyboard.dKey.wasPressedThisFrame)
        {
            equipmentFocusItem = (equipmentFocusItem + 1) % ownedItems.Length;
            RequestEditorRepaint();
        }

        if (keyboard.uKey.wasPressedThisFrame)
        {
            UpgradeEquipment((EquipmentSystem.Slot)equipmentFocusSlot,
                ownedItems[Mathf.Clamp(equipmentFocusItem, 0,
                    ownedItems.Length - 1)].id);
            return;
        }

        if (keyboard.enterKey.wasPressedThisFrame ||
            keyboard.numpadEnterKey.wasPressedThisFrame ||
            keyboard.spaceKey.wasPressedThisFrame)
        {
            EquipItem((EquipmentSystem.Slot)equipmentFocusSlot,
                ownedItems[Mathf.Clamp(equipmentFocusItem, 0, ownedItems.Length - 1)].id);
        }
    }

    // Unity's embedded Game view can deliver a key through IMGUI even when
    // the editor's Input System device has not received the native key event.
    // Keep this fallback in sync with HandleEquipmentInput so the equipment
    // page remains usable from the actual keyboard as well as from a build.
    private void HandleEquipmentGuiEvent(Event currentEvent)
    {
        if (currentEvent == null || currentEvent.type != EventType.KeyDown)
            return;

        KeyCode key = currentEvent.keyCode;
        bool isEquipmentKey = key == KeyCode.Escape ||
            key == KeyCode.UpArrow || key == KeyCode.DownArrow ||
            key == KeyCode.LeftArrow || key == KeyCode.RightArrow ||
            key == KeyCode.W || key == KeyCode.S || key == KeyCode.A ||
            key == KeyCode.D || key == KeyCode.U || key == KeyCode.Return ||
            key == KeyCode.KeypadEnter || key == KeyCode.Space;
        if (!isEquipmentKey || equipmentInputFrame == Time.frameCount ||
            WasEquipmentInputAlreadyHandled(key))
            return;

        bool handled = false;
        if (key == KeyCode.Escape)
        {
            if (equipmentListOpen)
            {
                equipmentListOpen = false;
                equipmentFocusItem = 0;
            }
            else
            {
                ReturnToMenu();
            }
            handled = true;
        }
        else if (key == KeyCode.UpArrow || key == KeyCode.W)
        {
            equipmentFocusSlot = Mathf.Max(0, equipmentFocusSlot - 1);
            equipmentFocusItem = 0;
            equipmentListScroll = Vector2.zero;
            handled = true;
        }
        else if (key == KeyCode.DownArrow || key == KeyCode.S)
        {
            equipmentFocusSlot = Mathf.Min(3, equipmentFocusSlot + 1);
            equipmentFocusItem = 0;
            equipmentListScroll = Vector2.zero;
            handled = true;
        }
        else if (equipmentListOpen && key == KeyCode.U)
        {
            EquipmentSystem.Item[] ownedItems = EquipmentSystem.GetOwnedItems(
                (EquipmentSystem.Slot)equipmentFocusSlot);
            if (ownedItems.Length > 0)
            {
                UpgradeEquipment((EquipmentSystem.Slot)equipmentFocusSlot,
                    ownedItems[Mathf.Clamp(equipmentFocusItem, 0,
                        ownedItems.Length - 1)].id);
            }
            handled = true;
        }
        else if (!equipmentListOpen &&
            (key == KeyCode.Return || key == KeyCode.KeypadEnter ||
             key == KeyCode.Space))
        {
            equipmentListOpen = true;
            equipmentFocusItem = 0;
            equipmentListScroll = Vector2.zero;
            handled = true;
        }
        else if (equipmentListOpen)
        {
            EquipmentSystem.Item[] ownedItems = EquipmentSystem.GetOwnedItems(
                (EquipmentSystem.Slot)equipmentFocusSlot);
            if (key == KeyCode.LeftArrow || key == KeyCode.A)
            {
                if (ownedItems.Length > 0)
                    equipmentFocusItem = (equipmentFocusItem - 1 + ownedItems.Length) %
                        ownedItems.Length;
                handled = true;
            }
            else if (key == KeyCode.RightArrow || key == KeyCode.D)
            {
                if (ownedItems.Length > 0)
                    equipmentFocusItem = (equipmentFocusItem + 1) % ownedItems.Length;
                handled = true;
            }
            else if (key == KeyCode.Return || key == KeyCode.KeypadEnter ||
                key == KeyCode.Space)
            {
                if (ownedItems.Length > 0)
                {
                    EquipItem((EquipmentSystem.Slot)equipmentFocusSlot,
                        ownedItems[Mathf.Clamp(equipmentFocusItem, 0,
                            ownedItems.Length - 1)].id);
                }
                handled = true;
            }
        }

        if (handled)
        {
            equipmentInputFrame = Time.frameCount;
            currentEvent.Use();
            RequestEditorRepaint();
        }
    }

    private bool WasEquipmentInputAlreadyHandled(KeyCode key)
    {
        float now = Time.unscaledTime;
        const float duplicateWindow = 0.08f;
        if (equipmentLastHandledKey == key &&
            now - equipmentLastHandledKeyTime < duplicateWindow)
            return true;

        equipmentLastHandledKey = key;
        equipmentLastHandledKeyTime = now;
        return false;
    }

    private void HandleGachaGuiEvent(Event currentEvent)
    {
        if (currentEvent == null || currentEvent.type != EventType.KeyDown)
            return;

        if ((gachaRatesOpen || gachaResultPopupOpen) &&
            (currentEvent.keyCode == KeyCode.Escape ||
                currentEvent.keyCode == KeyCode.B))
        {
            gachaRatesOpen = false;
            gachaResultPopupOpen = false;
            currentEvent.Use();
            RequestEditorRepaint();
            return;
        }

        if (gachaRatesOpen || gachaResultPopupOpen)
            return;

        if (currentEvent.keyCode == KeyCode.Escape || currentEvent.keyCode == KeyCode.B)
        {
            ReturnToMenu();
            currentEvent.Use();
            RequestEditorRepaint();
        }
        else if (currentEvent.keyCode == KeyCode.Return ||
            currentEvent.keyCode == KeyCode.KeypadEnter ||
            currentEvent.keyCode == KeyCode.Space)
        {
            if (ticketGachaSelected)
                TryPullTicketGacha();
            else
                TryPullEquipmentGacha();
            currentEvent.Use();
        }
    }

    private void EquipItem(EquipmentSystem.Slot slot, int itemId)
    {
        EquipmentSystem.Equip(slot, itemId);
        PlayConfirmSound();
        if (state == GameState.Battle)
        {
            CreateHeroEquipmentVisuals();
            CreatePetCompanion();
        }
        RequestEditorRepaint();
    }

    private void UpgradeEquipment(EquipmentSystem.Slot slot, int itemId)
    {
        if (!EquipmentSystem.TryUpgrade(slot, itemId))
        {
            RequestEditorRepaint();
            return;
        }

        PlayConfirmSound();
        if (state == GameState.Battle)
        {
            CreateHeroEquipmentVisuals();
            CreatePetCompanion();
        }
        RequestEditorRepaint();
    }

    private void UpdateSkillTreeEventInput(Event currentEvent, Rect viewport)
    {
        if (currentEvent == null) return;

        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
        {
            Vector2 eventPosition = PhysicalGuiPointToFrontendPoint(
                currentEvent.mousePosition);
            if (!viewport.Contains(eventPosition)) return;

            skillTreePointerHeld = true;
            skillTreeSuppressNodeClick = false;
            skillTreeLastPointerPosition = eventPosition;
            return;
        }

        if (currentEvent.type == EventType.MouseDrag && skillTreePointerHeld)
        {
            Vector2 eventPosition = PhysicalGuiPointToFrontendPoint(
                currentEvent.mousePosition);
            Vector2 delta = eventPosition - skillTreeLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                // Match the stage map's drag direction in the Unity Game view.
                // The editor event reports the drag delta with the opposite
                // sign, so add it here to move the tree with the pointer.
                skillTreePan += delta;
                skillTreeSuppressNodeClick = true;
                skillTreeLastPointerPosition = eventPosition;
                ClampSkillTreePan(viewport);
                SyncSkillTreePanOverlayFromPosition();
                currentEvent.Use();
                RequestEditorRepaint();
            }
            return;
        }

        if (currentEvent.type == EventType.MouseUp && skillTreePointerHeld)
        {
            if (skillTreeSuppressNodeClick)
                currentEvent.Use();
            skillTreePointerHeld = false;
            return;
        }

        // Trackpad two-finger scrolling arrives in the Unity Editor as an
        // IMGUI scroll-wheel event. Handle it here as well as through the
        // Input System path above so it works reliably in the Game view.
        if (currentEvent.type == EventType.ScrollWheel &&
            (skillTreePanOverlay == null || !skillTreePanOverlay.activeSelf) &&
            skillTreeScrollHandledFrame != Time.frameCount)
        {
            Vector2 scrollDelta = currentEvent.delta;
            if (currentEvent.shift &&
                Mathf.Abs(scrollDelta.x) <= 0.001f &&
                Mathf.Abs(scrollDelta.y) > 0.001f)
            {
                scrollDelta.x = scrollDelta.y;
                scrollDelta.y = 0f;
            }
            skillTreePan += new Vector2(-scrollDelta.x, scrollDelta.y) * 24f;
            skillTreeScrollHandledFrame = Time.frameCount;
            ClampSkillTreePan(viewport);
            currentEvent.Use();
            RequestEditorRepaint();
        }
    }

    private void CreateMapVisual()
    {
        // Re-opening the stage select page reuses the existing map canvas.
        // This is a normal path, not a warning condition.
        if (mapVisualRoot == null || mapVisualPanel != null)
            return;

        mapStageButtons.Clear();
        // The sprite sheet can be replaced while testing in the Editor.
        // Clear sliced sprites so every node uses the current sheet instead
        // of keeping a mixture of old and new icon textures in the cache.
        stageIconSprites.Clear();
        stageIconsTexture = null;

        GameObject mapBackground = CreateUiImage(mapVisualRoot.transform, "MapBackground",
            Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);
        RectTransform mapBackgroundRect = mapBackground.GetComponent<RectTransform>();
        mapBackgroundRect.anchorMin = new Vector2(0.5f, 0.5f);
        mapBackgroundRect.anchorMax = new Vector2(0.5f, 0.5f);
        mapBackgroundRect.sizeDelta = new Vector2(2200f, 1400f);
        mapBackgroundRect.anchoredPosition = Vector2.zero;
        mapVisualPanel = CreateUiImage(mapVisualRoot.transform, "MapPanel", Vector2.zero,
            new Vector2(MapPanelWidth, MapPanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        Transform panel = mapVisualPanel.transform;
        CreateUiImage(panel, "MapPanelTopLine", new Vector2(0f, 338f),
            new Vector2(1120f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel, "MapPanelBottomLine", new Vector2(0f, -338f),
            new Vector2(1120f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        mapPageLabel = CreateUiText(panel, "WORLD MAP", 18, Color.white,
            TextAnchor.MiddleCenter, new Vector2(-180f, 306f), new Vector2(420f, 38f));
        UpdateMapPageLabel();
        GameObject mapCoinCounter = CreateUiImage(panel, "MapCoinCounter",
            new Vector2(390f, 306f), new Vector2(180f, 42f),
            new Color(0.01f, 0.025f, 0.04f, 0.88f), false);
        CreateUiImage(mapCoinCounter.transform, "MapCoinCounterTopLine",
            new Vector2(0f, 19f), new Vector2(180f, 2f),
            new Color(0.95f, 0.78f, 0.25f, 0.75f), false);
        CreateUiImage(mapCoinCounter.transform, "MapCoinCounterBottomLine",
            new Vector2(0f, -19f), new Vector2(180f, 2f),
            new Color(0.95f, 0.78f, 0.25f, 0.75f), false);
        Image mapCoinIcon = CreateUiImage(mapCoinCounter.transform, "CoinIcon",
            new Vector2(-40f, 0f), new Vector2(28f, 28f), Color.white, false)
            .GetComponent<Image>();
        mapCoinIcon.sprite = GetCoinSprite();
        mapCoinIcon.preserveAspect = true;
        CreateUiText(mapCoinCounter.transform, $"x{coins}", 19, Color.white,
            TextAnchor.MiddleLeft, new Vector2(16f, 0f), new Vector2(80f, 34f));

        GameObject viewportObject = CreateUiImage(panel, "MapArea", new Vector2(0f, -10f),
            new Vector2(MapViewportWidth, MapViewportHeight),
            new Color(0.02f, 0.08f, 0.14f, 0.55f), false);
        RectTransform viewport = viewportObject.GetComponent<RectTransform>();
        viewportObject.AddComponent<RectMask2D>();
        Image viewportImage = viewportObject.GetComponent<Image>();
        viewportImage.raycastTarget = true;

        mapCanvasContent = new GameObject("MapContent", typeof(RectTransform)).GetComponent<RectTransform>();
        mapCanvasContent.SetParent(viewport, false);
        // ScrollRect content must use a fixed top-left anchor. Center
        // anchoring makes normalizedPosition changes appear to do nothing.
        mapCanvasContent.anchorMin = new Vector2(0f, 1f);
        mapCanvasContent.anchorMax = new Vector2(0f, 1f);
        mapCanvasContent.pivot = new Vector2(0f, 1f);
        mapCanvasContent.sizeDelta = new Vector2(MapContentWidth, MapContentHeight);
        mapCanvasContent.anchoredPosition = Vector2.zero;

        GameObject mapArt = new GameObject("MapArt", typeof(RectTransform), typeof(RawImage));
        mapArt.transform.SetParent(mapCanvasContent, false);
        RectTransform mapArtRect = mapArt.GetComponent<RectTransform>();
        mapArtRect.anchorMin = Vector2.zero;
        mapArtRect.anchorMax = Vector2.one;
        mapArtRect.offsetMin = Vector2.zero;
        mapArtRect.offsetMax = Vector2.zero;
        RawImage mapArtImage = mapArt.GetComponent<RawImage>();
        mapArtImage.texture = GetMapBackgroundTexture();
        mapArtImage.color = Color.white;
        mapArtImage.raycastTarget = false;

        mapCanvasScrollRect = viewportObject.AddComponent<ScrollRect>();
        mapCanvasScrollRect.viewport = viewport;
        mapCanvasScrollRect.content = mapCanvasContent;
        mapCanvasScrollRect.horizontal = true;
        mapCanvasScrollRect.vertical = true;
        mapCanvasScrollRect.movementType = ScrollRect.MovementType.Clamped;
        mapCanvasScrollRect.inertia = false;
        mapCanvasScrollRect.scrollSensitivity = 1f;
        mapCanvasScrollRect.horizontalScrollbar = null;
        mapCanvasScrollRect.verticalScrollbar = null;
        mapCanvasScrollRect.onValueChanged.AddListener(OnMapCanvasScrollChanged);
        // The map is panned by the MapScene camera. Keep this component only
        // for the existing viewport/content hierarchy and clipping.
        mapCanvasScrollRect.enabled = false;

        if (mapTravelMode)
        {
            // The travel button opens a real map-selection screen. MAP1 and
            // MAP2 are destination choices here; their stage nodes are shown
            // only after the destination map has been entered.
            mapScrollPosition = new Vector2(
                Mathf.Max(0f, (MapContentWidth - MapViewportWidth) * 0.5f),
                Mathf.Max(0f, (MapContentHeight - MapViewportHeight) * 0.5f));
            mapScrollInitialized = true;
            ApplyMapCanvasContentOffset();
            CreateMapSelectionNodes(mapCanvasContent);
            return;
        }

        // The map itself is the level route.  Each playable level must remain
        // a node here; do not collapse LEVEL1..LEVEL10 (or LEVEL11..LEVEL20)
        // into a pair of abstract STAGE nodes.
        List<StageDefinition> stages = GetCurrentMapStages();
        Vector2[] nodePositions = new Vector2[stages.Count];
        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        for (int i = 0; i < stages.Count; i++)
        {
            Vector2 mapPosition = GetMapNodePosition(mapContent, stages[i], i,
                stages.Count);
            nodePositions[i] = new Vector2(mapPosition.x, -mapPosition.y);
        }

        if (!mapTravelMode)
        {
            for (int i = 0; i < nodePositions.Length - 1; i++)
                CreateMapLine(mapCanvasContent, nodePositions[i], nodePositions[i + 1], i);
        }

        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            List<StageDefinition> allStages = GetStages();
            bool unlocked = IsStageUnlocked(stage.stageId, allStages);
            bool cleared = IsStageCleared(stage.stageId, allStages);
            GameObject nodeObject = new GameObject($"StageNode_{stage.stageId}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(mapCanvasContent, false);
            nodeObject.SetActive(unlocked);
            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(MapNodeSize, MapNodeSize);
            nodeRect.anchoredPosition = nodePositions[i];

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.sprite = GetMapCircleSprite();
            nodeImage.color = GetStageNodeColor(unlocked, cleared);
            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            ConfigureButtonHover(nodeButton, nodeImage.color,
                unlocked ? new Color(1f, 0.84f, 0.36f, 1f) : nodeImage.color);
            nodeButton.interactable = unlocked;
            int stageId = stage.stageId;
            nodeButton.onClick.AddListener(() =>
            {
                if (mapTravelMode)
                    SelectMapTravelStage(stageId);
                else
                    OpenStageInfo(stageId);
            });
            mapStageButtons[nodeButton] = stage.stageId;

            GameObject iconObject = new GameObject("StageIcon", typeof(RectTransform), typeof(Image));
            iconObject.transform.SetParent(nodeObject.transform, false);
            RectTransform iconRect = iconObject.GetComponent<RectTransform>();
            iconRect.anchorMin = Vector2.zero;
            iconRect.anchorMax = Vector2.one;
            iconRect.offsetMin = new Vector2(12f, 12f);
            iconRect.offsetMax = new Vector2(-12f, -12f);
            Image iconImage = iconObject.GetComponent<Image>();
            iconImage.sprite = GetStageIconSprite(stage, i);
            iconImage.color = unlocked
                ? Color.white
                : new Color(0.42f, 0.46f, 0.48f, 0.52f);
            iconImage.preserveAspect = true;
            iconImage.raycastTarget = false;

            GameObject lockShade = CreateUiImage(nodeObject.transform,
                "StageLockShade", Vector2.zero,
                new Vector2(MapNodeSize - 12f, MapNodeSize - 12f),
                new Color(0.01f, 0.02f, 0.03f, 0.56f), false);
            lockShade.SetActive(!unlocked);

            GameObject numberBadge = CreateUiImage(nodeObject.transform,
                "StageNumberBadge", new Vector2(0f, 54f),
                new Vector2(62f, 28f),
                new Color(0.01f, 0.025f, 0.04f, 0.94f), false);
            CreateUiText(numberBadge.transform,
                mapTravelMode ? (i + 1).ToString() : stage.stageId.ToString(), 18,
                unlocked ? new Color(1f, 0.91f, 0.48f) :
                    new Color(0.62f, 0.66f, 0.68f),
                TextAnchor.MiddleCenter, Vector2.zero, new Vector2(62f, 28f));

            GameObject lockBadge = CreateUiImage(nodeObject.transform,
                "StageLockBadge", new Vector2(0f, -53f),
                new Vector2(86f, 22f),
                new Color(0.01f, 0.02f, 0.03f, 0.88f), false);
            CreateUiText(lockBadge.transform, "LOCKED", 11,
                new Color(0.72f, 0.76f, 0.78f), TextAnchor.MiddleCenter,
                Vector2.zero, new Vector2(86f, 22f));
            lockBadge.SetActive(!unlocked);
        }

        // Keep the artwork-sized node button for visuals, but give each
        // visible node a slightly larger transparent hit area.  The map is
        // panned and scaled by Canvas, so relying on a second IMGUI rect can
        // drift away from the actual sprite in the Editor Game view.  This
        // target stays in the same ScrollRect content and therefore follows
        // the node exactly while the map moves.
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            if (stage == null) continue;

            GameObject hitObject = new GameObject(
                $"StageHitTarget_{stage.stageId}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            hitObject.transform.SetParent(mapCanvasContent, false);
            RectTransform hitRect = hitObject.GetComponent<RectTransform>();
            hitRect.anchorMin = new Vector2(0f, 1f);
            hitRect.anchorMax = new Vector2(0f, 1f);
            hitRect.pivot = new Vector2(0.5f, 0.5f);
            hitRect.sizeDelta = new Vector2(MapNodeSize + 28f, MapNodeSize + 28f);
            hitRect.anchoredPosition = nodePositions[i];

            Image hitImage = hitObject.GetComponent<Image>();
            hitImage.color = new Color(1f, 1f, 1f, 0f);
            hitImage.raycastTarget = true;
            Button hitButton = hitObject.GetComponent<Button>();
            Transform visualNode = mapCanvasContent.Find($"StageNode_{stage.stageId}");
            Image visualNodeImage = visualNode != null
                ? visualNode.GetComponent<Image>() : null;
            // The hit target owns the pointer event, but tints the actual
            // visible node so hover feedback remains exactly where the mouse
            // is pointing.
            hitButton.targetGraphic = visualNodeImage != null
                ? visualNodeImage : hitImage;
            if (visualNodeImage != null)
            {
                ConfigureButtonHover(hitButton, visualNodeImage.color,
                    new Color(1f, 0.84f, 0.36f, 1f));
            }
            else
            {
                hitButton.transition = Selectable.Transition.None;
            }
            hitButton.navigation = new Navigation { mode = Navigation.Mode.None };
            hitButton.interactable = IsStageUnlocked(stage.stageId, GetStages());
            int hitStageId = stage.stageId;
            hitButton.onClick.AddListener(() => OpenStageInfo(hitStageId));
            mapStageButtons[hitButton] = hitStageId;
        }

        CreateMapHeroToken(stages);

        mapCanvasScrollRect.normalizedPosition = new Vector2(0.5f, 0.5f);
        RefreshMapStagePresentation();
    }

    private void CreateMapStageGroupVisual(RectTransform contentTransform)
    {
        List<MapStageGroup> groups = GetMapStageGroups(currentMapPage);
        if (contentTransform == null || groups.Count == 0)
            return;

        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        Vector2[] nodePositions = new Vector2[groups.Count];
        for (int i = 0; i < groups.Count; i++)
        {
            Vector2 position = GetMapStageGroupNodePosition(mapContent, i, groups.Count);
            nodePositions[i] = new Vector2(position.x, -position.y);
            if (i < groups.Count - 1)
            {
                Vector2 nextPosition = GetMapStageGroupNodePosition(mapContent, i + 1,
                    groups.Count);
                CreateMapLine(contentTransform, nodePositions[i],
                    new Vector2(nextPosition.x, -nextPosition.y), i);
            }
        }

        for (int i = 0; i < groups.Count; i++)
        {
            MapStageGroup group = groups[i];
            bool unlocked = IsMapStageGroupUnlocked(group);
            bool cleared = IsMapStageGroupCleared(group);
            GameObject nodeObject = new GameObject("StageGroupNode_" + group.groupId,
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(contentTransform, false);
            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(MapNodeSize, MapNodeSize);
            nodeRect.anchoredPosition = nodePositions[i];

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.sprite = GetMapCircleSprite();
            nodeImage.color = unlocked
                ? (cleared ? new Color(0.25f, 0.68f, 0.46f, 1f)
                    : new Color(0.95f, 0.55f, 0.18f, 1f))
                : new Color(0.16f, 0.20f, 0.23f, 1f);
            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.interactable = unlocked;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            ConfigureButtonHover(nodeButton, nodeImage.color,
                unlocked ? new Color(1f, 0.84f, 0.36f, 1f) : nodeImage.color);
            int selectedGroupId = group.groupId;
            nodeButton.onClick.AddListener(() =>
                OpenStageGroupInfo(currentMapPage, selectedGroupId));
            mapStageButtons[nodeButton] = group.levels[0].stageId;

            GameObject iconObject = new GameObject("StageGroupIcon",
                typeof(RectTransform), typeof(Image));
            iconObject.transform.SetParent(nodeObject.transform, false);
            RectTransform iconRect = iconObject.GetComponent<RectTransform>();
            iconRect.anchorMin = Vector2.zero;
            iconRect.anchorMax = Vector2.one;
            iconRect.offsetMin = new Vector2(12f, 12f);
            iconRect.offsetMax = new Vector2(-12f, -12f);
            Image iconImage = iconObject.GetComponent<Image>();
            iconImage.sprite = GetStageIconSprite(group.levels[0], i);
            iconImage.color = unlocked ? Color.white :
                new Color(0.42f, 0.46f, 0.48f, 0.52f);
            iconImage.preserveAspect = true;
            iconImage.raycastTarget = false;

            GameObject numberBadge = CreateUiImage(nodeObject.transform,
                "StageGroupNumberBadge", new Vector2(0f, 54f),
                new Vector2(116f, 28f),
                new Color(0.01f, 0.025f, 0.04f, 0.94f), false);
            CreateUiText(numberBadge.transform, "STAGE " + group.groupId, 16,
                unlocked ? new Color(1f, 0.91f, 0.48f) :
                    new Color(0.62f, 0.66f, 0.68f), TextAnchor.MiddleCenter,
                Vector2.zero, new Vector2(116f, 28f));

            StageDefinition firstLevel = group.levels[0];
            StageDefinition lastLevel = group.levels[group.levels.Count - 1];
            CreateUiText(nodeObject.transform,
                "LEVEL " + firstLevel.stageId + " - " + lastLevel.stageId,
                11, Color.white, TextAnchor.MiddleCenter,
                new Vector2(0f, -53f), new Vector2(150f, 22f));

            if (!unlocked)
            {
                GameObject lockBadge = CreateUiImage(nodeObject.transform,
                    "StageGroupLockBadge", new Vector2(0f, -74f),
                    new Vector2(86f, 22f),
                    new Color(0.01f, 0.02f, 0.03f, 0.88f), false);
                CreateUiText(lockBadge.transform, "LOCKED", 11,
                    new Color(0.72f, 0.76f, 0.78f), TextAnchor.MiddleCenter,
                    Vector2.zero, new Vector2(86f, 22f));
            }
        }

        CreateMapHeroTokenForGroups(groups);
        RefreshMapStageGroupPresentation();
    }

    private Vector2 GetMapSelectionNodePosition(Rect mapArea, int mapPage)
    {
        // Locations are deliberately tied to distinct regions in the world
        // background. The extra slots reserve places for future stage types:
        // forest, volcano, crossroads, waterfall, mountain pass and bridge.
        // This keeps new stage groups from being piled on top of Stage1/2.
        Vector2[] worldLocations =
        {
            new Vector2(0.12f, 0.23f), // village / grassland
            new Vector2(0.76f, 0.23f), // ancient ruins
            new Vector2(0.78f, 0.72f), // enchanted forest
            new Vector2(0.15f, 0.72f), // volcano
            new Vector2(0.50f, 0.46f), // central crossroads
            new Vector2(0.48f, 0.16f), // waterfall valley
            new Vector2(0.60f, 0.72f), // mountain pass
            new Vector2(0.30f, 0.52f)  // river bridge
        };
        int locationIndex = Mathf.Clamp(mapPage - 1, 0,
            worldLocations.Length - 1);
        Vector2 normalized = worldLocations[locationIndex];
        return new Vector2(
            Mathf.Lerp(mapArea.x, mapArea.xMax, normalized.x),
            Mathf.Lerp(mapArea.y, mapArea.yMax, normalized.y));
    }

    private void CreateMapSelectionNodes(RectTransform contentTransform)
    {
        if (contentTransform == null)
            return;

        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        List<MapStageGroup> groups = GetMapStageGroups(currentMapPage);
        for (int i = 0; i < groups.Count; i++)
        {
            MapStageGroup group = groups[i];
            if (group == null || group.levels.Count == 0)
                continue;

            bool unlocked = IsMapStageGroupUnlocked(group);
            Vector2 position = GetMapSelectionNodePosition(mapContent, i + 1);
            GameObject nodeObject = new GameObject($"MapStageSelectionNode_{group.groupId}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(contentTransform, false);

            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(180f, 180f);
            nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.sprite = GetUiWhiteSprite();
            // Keep an almost invisible parent Image as the pointer hit area;
            // the map art remains visible behind the entrance landmark.
            nodeImage.color = new Color(1f, 1f, 1f, 0.001f);

            // Make the entrance legible without turning it back into a large
            // floating card. The colored location disk anchors the landmark
            // to the world map and the outline separates it from the terrain.
            GameObject markerObject = CreateUiImage(nodeObject.transform,
                "StageEntranceMarker", new Vector2(0f, -4f),
                new Vector2(164f, 164f),
                group.groupId >= 2
                    ? new Color(0.16f, 0.28f, 0.72f, 0.82f)
                    : new Color(0.08f, 0.56f, 0.32f, 0.82f), false);
            Image markerImage = markerObject.GetComponent<Image>();
            markerImage.sprite = GetMapCircleSprite();
            markerImage.raycastTarget = false;
            Outline markerOutline = markerObject.AddComponent<Outline>();
            markerOutline.effectColor = group.groupId >= 2
                ? new Color(0.48f, 0.82f, 1f, 0.98f)
                : new Color(0.62f, 1f, 0.70f, 0.98f);
            markerOutline.effectDistance = new Vector2(4f, 4f);

            // Stage selection uses a landmark rather than a gameplay node
            // icon.  The landmark sits on the map-colored card so the choice
            // reads as the entrance to a whole stage group.
            GameObject landmarkObject = CreateUiImage(nodeObject.transform,
                "StageLandmark", new Vector2(0f, -2f), new Vector2(164f, 132f),
                unlocked ? Color.white : new Color(0.48f, 0.50f, 0.52f, 0.72f),
                false);
            Image landmarkImage = landmarkObject.GetComponent<Image>();
            landmarkImage.sprite = GetStageLandmarkSprite(group.groupId);
            landmarkImage.preserveAspect = true;
            landmarkImage.raycastTarget = false;

            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = landmarkImage;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            nodeButton.interactable = unlocked;
            ConfigureButtonHover(nodeButton, landmarkImage.color,
                unlocked ? new Color(1f, 0.88f, 0.45f, 1f) : landmarkImage.color);
            int selectedGroupId = group.groupId;
            nodeButton.onClick.AddListener(() =>
                SelectStageGroupFromSelectionScreen(selectedGroupId));

            GameObject numberBadge = CreateUiImage(nodeObject.transform,
                "StageGroupNumber", new Vector2(0f, 92f), new Vector2(150f, 32f),
                new Color(0.01f, 0.025f, 0.04f, 0.94f), false);
            RectTransform numberBadgeRect = numberBadge.GetComponent<RectTransform>();
            numberBadgeRect.sizeDelta = new Vector2(140f, 28f);
            numberBadgeRect.anchoredPosition = new Vector2(0f, 82f);
            Image numberBadgeImage = numberBadge.GetComponent<Image>();
            numberBadgeImage.color = group.groupId >= 2
                ? new Color(0.04f, 0.12f, 0.30f, 0.96f)
                : new Color(0.02f, 0.22f, 0.14f, 0.96f);
            Outline numberBadgeOutline = numberBadge.AddComponent<Outline>();
            numberBadgeOutline.effectColor = group.groupId >= 2
                ? new Color(0.48f, 0.82f, 1f, 0.95f)
                : new Color(0.62f, 1f, 0.70f, 0.95f);
            numberBadgeOutline.effectDistance = new Vector2(2f, 2f);
            CreateUiText(numberBadge.transform, $"STAGE {group.groupId}", 19,
                unlocked ? new Color(1f, 0.91f, 0.48f) :
                    new Color(0.62f, 0.66f, 0.68f), TextAnchor.MiddleCenter,
                Vector2.zero, new Vector2(140f, 28f));

            StageDefinition firstLevel = group.levels[0];
            StageDefinition lastLevel = group.levels[group.levels.Count - 1];
            GameObject levelBadge = CreateUiImage(nodeObject.transform,
                "StageLevelBadge", new Vector2(0f, -84f), new Vector2(150f, 26f),
                new Color(0.01f, 0.025f, 0.04f, 0.90f), false);
            CreateUiText(levelBadge.transform,
                $"LEVEL {firstLevel.stageId} - {lastLevel.stageId}", 15,
                unlocked ? Color.white : new Color(0.62f, 0.66f, 0.68f),
                TextAnchor.MiddleCenter, Vector2.zero, new Vector2(150f, 26f));

            if (!unlocked)
            {
                GameObject lockBadge = CreateUiImage(nodeObject.transform,
                    "StageGroupLocked", new Vector2(0f, -88f), new Vector2(110f, 26f),
                    new Color(0.01f, 0.02f, 0.03f, 0.9f), false);
                lockBadge.GetComponent<RectTransform>().anchoredPosition =
                    new Vector2(0f, -101f);
                CreateUiText(lockBadge.transform, "LOCKED", 12,
                    new Color(0.72f, 0.76f, 0.78f), TextAnchor.MiddleCenter,
                    Vector2.zero, new Vector2(110f, 26f));
            }
        }
    }

    private void SelectStageGroupFromSelectionScreen(int groupId)
    {
        if (state != GameState.Menu || !mapTravelMode)
            return;

        MapStageGroup group = GetMapStageGroup(currentMapPage, groupId);
        if (!IsMapStageGroupUnlocked(group))
            return;

        PlayConfirmSound();
        int firstUnlockedIndex = 0;
        List<StageDefinition> allStages = GetStages();
        for (int i = 0; i < group.levels.Count; i++)
        {
            if (IsStageUnlocked(group.levels[i].stageId, allStages))
            {
                firstUnlockedIndex = i;
                break;
            }
        }

        selectedStage = group.levels[firstUnlockedIndex].stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();
        mapTravelMode = false;
        RebuildMapVisualForCurrentPage();
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void CreateMapHeroToken(List<StageDefinition> stages)
    {
        if (mapCanvasContent == null || mapHeroTokenRect != null || stages == null ||
            stages.Count == 0)
            return;

        GameObject heroObject = new GameObject("MapHeroToken",
            typeof(RectTransform), typeof(Image));
        heroObject.transform.SetParent(mapCanvasContent, false);

        mapHeroTokenRect = heroObject.GetComponent<RectTransform>();
        mapHeroTokenRect.anchorMin = new Vector2(0f, 1f);
        mapHeroTokenRect.anchorMax = new Vector2(0f, 1f);
        mapHeroTokenRect.pivot = new Vector2(0.5f, 0.5f);
        mapHeroTokenRect.sizeDelta = new Vector2(MapHeroTokenSize, MapHeroTokenSize);

        mapHeroTokenImage = heroObject.GetComponent<Image>();
        mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;

        int stageIndex = GetStageIndex(selectedStage, stages);
        mapHeroStageId = stages[stageIndex].stageId;
        mapHeroTokenRect.anchoredPosition = GetMapStageCanvasPosition(
            stageIndex, stages.Count);
        heroObject.transform.SetAsLastSibling();
    }

    private void CreateMapHeroTokenForGroups(List<MapStageGroup> groups)
    {
        if (mapCanvasContent == null || mapHeroTokenRect != null ||
            groups == null || groups.Count == 0)
            return;

        GameObject heroObject = new GameObject("MapHeroToken",
            typeof(RectTransform), typeof(Image));
        heroObject.transform.SetParent(mapCanvasContent, false);
        mapHeroTokenRect = heroObject.GetComponent<RectTransform>();
        mapHeroTokenRect.anchorMin = new Vector2(0f, 1f);
        mapHeroTokenRect.anchorMax = new Vector2(0f, 1f);
        mapHeroTokenRect.pivot = new Vector2(0.5f, 0.5f);
        mapHeroTokenRect.sizeDelta = new Vector2(MapHeroTokenSize, MapHeroTokenSize);
        mapHeroTokenImage = heroObject.GetComponent<Image>();
        mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;

        int groupId = GetStageGroupIdForLevel(selectedStage);
        int groupIndex = GetMapStageGroupIndex(groups, groupId);
        if (groupIndex < 0) groupIndex = 0;
        Vector2 mapContent = new Vector2(MapContentWidth, MapContentHeight);
        Vector2 position = GetMapStageGroupNodePosition(
            new Rect(0f, 0f, mapContent.x, mapContent.y),
            groupIndex, groups.Count);
        mapHeroStageId = selectedStage;
        mapHeroTokenRect.anchoredPosition = new Vector2(position.x, -position.y);
        heroObject.transform.SetAsLastSibling();
    }

    private Sprite GetMapHeroIdleSprite()
    {
        if (catalog == null)
            catalog = Resources.Load<StageCatalog>("StageCatalog");
        return catalog != null ? catalog.mapHeroIdleSprite : null;
    }

    private Sprite[] GetMapHeroRunSprites()
    {
        if (catalog == null)
            catalog = Resources.Load<StageCatalog>("StageCatalog");
        return catalog != null ? catalog.mapHeroRunSprites : null;
    }

    private void EnsureMapHeroTokenVisible()
    {
        if (state != GameState.Menu || mapCanvasContent == null) return;

        if (mapHeroTokenRect == null)
        {
            if (mapTravelMode)
                return;
            CreateMapHeroToken(GetCurrentMapStages());
            return;
        }

        if (mapHeroTokenImage == null)
            mapHeroTokenImage = mapHeroTokenRect.GetComponent<Image>();
        if (mapHeroTokenImage == null) return;

        if (mapHeroTokenImage.sprite == null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenRect.gameObject.SetActive(true);
        mapHeroTokenImage.enabled = true;
        mapHeroTokenImage.color = Color.white;
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;
        mapHeroTokenRect.SetAsLastSibling();
    }

    private void RestoreMapHeroTokenVisual()
    {
        if (mapHeroTokenRect == null) return;

        mapHeroTokenRect.gameObject.SetActive(true);
        mapHeroTokenRect.SetAsLastSibling();
        if (mapHeroTokenImage == null)
            mapHeroTokenImage = mapHeroTokenRect.GetComponent<Image>();
        if (mapHeroTokenImage == null) return;

        if (mapHeroTokenImage.sprite == null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenImage.enabled = true;
        mapHeroTokenImage.color = Color.white;
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;
    }

    private int GetStageIndex(int stageId, List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0) return 0;

        int index = stages.FindIndex(stage => stage != null && stage.stageId == stageId);
        return index >= 0 ? index : 0;
    }

    private Vector2 GetMapStageCanvasPosition(int stageIndex, int stageCount)
    {
        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        List<StageDefinition> stages = GetCurrentMapStages();
        StageDefinition stage = stageIndex >= 0 && stageIndex < stages.Count
            ? stages[stageIndex] : null;
        Vector2 mapPosition = GetMapNodePosition(mapContent, stage, stageIndex,
            stageCount);
        return new Vector2(mapPosition.x, -mapPosition.y);
    }

    private Vector2 GetMapNodePosition(Rect mapArea, StageDefinition stage,
        int index, int count)
    {
        if (!mapTravelMode)
        {
            int routeGroupId = stage == null ? 1 : GetStageGroupIdForLevel(stage.stageId);
            return GetStageNodePosition(mapArea, index, count, routeGroupId);
        }

        if (stage == null)
            return GetStageNodePosition(mapArea, index, count);

        // Travel mode is a landmark map, not a route map. These positions
        // deliberately follow each stage's concept: village, windmill, river,
        // bridge, farm and ruins on map 1; corridors, halls and waterways on
        // map 2. There are no connecting lines in this mode.
        Vector2[] mapOneLandmarks =
        {
            new Vector2(0.12f, 0.24f), // 1: 旅立ちの丘
            new Vector2(0.28f, 0.28f), // 2: 風車の丘
            new Vector2(0.42f, 0.42f), // 3: せせらぎ
            new Vector2(0.54f, 0.26f), // 4: 石の橋
            new Vector2(0.68f, 0.28f), // 5: 羊の牧場
            new Vector2(0.84f, 0.38f), // 6: 花の野原
            new Vector2(0.76f, 0.60f), // 7: 木の実の農園
            new Vector2(0.62f, 0.76f), // 8: 見晴らし台
            new Vector2(0.43f, 0.66f), // 9: 旅人の野営地
            new Vector2(0.24f, 0.73f)  // 10: 村への入口
        };
        Vector2[] mapTwoLandmarks =
        {
            new Vector2(0.13f, 0.28f), // 崩れた回廊
            new Vector2(0.36f, 0.48f), // 砂時計の間
            new Vector2(0.58f, 0.30f), // 地下水路
            new Vector2(0.77f, 0.51f), // 封印の広間
            new Vector2(0.54f, 0.74f)  // 遺跡の最深部
        };

        Vector2[] landmarks = currentMapPage == 2
            ? mapTwoLandmarks : mapOneLandmarks;
        Vector2 normalized = index >= 0 && index < landmarks.Length
            ? landmarks[index]
            : new Vector2(0.5f, 0.5f);
        return new Vector2(
            Mathf.Lerp(mapArea.x, mapArea.xMax, normalized.x),
            Mathf.Lerp(mapArea.y, mapArea.yMax, normalized.y));
    }

    private void SelectMapTravelStage(int stageId)
    {
        List<StageDefinition> pageStages = GetCurrentMapStages();
        List<StageDefinition> allStages = GetStages();
        StageDefinition stage = pageStages.Find(item => item.stageId == stageId);
        if (stage == null || !IsStageUnlocked(stageId, allStages))
            return;

        PlayConfirmSound();
        MoveMapHeroToStage(stageId);
        RequestEditorRepaint();
    }

    private void SelectMapFromSelectionScreen(int mapPage)
    {
        if (state != GameState.Menu || !mapTravelMode)
            return;

        int highestUnlockedPage = GetHighestUnlockedMapPage();
        if (mapPage < 1 || mapPage > highestUnlockedPage)
            return;

        List<StageDefinition> pageStages = GetMapPageStages(mapPage);
        if (pageStages.Count == 0)
            return;

        PlayConfirmSound();
        currentMapPage = mapPage;

        List<StageDefinition> allStages = GetStages();
        int lastUnlockedIndex = -1;
        for (int i = 0; i < pageStages.Count; i++)
        {
            if (IsStageUnlocked(pageStages[i].stageId, allStages))
                lastUnlockedIndex = i;
        }

        selectedStage = pageStages[Mathf.Max(0, lastUnlockedIndex)].stageId;
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();

        // Enter the chosen map's normal stage-select screen. This is the
        // actual destination transition; the map-selection screen itself is
        // not another page of the stage route.
        mapTravelMode = false;
        RebuildMapVisualForCurrentPage();
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void MoveMapHeroToStage(int stageId)
    {
        List<StageDefinition> stages = GetCurrentMapStages();
        if (stages.Count == 0) return;

        if (!IsStageUnlocked(stageId, GetStages()))
            return;

        int stageIndex = GetStageIndex(stageId, stages);
        selectedStage = stages[stageIndex].stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();

        if (mapHeroTokenRect == null)
            return;

        FocusMapOnStage(stageIndex, stages.Count);
        if (mapHeroMoveRoutine != null)
            StopCoroutine(mapHeroMoveRoutine);

        mapHeroMoveRoutine = StartCoroutine(AnimateMapHeroAlongRoute(
            stages, stageIndex, selectedStage));
    }

    private void FocusMapOnStage(int stageIndex, int stageCount)
    {
        if (stageCount <= 0) return;

        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        List<StageDefinition> stages = GetCurrentMapStages();
        StageDefinition stage = stageIndex >= 0 && stageIndex < stages.Count
            ? stages[stageIndex] : null;
        Vector2 mapPosition = GetMapNodePosition(mapContent, stage, stageIndex,
            stageCount);
        float maxScrollX = Mathf.Max(0f, MapContentWidth - MapViewportWidth);
        float maxScrollY = Mathf.Max(0f, MapContentHeight - MapViewportHeight);
        Vector2 targetScroll = new Vector2(
            Mathf.Clamp(mapPosition.x - MapViewportWidth * 0.5f, 0f, maxScrollX),
            Mathf.Clamp(mapPosition.y - MapViewportHeight * 0.5f, 0f, maxScrollY));

        Vector2 targetCameraPan = Vector2.zero;
        if (mapCameraConfigured && mapCamera != null)
        {
            float cameraX = maxScrollX <= 0f
                ? 0f
                : (targetScroll.x - maxScrollX * 0.5f) /
                    (maxScrollX * 0.5f) * MapCameraPanLimit.x;
            float cameraY = maxScrollY <= 0f
                ? 0f
                : (targetScroll.y - maxScrollY * 0.5f) /
                    (maxScrollY * 0.5f) * MapCameraPanLimit.y;
            targetCameraPan = new Vector2(
                Mathf.Clamp(cameraX, -MapCameraPanLimit.x, MapCameraPanLimit.x),
                Mathf.Clamp(cameraY, -MapCameraPanLimit.y, MapCameraPanLimit.y));
        }

        if (mapFocusRoutine != null)
            StopCoroutine(mapFocusRoutine);
        mapFocusRoutine = StartCoroutine(AnimateMapFocusTo(
            targetScroll, targetCameraPan));
    }

    private IEnumerator AnimateMapFocusTo(Vector2 targetScroll, Vector2 targetCameraPan)
    {
        Vector2 startScroll = mapScrollPosition;
        Vector2 startCameraPan = mapCameraPan;
        float elapsed = 0f;

        while (elapsed < MapFocusMoveDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / MapFocusMoveDuration);
            float easedProgress = Mathf.SmoothStep(0f, 1f, progress);
            mapScrollPosition = Vector2.Lerp(startScroll, targetScroll, easedProgress);
            mapCameraPan = Vector2.Lerp(startCameraPan, targetCameraPan, easedProgress);
            mapScrollInitialized = true;

            if (mapCameraConfigured && mapCamera != null)
            {
                mapCamera.transform.position = mapCameraHomePosition +
                    new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);
            }

            ApplyMapCanvasContentOffset();
            SyncMapPanOverlayFromPosition();
            RequestEditorRepaint();
            yield return null;
        }

        mapScrollPosition = targetScroll;
        mapCameraPan = targetCameraPan;
        mapScrollInitialized = true;
        if (mapCameraConfigured && mapCamera != null)
        {
            mapCamera.transform.position = mapCameraHomePosition +
                new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);
        }
        ApplyMapCanvasContentOffset();
        SyncMapPanOverlayFromPosition();
        RequestEditorRepaint();
        mapFocusRoutine = null;
    }

    private IEnumerator AnimateMapHeroAlongRoute(
        List<StageDefinition> stages, int targetStageIndex, int targetStageId)
    {
        if (mapHeroTokenRect == null || stages == null || stages.Count == 0)
            yield break;

        Vector2[] nodePositions = new Vector2[stages.Count];
        for (int i = 0; i < stages.Count; i++)
            nodePositions[i] = GetMapStageCanvasPosition(i, stages.Count);

        Vector2 currentPosition = mapHeroTokenRect.anchoredPosition;
        if (mapTravelMode)
        {
            yield return AnimateMapHeroSegment(currentPosition,
                nodePositions[targetStageIndex]);
            mapHeroTokenRect.anchoredPosition = nodePositions[targetStageIndex];
            if (mapHeroTokenImage != null)
                mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
            mapHeroStageId = targetStageId;
            mapHeroMoveRoutine = null;
            yield break;
        }

        List<Vector2> waypoints = new List<Vector2>();
        int nearestNodeIndex = -1;
        float nearestNodeDistance = float.MaxValue;
        float nodeSnapDistance = MapNodeSize * 0.35f;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            float distance = Vector2.Distance(currentPosition, nodePositions[i]);
            if (distance < nearestNodeDistance)
            {
                nearestNodeDistance = distance;
                nearestNodeIndex = i;
            }
        }

        if (nearestNodeDistance <= nodeSnapDistance)
        {
            int direction = targetStageIndex >= nearestNodeIndex ? 1 : -1;
            for (int i = nearestNodeIndex + direction;
                direction > 0 ? i <= targetStageIndex : i >= targetStageIndex;
                i += direction)
            {
                waypoints.Add(nodePositions[i]);
            }
        }
        else
        {
            int segmentIndex = FindClosestMapRouteSegment(currentPosition, nodePositions);
            if (targetStageIndex > segmentIndex)
            {
                for (int i = segmentIndex + 1; i <= targetStageIndex; i++)
                    waypoints.Add(nodePositions[i]);
            }
            else
            {
                for (int i = segmentIndex; i >= targetStageIndex; i--)
                    waypoints.Add(nodePositions[i]);
            }
        }

        for (int i = 0; i < waypoints.Count; i++)
        {
            Vector2 target = waypoints[i];
            yield return AnimateMapHeroSegment(currentPosition, target);
            currentPosition = target;

            int reachedNode = FindClosestMapNode(target, nodePositions);
            if (reachedNode >= 0)
                mapHeroStageId = stages[reachedNode].stageId;
        }

        mapHeroTokenRect.anchoredPosition = nodePositions[targetStageIndex];
        if (mapHeroTokenImage != null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroStageId = targetStageId;
        mapHeroMoveRoutine = null;
    }

    private IEnumerator AnimateMapHeroSegment(Vector2 start, Vector2 target)
    {
        float distance = Vector2.Distance(start, target);
        if (distance <= 0.5f)
        {
            mapHeroTokenRect.anchoredPosition = target;
            yield break;
        }

        Sprite[] runSprites = GetMapHeroRunSprites();
        float duration = Mathf.Clamp(distance / 420f, 0.28f, 1.1f);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / duration);
            mapHeroTokenRect.anchoredPosition = Vector2.Lerp(start, target, progress);

            if (mapHeroTokenImage != null && runSprites != null && runSprites.Length > 0)
            {
                int frame = Mathf.FloorToInt(elapsed / MapHeroRunFrameDuration) %
                    runSprites.Length;
                mapHeroTokenImage.sprite = runSprites[frame];
            }

            yield return null;
        }

        mapHeroTokenRect.anchoredPosition = target;
    }

    private int FindClosestMapRouteSegment(Vector2 position, Vector2[] nodePositions)
    {
        if (nodePositions == null || nodePositions.Length < 2)
            return 0;

        int closestSegment = 0;
        float closestDistance = float.MaxValue;
        for (int i = 0; i < nodePositions.Length - 1; i++)
        {
            Vector2 start = nodePositions[i];
            Vector2 direction = nodePositions[i + 1] - start;
            float lengthSquared = direction.sqrMagnitude;
            float projection = lengthSquared <= 0.001f
                ? 0f
                : Mathf.Clamp01(Vector2.Dot(position - start, direction) / lengthSquared);
            Vector2 pointOnSegment = start + direction * projection;
            float distance = (position - pointOnSegment).sqrMagnitude;
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestSegment = i;
            }
        }

        return closestSegment;
    }

    private int FindClosestMapNode(Vector2 position, Vector2[] nodePositions)
    {
        if (nodePositions == null || nodePositions.Length == 0)
            return -1;

        int closestNode = 0;
        float closestDistance = float.MaxValue;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            float distance = (position - nodePositions[i]).sqrMagnitude;
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestNode = i;
            }
        }

        return closestNode;
    }

    private void OnMapCanvasScrollChanged(Vector2 normalizedPosition)
    {
        if (updatingMapCanvasScroll || mapCanvasContent == null) return;

        float maxX = Mathf.Max(0f, mapCanvasContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapCanvasContent.rect.height - MapViewportHeight);
        mapScrollPosition = new Vector2(
            normalizedPosition.x * maxX,
            (1f - normalizedPosition.y) * maxY);
    }

    private void CreateMapPanOverlay()
    {
        if (mapPanOverlay != null || titleButtonCanvasObject == null) return;

        // This transparent ScrollRect is the real input surface for the map.
        // The map itself remains drawn by OnGUI, while Unity's UI input module
        // receives mouse, trackpad and touchpad drag events reliably.
        mapPanOverlay = new GameObject("MapPanInput", typeof(RectTransform),
            typeof(Image), typeof(ScrollRect));
        mapPanOverlay.transform.SetParent(titleButtonCanvasObject.transform, false);

        RectTransform viewport = mapPanOverlay.GetComponent<RectTransform>();
        viewport.anchorMin = new Vector2(0.5f, 0.5f);
        viewport.anchorMax = new Vector2(0.5f, 0.5f);
        viewport.pivot = new Vector2(0.5f, 0.5f);
        viewport.sizeDelta = new Vector2(MapViewportWidth, MapViewportHeight);
        viewport.anchoredPosition = new Vector2(0f, -10f);

        Image inputImage = mapPanOverlay.GetComponent<Image>();
        inputImage.color = new Color(0f, 0f, 0f, 0f);
        inputImage.raycastTarget = true;

        mapPanContent = new GameObject("MapPanContent", typeof(RectTransform),
            typeof(Image)).GetComponent<RectTransform>();
        mapPanContent.SetParent(viewport, false);
        mapPanContent.anchorMin = new Vector2(0f, 1f);
        mapPanContent.anchorMax = new Vector2(0f, 1f);
        mapPanContent.pivot = new Vector2(0f, 1f);
        mapPanContent.sizeDelta = new Vector2(MapContentWidth, MapContentHeight);
        mapPanContent.anchoredPosition = Vector2.zero;
        Image contentImage = mapPanContent.GetComponent<Image>();
        contentImage.color = new Color(0f, 0f, 0f, 0f);
        contentImage.raycastTarget = false;

        mapPanScrollRect = mapPanOverlay.GetComponent<ScrollRect>();
        mapPanScrollRect.viewport = viewport;
        mapPanScrollRect.content = mapPanContent;
        mapPanScrollRect.horizontal = true;
        mapPanScrollRect.vertical = true;
        mapPanScrollRect.movementType = ScrollRect.MovementType.Clamped;
        mapPanScrollRect.inertia = false;
        mapPanScrollRect.scrollSensitivity = 1f;
        mapPanScrollRect.horizontalScrollbar = null;
        mapPanScrollRect.verticalScrollbar = null;
        mapPanScrollRect.onValueChanged.AddListener(OnMapPanScrollRectChanged);

        CreateMapPanNodeButtons();
        mapPanOverlay.transform.SetAsLastSibling();
        SyncMapPanOverlayFromPosition();
    }

    private void CreateMapPanNodeButtons()
    {
        if (mapPanContent == null) return;

        if (mapTravelMode)
        {
            Rect selectionMapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
            List<MapStageGroup> selectionGroups =
                GetMapStageGroups(currentMapPage);
            for (int i = 0; i < selectionGroups.Count; i++)
            {
                MapStageGroup group = selectionGroups[i];
                GameObject nodeObject = new GameObject(
                    $"MapPanStageSelectionNode_{group.groupId}",
                    typeof(RectTransform), typeof(Image), typeof(Button));
                nodeObject.transform.SetParent(mapPanContent, false);
                RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
                nodeRect.anchorMin = new Vector2(0f, 1f);
                nodeRect.anchorMax = new Vector2(0f, 1f);
                nodeRect.pivot = new Vector2(0.5f, 0.5f);
                nodeRect.sizeDelta = new Vector2(180f, 180f);
                Vector2 position = GetMapSelectionNodePosition(selectionMapContent, i + 1);
                nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

                Image nodeImage = nodeObject.GetComponent<Image>();
                nodeImage.color = new Color(1f, 1f, 1f, 0f);
                nodeImage.raycastTarget = true;
                Button nodeButton = nodeObject.GetComponent<Button>();
                nodeButton.targetGraphic = nodeImage;
                nodeButton.transition = Selectable.Transition.None;
                nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
                nodeButton.interactable = IsMapStageGroupUnlocked(group);
                int selectedGroupId = group.groupId;
                nodeButton.onClick.AddListener(() =>
                    SelectStageGroupFromSelectionScreen(selectedGroupId));
                mapPanNodeButtons.Add(nodeButton);
            }
            return;
        }

        List<StageDefinition> stages = GetCurrentMapStages();
        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            Vector2 position = GetMapNodePosition(mapContent, stage, i, stages.Count);
            GameObject nodeObject = new GameObject("MapPanNode_" + stage.stageId,
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(mapPanContent, false);

            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(90f, 90f);
            nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.color = new Color(1f, 1f, 1f, 0f);
            nodeImage.raycastTarget = true;

            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.transition = Selectable.Transition.None;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            nodeButton.interactable = IsStageUnlocked(stage.stageId, GetStages());
            int selectedStageId = stage.stageId;
            nodeButton.onClick.AddListener(() =>
                OpenStageInfo(selectedStageId));
            mapPanNodeButtons.Add(nodeButton);
        }
    }

    private void RebuildMapPanNodeButtons()
    {
        if (mapPanContent == null)
            return;

        for (int i = mapPanContent.childCount - 1; i >= 0; i--)
            Destroy(mapPanContent.GetChild(i).gameObject);
        mapPanNodeButtons.Clear();
        CreateMapPanNodeButtons();
    }

    private void CreateSkillTreePanOverlay()
    {
        if (skillTreePanOverlay != null || titleButtonCanvasObject == null) return;

        // Use a real ScrollRect as the input surface. IMGUI receives trackpad
        // wheel events only when the Game view has focus, while ScrollRect is
        // also fed by Unity's Input System UI module and handles two-finger
        // scrolling/dragging consistently.
        skillTreePanOverlay = new GameObject("SkillTreePanInput",
            typeof(RectTransform), typeof(Image), typeof(ScrollRect));
        skillTreePanOverlay.transform.SetParent(titleButtonCanvasObject.transform, false);

        RectTransform viewport = skillTreePanOverlay.GetComponent<RectTransform>();
        viewport.anchorMin = new Vector2(0.5f, 0.5f);
        viewport.anchorMax = new Vector2(0.5f, 0.5f);
        viewport.pivot = new Vector2(0.5f, 0.5f);
        viewport.sizeDelta = new Vector2(MapViewportWidth, 425f);
        viewport.anchoredPosition = new Vector2(0f, -17.5f);

        Image viewportImage = skillTreePanOverlay.GetComponent<Image>();
        viewportImage.color = new Color(0f, 0f, 0f, 0f);
        viewportImage.raycastTarget = true;
        // The input overlay must have the same clipping boundary as the
        // visible IMGUI tree. Otherwise a transparent node button can remain
        // clickable after its visual node has moved outside the frame.
        skillTreePanOverlay.AddComponent<RectMask2D>();

        skillTreePanContent = new GameObject("SkillTreePanContent",
            typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
        skillTreePanContent.SetParent(viewport, false);
        skillTreePanContent.anchorMin = new Vector2(0f, 1f);
        skillTreePanContent.anchorMax = new Vector2(0f, 1f);
        skillTreePanContent.pivot = new Vector2(0f, 1f);
        skillTreePanContent.sizeDelta = new Vector2(
            SkillTreeContentWidth, SkillTreeContentHeight);
        skillTreePanContent.anchoredPosition = Vector2.zero;
        Image contentImage = skillTreePanContent.GetComponent<Image>();
        contentImage.color = new Color(0f, 0f, 0f, 0f);
        contentImage.raycastTarget = false;

        skillTreePanScrollRect = skillTreePanOverlay.GetComponent<ScrollRect>();
        skillTreePanScrollRect.viewport = viewport;
        skillTreePanScrollRect.content = skillTreePanContent;
        skillTreePanScrollRect.horizontal = true;
        skillTreePanScrollRect.vertical = true;
        skillTreePanScrollRect.movementType = ScrollRect.MovementType.Clamped;
        skillTreePanScrollRect.inertia = false;
        // Wheel/trackpad deltas are applied from InputSystem.onEvent above;
        // keep ScrollRect for the reliable drag surface without applying the
        // same two-finger delta a second time.
        skillTreePanScrollRect.scrollSensitivity = 0f;
        skillTreePanScrollRect.horizontalScrollbar = null;
        skillTreePanScrollRect.verticalScrollbar = null;
        skillTreePanScrollRect.onValueChanged.AddListener(OnSkillTreePanScrollRectChanged);

        CreateSkillTreePanNodeButtons();
        ConfigureSkillTreePanOverlayGeometry();
        skillTreePanScrollRect.normalizedPosition = new Vector2(0.5f, 0.5f);
        skillTreePanOverlay.SetActive(false);
    }

    private void ConfigureSkillTreePanOverlayGeometry()
    {
        if (skillTreePanOverlay == null) return;

        RectTransform viewport = skillTreePanOverlay.GetComponent<RectTransform>();
        if (viewport != null)
        {
            Rect guiViewport = GetSkillTreeViewport(GetUpgradePanelRect());
            GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
                out float logicalHeight);
            viewport.sizeDelta = guiViewport.size;
            viewport.anchoredPosition = new Vector2(
                guiViewport.center.x - logicalWidth * 0.5f,
                -(guiViewport.center.y - logicalHeight * 0.5f));
        }

        if (skillTreePanOverlay.GetComponent<RectMask2D>() == null)
            skillTreePanOverlay.AddComponent<RectMask2D>();

        if (skillTreePanContent == null) return;

        skillTreePanContent.sizeDelta = new Vector2(
            SkillTreeContentWidth, SkillTreeContentHeight);

        Vector2 treeCenter = new Vector2(
            SkillTreeContentWidth * 0.5f, SkillTreeContentHeight * 0.5f) +
            SkillTreeCenterOffset;
        int count = Mathf.Min(skillTreePanNodeButtons.Count, GetSkillNodeCount());
        for (int i = 0; i < count; i++)
        {
            Vector2 position = GetSkillTreeNodePosition(treeCenter, i);
            RectTransform nodeRect = skillTreePanNodeButtons[i].GetComponent<RectTransform>();
            if (nodeRect != null)
            {
                nodeRect.sizeDelta = new Vector2(SkillTreeNodeSize, SkillTreeNodeSize);
                nodeRect.anchoredPosition = new Vector2(position.x, -position.y);
            }
        }
    }

    private void CreateSkillTreePanNodeButtons()
    {
        if (skillTreePanContent == null) return;

        Vector2 treeCenter = new Vector2(
            SkillTreeContentWidth * 0.5f, SkillTreeContentHeight * 0.5f);

        for (int i = 0; i < GetSkillNodeCount(); i++)
        {
            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            int nodeIndex = i;
            GameObject nodeObject = new GameObject(
                $"SkillTreePanNode_{branchIndex + 1}_{levelIndex + 1}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(skillTreePanContent, false);

            Vector2 position = GetSkillTreeNodePosition(treeCenter, nodeIndex);
            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(SkillTreeNodeSize, SkillTreeNodeSize);
            nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.color = new Color(0f, 0f, 0f, 0f);
            nodeImage.raycastTarget = true;

            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.transition = Selectable.Transition.None;
            nodeButton.onClick.AddListener(() =>
            {
                TryBuySkillNode(nodeIndex);
                RequestEditorRepaint();
            });
            skillTreePanNodeButtons.Add(nodeButton);
        }
    }

    private void OnSkillTreePanScrollRectChanged(Vector2 normalizedPosition)
    {
        if (updatingSkillTreePanOverlay) return;

        Vector2 viewportSize = GetSkillTreeViewport(GetUpgradePanelRect()).size;
        float maxX = Mathf.Max(0f,
            SkillTreeContentWidth - viewportSize.x);
        float maxY = Mathf.Max(0f,
            SkillTreeContentHeight - viewportSize.y);
        skillTreePan = new Vector2(
            maxX <= 0f ? 0f : (0.5f - normalizedPosition.x) * maxX,
            maxY <= 0f ? 0f : (0.5f - normalizedPosition.y) * maxY);
        ClampSkillTreePan(GetSkillTreeViewport(GetUpgradePanelRect()));
        RequestEditorRepaint();
    }

    private void SyncSkillTreePanOverlayFromPosition()
    {
        if (skillTreePanScrollRect == null) return;

        Vector2 viewportSize = GetSkillTreeViewport(GetUpgradePanelRect()).size;
        float maxX = Mathf.Max(0f,
            SkillTreeContentWidth - viewportSize.x);
        float maxY = Mathf.Max(0f,
            SkillTreeContentHeight - viewportSize.y);
        updatingSkillTreePanOverlay = true;
        skillTreePanScrollRect.normalizedPosition = new Vector2(
            maxX <= 0f ? 0.5f : 0.5f - skillTreePan.x / maxX,
            maxY <= 0f ? 0.5f : 0.5f - skillTreePan.y / maxY);
        updatingSkillTreePanOverlay = false;
    }

    private void UpdateSkillTreePanNodeButtons()
    {
        int count = Mathf.Min(skillTreePanNodeButtons.Count, GetSkillNodeCount());
        for (int i = 0; i < count; i++)
        {
            bool visible = IsSkillNodeVisible(i);
            skillTreePanNodeButtons[i].gameObject.SetActive(visible);
            if (!visible)
                continue;

            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            string upgradeKey = SkillUpgradeKeys[branchIndex];
            skillTreePanNodeButtons[i].interactable =
                !IsSkillNodePurchased(i) &&
                IsSkillNodeUnlocked(i) &&
                coins >= GetUpgradeCostForLevel(upgradeKey, levelIndex);
        }
    }

    private void OnMapPanScrollRectChanged(Vector2 normalizedPosition)
    {
        if (updatingMapPanOverlay || mapPanContent == null) return;

        float maxX = Mathf.Max(0f, mapPanContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapPanContent.rect.height - MapViewportHeight);
        mapScrollPosition = new Vector2(
            normalizedPosition.x * maxX,
            (1f - normalizedPosition.y) * maxY);
        mapScrollInitialized = true;
        RequestEditorRepaint();
    }

    private void SyncMapPanOverlayFromPosition()
    {
        if (mapPanScrollRect == null || mapPanContent == null) return;

        float maxX = Mathf.Max(0f, mapPanContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapPanContent.rect.height - MapViewportHeight);
        updatingMapPanOverlay = true;
        mapPanScrollRect.normalizedPosition = new Vector2(
            maxX <= 0f ? 0f : mapScrollPosition.x / maxX,
            maxY <= 0f ? 1f : 1f - mapScrollPosition.y / maxY);
        updatingMapPanOverlay = false;
    }

    private void CreateMapLine(Transform parent, Vector2 start, Vector2 end,
        int lineIndex)
    {
        GameObject lineObject = CreateUiImage(parent, $"MapLine_{lineIndex}", Vector2.zero,
            Vector2.one, new Color(0.72f, 0.53f, 0.28f, 0.95f), false);
        RectTransform lineRect = lineObject.GetComponent<RectTransform>();
        lineRect.anchorMin = new Vector2(0f, 1f);
        lineRect.anchorMax = new Vector2(0f, 1f);
        lineRect.pivot = new Vector2(0.5f, 0.5f);
        Vector2 direction = end - start;
        float length = direction.magnitude;
        lineRect.sizeDelta = new Vector2(Mathf.Max(0f, length - 76f), 8f);
        lineRect.anchoredPosition = (start + end) * 0.5f;
        lineRect.localRotation = Quaternion.Euler(0f, 0f,
            Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg);
    }

    private void ConfigureButtonHover(Button button, Color normalColor, Color hoverColor)
    {
        if (button == null) return;

        ColorBlock colors = button.colors;
        colors.normalColor = normalColor;
        colors.highlightedColor = hoverColor;
        colors.pressedColor = new Color(
            hoverColor.r * 0.78f, hoverColor.g * 0.78f, hoverColor.b * 0.78f,
            hoverColor.a);
        colors.selectedColor = hoverColor;
        // Stage buttons are disabled while a detail dialog is open, but the
        // map artwork must stay fully visible behind the dialog.  Do not let
        // Unity's disabled tint make the node itself look transparent.
        colors.disabledColor = normalColor;
        colors.fadeDuration = 0.08f;
        button.colors = colors;
        button.transition = Selectable.Transition.ColorTint;
    }

    private void RequestEditorRepaint()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
        UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
#endif
    }

    private bool IsConfirmHeld()
    {
        Keyboard keyboard = Keyboard.current;
        return keyboard != null &&
            (keyboard.enterKey.isPressed || keyboard.numpadEnterKey.isPressed || keyboard.spaceKey.isPressed);
    }

    private List<StageDefinition> GetStages()
    {
        List<StageDefinition> stages = new List<StageDefinition>();
        if (catalog != null && catalog.stages != null)
        {
            for (int i = 0; i < catalog.stages.Length; i++)
            {
                if (catalog.stages[i] != null) stages.Add(catalog.stages[i]);
            }
        }

        if (stages.Count == 0)
        {
            stages.Add(new StageDefinition
            {
                stageId = 1,
                displayName = "STAGE 1",
                waves = new[]
                {
                    new StageWave { monsterId = 0, count = 4, spawnInterval = 0.5f, minDistanceFromWitch = 6f }
                }
            });
        }

        return stages;
    }

    private List<StageDefinition> GetMapPageStages(int mapPage)
    {
        List<StageDefinition> pageStages = new List<StageDefinition>();
        List<StageDefinition> allStages = GetStages();
        for (int i = 0; i < allStages.Count; i++)
        {
            StageDefinition stage = allStages[i];
            if (stage != null && Mathf.Max(1, stage.mapPage) == mapPage)
                pageStages.Add(stage);
        }

        return pageStages;
    }

    private List<MapStageGroup> GetMapStageGroups(int mapPage)
    {
        List<MapStageGroup> groups = new List<MapStageGroup>();
        List<StageDefinition> levels = GetMapPageStages(mapPage);
        for (int i = 0; i < levels.Count; i++)
        {
            StageDefinition level = levels[i];
            if (level == null) continue;

            int groupId = Mathf.Max(1, level.stageGroupId);
            MapStageGroup group = groups.Find(item => item.groupId == groupId);
            if (group == null)
            {
                group = new MapStageGroup { groupId = groupId };
                groups.Add(group);
            }
            group.levels.Add(level);
        }

        groups.Sort((left, right) => left.groupId.CompareTo(right.groupId));
        for (int i = 0; i < groups.Count; i++)
            groups[i].levels.Sort((left, right) => left.stageId.CompareTo(right.stageId));
        return groups;
    }

    private MapStageGroup GetMapStageGroup(int mapPage, int groupId)
    {
        return GetMapStageGroups(mapPage).Find(group => group.groupId == groupId);
    }

    private int GetMapStageGroupIndex(List<MapStageGroup> groups, int groupId)
    {
        if (groups == null) return -1;
        return groups.FindIndex(group => group != null && group.groupId == groupId);
    }

    private bool IsMapStageGroupUnlocked(MapStageGroup group)
    {
        if (group == null || group.levels.Count == 0) return false;
        List<StageDefinition> allLevels = GetStages();
        return IsStageUnlocked(group.levels[0].stageId, allLevels);
    }

    private bool IsMapStageGroupCleared(MapStageGroup group)
    {
        if (group == null || group.levels.Count == 0) return false;
        List<StageDefinition> allLevels = GetStages();
        for (int i = 0; i < group.levels.Count; i++)
        {
            if (!IsStageCleared(group.levels[i].stageId, allLevels))
                return false;
        }
        return true;
    }

    private int GetStageGroupIdForLevel(int levelId)
    {
        List<StageDefinition> levels = GetStages();
        StageDefinition level = levels.Find(item => item != null && item.stageId == levelId);
        return level == null ? 1 : Mathf.Max(1, level.stageGroupId);
    }

    private Vector2 GetMapStageGroupNodePosition(Rect mapArea, int index, int count)
    {
        // Preserve the original map route placement. Only the hierarchy
        // changed; the map's visual layout and route anchors do not.
        if (count == 2)
            return GetStageNodePosition(mapArea, index, MapRoutePoints.Length);
        return GetStageNodePosition(mapArea, index, count);
    }

    private List<StageDefinition> GetCurrentMapStages()
    {
        // The map-selection screen chooses a stage group (LEVEL1-10,
        // LEVEL11-20, ...).  Once inside that group, the original route is
        // drawn using only its levels so the ten original node positions are
        // preserved instead of stretching all levels into one new route.
        List<MapStageGroup> groups = GetMapStageGroups(currentMapPage);
        if (groups.Count == 0)
            return new List<StageDefinition>();

        int groupId = GetStageGroupIdForLevel(selectedStage);
        MapStageGroup selectedGroup = groups.Find(group =>
            group != null && group.groupId == groupId);
        if (selectedGroup != null && selectedGroup.levels.Count > 0)
            return selectedGroup.levels;

        return groups[0].levels;
    }

    private int GetHighestMapPageInCatalog()
    {
        List<StageDefinition> allStages = GetStages();
        int highestPage = 1;
        for (int i = 0; i < allStages.Count; i++)
        {
            if (allStages[i] != null)
                highestPage = Mathf.Max(highestPage, Mathf.Max(1, allStages[i].mapPage));
        }

        return highestPage;
    }

    private bool AreAllMapStagesCleared(int mapPage)
    {
        List<StageDefinition> pageStages = GetMapPageStages(mapPage);
        if (pageStages.Count == 0)
            return false;

        List<StageDefinition> allStages = GetStages();
        for (int i = 0; i < pageStages.Count; i++)
        {
            if (!IsStageCleared(pageStages[i].stageId, allStages))
                return false;
        }

        return true;
    }

    private int GetHighestUnlockedMapPage()
    {
        int highestPage = 1;
        int catalogPageCount = GetHighestMapPageInCatalog();
        for (int page = 1; page < catalogPageCount; page++)
        {
            if (!AreAllMapStagesCleared(page))
                break;
            highestPage = page + 1;
        }

        return highestPage;
    }

    private void ClampCurrentMapPageToUnlocked()
    {
        int highestUnlockedPage = GetHighestUnlockedMapPage();
        currentMapPage = Mathf.Clamp(currentMapPage, 1, highestUnlockedPage);
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        PlayerPrefs.Save();
    }

    private void UpdateMapPageLabel()
    {
        if (mapPageLabel == null)
            return;

        List<StageDefinition> pageStages = GetCurrentMapStages();
        string theme = pageStages.Count > 0 && pageStages[0] != null
            ? pageStages[0].mapTheme : "未設定";
        string concept = pageStages.Count > 0 && pageStages[0] != null
            ? pageStages[0].mapConcept : "";
        if (mapTravelMode)
        {
            mapPageLabel.text = "マップ選択　行き先を選ぶ";
            return;
        }

        mapPageLabel.text = $"マップ  {theme}  {concept}";
    }

    private void OpenMapPage(int mapPage)
    {
        if (state != GameState.Menu)
            return;

        if (mapPage != currentMapPage &&
            Time.unscaledTime - mapPageChangeTime < 0.35f)
            return;

        int highestUnlockedPage = GetHighestUnlockedMapPage();
        if (mapPage < 1 || mapPage > highestUnlockedPage)
            return;

        List<StageDefinition> pageStages = GetMapPageStages(mapPage);
        if (pageStages.Count == 0)
            return;

        // Preserve the hero's current travel position so changing to another
        // map page is an actual map-to-map movement, rather than silently
        // respawning the token at the destination node.
        bool animateTravelToNewPage = mapTravelMode &&
            mapHeroTokenRect != null && mapPage != currentMapPage;
        Vector2 previousTravelPosition = animateTravelToNewPage
            ? mapHeroTokenRect.anchoredPosition : Vector2.zero;

        PlayConfirmSound();
        if (mapPage != currentMapPage)
            mapPageChangeTime = Time.unscaledTime;
        currentMapPage = mapPage;
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        if (!pageStages.Exists(stage => stage.stageId == selectedStage &&
            IsStageUnlocked(stage.stageId, GetStages())))
        {
            List<StageDefinition> allStages = GetStages();
            int pageUnlockedIndex = -1;
            for (int i = 0; i < pageStages.Count; i++)
            {
                if (IsStageUnlocked(pageStages[i].stageId, allStages))
                    pageUnlockedIndex = i;
            }

            selectedStage = pageStages[Mathf.Max(0, pageUnlockedIndex)].stageId;
            PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        }
        PlayerPrefs.Save();
        RebuildMapVisualForCurrentPage();
        if (animateTravelToNewPage && mapHeroTokenRect != null)
        {
            mapHeroTokenRect.anchoredPosition = previousTravelPosition;
            MoveMapHeroToStage(selectedStage);
        }
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void RebuildMapVisualForCurrentPage()
    {
        if (mapVisualRoot == null)
            return;

        if (mapHeroMoveRoutine != null)
        {
            StopCoroutine(mapHeroMoveRoutine);
            mapHeroMoveRoutine = null;
        }
        if (mapFocusRoutine != null)
        {
            StopCoroutine(mapFocusRoutine);
            mapFocusRoutine = null;
        }

        for (int i = mapVisualRoot.transform.childCount - 1; i >= 0; i--)
            Destroy(mapVisualRoot.transform.GetChild(i).gameObject);

        mapVisualPanel = null;
        mapPageLabel = null;
        mapCanvasScrollRect = null;
        mapCanvasContent = null;
        mapHeroTokenRect = null;
        mapHeroTokenImage = null;
        mapStageButtons.Clear();
        stageIconSprites.Clear();
        stageIconsTexture = null;
        CreateMapVisual();
        RebuildMapPanNodeButtons();
        mapScrollInitialized = false;
        SyncMapPanOverlayFromPosition();
    }

    private int GetHighestClearedStageIndex(List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0)
            return -1;

        int highestIndex = Mathf.Clamp(
            PlayerPrefs.GetInt(HighestClearedStageKey, -1),
            -1, stages.Count - 1);
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            if (stage != null && PlayerPrefs.GetInt(
                ClearedStageKeyPrefix + stage.stageId, 0) == 1)
                highestIndex = Mathf.Max(highestIndex, i);
        }

        return highestIndex;
    }

    private int GetLastUnlockedStageIndex(List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0)
            return -1;

        return Mathf.Min(stages.Count - 1,
            GetHighestClearedStageIndex(stages) + 1);
    }

    private bool IsStageUnlocked(List<StageDefinition> stages, int stageIndex)
    {
        return stages != null && stageIndex >= 0 &&
            stageIndex <= GetLastUnlockedStageIndex(stages);
    }

    private bool IsStageCleared(List<StageDefinition> stages, int stageIndex)
    {
        return stages != null && stageIndex >= 0 &&
            stageIndex <= GetHighestClearedStageIndex(stages);
    }

    private bool IsStageCleared(int stageId, List<StageDefinition> stages)
    {
        return stages != null && stages.Exists(stage => stage != null &&
            stage.stageId == stageId) &&
            PlayerPrefs.GetInt(ClearedStageKeyPrefix + stageId, 0) == 1;
    }

    private bool IsStageUnlocked(int stageId, List<StageDefinition> stages)
    {
        if (stages == null) return false;
        int stageIndex = stages.FindIndex(stage => stage != null &&
            stage.stageId == stageId);
        return stageIndex >= 0 && IsStageUnlocked(stages, stageIndex);
    }

    private Color GetStageNodeColor(bool unlocked, bool cleared)
    {
        if (!unlocked)
            return new Color(0.16f, 0.20f, 0.23f, 1f);

        if (cleared)
            return new Color(0.30f, 0.72f, 0.48f, 1f);

        // Unplayed levels use the same readable green family as cleared
        // levels.  Orange/red nodes made an entire new stage look like an
        // error state instead of a selectable route.
        return new Color(0.22f, 0.58f, 0.42f, 1f);
    }

    private void RefreshMapStagePresentation()
    {
        List<StageDefinition> stages = GetCurrentMapStages();
        if (stages == null || stages.Count == 0)
            return;

        List<StageDefinition> allStages = GetStages();
        int lastUnlockedIndex = -1;
        for (int i = 0; i < stages.Count; i++)
        {
            if (IsStageUnlocked(stages[i].stageId, allStages))
                lastUnlockedIndex = i;
        }
        for (int i = 0; i < stages.Count - 1; i++)
        {
            Transform line = mapCanvasContent != null
                ? mapCanvasContent.Find($"MapLine_{i}")
                : null;
            if (line != null)
                line.gameObject.SetActive(i < lastUnlockedIndex);
        }

        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            if (stage == null)
                continue;

            bool unlocked = IsStageUnlocked(stage.stageId, allStages);
            bool cleared = IsStageCleared(stage.stageId, allStages);

            if (mapCanvasContent != null)
            {
                Transform node = mapCanvasContent.Find($"StageNode_{stage.stageId}");
                if (node != null)
                {
                    // Locked stages are omitted from the map entirely. The
                    // player sees only the currently available route and no
                    // LOCKED badge or dark placeholder.
                    node.gameObject.SetActive(unlocked);
                    Image nodeImage = node.GetComponent<Image>();
                    if (nodeImage != null)
                        nodeImage.color = GetStageNodeColor(unlocked, cleared);

                    Button nodeButton = node.GetComponent<Button>();
                    if (nodeButton != null)
                    {
                        nodeButton.interactable = unlocked;
                        if (nodeImage != null)
                        {
                            ConfigureButtonHover(nodeButton, nodeImage.color,
                                unlocked
                                    ? new Color(1f, 0.84f, 0.36f, 1f)
                                    : nodeImage.color);
                        }
                    }

                    Transform hitTarget = mapCanvasContent.Find(
                        $"StageHitTarget_{stage.stageId}");
                    Button hitButton = hitTarget != null
                        ? hitTarget.GetComponent<Button>() : null;
                    if (hitButton != null)
                    {
                        hitButton.interactable = unlocked;
                        if (nodeImage != null)
                        {
                            hitButton.targetGraphic = nodeImage;
                            ConfigureButtonHover(hitButton, nodeImage.color,
                                unlocked
                                    ? new Color(1f, 0.84f, 0.36f, 1f)
                                    : nodeImage.color);
                        }
                    }

                    Transform icon = node.Find("StageIcon");
                    Image iconImage = icon != null
                        ? icon.GetComponent<Image>() : null;
                    if (iconImage != null)
                    {
                        iconImage.color = unlocked
                            ? Color.white
                            : new Color(0.42f, 0.46f, 0.48f, 0.52f);
                    }

                    Transform lockShade = node.Find("StageLockShade");
                    if (lockShade != null)
                        lockShade.gameObject.SetActive(!unlocked);

                    Transform numberBadge = node.Find("StageNumberBadge");
                    if (numberBadge != null)
                    {
                        Image badgeImage = numberBadge.GetComponent<Image>();
                        if (badgeImage != null)
                            badgeImage.color = new Color(0.01f, 0.025f,
                                0.04f, 0.94f);

                        Transform numberTextTransform = numberBadge.Find("Text");
                        Text numberText = numberTextTransform != null
                            ? numberTextTransform.GetComponent<Text>()
                            : null;
                        if (numberText != null)
                        {
                            numberText.text = stage.stageId.ToString();
                            numberText.color = unlocked
                                ? new Color(1f, 0.91f, 0.48f)
                                : new Color(0.62f, 0.66f, 0.68f);
                        }
                    }

                    Transform lockBadge = node.Find("StageLockBadge");
                    if (lockBadge != null)
                        lockBadge.gameObject.SetActive(!unlocked);
                }
            }

            if (mapPanNodeButtons != null && i < mapPanNodeButtons.Count &&
                mapPanNodeButtons[i] != null)
            {
                mapPanNodeButtons[i].gameObject.SetActive(unlocked);
                mapPanNodeButtons[i].interactable = unlocked;
            }
        }
    }

    private void RefreshMapStageGroupPresentation()
    {
        List<MapStageGroup> groups = GetMapStageGroups(currentMapPage);
        if (groups.Count == 0)
            return;

        for (int i = 0; i < groups.Count; i++)
        {
            MapStageGroup group = groups[i];
            bool unlocked = IsMapStageGroupUnlocked(group);
            bool cleared = IsMapStageGroupCleared(group);
            Transform node = mapCanvasContent != null
                ? mapCanvasContent.Find("StageGroupNode_" + group.groupId) : null;
            if (node != null)
            {
                node.gameObject.SetActive(unlocked);
                Image nodeImage = node.GetComponent<Image>();
                if (nodeImage != null)
                    nodeImage.color = unlocked
                        ? (cleared ? new Color(0.25f, 0.68f, 0.46f, 1f)
                            : new Color(0.95f, 0.55f, 0.18f, 1f))
                        : new Color(0.16f, 0.20f, 0.23f, 1f);
                Button nodeButton = node.GetComponent<Button>();
                if (nodeButton != null)
                {
                    nodeButton.interactable = unlocked;
                    if (nodeImage != null)
                    {
                        ConfigureButtonHover(nodeButton, nodeImage.color,
                            unlocked
                                ? new Color(1f, 0.84f, 0.36f, 1f)
                                : nodeImage.color);
                    }
                }
            }

            if (mapPanNodeButtons != null && i < mapPanNodeButtons.Count &&
                mapPanNodeButtons[i] != null)
            {
                mapPanNodeButtons[i].gameObject.SetActive(unlocked);
                mapPanNodeButtons[i].interactable = unlocked;
            }
        }
    }

    private void ClampSelectedStageToUnlocked()
    {
        List<StageDefinition> stages = GetStages();
        if (stages.Count == 0) return;

        int selectedIndex = GetStageIndex(selectedStage, stages);
        int lastUnlockedIndex = GetLastUnlockedStageIndex(stages);
        if (selectedIndex < 0 || selectedIndex > lastUnlockedIndex)
            selectedIndex = Mathf.Clamp(lastUnlockedIndex, 0, stages.Count - 1);

        selectedStage = stages[selectedIndex].stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();
    }

    private void ClampSelectedStageToCurrentMap()
    {
        List<StageDefinition> pageStages = GetCurrentMapStages();
        if (pageStages.Count == 0)
            return;

        List<StageDefinition> allStages = GetStages();
        bool selectedStageIsUsable = pageStages.Exists(stage =>
            stage.stageId == selectedStage && IsStageUnlocked(stage.stageId, allStages));
        if (!selectedStageIsUsable)
        {
            int lastUnlockedIndex = -1;
            for (int i = 0; i < pageStages.Count; i++)
            {
                if (IsStageUnlocked(pageStages[i].stageId, allStages))
                    lastUnlockedIndex = i;
            }

            selectedStage = pageStages[Mathf.Max(0, lastUnlockedIndex)].stageId;
        }

        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();
    }

    private void MarkStageCleared(int stageId)
    {
        List<StageDefinition> stages = GetStages();
        int stageIndex = GetStageIndex(stageId, stages);
        if (stageIndex < 0) return;

        int highestCleared = GetHighestClearedStageIndex(stages);
        PlayerPrefs.SetInt(ClearedStageKeyPrefix + stageId, 1);
        if (stageIndex <= highestCleared)
        {
            PlayerPrefs.Save();
            return;
        }

        PlayerPrefs.SetInt(HighestClearedStageKey, stageIndex);
        PlayerPrefs.Save();
    }

    private void StartStage(int stageId)
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        bool bypassUnlockForDevelopment = developmentDirectStageStart;
        developmentDirectStageStart = false;
#else
        bool bypassUnlockForDevelopment = false;
#endif
        // A result screen is also a valid entry point for retrying the same
        // stage. The old Menu-only guard made the button render correctly but
        // silently ignored its click while state was Result.
        if ((state != GameState.Menu && state != GameState.Result) ||
            mapVisualBuildPending)
            return;

        List<StageDefinition> availableStages = GetStages();
        if (!bypassUnlockForDevelopment &&
            !IsStageUnlocked(stageId, availableStages))
            return;

        if (mapOnlyScene)
        {
            battleLoadRequested = true;
            PlayerPrefs.SetInt(PendingStageKey, stageId);
            PlayerPrefs.Save();
            if (battleScenePreloaded)
            {
                // The battle scene is already loaded additively and hidden.
                // The button press only swaps the visible scene roots, so no
                // scene-load pause remains here.
                ActivatePreloadedBattleScene(stageId);
            }
            else if (battleScenePreloadOperation != null)
            {
                // The preload is still finishing. Its completion callback
                // will activate the battle as soon as it is ready.
            }
            else
            {
                // Fallback for an unusual entry path where preloading could
                // not start. Keep the load asynchronous so the editor does
                // not freeze while the battle scene is being read.
                SceneManager.LoadSceneAsync(BattleSceneName);
            }
            return;
        }

        selectedStage = stageId;
        currentStage = catalog != null ? catalog.GetStage(stageId) : null;
        if (currentStage == null)
        {
            List<StageDefinition> stages = GetStages();
            currentStage = stages[0];
            selectedStage = currentStage.stageId;
        }

        ResumeBattleTime();
        won = false;
        experience = 0;
        ClearBattleObjects();
        spawning = true;

        witch.gameObject.SetActive(true);
        hero.gameObject.SetActive(true);
        witch.ResetForStage(Vector3.zero);
        hero.ResetForStage(new Vector3(-2f, 0f, 0f));
        CreateHeroEquipmentVisuals();
        CreatePetCompanion();

        state = GameState.Battle;
        stageOneTutorialActive = currentStage != null &&
            currentStage.stageId == StageOneTutorialStageId;
        stageOneTutorialStep = stageOneTutorialActive ? 0 : StageOneTutorialStepCount;
        BeginBattleStartFreeze();
        spawnRoutine = StartCoroutine(SpawnWaves(currentStage));
    }

    private IEnumerator SpawnWaves(StageDefinition stage)
    {
        // Enter the battle immediately, but give the player one readable
        // second before the first monster appears.
        if (BattleStartMonsterDelay > 0f)
            yield return new WaitForSeconds(BattleStartMonsterDelay);

        if (stage.waves != null)
        {
            for (int waveIndex = 0; waveIndex < stage.waves.Length; waveIndex++)
            {
                StageWave wave = stage.waves[waveIndex];
                if (wave == null) continue;

                if (wave.startDelay > 0f)
                    yield return new WaitForSeconds(wave.startDelay);

                for (int i = 0; i < Mathf.Max(0, wave.count); i++)
                {
                    if (state != GameState.Battle) yield break;

                    SpawnMonster(wave.monsterId, wave.minDistanceFromWitch, i);
                    if (wave.spawnInterval > 0f)
                        yield return new WaitForSeconds(wave.spawnInterval);
                }
            }
        }

        spawning = false;
        spawnRoutine = null;
    }

    private void SpawnMonster(int monsterId, float minDistanceFromWitch, int indexInWave)
    {
        MonsterDefinition definition = monsterCatalog != null
            ? monsterCatalog.GetMonster(monsterId)
            : null;

        GameObject source;
        if (!monsterSources.TryGetValue(monsterId, out source) &&
            !monsterSources.TryGetValue(0, out source))
        {
            source = null;
            foreach (GameObject fallback in monsterSources.Values)
            {
                source = fallback;
                break;
            }
        }

        if (source == null) return;

        GameObject monsterObject = Instantiate(source);
        monsterObject.name = $"Monster_{monsterId}_{spawnedMonsters.Count + 1}";
        monsterObject.SetActive(true);
        monsterObject.transform.position = GetSpawnPosition(witch.transform.position, minDistanceFromWitch);

        Monster monster = monsterObject.GetComponent<Monster>();
        if (monster == null)
        {
            Destroy(monsterObject);
            return;
        }

        monster.ApplyDefinition(definition);
        monster.SetTarget(witch.transform);
        spawnedMonsters.Add(monster);
    }

    private void CreatePetCompanion()
    {
        DestroyPetCompanion();

        int equippedPet = EquipmentSystem.GetEquipped(EquipmentSystem.Slot.Pet);
        if (hero == null || equippedPet < 0)
            return;

        int petId = equippedPet;
        Sprite petSprite = GetEquipmentIconSprite(petId == 1 ? 5 : 4);
        if (petSprite == null) return;

        petCompanionObject = new GameObject("EquippedPet");
        // EquipmentIcons is imported at 512 pixels per world unit. The
        // cropped sprite therefore already has a usable world size; applying
        // a pixel-to-world factor here made the pet effectively invisible.
        petCompanionObject.transform.localScale = Vector3.one * 0.55f;
        petCompanionRenderer = petCompanionObject.AddComponent<SpriteRenderer>();
        petCompanionRenderer.sprite = petSprite;
        petCompanionRenderer.sortingOrder = 6;
        petCompanionObject.transform.position = FindNearestClearPetPosition(
            hero.transform.position + new Vector3(-PetFollowDistance, -0.18f, 0f));
        petOrbitAngle = Random.Range(0f, Mathf.PI * 2f);
        petAttackStopUntil = 0f;
        pendingPetAttackTarget = null;
        nextPetAttackTime = Time.time + 0.65f;
        petWanderTarget = petCompanionObject.transform.position;
        nextPetWanderChangeTime = Time.time + Random.Range(0.8f, 1.4f);
        petHasWanderTarget = false;
    }

    private void CreateHeroEquipmentVisuals()
    {
        DestroyHeroEquipmentVisuals();
        // Equipment icons are inventory art, not character body parts. A
        // static boots icon under the animated hero reads as a stray shadow
        // and never follows the feet correctly, so battle keeps the hero
        // sprite clean. Equipment effects still apply through the stats.
    }

    private void CreateHeroEquipmentVisual(EquipmentSystem.Slot slot,
        Vector3 localPosition, float scale, int sortingOrder)
    {
        int itemId = EquipmentSystem.GetEquipped(slot);
        if (itemId < 0) return;

        EquipmentSystem.Item item = EquipmentSystem.GetItem(slot, itemId);
        Sprite sprite = GetEquipmentIconSprite(item.iconCell);
        if (sprite == null) return;

        GameObject visual = new GameObject($"Equipped{EquipmentSystem.GetSlotName(slot)}");
        visual.transform.SetParent(hero.transform, false);
        visual.transform.localPosition = localPosition;
        visual.transform.localScale = Vector3.one * scale;
        SpriteRenderer renderer = visual.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = sortingOrder;
        heroEquipmentVisualObjects.Add(visual);
    }

    private void DestroyHeroEquipmentVisuals()
    {
        for (int i = 0; i < heroEquipmentVisualObjects.Count; i++)
        {
            if (heroEquipmentVisualObjects[i] != null)
                Destroy(heroEquipmentVisualObjects[i]);
        }
        heroEquipmentVisualObjects.Clear();
    }

    private void UpdatePetCompanion()
    {
        // Recreate lazily as well as at stage start. Scene transitions can
        // activate the battle objects one frame after StartStage; this keeps
        // the equipped companion reliable in both the editor and a build.
        if (petCompanionObject == null && hero != null &&
            EquipmentSystem.GetEquipped(EquipmentSystem.Slot.Pet) >= 0)
            CreatePetCompanion();

        if (petCompanionObject == null || hero == null || hero.IsDead)
            return;

        int petId = EquipmentSystem.GetEquipped(EquipmentSystem.Slot.Pet);
        if (petId < 0)
        {
            DestroyPetCompanion();
            return;
        }

        // Keep this guard active even while the pet is in its attack wind-up.
        // A moving monster must not be able to enter the pet's visible body
        // during the short period when the pet intentionally stands still.
        if (!IsPetPositionClear(petCompanionObject.transform.position))
        {
            petCompanionObject.transform.position =
                FindNearestClearPetPosition(petCompanionObject.transform.position);
        }

        Monster nearest = null;
        float nearestDistance = float.MaxValue;
        Vector3 petPosition = petCompanionObject.transform.position;
        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (monster == null || monster.IsDead) continue;

            float distance = (monster.transform.position - petPosition).sqrMagnitude;
            if (distance < nearestDistance)
            {
                nearest = monster;
                nearestDistance = distance;
            }
        }

        if (pendingPetAttackTarget != null)
        {
            if (pendingPetAttackTarget == null ||
                pendingPetAttackTarget.IsDead)
            {
                pendingPetAttackTarget = null;
                petAttackStopUntil = 0f;
                return;
            }

            // Keep the pet completely still during the short wind-up, then
            // fire. This makes the attack readable instead of sliding while
            // the projectile is created.
            if (Time.time < petAttackStopUntil)
                return;

            LaunchPetAttack(pendingPetAttackTarget, petId);
            pendingPetAttackTarget = null;
            nextPetAttackTime = Time.time + EquipmentSystem.GetPetAttackInterval();
            return;
        }

        UpdatePetMovement(nearest);

        if (Time.time < nextPetAttackTime) return;
        if (nearest == null) return;

        float petDistanceToTarget = Vector3.Distance(
            petCompanionObject.transform.position, nearest.transform.position);
        if (petDistanceToTarget > PetAttackRange + 0.9f)
            return;

        // Reach the attack position first, stop, then fire on the next phase.
        pendingPetAttackTarget = nearest;
        petAttackStopUntil = Time.time + PetAttackWindup;
    }

    private void UpdatePetMovement(Monster nearest)
    {
        if (petCompanionObject == null || hero == null)
            return;

        petOrbitAngle += Time.deltaTime * PetOrbitSpeed;
        Vector3 currentPosition = petCompanionObject.transform.position;
        float heroDistance = Vector3.Distance(currentPosition,
            hero.transform.position);
        Vector3 desiredPosition;

        // The pet is autonomous. It only returns when its current position
        // has genuinely left the leash range; the hero's movement never
        // rewrites the pet's target position every frame.
        if (heroDistance > PetMaxDistanceFromHero)
        {
            Vector2 returnDirection = currentPosition - hero.transform.position;
            if (returnDirection.sqrMagnitude <= 0.001f)
                returnDirection = Vector2.left;
            desiredPosition = hero.transform.position +
                (Vector3)returnDirection.normalized * PetHeroReturnRadius;
        }
        else if (nearest != null && !nearest.IsDead &&
            Vector3.Distance(currentPosition, nearest.transform.position) <=
            PetCombatDetectionRange)
        {
            // Approach a nearby enemy from the side. This target is based on
            // the pet's own position, not on the hero's current position.
            Vector2 petToMonster = nearest.transform.position -
                currentPosition;
            Vector2 approachDirection = petToMonster.sqrMagnitude > 0.001f
                ? petToMonster.normalized
                : Vector2.right;
            Vector2 sideDirection = new Vector2(
                -approachDirection.y, approachDirection.x);
            desiredPosition = nearest.transform.position -
                (Vector3)(approachDirection * PetAttackRange) +
                (Vector3)(sideDirection * Mathf.Sin(petOrbitAngle) * 0.28f);
            petHasWanderTarget = false;
        }
        else
        {
            // When there is no nearby target, choose a small independent
            // patrol point. It is deliberately not recalculated from the
            // hero every frame, so the pet does not mirror hero movement.
            if (!petHasWanderTarget || Time.time >= nextPetWanderChangeTime ||
                Vector3.Distance(currentPosition, petWanderTarget) < 0.16f)
            {
                Vector2 offset = Random.insideUnitCircle * PetWanderRadius;
                petWanderTarget = ClampPetPosition(currentPosition +
                    (Vector3)offset);
                if (Vector3.Distance(petWanderTarget, hero.transform.position) >
                    PetMaxDistanceFromHero)
                {
                    Vector2 towardHero = petWanderTarget - hero.transform.position;
                    if (towardHero.sqrMagnitude <= 0.001f)
                        towardHero = Vector2.left;
                    petWanderTarget = hero.transform.position +
                        (Vector3)towardHero.normalized * PetHeroReturnRadius;
                }

                petWanderTarget = FindNearestClearPetPosition(petWanderTarget);
                nextPetWanderChangeTime = Time.time + Random.Range(1.4f, 2.8f);
                petHasWanderTarget = true;
            }

            desiredPosition = petWanderTarget;
        }

        desiredPosition = FindNearestClearPetPosition(desiredPosition);

        Vector3 nextPosition = Vector3.MoveTowards(
            petCompanionObject.transform.position,
            desiredPosition,
            (nearest != null && !nearest.IsDead &&
                Vector3.Distance(currentPosition, nearest.transform.position) <=
                PetCombatDetectionRange ? PetMoveSpeed : PetWanderSpeed) *
            Time.deltaTime);

        // A monster can move into the pet between frames. Resolve the next
        // position as well as the destination so the pet never visibly ends
        // up inside the hero, witch, or a monster.
        if (!IsPetPositionClear(nextPosition))
            nextPosition = FindNearestClearPetPosition(nextPosition);

        petCompanionObject.transform.position = ClampPetPosition(nextPosition);
    }

    private Vector3 FindNearestClearPetPosition(Vector3 desiredPosition)
    {
        desiredPosition = ClampPetPosition(desiredPosition);
        if (IsPetPositionClear(desiredPosition))
            return desiredPosition;

        if (hero == null)
            return desiredPosition;

        float minimumRadius = GetPetRequiredDistance(hero.transform,
            PetHeroClearance) + 0.04f;
        float maximumRadius = Mathf.Max(minimumRadius, PetMaxDistanceFromHero);
        Vector3 bestPosition = desiredPosition;
        float bestDistance = float.MaxValue;

        // Search a small ring around the hero. This keeps the pet close while
        // still finding a free pocket when a monster blocks its preferred
        // orbit or attack approach.
        const int ringCount = 4;
        const int sampleCount = 24;
        for (int ring = 0; ring < ringCount; ring++)
        {
            float radius = Mathf.Lerp(minimumRadius, maximumRadius,
                ring / (float)(ringCount - 1));
            for (int sample = 0; sample < sampleCount; sample++)
            {
                float angle = petOrbitAngle + sample * Mathf.PI * 2f / sampleCount;
                Vector3 candidate = hero.transform.position + new Vector3(
                    Mathf.Cos(angle) * radius,
                    Mathf.Sin(angle) * radius,
                    0f);
                candidate = ClampPetPosition(candidate);
                if (!IsPetPositionClear(candidate))
                    continue;

                float distance = (candidate - desiredPosition).sqrMagnitude;
                if (distance < bestDistance)
                {
                    bestPosition = candidate;
                    bestDistance = distance;
                }
            }
        }

        if (bestDistance < float.MaxValue)
            return bestPosition;

        // The normal battle layout always has a free sample. This fallback
        // still separates the pet from every occupied character if a large
        // group temporarily fills the search ring.
        Vector3 adjusted = desiredPosition;
        for (int pass = 0; pass < 3; pass++)
        {
            adjusted = KeepPetAwayFromMonsters(adjusted, null);
            adjusted = KeepPetAwayFromWitch(adjusted);
            adjusted = KeepPetAwayFromHero(adjusted);
            adjusted = KeepPetNearHero(adjusted);
            adjusted = ClampPetPosition(adjusted);
            if (IsPetPositionClear(adjusted))
                break;
        }

        return adjusted;
    }

    private bool IsPetPositionClear(Vector3 position)
    {
        if (hero != null && !IsPetClearOfTarget(position, hero.transform,
            PetHeroClearance))
            return false;

        if (witch != null && !IsPetClearOfTarget(position, witch.transform,
            PetWitchClearance))
            return false;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (monster == null || !monster.gameObject.activeInHierarchy)
                continue;

            if (!IsPetClearOfTarget(position, monster.transform,
                PetMonsterClearance))
                return false;
        }

        return true;
    }

    private bool IsPetClearOfTarget(Vector3 petPosition, Transform target,
        float minimumDistance)
    {
        if (target == null)
            return true;

        Vector3 targetPosition = GetCharacterBoundsCenter(target);
        float requiredDistance = GetPetRequiredDistance(target, minimumDistance);
        return (petPosition - targetPosition).sqrMagnitude >=
            requiredDistance * requiredDistance;
    }

    private float GetPetRequiredDistance(Transform target, float minimumDistance)
    {
        float petRadius = GetPetRadius();
        float targetRadius = GetCharacterRadius(target);
        return Mathf.Max(minimumDistance,
            petRadius + targetRadius + PetPositionGap);
    }

    private float GetPetRadius()
    {
        if (petCompanionRenderer == null)
            return 0.3f;

        Bounds bounds = petCompanionRenderer.bounds;
        return Mathf.Max(0.1f, Mathf.Max(bounds.extents.x, bounds.extents.y));
    }

    private float GetCharacterRadius(Transform target)
    {
        if (target == null)
            return 0.3f;

        Collider2D collider = target.GetComponent<Collider2D>();
        if (collider != null)
        {
            Bounds bounds = collider.bounds;
            return Mathf.Max(0.1f, Mathf.Max(bounds.extents.x, bounds.extents.y));
        }

        SpriteRenderer renderer = target.GetComponentInChildren<SpriteRenderer>();
        if (renderer != null)
        {
            Bounds bounds = renderer.bounds;
            return Mathf.Max(0.1f, Mathf.Max(bounds.extents.x, bounds.extents.y));
        }

        return 0.3f;
    }

    private Vector3 GetCharacterBoundsCenter(Transform target)
    {
        if (target == null)
            return Vector3.zero;

        Collider2D collider = target.GetComponent<Collider2D>();
        if (collider != null)
            return collider.bounds.center;

        SpriteRenderer renderer = target.GetComponentInChildren<SpriteRenderer>();
        return renderer != null ? renderer.bounds.center : target.position;
    }

    private Vector3 ClampPetPosition(Vector3 position)
    {
        float marginX = 0.45f;
        float marginY = 0.45f;
        if (petCompanionRenderer != null)
        {
            Bounds bounds = petCompanionRenderer.bounds;
            marginX = Mathf.Max(marginX, bounds.extents.x);
            marginY = Mathf.Max(marginY, bounds.extents.y);
        }

        position.x = Mathf.Clamp(position.x, MinX + marginX, MaxX - marginX);
        position.y = Mathf.Clamp(position.y, MinY + marginY, MaxY - marginY);
        return position;
    }

    private Vector3 KeepPetNearHero(Vector3 position)
    {
        Vector3 offset = position - hero.transform.position;
        if (offset.sqrMagnitude <= PetMaxDistanceFromHero * PetMaxDistanceFromHero)
            return position;

        return hero.transform.position + offset.normalized * PetMaxDistanceFromHero;
    }

    private Vector3 KeepPetAwayFromMonsters(Vector3 position, Monster ignoredMonster)
    {
        Vector3 adjusted = position;
        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (monster == null || !monster.gameObject.activeInHierarchy)
                continue;

            Vector3 monsterPosition = GetCharacterBoundsCenter(monster.transform);
            Vector3 away = adjusted - monsterPosition;
            float requiredDistance = GetPetRequiredDistance(monster.transform,
                PetMonsterClearance);
            if (monster == ignoredMonster)
                requiredDistance = Mathf.Max(requiredDistance,
                    PetAttackRange * 0.82f);

            if (away.sqrMagnitude >= requiredDistance * requiredDistance)
                continue;

            if (away.sqrMagnitude <= 0.0001f && hero != null)
                away = hero.transform.position - monsterPosition;
            if (away.sqrMagnitude <= 0.0001f)
                away = Vector3.left;

            adjusted = monsterPosition +
                away.normalized * requiredDistance;
        }

        return adjusted;
    }

    private Vector3 KeepPetAwayFromWitch(Vector3 position)
    {
        if (witch == null)
            return position;

        Vector3 witchPosition = GetCharacterBoundsCenter(witch.transform);
        Vector3 away = position - witchPosition;
        float requiredDistance = GetPetRequiredDistance(witch.transform,
            PetWitchClearance);
        if (away.sqrMagnitude >= requiredDistance * requiredDistance)
            return position;

        if (away.sqrMagnitude <= 0.0001f && hero != null)
            away = hero.transform.position - witchPosition;
        if (away.sqrMagnitude <= 0.0001f)
            away = Vector3.right;

        return witchPosition + away.normalized * requiredDistance;
    }

    private Vector3 KeepPetAwayFromHero(Vector3 position)
    {
        if (hero == null)
            return position;

        Vector3 heroPosition = GetCharacterBoundsCenter(hero.transform);
        Vector3 away = position - heroPosition;
        float requiredDistance = GetPetRequiredDistance(hero.transform,
            PetHeroClearance);

        if (away.sqrMagnitude >= requiredDistance * requiredDistance)
            return position;

        if (away.sqrMagnitude <= 0.0001f)
            away = Vector3.left;

        return heroPosition + away.normalized * requiredDistance;
    }

    private void LaunchPetAttack(Monster target, int petId)
    {
        if (petCompanionObject == null || petCompanionRenderer == null ||
            target == null || target.IsDead)
            return;

        GameObject attackObject = new GameObject("PetAttack");
        attackObject.transform.position = petCompanionObject.transform.position;
        attackObject.transform.localScale = Vector3.one * 0.16f;

        SpriteRenderer renderer = attackObject.AddComponent<SpriteRenderer>();
        renderer.sprite = GetUiWhiteSprite();
        renderer.color = EquipmentSystem.GetItem(
            EquipmentSystem.Slot.Pet, petId).accent;
        renderer.sortingOrder = 8;

        PetProjectile projectile = attackObject.AddComponent<PetProjectile>();
        projectile.Initialize(target, EquipmentSystem.GetPetDamage(), 5.5f);
    }

    private void DestroyPetCompanion()
    {
        if (petCompanionObject != null)
            Destroy(petCompanionObject);
        petCompanionObject = null;
        petCompanionRenderer = null;
        petAttackStopUntil = 0f;
        pendingPetAttackTarget = null;
    }

    private Sprite GetEquipmentIconSprite(int cellIndex)
    {
        if (equipmentIconsTexture == null)
            equipmentIconsTexture = Resources.Load<Texture2D>("Equipment/EquipmentIcons");
        if (equipmentIconsTexture == null) return null;

        int column = Mathf.Clamp(cellIndex, 0, 5) % 3;
        int row = Mathf.Clamp(cellIndex, 0, 5) / 3;
        int cellWidth = equipmentIconsTexture.width / 3;
        int cellHeight = equipmentIconsTexture.height / 2;
        Rect rect = new Rect(column * cellWidth,
            equipmentIconsTexture.height - (row + 1) * cellHeight,
            cellWidth, cellHeight);
        return Sprite.Create(equipmentIconsTexture, rect,
            new Vector2(0.5f, 0.5f), 512f);
    }

    public void SpawnExperienceOrb(Vector3 position)
    {
        if (state != GameState.Battle) return;

        Sprite orbSprite = GetExperienceOrbSprite();
        if (orbSprite == null) return;

        GameObject orbObject = new GameObject("ExperienceOrb");
        orbObject.transform.position = position;
        orbObject.transform.localScale = Vector3.one * 0.87f;

        SpriteRenderer renderer = orbObject.AddComponent<SpriteRenderer>();
        renderer.sprite = orbSprite;
        renderer.sortingOrder = 1;

        CircleCollider2D pickupCollider = orbObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.42f;

        ExperienceOrb orb = orbObject.AddComponent<ExperienceOrb>();
        orb.Initialize(this, hero != null ? hero.transform : null, ExperiencePerOrb);
    }

    private Sprite GetExperienceOrbSprite()
    {
        if (experienceOrbSprite != null) return experienceOrbSprite;

        Texture2D texture = Resources.Load<Texture2D>("ExperienceOrb/ExperienceOrb");
        if (texture == null)
        {
            Debug.LogError("経験値オーブの画像が見つかりません。Resources/ExperienceOrb/ExperienceOrb.pngを確認してください。");
            return null;
        }

        experienceOrbSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            1024f);
        return experienceOrbSprite;
    }

    public void CollectExperience(int amount)
    {
        experience = Mathf.Clamp(experience + Mathf.Max(0, amount), 0, ExperienceToNextLevel);
    }

    public void SpawnCoin(Vector3 position)
    {
        SpawnCoin(position, false);
    }

    public void SpawnCoin(Vector3 position, bool guaranteed)
    {
        if (state != GameState.Battle) return;
        if (!guaranteed && Random.value > CoinDropChance) return;

        Sprite sprite = GetCoinSprite();
        if (sprite == null) return;

        GameObject coinObject = new GameObject("Coin");
        coinObject.transform.position = position + Vector3.right * 0.32f;
        coinObject.transform.localScale = Vector3.one * 0.63f;

        SpriteRenderer renderer = coinObject.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = 1;

        CircleCollider2D pickupCollider = coinObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.42f;

        CoinPickup coin = coinObject.AddComponent<CoinPickup>();
        coin.Initialize(this, hero != null ? hero.transform : null, CoinsPerDrop);
    }

    public void SpawnGachaTicket(Vector3 position)
    {
        if (state != GameState.Battle || Random.value > BossGachaTicketDropChance)
            return;

        Sprite sprite = GetGachaTicketSprite();
        if (sprite == null) return;

        GameObject ticketObject = new GameObject("GachaTicket");
        ticketObject.transform.position = position + Vector3.up * 0.38f;
        ticketObject.transform.localScale = Vector3.one * 0.7f;

        SpriteRenderer renderer = ticketObject.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.color = Color.white;
        renderer.sortingOrder = 3;

        CircleCollider2D pickupCollider = ticketObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.46f;

        GachaTicketPickup pickup = ticketObject.AddComponent<GachaTicketPickup>();
        pickup.Initialize(this, hero != null ? hero.transform : null, 1);
    }

    public void SpawnEquipmentPiece(Vector3 position, bool eliteDrop)
    {
        if (state != GameState.Battle) return;

        float dropChance = eliteDrop
            ? EliteEquipmentPieceDropChance
            : EquipmentPieceDropChance;
        if (Random.value > dropChance) return;

        EquipmentSystem.Slot slot = (EquipmentSystem.Slot)Random.Range(0, 4);
        Sprite sprite = GetEquipmentPieceSprite(slot);
        if (sprite == null) return;

        GameObject pieceObject = new GameObject("EquipmentPiece");
        pieceObject.transform.position = position + Vector3.up * 0.18f;
        pieceObject.transform.localScale = Vector3.one * 0.46f;

        SpriteRenderer renderer = pieceObject.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        // Each slot now has its own emblem and palette; preserve the sprite
        // colors so the weapon/armor/boots/pet mark stays readable in battle.
        renderer.color = Color.white;
        renderer.sortingOrder = 2;

        CircleCollider2D pickupCollider = pieceObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.46f;

        EquipmentPiecePickup pickup = pieceObject.AddComponent<EquipmentPiecePickup>();
        pickup.Initialize(this, hero != null ? hero.transform : null, slot, 1);
    }

    public void CollectEquipmentPieces(EquipmentSystem.Slot slot, int amount)
    {
        EquipmentSystem.AddPieces(slot, amount);
        RequestEditorRepaint();
    }

    public void CollectGachaTicket(int amount)
    {
        gachaTickets += Mathf.Max(0, amount);
        PlayerPrefs.SetInt(GachaTicketBalanceKey, Mathf.Max(0, gachaTickets));
        PlayerPrefs.Save();
        RequestEditorRepaint();
    }

    private Sprite GetEquipmentPieceSprite(EquipmentSystem.Slot slot)
    {
        if (equipmentPieceSprites.TryGetValue(slot, out Sprite cachedSprite) &&
            cachedSprite != null)
            return cachedSprite;

        string resourcePath = "Equipment/EquipmentPiece";
        switch (slot)
        {
            case EquipmentSystem.Slot.Weapon:
                resourcePath = "Equipment/EquipmentPiece_Weapon";
                break;
            case EquipmentSystem.Slot.Armor:
                resourcePath = "Equipment/EquipmentPiece_Armor";
                break;
            case EquipmentSystem.Slot.Boots:
                resourcePath = "Equipment/EquipmentPiece_Boots";
                break;
            case EquipmentSystem.Slot.Pet:
                resourcePath = "Equipment/EquipmentPiece_Pet";
                break;
        }

        Texture2D sourceTexture = Resources.Load<Texture2D>(resourcePath);
        if (sourceTexture == null)
            sourceTexture = Resources.Load<Texture2D>(
                "Equipment/EquipmentPiece");
        if (sourceTexture != null)
        {
            Sprite sprite = Sprite.Create(sourceTexture,
                new Rect(0f, 0f, sourceTexture.width, sourceTexture.height),
                new Vector2(0.5f, 0.5f), Mathf.Max(1f, sourceTexture.width));
            sprite.name = resourcePath + "Sprite";
            equipmentPieceSprites[slot] = sprite;
            return sprite;
        }

        const int size = 32;
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        texture.name = "RuntimeEquipmentPiece";
        texture.filterMode = FilterMode.Point;
        Color[] pixels = new Color[size * size];
        for (int i = 0; i < pixels.Length; i++)
            pixels[i] = new Color(0f, 0f, 0f, 0f);

        Vector2 center = new Vector2((size - 1) * 0.5f, (size - 1) * 0.5f);
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float diamond = Mathf.Abs(x - center.x) + Mathf.Abs(y - center.y);
                if (diamond > 12f) continue;

                bool edge = diamond > 9.5f;
                pixels[y * size + x] = edge
                    ? new Color(0.08f, 0.12f, 0.16f, 0.95f)
                    : new Color(1f, 0.92f, 0.45f, 1f);
            }
        }

        texture.SetPixels(pixels);
        texture.Apply();
        Sprite fallbackSprite = Sprite.Create(texture,
            new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
        fallbackSprite.name = "RuntimeEquipmentPieceSprite";
        equipmentPieceSprites[slot] = fallbackSprite;
        return fallbackSprite;
    }

    private Sprite GetCoinSprite()
    {
        if (coinSprite != null) return coinSprite;

        Texture2D texture = Resources.Load<Texture2D>("Coin/Coin");
        if (texture == null)
        {
            Debug.LogError("コインの画像が見つかりません。Resources/Coin/Coin.pngを確認してください。");
            return null;
        }

        coinSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            1024f);
        return coinSprite;
    }

    private Sprite GetGachaTicketSprite()
    {
        if (gachaTicketSprite != null) return gachaTicketSprite;

        Texture2D texture = Resources.Load<Texture2D>("Coin/GachaTicket");
        if (texture == null)
        {
            Debug.LogError("ガチャチケットの画像が見つかりません。Resources/Coin/GachaTicket.pngを確認してください。");
            return null;
        }

        gachaTicketSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            1024f);
        return gachaTicketSprite;
    }

    public void CollectCoins(int amount)
    {
        coins += Mathf.Max(0, amount);
        SaveProgress();
    }

    private static int GetUpgradeLevel(string key)
    {
        return Mathf.Max(0, PlayerPrefs.GetInt(key, 0));
    }

    private static int GetUpgradeCostForLevel(string key, int levelIndex)
    {
        return SlashDamageUpgradeBaseCost + Mathf.Max(0, levelIndex) * UpgradeCostStep;
    }

    private static int GetUpgradeCost(string key)
    {
        return GetUpgradeCostForLevel(key, GetUpgradeLevel(key));
    }

    public static int GetHeroMaxHealth()
    {
        return BaseHeroHealth + GetUpgradeLevel(HeroHealthLevelKey) * HealthUpgradeAmount +
            EquipmentSystem.GetHeroHealthBonus();
    }

    public static int GetWitchMaxHealth()
    {
        return BaseWitchHealth + GetUpgradeLevel(WitchHealthLevelKey) * HealthUpgradeAmount;
    }

    public static float GetHeroMoveSpeed()
    {
        return BaseHeroMoveSpeed + GetUpgradeLevel(HeroSpeedLevelKey) * SpeedUpgradeAmount +
            EquipmentSystem.GetHeroSpeedBonus();
    }

    public static float GetHeroAttackInterval()
    {
        return Mathf.Max(
            MinimumHeroAttackInterval,
            BaseHeroAttackInterval -
            GetUpgradeLevel(AttackSpeedLevelKey) * AttackSpeedUpgradeAmount);
    }

    public static int GetSlashPiercingHits()
    {
        return BaseSlashPiercingHits + GetUpgradeLevel(SlashPierceLevelKey);
    }

    public static float GetMonsterKnockbackUpgradeMultiplier()
    {
        return 1f + GetUpgradeLevel(MonsterKnockbackLevelKey) *
            MonsterKnockbackUpgradeAmount;
    }

    public static int GetHeroSlashDamage()
    {
        int level = Mathf.Max(0, PlayerPrefs.GetInt(SlashDamageLevelKey, 0));
        return BaseSlashDamage + level + EquipmentSystem.GetWeaponDamageBonus();
    }

    private bool TryBuySkillNode(int nodeIndex)
    {
        if (nodeIndex < 0 || nodeIndex >= GetSkillNodeCount()) return false;
        if (IsSkillNodePurchased(nodeIndex) || !IsSkillNodeUnlocked(nodeIndex))
            return false;

        string key = SkillUpgradeKeys[GetSkillBranchIndex(nodeIndex)];
        return TryBuyUpgrade(key, GetSkillLevelIndex(nodeIndex));
    }

    private bool TryBuyUpgrade(string key, int levelIndex)
    {
        int currentLevel = GetUpgradeLevel(key);
        if (currentLevel != levelIndex) return false;

        int cost = GetUpgradeCostForLevel(key, levelIndex);
        if (coins < cost) return false;

        coins -= cost;
        PlayerPrefs.SetInt(key, currentLevel + 1);
        SaveProgress();
        PlayConfirmSound();
        return true;
    }

    private void SaveProgress()
    {
        PlayerPrefs.SetInt(CoinBalanceKey, Mathf.Max(0, coins));
        PlayerPrefs.Save();
    }

    private Vector3 GetSpawnPosition(Vector3 witchPosition, float minDistance)
    {
        for (int attempt = 0; attempt < 100; attempt++)
        {
            Vector3 position = new Vector3(
                Random.Range(MinX, MaxX),
                Random.Range(MinY, MaxY),
                0f);

            if (Vector3.Distance(position, witchPosition) >= Mathf.Max(0.1f, minDistance))
                return position;
        }

        return new Vector3(MaxX, MaxY, 0f);
    }

    private void Finish(bool isWin, DefeatReason reason = DefeatReason.WitchDefeated)
    {
        if (state != GameState.Battle) return;

        ResumeBattleTime();

        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
        spawning = false;
        won = isWin;
        defeatReason = reason;
        PlayResultSound(isWin);

        if (isWin)
        {
            MarkStageCleared(currentStage != null
                ? currentStage.stageId
                : selectedStage);
            CollectFieldPickups();
        }

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            if (spawnedMonsters[i] != null)
                spawnedMonsters[i].StopMovement();
        }

        // Result screens are static. In particular, a witch defeat must not
        // leave a living hero controllable behind the failure message.
        if (hero != null)
            hero.StopForResult();
        if (witch != null)
            witch.StopSkillAnimation();

        // Do not let a slash that was already spawned remain visible after
        // the hero dies or the battle has ended.
        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++)
            Destroy(projectiles[i].gameObject);

        PetProjectile[] petProjectiles = FindObjectsByType<PetProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < petProjectiles.Length; i++)
            Destroy(petProjectiles[i].gameObject);

        state = GameState.Result;
    }

    private void CollectFieldPickups()
    {
        ExperienceOrb[] orbs = FindObjectsByType<ExperienceOrb>(FindObjectsInactive.Include);
        for (int i = 0; i < orbs.Length; i++)
        {
            if (orbs[i] != null)
                orbs[i].CollectImmediately();
        }

        CoinPickup[] coinPickups = FindObjectsByType<CoinPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < coinPickups.Length; i++)
        {
            if (coinPickups[i] != null)
                coinPickups[i].CollectImmediately();
        }

        EquipmentPiecePickup[] equipmentPieces =
            FindObjectsByType<EquipmentPiecePickup>(FindObjectsInactive.Include);
        for (int i = 0; i < equipmentPieces.Length; i++)
        {
            if (equipmentPieces[i] != null)
                equipmentPieces[i].CollectImmediately();
        }

        GachaTicketPickup[] gachaTicketsOnField =
            FindObjectsByType<GachaTicketPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < gachaTicketsOnField.Length; i++)
        {
            if (gachaTicketsOnField[i] != null)
                gachaTicketsOnField[i].CollectImmediately();
        }
    }

    private void ReturnToMenu()
    {
        ResumeBattleTime();
        PlayConfirmSound();
        if (!mapOnlyScene)
        {
            // Returning from the battle/result scene should land on the
            // stage-select map, not make the player confirm the title again.
            returnToStageSelectRequested = true;
            battleScenePreloadOperation = null;
            preloadedBattleScene = default;
            battleScenePreloaded = false;
            SceneManager.LoadScene(MapSceneName);
            return;
        }

        ClearBattleObjects();
        if (witch != null)
            witch.gameObject.SetActive(false);
        if (hero != null)
            hero.gameObject.SetActive(false);
        stageInfoOpen = false;
        stageInfoStageId = 0;
        state = GameState.Menu;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(true);
        RefreshMapStagePresentation();
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private bool TryGetNextStageId(out int nextStageId)
    {
        nextStageId = 0;
        if (!won)
            return false;

        List<StageDefinition> stages = GetStages();
        int currentIndex = stages.FindIndex(stage => stage != null &&
            stage.stageId == selectedStage);
        int nextIndex = currentIndex + 1;
        if (currentIndex < 0 || nextIndex >= stages.Count ||
            !IsStageUnlocked(stages, nextIndex))
            return false;

        nextStageId = stages[nextIndex].stageId;
        return true;
    }

    private void OpenNextStageInfo()
    {
        if (!TryGetNextStageId(out int nextStageId))
            return;

        PlayConfirmSound();
        // The result screen is in the battle scene. Return to the map scene
        // and ask it to open the same stage-information modal automatically.
        PlayerPrefs.SetInt(PendingStageInfoKey, nextStageId);
        PlayerPrefs.Save();
        returnToStageSelectRequested = true;
        SceneManager.LoadScene(MapSceneName);
    }

    private void ClearBattleObjects()
    {
        // On the first entry the battle scene was already prepared during
        // preload and there cannot be any runtime pickups/projectiles yet.
        // Avoid scanning every loaded scene at the exact moment the player
        // presses the stage button. Retries/results still perform the full
        // sweep because they may contain leftovers from the previous run.
        bool needsSceneSweep = state == GameState.Result || currentStage != null;

        DestroyHeroEquipmentVisuals();
        DestroyPetCompanion();
        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
        spawning = false;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            if (spawnedMonsters[i] != null) Destroy(spawnedMonsters[i].gameObject);
        }
        spawnedMonsters.Clear();
        DestroyWitchSkillEffect();
        if (witch != null)
            witch.StopSkillAnimation();

        if (!needsSceneSweep)
            return;

        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++) Destroy(projectiles[i].gameObject);

        PetProjectile[] petProjectiles = FindObjectsByType<PetProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < petProjectiles.Length; i++) Destroy(petProjectiles[i].gameObject);

        ExperienceOrb[] orbs = FindObjectsByType<ExperienceOrb>(FindObjectsInactive.Include);
        for (int i = 0; i < orbs.Length; i++) Destroy(orbs[i].gameObject);

        CoinPickup[] coinPickups = FindObjectsByType<CoinPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < coinPickups.Length; i++) Destroy(coinPickups[i].gameObject);

        EquipmentPiecePickup[] equipmentPieces =
            FindObjectsByType<EquipmentPiecePickup>(FindObjectsInactive.Include);
        for (int i = 0; i < equipmentPieces.Length; i++)
            Destroy(equipmentPieces[i].gameObject);

        GachaTicketPickup[] gachaTicketsOnField =
            FindObjectsByType<GachaTicketPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < gachaTicketsOnField.Length; i++)
            Destroy(gachaTicketsOnField[i].gameObject);
    }

    private void OnGUI()
    {
        if (!runtimeInitialized) return;
#if UNITY_EDITOR
        Vector2 guiOrigin = GUIUtility.GUIToScreenPoint(Vector2.zero);
        Vector2 guiEnd = GUIUtility.GUIToScreenPoint(new Vector2(Screen.width, Screen.height));
        editorGameViewOrigin = guiOrigin;
        editorGameViewSize = guiEnd - guiOrigin;
#endif

        if (state == GameState.Battle)
        {
            DrawBattleHud();
            return;
        }

        // Menu map rendering/input lives only in the Canvas ScrollRect. Do
        // not draw the old IMGUI map over it, or the visible position can
        // differ from the ScrollRect position receiving the user's drag.
        if (state == GameState.Menu)
        {
            if (!mapCameraConfigured)
                ConfigureMapCamera();

            SyncMapVisualToCamera();
            if (!developmentDebugPanelOpen)
            {
                UpdateTitleButtonHover(titleUpgradeButton,
                    GetMapUpgradeButtonDesignRect(), false);
                UpdateTitleButtonHover(mapTitleButton,
                    GetMapTitleButtonDesignRect(), false);
                if (stageGroupInfoOpen)
                {
                    DrawStageGroupLevelModal();
                }
                else if (stageInfoOpen)
                {
                    StageDefinition infoStage = GetStageInfoDefinition();
                    if (infoStage != null)
                        DrawStageInfoModal(infoStage);
                }
                else
                {
                    DrawMapUpgradeInputTarget();
                }
            }
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            DrawDevelopmentDebugOverlay();
#endif
            return;
        }

        if (state == GameState.Title)
        {
            // The title visuals are rendered by the runtime Canvas. Keep a
            // single transparent IMGUI target for mouse clicks, while
            // keyboard confirmation is handled in Update().
            if (!developmentDebugPanelOpen && titleHelpOpen)
            {
                UpdateTitleButtonHover(titleHelpBackButton,
                    GetTitleHelpBackButtonDesignRect(), false);
            }
            else if (!developmentDebugPanelOpen)
            {
                UpdateTitleButtonHover(titleStageButton,
                    GetTitleStageButtonDesignRect(), false);
                UpdateTitleButtonHover(titleHelpButton,
                    GetTitleHelpButtonDesignRect(), false);
            }
            if (!developmentDebugPanelOpen)
                DrawOverlayInputTargets();
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            DrawDevelopmentDebugOverlay();
#endif
            return;
        }

        if (state == GameState.Equipment)
        {
            if (mapVisualRoot != null)
                mapVisualRoot.SetActive(false);
            if (mapWorldBackground != null)
                mapWorldBackground.SetActive(false);
            HandleEquipmentGuiEvent(Event.current);
            GetFrontendGuiMetrics(out float equipmentScale, out Vector2 equipmentOffset,
                out _, out _);
            Matrix4x4 previousEquipmentMatrix = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(equipmentOffset, Quaternion.identity,
                Vector3.one * equipmentScale);
            DrawEquipment(GetUpgradePanelRect());
            GUI.matrix = previousEquipmentMatrix;
            return;
        }

        if (state == GameState.Gacha)
        {
            if (mapVisualRoot != null)
                mapVisualRoot.SetActive(false);
            if (mapWorldBackground != null)
                mapWorldBackground.SetActive(false);
            HandleGachaGuiEvent(Event.current);
            GetFrontendGuiMetrics(out float gachaScale, out Vector2 gachaOffset,
                out _, out _);
            Matrix4x4 previousGachaMatrix = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(gachaOffset, Quaternion.identity,
                Vector3.one * gachaScale);
            DrawGacha(GetUpgradePanelRect());
            GUI.matrix = previousGachaMatrix;
            return;
        }

        const float resultPanelWidth = 680f;
        float resultPanelHeight = 480f;
        if (state == GameState.Result)
        {
            int nextStageId;
            if (TryGetNextStageId(out nextStageId))
                resultPanelHeight = 560f;
        }

        Rect panel = state == GameState.Upgrade
            ? GetUpgradePanelRect()
            : new Rect(
                (Screen.width - Mathf.Min(resultPanelWidth, Screen.width - 40f)) * 0.5f,
                (Screen.height - Mathf.Min(resultPanelHeight, Screen.height - 28f)) * 0.5f,
                Mathf.Min(resultPanelWidth, Screen.width - 40f),
                Mathf.Min(resultPanelHeight, Screen.height - 28f));

        if (state == GameState.Result)
        {
            DrawResult(panel);
        }
        else
        {
            // Canvas UI is authored at 1280x720 and CanvasScaler enlarges it
            // for the actual Game view. Apply the same transform to IMGUI so
            // the upgrade panel and its clipping frame use the full screen
            // instead of remaining at an unscaled 1180x680 pixel size.
            GetFrontendGuiMetrics(out float scale, out Vector2 offset,
                out _, out _);
            Matrix4x4 previousMatrix = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(offset, Quaternion.identity,
                Vector3.one * scale);
            DrawUpgrade(panel);
            GUI.matrix = previousMatrix;
        }
    }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
    private Rect GetDevelopmentDebugButtonRect()
    {
        return new Rect(1070f, 18f, 190f, 38f);
    }

    private void DrawDevelopmentDebugOverlay()
    {
        GetFrontendGuiMetrics(out float scale, out Vector2 offset,
            out _, out _);
        Matrix4x4 previousMatrix = GUI.matrix;
        GUI.matrix = Matrix4x4.TRS(offset, Quaternion.identity,
            Vector3.one * scale);

        GUIStyle entryStyle = CreateHoverButtonStyle(14, FontStyle.Bold);
        entryStyle.normal.textColor = new Color(1f, 0.86f, 0.36f, 1f);
        if (!developmentDebugPanelOpen)
        {
            if (GUI.Button(GetDevelopmentDebugButtonRect(),
                "開発デバッグ", entryStyle))
            {
                developmentDebugPanelOpen = true;
                RequestEditorRepaint();
            }

            GUI.matrix = previousMatrix;
            return;
        }

        // IMGUI is used for the compact debug panel, so hide the normal
        // Canvas page while it is open instead of letting the screen-space
        // frontend draw over the panel.
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(false);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(false);
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);

        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.04f, 1f);
        GUI.DrawTexture(new Rect(0f, 0f, 1280f, 720f),
            Texture2D.whiteTexture);
        GUI.color = previousColor;

        Rect panel = new Rect(295f, 10f, 690f, 700f);
        GUI.Box(panel, GUIContent.none);

        GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 26,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        titleStyle.normal.textColor = new Color(1f, 0.86f, 0.36f, 1f);
        GUI.Label(new Rect(panel.x + 24f, panel.y + 18f,
            panel.width - 48f, 42f), "DEVELOPMENT DEBUG", titleStyle);

        GUIStyle noteStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            alignment = TextAnchor.MiddleCenter,
            wordWrap = true
        };
        noteStyle.normal.textColor = new Color(0.78f, 0.86f, 0.92f, 1f);
        GUI.Label(new Rect(panel.x + 38f, panel.y + 62f,
            panel.width - 76f, 42f),
            "この画面はUnity Editor／Development Buildでのみ表示されます。\nクリックした操作は即時に保存されます。",
            noteStyle);

        GUIStyle sectionStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleLeft,
            fontStyle = FontStyle.Bold
        };
        sectionStyle.normal.textColor = new Color(0.96f, 0.94f, 0.80f, 1f);
        GUI.Label(new Rect(panel.x + 42f, panel.y + 116f,
            panel.width - 84f, 30f), "ステージ操作（ワンクリック）", sectionStyle);

        List<StageDefinition> stages = GetStages();
        GUIStyle actionStyle = CreateHoverButtonStyle(16, FontStyle.Bold);
        float buttonWidth = 286f;
        float buttonHeight = 34f;
        float buttonGap = 14f;
        float firstButtonX = panel.x + 42f;
        float secondButtonX = firstButtonX + buttonWidth + buttonGap;
        float buttonY = panel.y + 154f;
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            if (stage == null) continue;

            int column = i % 2;
            int row = i / 2;
            Rect buttonRect = new Rect(
                column == 0 ? firstButtonX : secondButtonX,
                buttonY + row * (buttonHeight + 10f),
                buttonWidth, buttonHeight);
            if (GUI.Button(buttonRect,
                $"{stage.stageId}面をクリア  ({stage.displayName})",
                actionStyle))
            {
                ApplyDevelopmentStageClear(stage.stageId);
                GUI.matrix = previousMatrix;
                return;
            }
        }

        int stageRows = Mathf.CeilToInt(stages.Count / 2f);
        float utilityY = buttonY + stageRows * (buttonHeight + 10f) + 18f;
        GUI.Label(new Rect(panel.x + 42f, utilityY - 32f,
            panel.width - 84f, 28f), "進行操作", sectionStyle);
        if (GUI.Button(new Rect(firstButtonX, utilityY,
            buttonWidth, buttonHeight), "全ステージをクリア", actionStyle))
        {
            ApplyDevelopmentAllStageClear(stages);
            GUI.matrix = previousMatrix;
            return;
        }
        if (GUI.Button(new Rect(secondButtonX, utilityY,
            buttonWidth, buttonHeight), "進行・強化を全リセット", actionStyle))
        {
            ApplyDevelopmentProgressReset();
            GUI.matrix = previousMatrix;
            return;
        }

        float travelY = utilityY + buttonHeight + 8f;
        if (GUI.Button(new Rect(panel.x + 180f, travelY,
            panel.width - 360f, buttonHeight), "2面へ移動（マップ2を表示）", actionStyle))
        {
            OpenDevelopmentMapPageDirect(2);
            GUI.matrix = previousMatrix;
            return;
        }

        GUIStyle closeStyle = CreateHoverButtonStyle(15, FontStyle.Bold);
        closeStyle.normal.textColor = new Color(0.86f, 0.90f, 0.94f, 1f);
        if (GUI.Button(new Rect(panel.x + 180f, panel.y + 650f,
            panel.width - 360f, 42f), "閉じる", closeStyle))
        {
            developmentDebugPanelOpen = false;
            UpdateTitleButtonOverlay();
            RequestEditorRepaint();
        }

        GUI.matrix = previousMatrix;
    }

    private void ApplyDevelopmentStageClear(int stageId)
    {
        MarkStageCleared(stageId);
        RefreshDevelopmentMap();
        developmentDebugPanelOpen = false;
        RequestEditorRepaint();
    }

    private void ApplyDevelopmentAllStageClear(List<StageDefinition> stages)
    {
        if (stages != null)
        {
            for (int i = 0; i < stages.Count; i++)
            {
                if (stages[i] != null)
                    MarkStageCleared(stages[i].stageId);
            }
        }

        currentMapPage = GetHighestUnlockedMapPage();
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        ClampSelectedStageToCurrentMap();
        PlayerPrefs.Save();
        RefreshDevelopmentMap();
        developmentDebugPanelOpen = false;
        if (state == GameState.Title)
            OpenStageMenu();
        else if (state == GameState.Menu)
            RebuildMapVisualForCurrentPage();
        RequestEditorRepaint();
    }

    private void ApplyDevelopmentProgressReset()
    {
        ResetSavedProgress();
        stageInfoOpen = false;
        developmentDebugPanelOpen = false;
        RefreshDevelopmentMap();
        RequestEditorRepaint();
    }

    private void StartDevelopmentStageDirect(int stageId)
    {
        List<StageDefinition> stages = GetStages();
        int stageIndex = GetStageIndex(stageId, stages);
        if (stageIndex < 0)
            return;

        // Direct debug travel is a temporary bypass. It must not change the
        // normal unlock state, so an unreleased face remains hidden on the map.
        developmentDebugPanelOpen = false;
        stageInfoOpen = false;
        if (state == GameState.Title)
            OpenStageMenu();

        if (state != GameState.Menu)
            return;

        selectedStage = stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, stageId);
        PlayerPrefs.Save();
        UpdateTitleButtonOverlay();
        developmentDirectStageStart = true;
        StartStage(stageId);
    }

    private void OpenDevelopmentMapPageDirect(int mapPage)
    {
        if (state == GameState.Title)
            OpenStageMenu();
        if (state != GameState.Menu)
            return;

        List<StageDefinition> pageStages = GetMapPageStages(mapPage);
        if (pageStages.Count == 0)
            return;

        currentMapPage = mapPage;
        selectedStage = pageStages[0].stageId;
        PlayerPrefs.SetInt(CurrentMapPageKey, currentMapPage);
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();
        RebuildMapVisualForCurrentPage();
        developmentDebugPanelOpen = false;
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void RefreshDevelopmentMap()
    {
        ClampSelectedStageToUnlocked();
        if (state == GameState.Menu)
            RefreshMapStagePresentation();
        UpdateTitleButtonOverlay();
    }
#endif

    private Vector2 GetPointerScreenPoint(Vector2 inputPosition)
    {
#if UNITY_EDITOR
        if (editorGameViewSize.x > 1f && editorGameViewSize.y > 1f)
        {
            Vector2 localPoint = inputPosition - editorGameViewOrigin;
            return new Vector2(
                localPoint.x / editorGameViewSize.x * Screen.width,
                (1f - localPoint.y / editorGameViewSize.y) * Screen.height);
        }
#endif
        return inputPosition;
    }

    private void HandleOverlayEditorInput()
    {
        if (Event.current == null) return;

        if (state == GameState.Title && Event.current.type == EventType.KeyDown &&
            (Event.current.keyCode == KeyCode.Return ||
             Event.current.keyCode == KeyCode.KeypadEnter ||
             Event.current.keyCode == KeyCode.Space))
        {
            ActivateTitleSelection();
            Event.current.Use();
            RequestEditorRepaint();
            return;
        }

        if (state == GameState.Title && Event.current.type == EventType.KeyDown &&
            Event.current.keyCode == KeyCode.V)
        {
            CycleVolume();
            Event.current.Use();
            return;
        }

    }

    private Rect DesignRectToGuiRect(Rect designRect)
    {
        return new Rect(
            designRect.x * Screen.width / 1280f,
            designRect.y * Screen.height / 720f,
            designRect.width * Screen.width / 1280f,
            designRect.height * Screen.height / 720f);
    }

    private Rect GetTitleStageButtonDesignRect()
    {
        const float panelHeight = TitlePanelHeight;
        const float buttonWidth = 800f;
        const float buttonHeight = 86f;
        float panelTop = (720f - panelHeight) * 0.5f;
        float buttonX = (1280f - TitlePanelWidth) * 0.5f + 100f;
        return new Rect(buttonX, panelTop + 300f, buttonWidth, buttonHeight);
    }

    private Rect GetMapStageDesignRect(int index, int stageCount)
    {
        const float panelWidth = MapPanelWidth;
        const float panelHeight = MapPanelHeight;
        const float nodeSize = MapNodeSize;
        float panelLeft = (1280f - panelWidth) * 0.5f;
        float panelTop = (720f - panelHeight) * 0.5f;
        Rect mapArea = new Rect(26f, 60f, MapViewportWidth, MapViewportHeight);
        List<StageDefinition> stages = GetCurrentMapStages();
        StageDefinition stage = index >= 0 && index < stages.Count ? stages[index] : null;
        Vector2 mapPosition = GetMapNodePosition(mapArea, stage, index, stageCount);
        Vector2 nodeCenter = new Vector2(
            panelLeft + panelWidth * 0.5f + mapPosition.x - mapArea.center.x,
            panelTop + panelHeight * 0.5f - (mapPosition.y - mapArea.center.y));
        return new Rect(
            nodeCenter.x - nodeSize * 0.5f,
            nodeCenter.y - nodeSize * 0.5f,
            nodeSize,
            nodeSize);
    }

    private void DrawOverlayInputTargets()
    {
        if (state == GameState.Title)
        {
            if (titleHelpOpen)
            {
                if (GUI.Button(DesignRectToGuiRect(GetTitleHelpBackButtonDesignRect()),
                    GUIContent.none, GUIStyle.none))
                    CloseTitleHelp();
                return;
            }

            if (GUI.Button(DesignRectToGuiRect(GetTitleStageButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
                OpenStageMenu();
            if (GUI.Button(DesignRectToGuiRect(GetTitleHelpButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
                OpenTitleHelp();

            if (GUI.Button(DesignRectToGuiRect(GetTitleVolumeButtonDesignRect()),
                GetVolumeLabel(), CreateHoverButtonStyle(20, FontStyle.Bold)))
                CycleVolume();
            return;
        }

        if (state != GameState.Menu) return;
        List<StageDefinition> stages = GetCurrentMapStages();
        for (int i = 0; i < stages.Count; i++)
        {
            if (GUI.Button(DesignRectToGuiRect(GetMapStageDesignRect(i, stages.Count)),
                GUIContent.none, GUIStyle.none))
            {
                OpenStageInfo(stages[i].stageId);
            }
        }
    }

    private Rect GetMapUpgradeButtonDesignRect()
    {
        return new Rect(980f, 650f, 220f, 42f);
    }

    private Rect GetMapTitleButtonDesignRect()
    {
        return new Rect(80f, 650f, 220f, 42f);
    }

    private Rect GetMapEquipmentButtonDesignRect()
    {
        return new Rect(740f, 650f, 220f, 42f);
    }

    private Rect GetMapGachaButtonDesignRect()
    {
        return new Rect(500f, 650f, 220f, 42f);
    }

    private Rect GetMapTravelButtonDesignRect()
    {
        return new Rect(70f, 64f, 180f, 42f);
    }

    private Rect GetMapPreviousPageButtonDesignRect()
    {
        return new Rect(70f, 18f, 190f, 38f);
    }

    private Rect GetMapNextPageButtonDesignRect()
    {
        return new Rect(850f, 18f, 190f, 38f);
    }

    private Rect GetTitleHelpButtonDesignRect()
    {
        return new Rect(240f, 435f, 800f, 70f);
    }

    private Rect GetTitleVolumeButtonDesignRect()
    {
        return new Rect(790f, 545f, 300f, 54f);
    }

    private Rect GetTitleHelpBackButtonDesignRect()
    {
        return new Rect(240f, 570f, 800f, 58f);
    }

    private void DrawMapUpgradeInputTarget()
    {
        if (state != GameState.Menu) return;

        // The map artwork and nodes are generated on the Canvas, but the
        // editor Game view's reliable click path is IMGUI.  Provide the same
        // transparent hit targets here so clicking LEVEL1, LEVEL2, etc.
        // actually opens that level's detail dialog.
        if (!mapTravelMode && !stageInfoOpen && !stageGroupInfoOpen)
        {
            List<StageDefinition> stages = GetCurrentMapStages();
            List<StageDefinition> allStages = GetStages();
            for (int i = 0; i < stages.Count; i++)
            {
                StageDefinition stage = stages[i];
                if (stage == null || !IsStageUnlocked(stage.stageId, allStages))
                    continue;

                if (GUI.Button(DesignRectToGuiRect(
                    GetMapStageDesignRect(i, stages.Count)),
                    GUIContent.none, GUIStyle.none))
                {
                    OpenStageInfo(stage.stageId);
                    return;
                }
            }
        }

        if (GUI.Button(DesignRectToGuiRect(GetMapTravelButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            ToggleMapTravelMode();
        }
        if (GUI.Button(DesignRectToGuiRect(GetMapUpgradeButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            OpenUpgradeMenu();
        }
        if (GUI.Button(DesignRectToGuiRect(GetMapTitleButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            ReturnToTitle();
        }
        if (GUI.Button(DesignRectToGuiRect(GetMapEquipmentButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            OpenEquipmentMenu();
        }
        if (GUI.Button(DesignRectToGuiRect(GetMapGachaButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            OpenGachaMenu();
        }
        if (!mapTravelMode && currentMapPage > 1 &&
            GUI.Button(DesignRectToGuiRect(GetMapPreviousPageButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
        {
            OpenMapPage(currentMapPage - 1);
        }
        if (!mapTravelMode && currentMapPage < GetHighestUnlockedMapPage() &&
            GUI.Button(DesignRectToGuiRect(GetMapNextPageButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
        {
            OpenMapPage(currentMapPage + 1);
        }
    }

    private void DrawTitle(Rect panel)
    {
        if (Event.current != null && Event.current.type == EventType.KeyDown)
        {
            if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter ||
                Event.current.keyCode == KeyCode.Space)
            {
                ActivateTitleSelection();
                Event.current.Use();
                return;
            }
        }

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 38,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUIStyle subtitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };
        subtitle.normal.textColor = new Color(1f, 0.93f, 0.72f);

        DrawMenuBackdrop(panel, true);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 62f, panel.width - 40f, 64f),
            "WITCH & HERO", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 128f, panel.width - 40f, 30f),
            "魔女と勇者の小さな冒険", subtitle);

        float buttonWidth = panel.width - 100f;
        float buttonX = panel.x + 50f;
        Rect stageButton = new Rect(buttonX, panel.y + 205f, buttonWidth, 58f);
        if (GUI.Button(stageButton, "ステージを選ぶ",
            CreateHoverButtonStyle(20, FontStyle.Bold)))
        {
            OpenStageMenu();
        }

        Rect upgradeButton = new Rect(buttonX, panel.y + 275f, buttonWidth, 58f);
        if (GUI.Button(upgradeButton, "強化画面",
            CreateHoverButtonStyle(20, FontStyle.Bold)))
        {
            OpenUpgradeMenu();
        }
    }

    private void DrawMenu(Rect panel, List<StageDefinition> stages)
    {
        GUIStyle worldMapLabel = new GUIStyle(GUI.skin.label)
        {
            fontSize = 15,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        worldMapLabel.normal.textColor = Color.white;
        GUIStyle coinLabel = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        coinLabel.normal.textColor = Color.white;
        DrawMenuBackdrop(panel, false);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 20f, panel.width - 40f, 26f),
            "WORLD MAP", worldMapLabel);
        DrawCoinCounter(new Rect(panel.x + panel.width - 180f, panel.y + 18f, 150f, 34f), coinLabel);

        Rect mapViewport = new Rect(panel.x + 22f, panel.y + 58f,
            panel.width - 44f, panel.height - 76f);
        Rect mapContent = new Rect(0f, 0f, 1280f, 800f);
        if (!mapScrollInitialized)
        {
            // Start in the middle so a natural drag in any direction has
            // room to move. Starting at an edge made one drag direction
            // appear to do nothing because the scroll was already clamped.
            mapScrollPosition = new Vector2(
                Mathf.Max(0f, (mapContent.width - mapViewport.width) * 0.5f),
                Mathf.Max(0f, (mapContent.height - mapViewport.height) * 0.5f));
            mapScrollInitialized = true;
            SyncMapPanOverlayFromPosition();
        }

        Event currentEvent = Event.current;
        UpdateMapScroll(mapViewport, mapContent);
        HandleMapEventKeyboardPan(currentEvent, mapContent, mapViewport);

        // Translate the map explicitly. This keeps the visual offset tied to
        // mapScrollPosition instead of letting an IMGUI ScrollView restore its
        // own internal position between frames.
        GUI.BeginGroup(mapViewport);
        GUI.BeginGroup(new Rect(-mapScrollPosition.x, -mapScrollPosition.y,
            mapContent.width, mapContent.height));
        DrawMapContentBackdrop(mapContent);

        // The Canvas owns the map-selection screen nodes. Do not let the
        // legacy IMGUI renderer draw the current page's stage nodes on top of
        // it; that was the source of the confusing MAP1/MAP2 mixed view.
        if (mapTravelMode)
        {
            GUI.EndGroup();
            GUI.EndGroup();
            return;
        }

        Vector2[] nodePositions = new Vector2[stages.Count];
        for (int i = 0; i < stages.Count; i++)
            nodePositions[i] = GetMapNodePosition(mapContent, stages[i], i,
                stages.Count);

        if (!mapTravelMode)
        {
            for (int i = 0; i < nodePositions.Length - 1; i++)
            {
                DrawMapLine(nodePositions[i], nodePositions[i + 1],
                    new Color(0.72f, 0.53f, 0.28f, 0.95f), 10f);
            }
        }

        StageDefinition hoveredStage = null;
        Vector2 hoveredNodePosition = Vector2.zero;
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            Vector2 nodePosition = nodePositions[i];
            const float nodeSize = 72f;

            Vector2 contentPointer = Event.current.mousePosition - mapViewport.position +
                mapScrollPosition;
            Rect nodeButton = new Rect(nodePosition.x - nodeSize * 0.5f,
                nodePosition.y - nodeSize * 0.5f, nodeSize, nodeSize);
            bool hovered = nodeButton.Contains(contentPointer);
            Color nodeColor = i == stages.Count - 1
                ? new Color(0.95f, 0.55f, 0.18f)
                : new Color(0.22f, 0.65f, 0.9f);
            if (hovered)
                nodeColor = Color.Lerp(nodeColor, new Color(1f, 0.84f, 0.36f), 0.42f);

            DrawMapNode(nodePosition, nodeColor, nodeSize, i % 3);

            if (hovered)
            {
                hoveredStage = stage;
                hoveredNodePosition = nodePosition;
            }
        }

        if (hoveredStage != null)
            DrawStagePopup(mapContent, hoveredNodePosition, hoveredStage);

        GUI.EndGroup();
        GUI.EndGroup();
    }

    private void HandleMapEventKeyboardPan(Event currentEvent, Rect content, Rect viewport)
    {
        if (currentEvent == null || currentEvent.type != EventType.KeyDown)
            return;

        Vector2 direction = Vector2.zero;
        switch (currentEvent.keyCode)
        {
            case KeyCode.A:
            case KeyCode.LeftArrow:
                direction.x = -1f;
                break;
            case KeyCode.D:
            case KeyCode.RightArrow:
                direction.x = 1f;
                break;
            case KeyCode.W:
            case KeyCode.UpArrow:
                direction.y = -1f;
                break;
            case KeyCode.S:
            case KeyCode.DownArrow:
                direction.y = 1f;
                break;
        }

        if (direction.sqrMagnitude <= 0.0001f)
            return;

        ApplyMapScroll(direction * 48f, content, viewport);
        currentEvent.Use();
    }

    private void UpdateMapScroll(Rect viewport, Rect content)
    {
        Event currentEvent = Event.current;
        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
        {
            if (!viewport.Contains(currentEvent.mousePosition))
                return;

            mapDragging = true;
            mapSuppressNodeClick = false;
            mapLastPointerPosition = currentEvent.mousePosition;
            return;
        }

        if (currentEvent.type == EventType.MouseDrag && mapDragging)
        {
            Vector2 pointerPosition = currentEvent.mousePosition;
            Vector2 delta = pointerPosition - mapLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                mapSuppressNodeClick = true;
                ApplyMapScroll(-delta, content, viewport);
                mapLastPointerPosition = pointerPosition;
                currentEvent.Use();
            }
            return;
        }

        if (currentEvent.type == EventType.MouseUp && mapDragging)
        {
            if (!mapSuppressNodeClick)
            {
                Vector2 contentPoint = currentEvent.mousePosition - viewport.position +
                    mapScrollPosition;
                if (mapTravelMode)
                {
                    List<MapStageGroup> selectionGroups =
                        GetMapStageGroups(currentMapPage);
                    for (int i = 0; i < selectionGroups.Count; i++)
                    {
                        Vector2 nodePosition = GetMapSelectionNodePosition(content,
                            i + 1);
                        Rect nodeRect = new Rect(nodePosition.x - 90f,
                            nodePosition.y - 90f, 180f, 180f);
                        if (nodeRect.Contains(contentPoint))
                        {
                            SelectStageGroupFromSelectionScreen(
                                selectionGroups[i].groupId);
                            currentEvent.Use();
                            break;
                        }
                    }
                }
                else
                {
                    List<StageDefinition> stages = GetCurrentMapStages();
                    for (int i = 0; i < stages.Count; i++)
                    {
                        Vector2 nodePosition = GetMapNodePosition(content, stages[i], i,
                            stages.Count);
                        Rect nodeRect = new Rect(nodePosition.x - 36f, nodePosition.y - 36f,
                            72f, 72f);
                        if (nodeRect.Contains(contentPoint))
                        {
                            OpenStageInfo(stages[i].stageId);
                            currentEvent.Use();
                            break;
                        }
                    }
                }
            }

            mapDragging = false;
            if (mapSuppressNodeClick)
                currentEvent.Use();
            return;
        }

        if (currentEvent.type == EventType.ScrollWheel)
        {
            if (!viewport.Contains(currentEvent.mousePosition))
                return;
            Vector2 scrollDelta = currentEvent.shift
                ? new Vector2(currentEvent.delta.y * 24f, 0f)
                : new Vector2(0f, currentEvent.delta.y * 24f);
            ApplyMapScroll(scrollDelta, content, viewport);
            currentEvent.Use();
        }
    }

    private void ClampMapScroll(Rect content, Rect viewport)
    {
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f,
            Mathf.Max(0f, content.width - viewport.width));
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f,
            Mathf.Max(0f, content.height - viewport.height));
    }

    private void DrawMapContentBackdrop(Rect contentRect)
    {
        Color previousColor = GUI.color;
        Texture2D background = GetMapBackgroundTexture();
        GUI.color = Color.white;
        if (background != null)
            GUI.DrawTexture(contentRect, background, ScaleMode.StretchToFill);
        GUI.color = new Color(0.02f, 0.08f, 0.14f, 0.34f);
        GUI.DrawTexture(contentRect, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawStagePopup(Rect panel, Vector2 nodePosition, StageDefinition stage)
    {
        const float popupWidth = 280f;
        const float popupHeight = 154f;
        float popupX = nodePosition.x + 48f;
        float popupY = nodePosition.y - popupHeight * 0.5f;
        if (popupX + popupWidth > panel.xMax - 12f)
            popupX = nodePosition.x - popupWidth - 48f;
        popupX = Mathf.Clamp(popupX, panel.x + 12f, panel.xMax - popupWidth - 12f);
        popupY = Mathf.Clamp(popupY, panel.y + 48f, panel.yMax - popupHeight - 18f);

        GUIStyle popupTitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        popupTitle.normal.textColor = Color.white;
        GUIStyle popupText = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleCenter
        };
        popupText.normal.textColor = new Color(1f, 0.93f, 0.72f);

        Rect popup = new Rect(popupX, popupY, popupWidth, popupHeight);
        GUI.Box(popup, GUIContent.none);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 8f, popup.width - 16f, 34f),
            stage.displayName, popupTitle);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 48f, popup.width - 16f, 28f),
            $"{stage.mapTheme}・{stage.mapConcept}", popupText);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 82f, popup.width - 16f, 28f),
            $"モンスター  {stage.TotalMonsterCount}体", popupText);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 116f, popup.width - 16f, 28f),
            "クリックで詳細", popupText);
    }

    private void DrawStageGroupLevelModal()
    {
        MapStageGroup group = GetMapStageGroup(stageGroupInfoMapPage,
            stageGroupInfoId);
        if (group == null || group.levels.Count == 0)
            return;

        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.62f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height),
            Texture2D.whiteTexture);
        GUI.color = previousColor;

        float popupWidth = Mathf.Min(760f, Screen.width - 40f);
        int columns = Mathf.Min(5, group.levels.Count);
        int rows = Mathf.CeilToInt((float)group.levels.Count / columns);
        float popupHeight = rows > 1 ? 430f : 350f;
        Rect popup = new Rect((Screen.width - popupWidth) * 0.5f,
            (Screen.height - popupHeight) * 0.5f, popupWidth, popupHeight);
        // The detail dialog itself must be opaque. Only the area outside the
        // dialog is dimmed; the map must not show through the panel behind
        // the LEVEL title, concept and action buttons.
        Color popupBackgroundColor = GUI.color;
        GUI.color = new Color(0.025f, 0.075f, 0.11f, 1f);
        GUI.DrawTexture(popup, Texture2D.whiteTexture);
        GUI.color = popupBackgroundColor;
        GUI.Box(popup, GUIContent.none);

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 34,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUI.Label(new Rect(popup.x + 20f, popup.y + 18f,
            popup.width - 40f, 48f), "STAGE " + stageGroupInfoId, title);

        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleCenter
        };
        hint.normal.textColor = new Color(0.72f, 0.82f, 0.88f);
        GUI.Label(new Rect(popup.x + 20f, popup.y + 68f,
            popup.width - 40f, 30f), "LEVELを選択", hint);

        GUIStyle levelButton = CreateHoverButtonStyle(22, FontStyle.Bold);
        float gap = 12f;
        float buttonWidth = (popup.width - 48f - gap * (columns - 1)) /
            Mathf.Max(1, columns);
        float buttonHeight = 64f;
        float buttonY = popup.y + 126f;
        for (int i = 0; i < group.levels.Count; i++)
        {
            StageDefinition level = group.levels[i];
            bool unlocked = IsStageUnlocked(level.stageId, GetStages());
            int column = i % columns;
            int row = i / columns;
            Rect levelRect = new Rect(popup.x + 24f + column * (buttonWidth + gap),
                buttonY + row * (buttonHeight + gap), buttonWidth, buttonHeight);
            GUIStyle style = new GUIStyle(levelButton);
            style.normal.textColor = unlocked
                ? (i == stageGroupInfoChoice
                    ? new Color(1f, 0.9f, 0.35f) : Color.white)
                : new Color(0.42f, 0.46f, 0.48f);
            string label = unlocked
                ? "LEVEL " + level.stageId
                : "LOCKED";
            if (GUI.Button(levelRect, label, style))
            {
                stageGroupInfoChoice = i;
                if (unlocked)
                {
                    stageGroupInfoOpen = false;
                    OpenStageInfo(level.stageId);
                    return;
                }
            }
        }

        GUIStyle back = CreateHoverButtonStyle(22, FontStyle.Bold);
        float backY = buttonY + rows * (buttonHeight + gap) + 8f;
        if (GUI.Button(new Rect(popup.x + 160f, backY,
            popup.width - 320f, 48f), "マップに戻る", back))
        {
            CloseStageGroupInfo();
        }
        GUI.Label(new Rect(popup.x + 20f, popup.y + popup.height - 32f,
            popup.width - 40f, 24f),
            "1〜4で選択　Enterで決定　Escで戻る", hint);
    }

    private void DrawStageInfoModal(StageDefinition stage)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.62f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = previousColor;

        const float popupWidth = 560f;
        const float popupHeight = 380f;
        Rect popup = new Rect(
            (Screen.width - popupWidth) * 0.5f,
            (Screen.height - popupHeight) * 0.5f,
            popupWidth,
            popupHeight);

        // Keep the stage detail panel opaque so the selected stage's dialog
        // does not show the map art through its background.
        Color popupBackgroundColor = GUI.color;
        GUI.color = new Color(0.025f, 0.075f, 0.11f, 1f);
        GUI.DrawTexture(popup, Texture2D.whiteTexture);
        GUI.color = popupBackgroundColor;
        GUI.Box(popup, GUIContent.none);

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 40,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUI.Label(new Rect(popup.x + 20f, popup.y + 18f, popup.width - 40f, 58f),
            stage.displayName, title);

        GUIStyle info = new GUIStyle(GUI.skin.label)
        {
            fontSize = 26,
            alignment = TextAnchor.MiddleCenter
        };
        info.normal.textColor = new Color(1f, 0.93f, 0.72f);
        GUIStyle concept = new GUIStyle(info)
        {
            fontSize = 22,
            fontStyle = FontStyle.Bold
        };
        concept.normal.textColor = new Color(0.72f, 0.9f, 0.78f);
        int waveCount = stage.waves == null ? 0 : stage.waves.Length;
        GUI.Label(new Rect(popup.x + 24f, popup.y + 74f, popup.width - 48f, 34f),
            $"{stage.mapTheme}・{stage.mapConcept}", concept);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 108f, popup.width - 48f, 42f),
            $"モンスター  {stage.TotalMonsterCount}体", info);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 148f, popup.width - 48f, 42f),
            $"ウェーブ  {waveCount}", info);

        GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect);
        GUIStyle button = CreateHoverButtonStyle(26, FontStyle.Bold);
        GUIStyle selectedButton = new GUIStyle(button);
        selectedButton.normal.textColor = new Color(1f, 0.9f, 0.35f);

        if (GUI.Button(challengeRect, "挑む", stageInfoChoice == 0 ? selectedButton : button))
            ConfirmStageInfo();
        if (GUI.Button(cancelRect, "やめる", stageInfoChoice == 1 ? selectedButton : button))
            CloseStageInfo();

        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleCenter
        };
        hint.normal.textColor = new Color(0.72f, 0.82f, 0.88f);
        GUI.Label(new Rect(popup.x + 20f, popup.y + 344f, popup.width - 40f, 26f),
            "← →で選択　Enterで決定　Escで戻る", hint);
    }

    private void DrawMenuBackdrop(Rect panel, bool includeBackground)
    {
        Color previousColor = GUI.color;
        if (includeBackground)
        {
            Texture2D background = GetMapBackgroundTexture();
            GUI.color = Color.white;
            if (background != null)
                GUI.DrawTexture(panel, background, ScaleMode.StretchToFill);
            else
                GUI.DrawTexture(panel, Texture2D.whiteTexture);
        }

        GUI.color = new Color(0.02f, 0.08f, 0.14f, 0.45f);
        GUI.DrawTexture(panel, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.55f);
        GUI.DrawTexture(new Rect(panel.x + 10f, panel.y + 10f, panel.width - 20f, 3f),
            Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panel.x + 10f, panel.y + panel.height - 13f,
            panel.width - 20f, 3f), Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private Texture2D GetMapBackgroundTexture()
    {
        if (mapTravelMode)
        {
            if (mapTravelBackgroundTexture == null)
            {
                mapTravelBackgroundTexture = Resources.Load<Texture2D>(
                    "StageMap/StageMapBackground_World");
            }

            return mapTravelBackgroundTexture;
        }

        // The current map contains multiple STAGE groups.  Their route
        // backgrounds follow the group's concept, so STAGE2's ancient-ruins
        // route does not reuse the grassland art from STAGE1.
        if (currentMapPage == 2 || GetStageGroupIdForLevel(selectedStage) >= 2)
        {
            if (mapRuinsBackgroundTexture == null)
            {
                mapRuinsBackgroundTexture = Resources.Load<Texture2D>(
                    "StageMap/StageMapBackground_Ruins");
            }

            return mapRuinsBackgroundTexture;
        }

        if (mapBackgroundTexture == null)
        {
            mapBackgroundTexture = Resources.Load<Texture2D>(
                "StageMap/StageMapBackground");
        }

        return mapBackgroundTexture;
    }

    private void DrawCoinCounter(Rect area, GUIStyle labelStyle)
    {
        float iconSize = Mathf.Min(32f, area.height);
        float textWidth = Mathf.Max(40f, area.width - iconSize - 8f);
        float contentWidth = iconSize + 8f + textWidth;
        float contentX = area.center.x - contentWidth * 0.5f;
        Rect frame = new Rect(contentX - 6f, area.y - 3f,
            contentWidth + 12f, area.height + 6f);
        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.68f);
        GUI.DrawTexture(frame, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.65f);
        GUI.DrawTexture(new Rect(frame.x, frame.y, frame.width, 2f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(frame.x, frame.yMax - 2f, frame.width, 2f), Texture2D.whiteTexture);
        GUI.color = Color.white;

        Sprite sprite = GetCoinSprite();
        if (sprite != null && sprite.texture != null)
        {
            GUI.DrawTexture(new Rect(contentX, area.y, iconSize, iconSize), sprite.texture,
                ScaleMode.ScaleToFit);
        }

        GUI.Label(new Rect(contentX + iconSize + 8f, area.y + 1f, textWidth,
            Mathf.Max(24f, area.height - 2f)),
            $"x{coins}", labelStyle);
        GUI.color = previousColor;
    }

    private void DrawTicketCounter(Rect area, GUIStyle labelStyle)
    {
        float iconSize = Mathf.Min(32f, area.height);
        float textWidth = Mathf.Max(40f, area.width - iconSize - 8f);
        float contentWidth = iconSize + 8f + textWidth;
        float contentX = area.center.x - contentWidth * 0.5f;
        Rect frame = new Rect(contentX - 6f, area.y - 3f,
            contentWidth + 12f, area.height + 6f);
        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.68f);
        GUI.DrawTexture(frame, Texture2D.whiteTexture);
        GUI.color = new Color(0.25f, 0.9f, 1f, 0.8f);
        GUI.DrawTexture(new Rect(frame.x, frame.y, frame.width, 2f),
            Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(frame.x, frame.yMax - 2f, frame.width, 2f),
            Texture2D.whiteTexture);

        Sprite sprite = GetGachaTicketSprite();
        if (sprite != null && sprite.texture != null)
        {
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(contentX, area.y, iconSize, iconSize),
                sprite.texture, ScaleMode.ScaleToFit, true);
        }

        GUI.color = Color.white;
        GUI.Label(new Rect(contentX + iconSize + 8f, area.y + 1f, textWidth,
            Mathf.Max(24f, area.height - 2f)),
            $"x{gachaTickets}", labelStyle);
        GUI.color = previousColor;
    }

    private void DrawEquipmentPieceCounter(Rect area, GUIStyle labelStyle,
        EquipmentSystem.Slot slot)
    {
        float iconSize = Mathf.Min(32f, area.height);
        float textWidth = Mathf.Max(40f, area.width - iconSize - 8f);
        float contentWidth = iconSize + 8f + textWidth;
        float contentX = area.center.x - contentWidth * 0.5f;
        Rect frame = new Rect(contentX - 6f, area.y - 3f,
            contentWidth + 12f, area.height + 6f);
        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.68f);
        GUI.DrawTexture(frame, Texture2D.whiteTexture);
        GUI.color = GetEquipmentSlotAccent(slot);
        GUI.DrawTexture(new Rect(frame.x, frame.y, frame.width, 2f),
            Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(frame.x, frame.yMax - 2f,
            frame.width, 2f), Texture2D.whiteTexture);
        GUI.color = Color.white;

        Sprite sprite = GetEquipmentPieceSprite(slot);
        if (sprite != null && sprite.texture != null)
        {
            GUI.DrawTexture(new Rect(contentX, area.y, iconSize, iconSize),
                sprite.texture, ScaleMode.ScaleToFit, true);
        }

        GUI.Label(new Rect(contentX + iconSize + 8f, area.y + 1f,
            textWidth, Mathf.Max(24f, area.height - 2f)),
            $"x{EquipmentSystem.GetPieceCount(slot)}", labelStyle);
        GUI.color = previousColor;
    }

    private Vector2 GetStageNodePosition(Rect mapArea, int index, int count,
        int routeGroupId = 1)
    {
        if (count <= 1)
            return new Vector2(mapArea.center.x, mapArea.center.y);

        // Follow the roads and landmarks in StageMapBackground instead of
        // drawing a straight diagonal. The points are normalized so the same
        // route is used by the IMGUI map, the Canvas map, the drag overlay,
        // and the camera focus code. When fewer than ten stages are defined,
        // sample this route evenly; when more are added, continue from the
        // last point so the catalog remains extensible.
        Vector2[] routePoints = routeGroupId >= 2
            ? RuinsRoutePoints : MapRoutePoints;
        float routePosition = count <= routePoints.Length
            ? (float)index / Mathf.Max(1, count - 1) * (routePoints.Length - 1)
            : index;
        int lowerIndex = Mathf.Clamp(Mathf.FloorToInt(routePosition), 0, routePoints.Length - 1);
        int upperIndex = Mathf.Min(lowerIndex + 1, routePoints.Length - 1);
        Vector2 normalizedPoint = Vector2.Lerp(routePoints[lowerIndex], routePoints[upperIndex],
            routePosition - lowerIndex);

        if (count > routePoints.Length)
        {
            float extraIndex = index - (routePoints.Length - 1);
            normalizedPoint += new Vector2(0.08f * extraIndex, -0.06f * extraIndex);
        }

        normalizedPoint.x = Mathf.Clamp(normalizedPoint.x, 0.08f, 0.92f);
        normalizedPoint.y = Mathf.Clamp(normalizedPoint.y, 0.12f, 0.86f);
        return new Vector2(
            Mathf.Lerp(mapArea.x, mapArea.xMax, normalizedPoint.x),
            Mathf.Lerp(mapArea.y, mapArea.yMax, normalizedPoint.y));
    }

    private void DrawMapLine(Vector2 start, Vector2 end, Color color, float width)
    {
        Color previousColor = GUI.color;
        Matrix4x4 previousMatrix = GUI.matrix;
        Vector2 direction = end - start;
        float distance = direction.magnitude;
        Vector2 unitDirection = direction / Mathf.Max(distance, 0.001f);
        const float lineInset = 58f;
        start += unitDirection * lineInset;
        end -= unitDirection * lineInset;
        direction = end - start;
        float length = direction.magnitude;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        GUIUtility.RotateAroundPivot(angle, start);
        GUI.color = new Color(0.16f, 0.1f, 0.05f, 0.78f);
        GUI.DrawTexture(new Rect(start.x, start.y - (width + 6f) * 0.5f,
                length, width + 6f), Texture2D.whiteTexture);
        GUI.color = color;
        GUI.DrawTexture(new Rect(start.x, start.y - width * 0.5f,
                length, width),
            Texture2D.whiteTexture);
        GUI.matrix = previousMatrix;
        GUI.color = previousColor;
    }

    private int GetHoveredSkillTreeNodeIndex(Vector2[] nodePositions,
        Vector2 treeGuiOrigin, Rect viewport)
    {
        if (nodePositions == null || nodePositions.Length == 0)
            return -1;

        bool hasPointer = TryGetGuiPointerPosition(out Vector2 pointer);
        if (!hasPointer || !viewport.Contains(pointer))
            return -1;
        pointer -= treeGuiOrigin;

        int hoveredIndex = -1;
        float nearestDistance = float.PositiveInfinity;
        float halfSize = SkillTreeNodeSize * 0.5f;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            if (!IsSkillNodeVisible(i))
                continue;

            Rect nodeRect = new Rect(
                nodePositions[i].x - halfSize,
                nodePositions[i].y - halfSize,
                SkillTreeNodeSize,
                SkillTreeNodeSize);
            if (!hasPointer || !nodeRect.Contains(pointer))
                continue;

            // If a stale editor event or a scaled Game view ever makes two
            // hit rectangles overlap, resolve the hover to the closest node
            // instead of highlighting every matching rectangle.
            float distance = hasPointer
                ? (nodePositions[i] - pointer).sqrMagnitude
                : i;
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                hoveredIndex = i;
            }
        }

        return hoveredIndex;
    }

    private void DrawSkillTreeLine(Vector2 start, Vector2 end, Color color,
        float width)
    {
        Color previousColor = GUI.color;
        Vector2 direction = end - start;
        float distance = direction.magnitude;
        Vector2 unitDirection = direction / Mathf.Max(distance, 0.001f);
        const float startInset = 56f;
        const float endInset = 56f;
        start += unitDirection * startInset;
        end -= unitDirection * endInset;

        GUI.color = new Color(0.03f, 0.05f, 0.08f, 0.95f);
        DrawSkillTreeSegment(start, end, width + 5f);
        GUI.color = color;
        DrawSkillTreeSegment(start, end, width);
        GUI.color = previousColor;
    }

    private void DrawSkillTreeSegment(Vector2 start, Vector2 end, float width)
    {
        Vector2 direction = end - start;
        float length = direction.magnitude;
        int steps = Mathf.Max(1, Mathf.CeilToInt(length /
            Mathf.Max(1f, width * 0.5f)));
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps;
            Vector2 point = Vector2.Lerp(start, end, t);
            GUI.DrawTexture(new Rect(point.x - width * 0.5f,
                point.y - width * 0.5f, width, width),
                Texture2D.whiteTexture);
        }
    }

    private void DrawSkillTreeNode(Vector2 center, float size, Color color,
        Color accent, string icon, string title, string value, string footer)
    {
        Texture2D circle = GetMapCircleTexture();
        if (circle == null)
            circle = Texture2D.whiteTexture;

        Color previousColor = GUI.color;
        Rect shadowRect = new Rect(center.x - size * 0.5f - 6f,
            center.y - size * 0.5f - 6f, size + 12f, size + 12f);
        Rect nodeRect = new Rect(center.x - size * 0.5f,
            center.y - size * 0.5f, size, size);
        GUI.color = new Color(0.01f, 0.02f, 0.04f, 0.95f);
        GUI.DrawTexture(shadowRect, circle, ScaleMode.StretchToFill);
        GUI.color = color;
        GUI.DrawTexture(nodeRect, circle, ScaleMode.StretchToFill);
        GUI.color = Color.white;

        float iconSize = Mathf.Clamp(size * 0.28f, 22f, 32f);
        Rect iconRect = new Rect(center.x - iconSize * 0.5f,
            nodeRect.y + size * 0.055f, iconSize, iconSize);
        GUI.color = accent;
        GUI.DrawTexture(iconRect, circle, ScaleMode.StretchToFill);
        GUI.color = Color.white;

        GUIStyle iconStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = Mathf.RoundToInt(iconSize * 0.66f),
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        iconStyle.normal.textColor = new Color(0.03f, 0.08f, 0.12f, 1f);
        GUI.Label(iconRect, icon, iconStyle);

        GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = title == "強化ツリー" ? 14 : size >= 100f ? 13 : 11,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            wordWrap = true
        };
        GUIStyle valueStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = size >= 100f ? 13 : 11,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle footerStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = size >= 100f ? 10 : 9,
            alignment = TextAnchor.MiddleCenter,
            wordWrap = true
        };
        footerStyle.normal.textColor = new Color(1f, 0.92f, 0.62f, 1f);

        GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.31f,
            nodeRect.width - 14f, size * 0.21f), title, titleStyle);
        GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.52f,
            nodeRect.width - 14f, size * 0.17f), value, valueStyle);
        if (footer.StartsWith("コイン "))
        {
            Sprite coinSprite = GetCoinSprite();
            Texture2D coinTexture = coinSprite != null ? coinSprite.texture : null;
            float badgeWidth = Mathf.Clamp(size * 0.66f, 72f, 84f);
            const float badgeHeight = 26f;
            Rect costBadgeRect = new Rect(
                center.x - badgeWidth * 0.5f,
                nodeRect.y + size * 0.685f,
                badgeWidth,
                badgeHeight);
            GUI.color = new Color(0.015f, 0.025f, 0.04f, 0.9f);
            GUI.DrawTexture(costBadgeRect, Texture2D.whiteTexture);
            GUI.color = new Color(1f, 0.78f, 0.25f, 0.8f);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.y,
                costBadgeRect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.yMax - 2f,
                costBadgeRect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.y,
                2f, costBadgeRect.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.xMax - 2f, costBadgeRect.y,
                2f, costBadgeRect.height), Texture2D.whiteTexture);

            float coinIconSize = Mathf.Clamp(size * 0.18f, 18f, 23f);
            Rect coinIconRect = new Rect(
                costBadgeRect.x + 7f,
                costBadgeRect.y + (badgeHeight - coinIconSize) * 0.5f,
                coinIconSize,
                coinIconSize);
            if (coinTexture != null)
            {
                GUI.color = Color.white;
                GUI.DrawTexture(coinIconRect, coinTexture, ScaleMode.ScaleToFit,
                    true);
            }

            string costText = footer.Substring("コイン ".Length);
            GUIStyle costStyle = new GUIStyle(footerStyle)
            {
                fontSize = 15,
                alignment = TextAnchor.MiddleLeft,
                fontStyle = FontStyle.Bold
            };
            GUI.Label(new Rect(coinIconRect.xMax + 4f,
                costBadgeRect.y,
                costBadgeRect.width - coinIconSize - 16f,
                badgeHeight), $"×{costText}", costStyle);
        }
        else
        {
            GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.70f,
                nodeRect.width - 14f, size * 0.20f), footer, footerStyle);
        }
        GUI.color = previousColor;
    }

    private void DrawMapNode(Vector2 center, Color color, float size, int iconType)
    {
        Texture2D circle = GetMapCircleTexture();
        Color previousColor = GUI.color;
        GUI.color = new Color(0.02f, 0.05f, 0.1f, 0.95f);
        GUI.DrawTexture(new Rect(center.x - size * 0.5f - 6f,
            center.y - size * 0.5f - 6f, size + 12f, size + 12f), circle);
        GUI.color = color;
        GUI.DrawTexture(new Rect(center.x - size * 0.5f,
            center.y - size * 0.5f, size, size), circle);
        Texture2D icon = GetNodeIconTexture(iconType);
        if (icon != null)
        {
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(center.x - size * 0.5f + 10f,
                center.y - size * 0.5f + 10f, size - 20f, size - 20f),
                icon, ScaleMode.ScaleToFit);
        }
        GUI.color = previousColor;
    }

    private Texture2D GetNodeIconTexture(int iconType)
    {
        if (iconType == 0)
        {
            if (nodeBuildingTexture == null)
                nodeBuildingTexture = Resources.Load<Texture2D>("StageMap/NodeBuilding");
            return nodeBuildingTexture;
        }

        if (iconType == 1)
        {
            if (nodeNatureTexture == null)
                nodeNatureTexture = Resources.Load<Texture2D>("StageMap/NodeNature");
            return nodeNatureTexture;
        }

        if (nodeMonsterTexture == null)
            nodeMonsterTexture = Resources.Load<Texture2D>("StageMap/NodeMonster");
        return nodeMonsterTexture;
    }

    private Sprite GetNodeIconSprite(int iconType)
    {
        if (iconType == 0)
        {
            if (nodeBuildingSprite == null)
            {
                Texture2D texture = GetNodeIconTexture(0);
                if (texture != null)
                    nodeBuildingSprite = Sprite.Create(texture,
                        new Rect(0f, 0f, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f), 100f);
            }

            return nodeBuildingSprite;
        }

        if (iconType == 1)
        {
            if (nodeNatureSprite == null)
            {
                Texture2D texture = GetNodeIconTexture(1);
                if (texture != null)
                    nodeNatureSprite = Sprite.Create(texture,
                        new Rect(0f, 0f, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f), 100f);
            }

            return nodeNatureSprite;
        }

        if (nodeMonsterSprite == null)
        {
            Texture2D texture = GetNodeIconTexture(2);
            if (texture != null)
                nodeMonsterSprite = Sprite.Create(texture,
                    new Rect(0f, 0f, texture.width, texture.height),
                    new Vector2(0.5f, 0.5f), 100f);
        }

        return nodeMonsterSprite;
    }

    private Sprite GetStageIconSprite(StageDefinition stage, int fallbackIndex)
    {
        if (stageIconsTexture == null)
            stageIconsTexture = Resources.Load<Texture2D>("StageMap/StageIcons");

        if (stageIconsTexture != null)
        {
            const int columns = 5;
            const int rows = 2;
            int iconIndex = stage != null && stage.mapIconId >= 0
                ? stage.mapIconId
                : fallbackIndex;
            iconIndex = Mathf.Clamp(iconIndex, 0, columns * rows - 1);

            if (stageIconSprites.TryGetValue(iconIndex, out Sprite cached) &&
                cached != null)
                return cached;

            int column = iconIndex % columns;
            int row = iconIndex / columns;
            int left = Mathf.RoundToInt(column * stageIconsTexture.width /
                (float)columns);
            int right = Mathf.RoundToInt((column + 1) * stageIconsTexture.width /
                (float)columns);
            int bottom = Mathf.RoundToInt((rows - row - 1) * stageIconsTexture.height /
                (float)rows);
            int top = Mathf.RoundToInt((rows - row) * stageIconsTexture.height /
                (float)rows);
            Sprite sprite = Sprite.Create(stageIconsTexture,
                new Rect(left, bottom, right - left, top - bottom),
                new Vector2(0.5f, 0.5f), 100f);
            stageIconSprites[iconIndex] = sprite;
            return sprite;
        }

        return GetNodeIconSprite(fallbackIndex % 3);
    }

    private Sprite GetStageLandmarkSprite(int groupId)
    {
        int landmarkId = Mathf.Max(1, groupId);
        if (stageLandmarkSprites.TryGetValue(landmarkId, out Sprite cached) &&
            cached != null)
            return cached;

        string resourceName = landmarkId >= 2
            ? "StageMap/StageLandmark_Ruins"
            : "StageMap/StageLandmark_Grassland";
        Texture2D texture = Resources.Load<Texture2D>(resourceName);
        if (texture == null)
            return null;

        Sprite overview = Sprite.Create(texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f), 100f);
        stageLandmarkSprites[landmarkId] = overview;
        return overview;
    }

    private Sprite GetMapCircleSprite()
    {
        if (mapCircleSprite == null)
        {
            Texture2D texture = GetMapCircleTexture();
            mapCircleSprite = Sprite.Create(texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f);
        }

        return mapCircleSprite;
    }

    private Texture2D GetMapCircleTexture()
    {
        if (mapCircleTexture != null) return mapCircleTexture;

        mapCircleTexture = new Texture2D(64, 64, TextureFormat.RGBA32, false);
        mapCircleTexture.hideFlags = HideFlags.HideAndDontSave;
        for (int y = 0; y < 64; y++)
        {
            for (int x = 0; x < 64; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f));
                mapCircleTexture.SetPixel(x, y,
                    distance <= 31.5f ? Color.white : Color.clear);
            }
        }
        mapCircleTexture.Apply();
        return mapCircleTexture;
    }

    private void DrawBattleHud()
    {
        GUIStyle hud = new GUIStyle(GUI.skin.label)
        {
            fontSize = 30,
            alignment = TextAnchor.UpperLeft
        };
        hud.normal.textColor = Color.white;

        const float coinPanelWidth = 220f;

        DrawHudPanel(new Rect(12f, 10f, coinPanelWidth, 64f));
        DrawExperienceBar();
        DrawWeaponSkillHud();

        DrawCoinCounter(new Rect(20f, 16f, coinPanelWidth - 30f, 48f), hud);
        DrawCharacterHealthBars();

        DrawMonsterHealthBars();
        DrawStageOneTutorial();
        if (battlePaused)
            DrawBattlePauseOverlay();
    }

    private void DrawWeaponSkillHud()
    {
        if (hero == null) return;

        PlayerSwordAttack swordAttack = hero.GetComponent<PlayerSwordAttack>();
        if (swordAttack == null) return;

        int requirement = Mathf.Max(1, swordAttack.WeaponSkillAttackRequirement);
        if (!EquipmentSystem.HasWeaponSkill())
            return;

        int count = Mathf.Clamp(swordAttack.WeaponSkillAttackCount,
            0, requirement);
        float panelWidth = Mathf.Min(258f, Screen.width - 260f);
        if (panelWidth < 180f) return;

        Rect panel = new Rect(Screen.width - panelWidth - 12f, 12f,
            panelWidth, 64f);
        DrawHudPanel(panel);

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            clipping = TextClipping.Clip
        };
        title.normal.textColor = new Color(1f, 0.88f, 0.48f);
        GUI.Label(new Rect(panel.x + 8f, panel.y + 4f,
            panel.width - 16f, 20f),
            $"武器スキル　{swordAttack.WeaponSkillName}", title);

        DrawBar(new Rect(panel.x + 12f, panel.y + 29f,
            panel.width - 24f, 14f), (float)count / requirement,
            swordAttack.IsWeaponSkillReady
                ? new Color(1f, 0.72f, 0.2f)
                : new Color(0.32f, 0.78f, 1f));

        GUIStyle status = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        status.normal.textColor = swordAttack.IsWeaponSkillReady
            ? new Color(1f, 0.94f, 0.48f)
            : Color.white;
        GUI.Label(new Rect(panel.x + 8f, panel.y + 44f,
            panel.width - 16f, 18f),
            swordAttack.IsWeaponSkillReady
                ? "READY　次のスペースで発動"
                : $"あと {requirement - count} 回", status);
    }

    private void DrawBattlePauseOverlay()
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.45f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height),
            Texture2D.whiteTexture, ScaleMode.StretchToFill, true);

        float panelWidth = Mathf.Min(620f, Screen.width - 40f);
        const float panelHeight = 276f;
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            (Screen.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
        DrawHudPanel(panel);

        GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 38,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter
        };
        titleStyle.normal.textColor = Color.white;
        GUI.color = Color.white;
        GUI.Label(new Rect(panel.x, panel.y + 24f, panel.width, 52f),
            "ポーズ", titleStyle);

        GUIStyle buttonStyle = CreateHoverButtonStyle(24, FontStyle.Bold);
        float buttonWidth = Mathf.Min(430f, panel.width - 70f);
        float buttonX = panel.x + (panel.width - buttonWidth) * 0.5f;
        if (GUI.Button(new Rect(buttonX, panel.y + 104f, buttonWidth, 58f),
            "続ける", buttonStyle))
            ResumeBattleTime();

        if (GUI.Button(new Rect(buttonX, panel.y + 178f, buttonWidth, 58f),
            "ステージ選択へ戻る", buttonStyle))
            ReturnToMenu();

        GUI.color = previousColor;
    }

    private void DrawStageOneTutorial()
    {
        if (!stageOneTutorialActive) return;

        float panelWidth = Mathf.Min(760f, Screen.width - 32f);
        const float panelHeight = 112f;
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            Screen.height - panelHeight - 22f,
            panelWidth,
            panelHeight);

        Color previousColor = GUI.color;
        GUI.color = new Color(0.015f, 0.035f, 0.06f, 0.9f);
        GUI.DrawTexture(panel, Texture2D.whiteTexture);
        GUI.color = new Color(0.96f, 0.78f, 0.25f, 0.95f);
        GUI.DrawTexture(new Rect(panel.x, panel.y, panel.width, 5f),
            Texture2D.whiteTexture);
        GUI.color = previousColor;

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 20,
            alignment = TextAnchor.MiddleLeft,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = new Color(1f, 0.88f, 0.48f);

        GUIStyle message = new GUIStyle(GUI.skin.label)
        {
            fontSize = 22,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            wordWrap = true
        };
        message.normal.textColor = Color.white;

        string stepLabel;
        string instruction;
        switch (stageOneTutorialStep)
        {
            case 0:
                stepLabel = "チュートリアル　1 / 5";
                instruction = "WASD または矢印キーでヒーローを動かそう";
                break;
            case 1:
                stepLabel = "チュートリアル　2 / 5";
                instruction = "敵に近づいて、スペースキーで斬撃を飛ばそう";
                break;
            case 2:
                stepLabel = "チュートリアル　3 / 5";
                instruction = "敵を倒すと経験値オーブが落ちる。近づいて拾おう";
                break;
            case 3:
                stepLabel = "チュートリアル　4 / 5";
                instruction = $"経験値を {WitchSkillExperienceCost} まで集めると、Eキーで魔女スキルを使える";
                break;
            case 4:
                stepLabel = "チュートリアル　5 / 5";
                instruction = "Eキーで画面内の敵を攻撃！残りを倒してクリアしよう";
                break;
            default:
                stepLabel = "チュートリアル完了";
                instruction = "あとは残りの敵をすべて倒せばステージクリア！";
                break;
        }

        GUI.Label(new Rect(panel.x + 18f, panel.y + 10f,
            panel.width - 36f, 28f), stepLabel, title);
        GUI.Label(new Rect(panel.x + 22f, panel.y + 42f,
            panel.width - 44f, 54f), instruction, message);
    }

    private void DrawExperienceBar()
    {
        float panelWidth = Mathf.Min(620f, Screen.width - 260f);
        const float panelHeight = 140f;
        float panelX = (Screen.width - panelWidth) * 0.5f;

        DrawHudPanel(new Rect(panelX, 12f, panelWidth, panelHeight));

        GUIStyle experienceStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 36,
            alignment = TextAnchor.UpperCenter,
            fontStyle = FontStyle.Bold
        };
        experienceStyle.normal.textColor = Color.white;
        GUI.Label(new Rect(panelX, 14f, panelWidth, 44f),
            $"経験値  {experience} / {ExperienceToNextLevel}", experienceStyle);
        DrawBar(new Rect(panelX + 14f, 62f, panelWidth - 28f, 30f),
            (float)experience / ExperienceToNextLevel,
            new Color(0.25f, 0.85f, 1f));

        GUIStyle skillStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            alignment = TextAnchor.UpperCenter,
            fontStyle = FontStyle.Bold
        };
        skillStyle.normal.textColor = experience >= WitchSkillExperienceCost
            ? new Color(0.65f, 0.95f, 1f)
            : new Color(0.72f, 0.72f, 0.72f);
        GUI.Label(new Rect(panelX, 100f, panelWidth, 32f),
            $"E  魔女スキル  ({WitchSkillExperienceCost}経験値)", skillStyle);
    }

    private void DrawHudPanel(Rect rect)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.32f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawCharacterHealthBars()
    {
        Camera gameCamera = Camera.main;
        if (gameCamera == null) return;

        if (witch != null)
        {
            DrawCharacterHealthBar(gameCamera, witch.transform, "魔女",
                witch.Health, witch.MaxHealth,
                new Color(0.95f, 0.28f, 0.35f), WitchHealthBarWorldYOffset);
        }

        if (hero != null)
        {
            DrawCharacterHealthBar(gameCamera, hero.transform, "ヒーロー",
                hero.Health, hero.MaxHealth,
                new Color(0.25f, 0.75f, 1f), HeroHealthBarWorldYOffset);
        }
    }

    private void DrawCharacterHealthBar(Camera gameCamera, Transform character,
        string label, int health, int maxHealth, Color fillColor,
        float worldYOffset)
    {
        if (character == null) return;

        Vector3 worldPosition = new Vector3(
            character.position.x,
            character.position.y + worldYOffset,
            character.position.z);
        Vector3 screenPosition = gameCamera.WorldToScreenPoint(worldPosition);
        if (screenPosition.z <= 0f) return;

        const float barWidth = 180f;
        const float barHeight = 20f;
        const float panelHeight = 32f;
        float x = Mathf.Clamp(screenPosition.x - barWidth * 0.5f,
            8f, Screen.width - barWidth - 8f);
        float y = Screen.height - screenPosition.y - panelHeight;
        if (y + panelHeight < 0f || y > Screen.height) return;

        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.76f);
        GUI.DrawTexture(new Rect(x - 6f, y, barWidth + 12f, panelHeight),
            Texture2D.whiteTexture);
        GUI.color = previousColor;

        // Keep the bars above the characters without adding a text label.
        // The color and position identify the owner while preserving the
        // play-field visibility requested for the battle HUD.
        DrawBar(new Rect(x, y + 6f, barWidth, barHeight),
            (float)health / Mathf.Max(1, maxHealth), fillColor);
    }

    private void DrawBar(Rect rect, float ratio, Color fillColor)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.8f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);

        ratio = Mathf.Clamp01(ratio);
        if (ratio > 0f)
        {
            GUI.color = fillColor;
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width * ratio, rect.height),
                Texture2D.whiteTexture);
        }

        GUI.color = previousColor;
    }

    private void DrawMonsterHealthBars()
    {
        Camera gameCamera = Camera.main;
        if (gameCamera == null) return;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (monster == null || monster.IsDead) continue;

            // スプライトのフレームごとの大きさに影響されない固定位置に表示する。
            Vector3 worldBarPosition = monster.transform.position +
                Vector3.up * MonsterHealthBarYOffset;
            Vector3 screenPosition = gameCamera.WorldToScreenPoint(worldBarPosition);
            if (screenPosition.z <= 0f) continue;

            const float barWidth = 64f;
            const float barHeight = 9f;
            if (screenPosition.x < -barWidth || screenPosition.x > Screen.width + barWidth ||
                screenPosition.y < -20f || screenPosition.y > Screen.height + 20f)
                continue;

            float x = screenPosition.x - barWidth * 0.5f;
            float y = Screen.height - screenPosition.y - barHeight;
            if (x + barWidth < 0f || x > Screen.width ||
                y + barHeight < 0f || y > Screen.height)
                continue;

            DrawBar(new Rect(x, y, barWidth, barHeight), monster.HealthRatio,
                new Color(0.95f, 0.8f, 0.18f));
        }
    }

    private void DrawResult(Rect panel)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.58f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height),
            Texture2D.whiteTexture);
        GUI.color = new Color(0.04f, 0.11f, 0.16f, 0.98f);
        GUI.DrawTexture(panel, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.9f);
        GUI.DrawTexture(new Rect(panel.x + 14f, panel.y + 14f,
            panel.width - 28f, 5f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panel.x + 14f, panel.yMax - 19f,
            panel.width - 28f, 5f), Texture2D.whiteTexture);
        GUI.color = previousColor;

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 48,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle text = new GUIStyle(GUI.skin.label)
        {
            fontSize = 25,
            alignment = TextAnchor.MiddleCenter
        };

        GUI.Label(new Rect(panel.x + 20f, panel.y + 36f, panel.width - 40f, 72f),
            won ? "勝利!" : "敗北...", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 112f, panel.width - 40f, 48f),
            won ? "モンスターをすべて倒しました" : GetDefeatMessage(), text);
        DrawCoinCounter(new Rect(panel.x + panel.width * 0.5f - 120f,
            panel.y + 168f, 240f, 44f), text);

        float buttonWidth = panel.width - 100f;
        float buttonX = panel.x + 35f;
        const float resultButtonHeight = 74f;
        const float resultButtonGap = 84f;
        GUIStyle resultButtonStyle = CreateHoverButtonStyle(24, FontStyle.Bold);
        float buttonY = 220f;
        int nextStageId;
        if (TryGetNextStageId(out nextStageId))
        {
            if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
                "次のステージへ", resultButtonStyle))
                OpenNextStageInfo();
            buttonY += resultButtonGap;
        }

        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "強化画面", resultButtonStyle))
            OpenUpgradeMenu();
        buttonY += resultButtonGap;
        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "もう一度プレイ", resultButtonStyle))
        {
            PlayConfirmSound();
            StartStage(selectedStage);
        }
        buttonY += resultButtonGap;
        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "ステージ選択へ", resultButtonStyle))
            ReturnToMenu();
    }

    private void DrawUpgrade(Rect panel)
    {
        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 32,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle text = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };

        GUI.Label(new Rect(panel.x + 20f, panel.y + 20f, panel.width - 40f, 46f),
            "強化", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 67f, panel.width - 40f, 28f),
            "集めたコインで魔女とヒーローを強化できます", text);
        DrawCoinCounter(new Rect(panel.x + panel.width - 205f,
            panel.y + 24f, 180f, 32f), text);

        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 12,
            alignment = TextAnchor.MiddleCenter
        };
        hint.normal.textColor = new Color(0.72f, 0.82f, 0.88f);
        GUIStyle legend = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        legend.normal.textColor = new Color(0.93f, 0.9f, 0.72f, 1f);
        GUI.Label(new Rect(panel.x + 30f, panel.y + 99f, panel.width - 60f, 24f),
            "剣 斬撃攻撃力　／　体 ヒーロー体力　／　魔 魔女体力　／　速 歩く速度　／　貫 斬撃貫通　／　連 攻撃速度　／　押 ノックバック",
            legend);
        int slashDamageBonus = GetUpgradeLevel(SlashDamageLevelKey);
        int heroHealthBonus = GetUpgradeLevel(HeroHealthLevelKey) * HealthUpgradeAmount;
        int witchHealthBonus = GetUpgradeLevel(WitchHealthLevelKey) * HealthUpgradeAmount;
        float heroSpeedBonus = GetUpgradeLevel(HeroSpeedLevelKey) * SpeedUpgradeAmount;
        int slashPierceBonus = GetUpgradeLevel(SlashPierceLevelKey);
        float attackIntervalReduction =
            GetUpgradeLevel(AttackSpeedLevelKey) * AttackSpeedUpgradeAmount;
        float knockbackMultiplier = GetMonsterKnockbackUpgradeMultiplier();
        GUIStyle totalStatus = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        totalStatus.normal.textColor = new Color(1f, 0.93f, 0.72f, 1f);
        GUI.Label(new Rect(panel.x + 30f, panel.y + 119f, panel.width - 60f, 22f),
            $"解放合計　斬撃 +{slashDamageBonus}　ヒーローHP +{heroHealthBonus}　魔女HP +{witchHealthBonus}　速度 +{heroSpeedBonus:0.0}　貫通 +{slashPierceBonus}　攻撃間隔 -{attackIntervalReduction:0.00}秒　押し出し x{knockbackMultiplier:0.00}",
            totalStatus);
        Rect viewport = GetSkillTreeViewport(panel);
        DrawSkillTreeViewportSurface(viewport);
        // Keep the transparent Canvas hit rectangles in the same coordinate
        // system and size as the visible IMGUI nodes. This also repairs their
        // position after a Game view resize before the next pointer event.
        ConfigureSkillTreePanOverlayGeometry();
        UpdateSkillTreeEventInput(Event.current, viewport);
        UpdateSkillTreePanNodeButtons();

        Rect navigationBar = new Rect(panel.x + 28f, panel.y + 575f,
            285f, 95f);
        Color previousGuiColor = GUI.color;
        GUI.color = new Color(0.012f, 0.03f, 0.05f, 0.94f);
        GUI.DrawTexture(navigationBar, Texture2D.whiteTexture);
        GUI.color = previousGuiColor;

        float buttonWidth = 251f;
        float buttonX = panel.x + 45f;
        GUIStyle navigationStyle = CreateHoverButtonStyle(18, FontStyle.Bold);
        if (GUI.Button(new Rect(buttonX, panel.y + 590f, buttonWidth, 44f),
            "ステージ選択へ", navigationStyle))
            ReturnToMenu();

        GUIStyle resetStyle = CreateHoverButtonStyle(14);
        resetStyle.normal.textColor = resetProgressConfirm
            ? new Color(1f, 0.55f, 0.45f)
            : new Color(0.82f, 0.86f, 0.9f);
        string resetLabel = resetProgressConfirm
            ? "本当にリセットする（もう一度押す）"
            : "コイン・強化をリセット";
        if (GUI.Button(new Rect(buttonX, panel.y + 640f, buttonWidth, 25f),
            resetLabel, resetStyle))
        {
            if (resetProgressConfirm)
                ResetSavedProgress();
            else
                RequestProgressReset();
        }

        // Keep the tree inside its own clipped viewport. Dragging can still
        // move the content, but nodes can never paint over the header, coin
        // counter, or the navigation buttons outside this rectangle.
        GUI.BeginGroup(viewport);
        Vector2 treeCenter = new Vector2(
            viewport.width * 0.5f, viewport.height * 0.5f) +
            SkillTreeCenterOffset + skillTreePan;
        Vector2 rootPosition = treeCenter + SkillTreeRootOffset;
        int nodeCount = GetSkillNodeCount();
        Vector2[] nodePositions = new Vector2[nodeCount];
        for (int i = 0; i < nodeCount; i++)
        {
            nodePositions[i] = GetSkillTreeNodePosition(treeCenter, i);
        }

        for (int i = 0; i < nodeCount; i++)
        {
            if (!IsSkillNodeVisible(i))
                continue;

            int prerequisite = GetSkillNodePrerequisite(i);
            // Entry nodes branch from the small origin node above the grid;
            // later nodes connect only to their immediate predecessor below.
            Vector2 lineStart = prerequisite >= 0
                ? nodePositions[prerequisite]
                : rootPosition;
            string upgradeKey = SkillUpgradeKeys[GetSkillBranchIndex(i)];
            int levelIndex = GetSkillLevelIndex(i);
            bool purchased = IsSkillNodePurchased(i);
            bool unlocked = IsSkillNodeUnlocked(i);
            bool affordable = coins >= GetUpgradeCostForLevel(upgradeKey, levelIndex);
            Color lineColor = purchased
                ? new Color(0.42f, 0.75f, 0.34f, 0.95f)
                : unlocked && affordable
                    ? new Color(0.95f, 0.72f, 0.22f, 0.95f)
                    : new Color(0.38f, 0.43f, 0.48f, 0.9f);
            DrawSkillTreeLine(lineStart, nodePositions[i], lineColor, 4f);
        }

        DrawSkillTreeNode(rootPosition, 82f,
            new Color(0.35f, 0.23f, 0.12f, 1f),
            new Color(1f, 0.78f, 0.24f, 1f),
            "起", "原点", "START", "ここから分岐");

        int hoveredSkillNodeIndex = GetHoveredSkillTreeNodeIndex(nodePositions,
            viewport.position, viewport);
        for (int i = 0; i < nodePositions.Length; i++)
        {
            if (!IsSkillNodeVisible(i))
                continue;

            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            string upgradeKey = SkillUpgradeKeys[branchIndex];
            bool purchased = IsSkillNodePurchased(i);
            bool unlocked = IsSkillNodeUnlocked(i);
            int cost = GetUpgradeCostForLevel(upgradeKey, levelIndex);
            bool canBuy = unlocked && !purchased && coins >= cost;
            float nodeHalfSize = SkillTreeNodeSize * 0.5f;
            Rect nodeRect = new Rect(nodePositions[i].x - nodeHalfSize,
                nodePositions[i].y - nodeHalfSize,
                SkillTreeNodeSize, SkillTreeNodeSize);
            bool hovered = i == hoveredSkillNodeIndex;
            Color nodeColor = purchased
                ? new Color(0.38f, 0.52f, 0.24f, 1f)
                : unlocked
                    ? new Color(0.16f, 0.48f, 0.62f, 1f)
                    : new Color(0.20f, 0.24f, 0.28f, 1f);
            if (hovered)
                nodeColor = Color.Lerp(nodeColor, new Color(1f, 0.84f, 0.36f), 0.42f);

            string nodeStatus = purchased
                ? "取得済み"
                : unlocked
                    ? $"コイン {cost}"
                    : branchIndex == 5
                        ? $"{AttackSpeedUnlockRequiredNodes}個で解放"
                        : branchIndex == 6
                            ? $"{MonsterKnockbackUnlockRequiredNodes}個で解放"
                        : "ロック";
            DrawSkillTreeNode(nodePositions[i], SkillTreeNodeSize, nodeColor,
                GetSkillBranchAccent(branchIndex),
                GetSkillBranchIcon(branchIndex),
                SkillUpgradeNames[branchIndex],
                GetSkillEffectText(branchIndex),
                nodeStatus);

            GUI.enabled = canBuy && !skillTreeSuppressNodeClick;
            if (GUI.Button(nodeRect, GUIContent.none, GUIStyle.none))
            {
                TryBuySkillNode(i);
                RequestEditorRepaint();
            }
            GUI.enabled = true;
        }
        GUI.EndGroup();
        DrawSkillTreeViewportFrame(viewport);
        // Keep the operation hint outside the header/status rows and outside
        // the tree viewport so it cannot overlap the cumulative status text.
        GUI.Label(new Rect(panel.x + 330f, panel.y + 590f,
                panel.width - 370f, 40f),
            "強化ノードを選択　／　ドラッグ・ホイール・WASDでツリーを移動", hint);
    }

    private void DrawEquipment(Rect panel)
    {
        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 34,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;

        GUIStyle subtitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };
        subtitle.normal.textColor = new Color(0.76f, 0.86f, 0.9f);

        GUI.Label(new Rect(panel.x + 20f, panel.y + 20f, panel.width - 40f, 48f),
            "装備", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 67f, panel.width - 40f, 28f),
            "武器・防具・ペットを勇者に装着できます", subtitle);
        DrawEquipmentPieceCounter(new Rect(panel.x + panel.width - 205f,
            panel.y + 24f, 180f, 32f), subtitle,
            (EquipmentSystem.Slot)equipmentFocusSlot);

        Sprite pieceSprite = GetEquipmentPieceSprite(
            (EquipmentSystem.Slot)equipmentFocusSlot);
        EquipmentSystem.Slot[] slots =
        {
            EquipmentSystem.Slot.Weapon,
            EquipmentSystem.Slot.Armor,
            EquipmentSystem.Slot.Boots,
            EquipmentSystem.Slot.Pet
        };

        GUIStyle sectionTitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft
        };
        sectionTitle.normal.textColor = new Color(0.78f, 0.88f, 0.9f);
        GUI.Label(new Rect(panel.x + 36f, panel.y + 100f, 220f, 24f),
            "現在の装備", sectionTitle);

        const float tabHeight = 86f;
        const float tabGap = 10f;
        for (int row = 0; row < slots.Length; row++)
        {
            EquipmentSystem.Slot slot = slots[row];
            float rowY = panel.y + 126f + row * (tabHeight + tabGap);
            bool focusedRow = row == equipmentFocusSlot;
            Color rowColor = focusedRow
                ? new Color(0.12f, 0.3f, 0.38f, 0.98f)
                : new Color(0.025f, 0.07f, 0.1f, 0.95f);
            Rect tabRect = new Rect(panel.x + 30f, rowY, 230f, tabHeight);
            GUI.color = rowColor;
            GUI.DrawTexture(tabRect, Texture2D.whiteTexture);
            GUI.color = GetEquipmentSlotAccent(slot);
            GUI.DrawTexture(new Rect(tabRect.x, tabRect.y, 6f, tabRect.height),
                Texture2D.whiteTexture);
            GUI.color = Color.white;

            GUIStyle slotTitle = new GUIStyle(GUI.skin.label)
            {
                fontSize = 20,
                alignment = TextAnchor.MiddleLeft,
                fontStyle = FontStyle.Bold
            };
            slotTitle.normal.textColor = GetEquipmentSlotAccent(slot);
            GUI.Label(new Rect(tabRect.x + 18f, rowY + 12f, 132f, 28f),
                EquipmentSystem.GetSlotName(slot), slotTitle);

            int equippedId = EquipmentSystem.GetEquipped(slot);
            EquipmentSystem.Item equippedItem = EquipmentSystem.GetItem(slot, equippedId);
            GUIStyle equippedText = new GUIStyle(GUI.skin.label)
            {
                fontSize = 13,
                alignment = TextAnchor.MiddleLeft,
                wordWrap = true
            };
            equippedText.normal.textColor = equippedId >= 0
                ? new Color(0.65f, 1f, 0.72f)
                : new Color(0.58f, 0.64f, 0.68f);
            GUI.Label(new Rect(tabRect.x + 18f, rowY + 43f, 136f, 32f),
                equippedId >= 0 ? $"装備中\n{equippedItem.name}" : "未装備",
                equippedText);

            // Show the actual equipped item in each slot so the current loadout
            // can be understood at a glance without opening the item list.
            Rect equippedIconRect = new Rect(tabRect.xMax - 62f, rowY + 16f,
                48f, 48f);
            GUI.color = new Color(0.01f, 0.04f, 0.06f, 0.9f);
            GUI.DrawTexture(equippedIconRect, Texture2D.whiteTexture);
            GUI.color = GetEquipmentSlotAccent(slot);
            GUI.DrawTexture(new Rect(equippedIconRect.x, equippedIconRect.y,
                2f, equippedIconRect.height), Texture2D.whiteTexture);
            GUI.color = Color.white;
            if (equippedId >= 0)
            {
                Texture2D equippedIcons = GetEquipmentIconTexture(equippedItem);
                if (equippedIcons != null)
                    DrawEquipmentIcon(equippedIconRect, equippedItem.iconCell,
                        equippedIcons);
            }

            if (GUI.Button(tabRect, GUIContent.none, GUIStyle.none))
            {
                equipmentFocusSlot = row;
                equipmentFocusItem = 0;
                equipmentListOpen = true;
                equipmentListScroll = Vector2.zero;
                RequestEditorRepaint();
            }
        }

        Rect listPanel = new Rect(panel.x + 282f, panel.y + 112f,
            panel.width - 312f, 456f);
        GUI.color = new Color(0.025f, 0.07f, 0.1f, 0.97f);
        GUI.DrawTexture(listPanel, Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle listHint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            alignment = TextAnchor.MiddleLeft
        };
        listHint.normal.textColor = new Color(0.68f, 0.78f, 0.81f);

        if (!equipmentListOpen)
        {
            GUI.Label(new Rect(listPanel.x + 24f, listPanel.y + 30f,
                listPanel.width - 48f, 40f),
                "左の装備枠を選ぶと、その枠の所持品が表示されます", listHint);
            GUI.Label(new Rect(listPanel.x + 24f, listPanel.y + 80f,
                listPanel.width - 48f, 32f),
                "Enter / Space で所持品一覧を開く", listHint);
        }
        else
        {
            EquipmentSystem.Slot focusedSlot =
                (EquipmentSystem.Slot)equipmentFocusSlot;
            EquipmentSystem.Item[] ownedItems = EquipmentSystem.GetOwnedItems(focusedSlot);
            GUI.Label(new Rect(listPanel.x + 24f, listPanel.y + 24f,
                listPanel.width - 48f, 24f),
                "持っている装備から1つを選択", listHint);
            if (ownedItems.Length == 0)
            {
                GUI.Label(new Rect(listPanel.x + 24f, listPanel.y + 70f,
                    listPanel.width - 48f, 32f),
                    "この枠の所持品はありません", listHint);
            }
            else
            {
                const int columns = 2;
                const float cardGap = 14f;
                const float cardHeight = 154f;
                const float cardRowGap = 12f;
                Rect listViewport = new Rect(listPanel.x + 14f,
                    listPanel.y + 54f, listPanel.width - 28f,
                    listPanel.height - 64f);
                float contentWidth = Mathf.Max(0f, listViewport.width - 18f);
                float cardWidth = (contentWidth - cardGap) / columns;
                int rowCount = Mathf.CeilToInt(ownedItems.Length / (float)columns);
                float contentHeight = Mathf.Max(listViewport.height,
                    rowCount * (cardHeight + cardRowGap));
                bool needsVerticalScroll = rowCount * (cardHeight + cardRowGap) >
                    listViewport.height + 0.5f;
                equipmentListScroll = GUI.BeginScrollView(listViewport,
                    equipmentListScroll,
                    new Rect(0f, 0f, contentWidth, contentHeight),
                    false, needsVerticalScroll);
                for (int i = 0; i < ownedItems.Length; i++)
                {
                    EquipmentSystem.Item item = ownedItems[i];
                    int column = i % columns;
                    int itemRow = i / columns;
                    Rect cardRect = new Rect(
                        column * (cardWidth + cardGap),
                        itemRow * (cardHeight + cardRowGap),
                        cardWidth, cardHeight);
                    bool isEquipped = EquipmentSystem.IsEquipped(focusedSlot, item.id);
                    bool isFocused = equipmentFocusItem == i;
                    int itemLevel = EquipmentSystem.GetItemLevel(focusedSlot, item.id);
                    int pieceCount = EquipmentSystem.GetPieceCount(focusedSlot);
                    int upgradeCost = EquipmentSystem.GetUpgradePieceCost(
                        focusedSlot, item.id);
                    bool canUpgrade = itemLevel > 0 && upgradeCost > 0 &&
                        pieceCount >= upgradeCost;

                    GUI.color = isEquipped
                        ? new Color(0.16f, 0.36f, 0.24f, 1f)
                        : isFocused
                            ? new Color(0.14f, 0.28f, 0.36f, 1f)
                            : new Color(0.07f, 0.15f, 0.2f, 1f);
                    GUI.DrawTexture(cardRect, Texture2D.whiteTexture);
                    GUI.color = isEquipped
                        ? new Color(0.55f, 0.95f, 0.52f)
                        : item.accent;
                    GUI.DrawTexture(new Rect(cardRect.x, cardRect.y,
                        cardRect.width, 4f), Texture2D.whiteTexture);
                    GUI.color = Color.white;

                    Texture2D itemIcons = GetEquipmentIconTexture(item);
                    if (itemIcons != null)
                        DrawEquipmentIcon(new Rect(cardRect.x + 12f, cardRect.y + 18f,
                            92f, 92f), item.iconCell, itemIcons);

                    GUIStyle itemName = new GUIStyle(GUI.skin.label)
                    {
                        fontSize = 18,
                        alignment = TextAnchor.MiddleLeft,
                        fontStyle = FontStyle.Bold
                    };
                    itemName.normal.textColor = Color.white;
                    GUI.Label(new Rect(cardRect.x + 116f, cardRect.y + 18f,
                        cardRect.width - 130f, 30f), item.name, itemName);

                    GUIStyle itemRarity = new GUIStyle(GUI.skin.label)
                    {
                        fontSize = 16,
                        alignment = TextAnchor.MiddleLeft,
                        fontStyle = FontStyle.Bold
                    };
                    itemRarity.normal.textColor = item.accent;
                    GUI.Label(new Rect(cardRect.x + 116f, cardRect.y + 44f,
                        cardRect.width - 130f, 24f),
                        $"{EquipmentSystem.GetRarityStars(item.rarity)}  Lv.{itemLevel}",
                        itemRarity);

                    GUIStyle itemInfo = new GUIStyle(GUI.skin.label)
                    {
                        fontSize = 14,
                        alignment = TextAnchor.UpperLeft,
                        wordWrap = true
                    };
                    itemInfo.normal.textColor = new Color(0.82f, 0.9f, 0.91f);
                    GUI.Label(new Rect(cardRect.x + 116f, cardRect.y + 70f,
                        cardRect.width - 130f, 34f),
                        EquipmentSystem.GetItemEffectText(focusedSlot, item.id), itemInfo);

                    GUIStyle equipHint = new GUIStyle(GUI.skin.label)
                    {
                        fontSize = 10,
                        alignment = TextAnchor.MiddleLeft
                    };
                    equipHint.normal.textColor = isEquipped
                        ? new Color(0.65f, 1f, 0.72f)
                        : new Color(0.72f, 0.82f, 0.86f);
                    GUI.Label(new Rect(cardRect.x + 12f, cardRect.y + 122f,
                        92f, 18f),
                        isEquipped ? "装備中" : "クリックで装備", equipHint);

                    const float upgradeHeight = 40f;
                    const float upgradeBottom = 4f;
                    Rect upgradeRect = new Rect(cardRect.x + 106f,
                        cardRect.y + cardRect.height - upgradeHeight - upgradeBottom,
                        cardRect.width - 118f, upgradeHeight);
                    GUIStyle upgradeStyle = CreateHoverButtonStyle(13,
                        FontStyle.Bold);
                    upgradeStyle.alignment = TextAnchor.MiddleLeft;
                    upgradeStyle.padding = new RectOffset(16, 8, 0, 0);
                    upgradeStyle.normal.textColor = Color.white;
                    upgradeStyle.hover.textColor = Color.white;
                    upgradeStyle.active.textColor = Color.white;
                    upgradeStyle.focused.textColor = Color.white;
                    string upgradeLabel = itemLevel >= EquipmentSystem.MaxItemLevel
                        ? "MAX"
                        : "強化";
                    if (GUI.Button(upgradeRect, upgradeLabel, upgradeStyle))
                    {
                        equipmentFocusItem = i;
                        if (canUpgrade)
                            UpgradeEquipment(focusedSlot, item.id);
                    }

                    if (itemLevel < EquipmentSystem.MaxItemLevel)
                    {
                        Rect costBadge = new Rect(
                            upgradeRect.x + upgradeRect.width * 0.34f,
                            upgradeRect.y + 3f,
                            upgradeRect.width * 0.62f,
                            upgradeRect.height - 6f);
                        GUI.color = new Color(0.015f, 0.055f, 0.075f, 0.78f);
                        GUI.DrawTexture(costBadge, Texture2D.whiteTexture);
                        GUI.color = Color.white;

                        if (pieceSprite != null && pieceSprite.texture != null)
                        {
                            GUI.DrawTexture(new Rect(costBadge.x + 4f,
                                costBadge.y, 34f, 34f),
                                pieceSprite.texture, ScaleMode.ScaleToFit, true);
                        }

                        GUIStyle costStyle = new GUIStyle(GUI.skin.label)
                        {
                            fontSize = 11,
                            alignment = TextAnchor.MiddleLeft,
                            fontStyle = FontStyle.Bold
                        };
                        costStyle.normal.textColor = new Color(1f, 0.88f, 0.52f);
                        GUI.Label(new Rect(costBadge.x + 36f, costBadge.y,
                            costBadge.width - 40f, costBadge.height),
                            $"費用：{EquipmentSystem.GetPieceName(focusedSlot)} ×{upgradeCost}",
                            costStyle);
                    }

                    // The enlarged upgrade button is its own hitbox. Keep the
                    // rest of the visible card available for equipment select.
                    Rect equipTopRect = new Rect(cardRect.x, cardRect.y,
                        cardRect.width, cardRect.height - upgradeHeight - upgradeBottom);
                    Rect equipBottomRect = new Rect(cardRect.x, upgradeRect.y,
                        100f, upgradeHeight);
                    if (GUI.Button(equipTopRect, GUIContent.none, GUIStyle.none) ||
                        GUI.Button(equipBottomRect, GUIContent.none, GUIStyle.none))
                    {
                        equipmentFocusItem = i;
                        EquipItem(focusedSlot, item.id);
                    }
                }
                GUI.EndScrollView();
            }
        }

        GUIStyle footer = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleCenter
        };
        footer.normal.textColor = new Color(0.72f, 0.82f, 0.86f);
        GUI.Label(new Rect(panel.x + 285f, panel.y + 580f,
            panel.width - 520f, 24f),
            equipmentListOpen
                ? "左右 / A・Dで選択　クリックで装備　強化ボタン / Uで強化"
                : "上下 / W・Sで装備枠を選択　ENTERで所持品一覧　ESCでステージ選択へ",
            footer);

        GUIStyle backStyle = CreateHoverButtonStyle(18, FontStyle.Bold);
        if (GUI.Button(new Rect(panel.x + 30f, panel.y + 600f, 230f, 48f),
            "ステージ選択へ", backStyle))
            ReturnToMenu();
    }

    private bool DrawGachaTypeTab(Rect rect, string label, bool selected,
        Sprite icon, Color accent)
    {
        bool hovered = IsGuiRectHovered(rect);
        Color background = selected
            ? new Color(0.12f, 0.3f, 0.38f, 0.98f)
            : new Color(0.025f, 0.07f, 0.1f, 0.95f);
        if (hovered)
            background = Color.Lerp(background,
                new Color(0.25f, 0.55f, 0.68f, 1f), 0.62f);

        GUI.color = background;
        GUI.DrawTexture(rect, Texture2D.whiteTexture);
        GUI.color = accent;
        GUI.DrawTexture(new Rect(rect.x, rect.y, 6f, rect.height),
            Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle labelStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 17,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft
        };
        labelStyle.normal.textColor = selected
            ? Color.white
            : new Color(0.78f, 0.88f, 0.9f, 1f);
        GUI.Label(new Rect(rect.x + 18f, rect.y + 3f,
            rect.width - 72f, rect.height - 6f), label, labelStyle);

        Rect iconRect = new Rect(rect.xMax - 54f, rect.y + 9f, 42f, 42f);
        GUI.color = new Color(0.01f, 0.04f, 0.06f, 0.9f);
        GUI.DrawTexture(iconRect, Texture2D.whiteTexture);
        if (icon != null && icon.texture != null)
        {
            GUI.color = Color.white;
            GUI.DrawTexture(iconRect, icon.texture, ScaleMode.ScaleToFit, true);
        }
        GUI.color = Color.white;

        return GUI.Button(rect, GUIContent.none, GUIStyle.none);
    }

    private void DrawGacha(Rect panel)
    {
        DrawMenuBackdrop(panel, false);

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 36,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUI.Label(new Rect(panel.x + 24f, panel.y + 18f,
            panel.width - 48f, 48f), "装備ガチャ", title);

        GUIStyle subtitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };
        subtitle.normal.textColor = new Color(0.76f, 0.86f, 0.9f);
        GUI.Label(new Rect(panel.x + 24f, panel.y + 65f,
            panel.width - 48f, 28f),
            ticketGachaSelected
                ? "ボスから稀に落ちるチケットで、限定武器を手に入れよう"
                : "コインを使って、武器・服・靴・ペットを手に入れよう", subtitle);
        Rect currencyRect = new Rect(panel.x + panel.width - 205f,
            panel.y + 24f, 180f, 32f);
        if (ticketGachaSelected)
        {
            GUIStyle ticketCounter = new GUIStyle(subtitle)
            {
                fontStyle = FontStyle.Bold
            };
            ticketCounter.normal.textColor = new Color(0.45f, 0.9f, 1f);
            DrawTicketCounter(currencyRect, ticketCounter);
        }
        else
        {
            DrawCoinCounter(currencyRect, subtitle);
        }

        Rect typePanel = new Rect(panel.x + 32f, panel.y + 112f,
            260f, 456f);
        Rect detailPanel = new Rect(panel.x + 312f, panel.y + 112f,
            panel.width - 344f, 456f);
        GUI.color = new Color(0.025f, 0.07f, 0.1f, 0.97f);
        GUI.DrawTexture(typePanel, Texture2D.whiteTexture);
        GUI.DrawTexture(detailPanel, Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle panelTitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 22,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft,
            clipping = TextClipping.Overflow
        };
        panelTitle.normal.textColor = new Color(1f, 0.88f, 0.48f);
        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleLeft
        };
        hint.normal.textColor = new Color(0.68f, 0.78f, 0.81f);

        Rect normalGachaRect = new Rect(typePanel.x + 20f, typePanel.y + 28f,
            typePanel.width - 40f, 60f);
        if (DrawGachaTypeTab(normalGachaRect, "ノーマルガチャ",
            !ticketGachaSelected, GetCoinSprite(),
            new Color(0.95f, 0.78f, 0.25f, 1f)))
        {
            ticketGachaSelected = false;
            gachaSlotFilter = -1;
            gachaLineupScroll = Vector2.zero;
            gachaRatesScroll = Vector2.zero;
            RequestEditorRepaint();
        }
        Rect ticketGachaRect = new Rect(typePanel.x + 20f, typePanel.y + 92f,
            typePanel.width - 40f, 60f);
        if (DrawGachaTypeTab(ticketGachaRect, "チケットガチャ",
            ticketGachaSelected, GetGachaTicketSprite(),
            new Color(0.25f, 0.9f, 1f, 1f)))
        {
            ticketGachaSelected = true;
            gachaSlotFilter = -1;
            gachaRatesOpen = false;
            gachaResultPopupOpen = false;
            gachaLineupScroll = Vector2.zero;
            gachaRatesScroll = Vector2.zero;
            RequestEditorRepaint();
        }
        GUI.Label(new Rect(detailPanel.x + 20f, detailPanel.y + 16f,
            detailPanel.width - 76f, 32f),
            ticketGachaSelected ? "チケットガチャ" : "ノーマルガチャ",
            panelTitle);

        GUIStyle rateButton = CreateHoverButtonStyle(16, FontStyle.Bold);
        Rect rateButtonRect = new Rect(detailPanel.x + detailPanel.width - 54f,
            detailPanel.y + 16f, 34f, 28f);
        if (GUI.Button(rateButtonRect, "?", rateButton))
        {
            gachaRatesOpen = true;
            RequestEditorRepaint();
        }

        List<EquipmentSystem.Slot> poolSlots;
        List<EquipmentSystem.Item> poolItems;
        if (ticketGachaSelected)
            GetTicketGachaPool(out poolSlots, out poolItems);
        else
            GetGachaPool(out poolSlots, out poolItems);

        if (gachaRatesOpen)
        {
            DrawGachaRatesPopup(panel, poolSlots, poolItems, hint);
            return;
        }

        if (gachaResultPopupOpen)
        {
            DrawGachaResultPopup(panel, hint);
            return;
        }

        // A gacha banner should sell the visual impression first. Show the
        // actual weapon art in a single promotional strip; do not turn this
        // area into another explanatory list.
        Rect banner = new Rect(detailPanel.x + 20f, detailPanel.y + 88f,
            detailPanel.width - 40f, 214f);
        Texture2D normalBackground = GetGachaNormalBackgroundTexture();
        GUI.color = Color.white;
        if (normalBackground != null)
        {
            GUI.DrawTexture(banner, normalBackground,
                ScaleMode.ScaleAndCrop, true);
        }
        else
        {
            GUI.color = new Color(0.025f, 0.06f, 0.11f, 1f);
            GUI.DrawTexture(banner, Texture2D.whiteTexture);
        }
        GUI.color = new Color(0.14f, 0.3f, 0.46f, 1f);
        GUI.DrawTexture(new Rect(banner.x + 12f, banner.y + 12f,
            banner.width - 24f, 2f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(banner.x + 12f, banner.yMax - 14f,
            banner.width - 24f, 2f), Texture2D.whiteTexture);

        HashSet<string> drawnIconKeys = new HashSet<string>();
        List<EquipmentSystem.Item> uniqueLineupItems =
            new List<EquipmentSystem.Item>();
        for (int i = 0; i < poolItems.Count; i++)
        {
            string iconKey = $"{poolItems[i].iconResource}|{poolItems[i].iconCell}";
            if (drawnIconKeys.Add(iconKey))
                uniqueLineupItems.Add(poolItems[i]);
        }

        float weaponAreaX = banner.x + 18f;
        float weaponAreaWidth = banner.width - 36f;
        float weaponSlotWidth = weaponAreaWidth /
            Mathf.Max(1, uniqueLineupItems.Count);
        float iconSize = Mathf.Min(82f, banner.height - 30f);
        for (int i = 0; i < uniqueLineupItems.Count; i++)
        {
            EquipmentSystem.Item item = uniqueLineupItems[i];
            float iconCenterX = weaponAreaX + weaponSlotWidth * (i + 0.5f);
            float iconCenterY = banner.center.y + 2f;

            Texture2D itemIcons = GetEquipmentIconTexture(item);
            if (itemIcons != null)
            {
                GUI.color = Color.white;
                DrawEquipmentIcon(new Rect(
                    iconCenterX - iconSize * 0.5f,
                    iconCenterY - iconSize * 0.5f,
                    iconSize, iconSize), item.iconCell, itemIcons);
            }
        }
        GUI.color = Color.white;

        GUIStyle pullButton = CreateHoverButtonStyle(17, FontStyle.Bold);
        if (ticketGachaSelected)
        {
            Rect pullRect = new Rect(detailPanel.x + 20f, detailPanel.y + 386f,
                detailPanel.width - 40f, 58f);
            if (GUI.Button(pullRect, $"1連　{TicketGachaCost}枚", pullButton))
                TryPullTicketGacha();
        }
        else
        {
            float pullButtonWidth = (detailPanel.width - 40f - 10f) * 0.5f;
            Rect pullRect = new Rect(detailPanel.x + 20f, detailPanel.y + 386f,
                pullButtonWidth, 58f);
            if (GUI.Button(pullRect, $"1連　{EquipmentGachaCost}コイン", pullButton))
                TryPullEquipmentGacha();
            Rect tenPullRect = new Rect(pullRect.xMax + 10f, pullRect.y,
                pullButtonWidth, pullRect.height);
            if (GUI.Button(tenPullRect,
                $"10連　{EquipmentTenGachaCost}コイン", pullButton))
                TryPullEquipmentGachaTen();
        }

        if (gachaMessageTimer > 0f && !string.IsNullOrEmpty(gachaMessage))
        {
            const float fadeInDuration = 0.18f;
            const float fadeOutDuration = 0.42f;
            const float riseDistance = 14f;
            const float riseDuration = 0.45f;
            float elapsed = GachaMessageDuration - gachaMessageTimer;
            float fadeIn = Mathf.Clamp01(elapsed / fadeInDuration);
            float fadeOut = Mathf.Clamp01(gachaMessageTimer / fadeOutDuration);
            float alpha = fadeIn * fadeOut;
            float rise = Mathf.SmoothStep(0f, riseDistance,
                Mathf.Clamp01(elapsed / riseDuration));

            GUIStyle shortageMessage = new GUIStyle(GUI.skin.label)
            {
                fontSize = 16,
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold
            };
            shortageMessage.normal.textColor = new Color(1f, 0.88f, 0.48f,
                alpha);
            GUI.Label(new Rect(detailPanel.x + 20f,
                detailPanel.y + 452f - rise, detailPanel.width - 40f, 24f),
                gachaMessage, shortageMessage);
        }

        GUIStyle backStyle = CreateHoverButtonStyle(18, FontStyle.Bold);
        if (GUI.Button(new Rect(panel.x + 32f, panel.y + 600f, 220f, 48f),
            "ステージ選択へ", backStyle))
            ReturnToMenu();
    }

    private void DrawGachaResultPopup(Rect panel, GUIStyle hint)
    {
        Rect popup = new Rect(panel.x + 220f, panel.y + 76f,
            panel.width - 440f, 500f);
        GUI.color = new Color(0f, 0f, 0f, 0.72f);
        GUI.DrawTexture(new Rect(panel.x, panel.y, panel.width, panel.height),
            Texture2D.whiteTexture);
        GUI.color = new Color(0.025f, 0.07f, 0.1f, 0.99f);
        GUI.DrawTexture(popup, Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 26,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft
        };
        title.normal.textColor = new Color(1f, 0.88f, 0.48f);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 16f,
            popup.width - 120f, 36f),
            gachaResults.Count > 1 ? "10連の結果" : "ガチャ結果", title);

        GUIStyle closeStyle = CreateHoverButtonStyle(14, FontStyle.Bold);
        if (GUI.Button(new Rect(popup.x + popup.width - 82f, popup.y + 20f,
            58f, 30f), "閉じる", closeStyle))
        {
            gachaResultPopupOpen = false;
            RequestEditorRepaint();
            return;
        }

        if (gachaResults.Count > 1)
        {
            DrawGachaTenResults(popup, hint);
            return;
        }

        if (gachaResultItemId < 0)
        {
            GUI.Label(new Rect(popup.x + 24f, popup.y + 92f,
                popup.width - 48f, 36f), gachaMessage, hint);
            return;
        }

        EquipmentSystem.Item result = EquipmentSystem.GetItem(
            gachaResultSlot, gachaResultItemId);
        Rect resultCard = new Rect(popup.x + 24f, popup.y + 78f,
            popup.width - 48f, 250f);
        Color rarityColor = EquipmentSystem.GetRarityColor(result.rarity);
        GUI.color = Color.Lerp(rarityColor,
            new Color(0.08f, 0.12f, 0.18f), 0.28f);
        GUI.DrawTexture(resultCard, Texture2D.whiteTexture);
        GUI.color = rarityColor;
        GUI.DrawTexture(new Rect(resultCard.x, resultCard.y,
            resultCard.width, 6f), Texture2D.whiteTexture);
        GUI.color = Color.white;
        GUIStyle resultName = new GUIStyle(GUI.skin.label)
        {
            fontSize = 26,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            clipping = TextClipping.Overflow
        };
        resultName.normal.textColor = Color.white;
        GUI.Label(new Rect(resultCard.x + 24f, resultCard.y + 44f,
            resultCard.width - 48f, 38f), result.name, resultName);

        GUIStyle resultRarity = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleLeft,
            fontStyle = FontStyle.Bold
        };
        resultRarity.normal.textColor = rarityColor +
            new Color(0.18f, 0.18f, 0.18f);
        GUI.Label(new Rect(resultCard.x + 24f, resultCard.y + 100f,
            resultCard.width - 48f, 28f),
            EquipmentSystem.GetRarityStars(result.rarity), resultRarity);
        GUI.Label(new Rect(resultCard.x + 24f, resultCard.y + 146f,
            resultCard.width - 48f, 28f), result.effect, hint);
        GUI.Label(new Rect(resultCard.x + 24f, resultCard.y + 184f,
            resultCard.width - 48f, 24f),
            EquipmentSystem.GetSlotName(gachaResultSlot), hint);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 350f,
            popup.width - 48f, 32f), gachaMessage, resultRarity);
    }

    private void DrawGachaRatesPopup(Rect panel,
        List<EquipmentSystem.Slot> poolSlots,
        List<EquipmentSystem.Item> poolItems,
        GUIStyle hint)
    {
        Rect popup = new Rect(panel.x + 170f, panel.y + 48f,
            panel.width - 340f, 570f);
        GUI.color = new Color(0f, 0f, 0f, 0.72f);
        GUI.DrawTexture(new Rect(panel.x, panel.y, panel.width, panel.height),
            Texture2D.whiteTexture);
        GUI.color = new Color(0.025f, 0.07f, 0.1f, 0.99f);
        GUI.DrawTexture(popup, Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleLeft
        };
        title.normal.textColor = new Color(1f, 0.88f, 0.48f);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 16f,
            popup.width - 120f, 34f), "装備ごとの排出確率", title);

        GUIStyle closeStyle = CreateHoverButtonStyle(14, FontStyle.Bold);
        if (GUI.Button(new Rect(popup.x + popup.width - 82f, popup.y + 18f,
            58f, 30f), "閉じる", closeStyle))
        {
            gachaRatesOpen = false;
            RequestEditorRepaint();
            return;
        }

        GUI.Label(new Rect(popup.x + 24f, popup.y + 54f,
            popup.width - 48f, 24f),
            "現在選択中のラインナップの個別確率（絵なし）", hint);

        Rect listViewport = new Rect(popup.x + 24f, popup.y + 88f,
            popup.width - 48f, popup.height - 124f);
        const float rowHeight = 30f;
        float contentHeight = Mathf.Max(listViewport.height,
            poolItems.Count * rowHeight);
        gachaRatesScroll = GUI.BeginScrollView(listViewport,
            gachaRatesScroll,
            new Rect(0f, 0f, listViewport.width, contentHeight),
            false, true);

        for (int i = 0; i < poolItems.Count; i++)
        {
            EquipmentSystem.Item item = poolItems[i];
            Rect row = new Rect(0f, i * rowHeight,
                listViewport.width, rowHeight - 3f);
            GUI.color = i % 2 == 0
                ? new Color(0.06f, 0.13f, 0.17f, 1f)
                : new Color(0.04f, 0.1f, 0.14f, 1f);
            GUI.DrawTexture(row, Texture2D.whiteTexture);
            GUI.color = Color.white;

            GUIStyle itemName = new GUIStyle(hint)
            {
                fontSize = 14,
                alignment = TextAnchor.MiddleLeft,
                clipping = TextClipping.Overflow
            };
            itemName.normal.textColor = Color.white;
            float probability = GetGachaItemProbabilityPercent(poolItems, item);
            GUI.Label(new Rect(row.x + 12f, row.y, row.width - 170f,
                row.height),
                $"{EquipmentSystem.GetSlotName(poolSlots[i])}　{item.name}",
                itemName);

            GUIStyle probabilityStyle = new GUIStyle(itemName)
            {
                alignment = TextAnchor.MiddleRight
            };
            probabilityStyle.normal.textColor = new Color(1f, 0.88f, 0.48f);
            GUI.Label(new Rect(row.x + row.width - 155f, row.y,
                143f, row.height), $"{probability:0.##}%",
                probabilityStyle);
        }

        GUI.EndScrollView();
    }

    private void DrawGachaTenResults(Rect resultPanel, GUIStyle hint)
    {
        const int columns = 2;
        const float gap = 6f;
        float listX = resultPanel.x + 18f;
        float listY = resultPanel.y + 58f;
        float listWidth = resultPanel.width - 36f;
        float cardWidth = (listWidth - gap) / columns;
        float cardHeight = 50f;

        for (int i = 0; i < gachaResults.Count; i++)
        {
            EquipmentGachaResult gachaResult = gachaResults[i];
            EquipmentSystem.Item item = EquipmentSystem.GetItem(
                gachaResult.slot, gachaResult.itemId);
            int column = i % columns;
            int row = i / columns;
            Rect card = new Rect(listX + column * (cardWidth + gap),
                listY + row * (cardHeight + gap), cardWidth, cardHeight);
            Color rarityColor = EquipmentSystem.GetRarityColor(item.rarity);
            GUI.color = Color.Lerp(rarityColor,
                gachaResult.isNew
                    ? new Color(0.12f, 0.3f, 0.22f)
                    : new Color(0.08f, 0.12f, 0.17f),
                gachaResult.isNew ? 0.35f : 0.28f);
            GUI.DrawTexture(card, Texture2D.whiteTexture);
            GUI.color = rarityColor;
            GUI.DrawTexture(new Rect(card.x, card.y, card.width, 3f),
                Texture2D.whiteTexture);
            GUI.color = Color.white;

            Rect nameRect = new Rect(card.x + 14f, card.y + 8f,
                card.width - 28f, 19f);
            GUIStyle name = new GUIStyle(GUI.skin.label)
            {
                fontSize = 12,
                alignment = TextAnchor.MiddleLeft,
                fontStyle = FontStyle.Bold,
                clipping = TextClipping.Clip
            };
            while (name.fontSize > 9 &&
                name.CalcSize(new GUIContent(item.name)).x > nameRect.width)
                name.fontSize--;
            name.normal.textColor = Color.white;
            GUI.Label(nameRect, item.name, name);

            GUIStyle detail = new GUIStyle(hint)
            {
                fontSize = 10,
                clipping = TextClipping.Clip
            };
            GUI.Label(new Rect(card.x + 14f, card.y + 28f,
                card.width - 28f, 18f),
                $"{EquipmentSystem.GetRarityStars(item.rarity)} / " +
                (gachaResult.isNew ? "新規" : "所持済み"), detail);
        }

        GUI.Label(new Rect(resultPanel.x + 24f, resultPanel.y + 350f,
            resultPanel.width - 48f, 32f), gachaMessage, hint);
    }

    private Texture2D GetEquipmentIconsTexture()
    {
        if (equipmentIconsTexture == null)
            equipmentIconsTexture = Resources.Load<Texture2D>("Equipment/EquipmentIcons");
        return equipmentIconsTexture;
    }

    private Texture2D GetEquipmentIconTexture(EquipmentSystem.Item item)
    {
        if (string.IsNullOrEmpty(item.iconResource))
            return GetEquipmentIconsTexture();

        if (!equipmentIconTextures.TryGetValue(item.iconResource,
            out Texture2D texture) || texture == null)
        {
            texture = Resources.Load<Texture2D>(item.iconResource);
            equipmentIconTextures[item.iconResource] = texture;
        }

        return texture;
    }

    private Texture2D GetGachaNormalBackgroundTexture()
    {
        if (gachaNormalBackgroundTexture == null)
        {
            gachaNormalBackgroundTexture = Resources.Load<Texture2D>(
                "Equipment/GachaBanner_NormalBackground");
        }
        return gachaNormalBackgroundTexture;
    }

    private void DrawEquipmentIcon(Rect rect, int cellIndex, Texture2D texture)
    {
        if (texture.width == texture.height)
        {
            GUI.DrawTexture(rect, texture, ScaleMode.ScaleToFit, true);
            return;
        }

        int safeCell = Mathf.Clamp(cellIndex, 0, 5);
        int column = safeCell % 3;
        int row = safeCell / 3;
        Rect textureRect = new Rect(column / 3f, 1f - (row + 1) / 2f,
            1f / 3f, 0.5f);
        GUI.DrawTextureWithTexCoords(rect, texture, textureRect);
    }

    private static Color GetEquipmentSlotAccent(EquipmentSystem.Slot slot)
    {
        switch (slot)
        {
            case EquipmentSystem.Slot.Weapon: return new Color(0.3f, 0.78f, 1f);
            case EquipmentSystem.Slot.Armor: return new Color(0.34f, 0.9f, 0.52f);
            case EquipmentSystem.Slot.Boots: return new Color(1f, 0.65f, 0.28f);
            case EquipmentSystem.Slot.Pet: return new Color(0.78f, 0.48f, 1f);
            default: return Color.white;
        }
    }

    private void DrawSkillTreeViewportSurface(Rect viewport)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0.015f, 0.04f, 0.065f, 0.62f);
        GUI.DrawTexture(viewport, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawSkillTreeViewportFrame(Rect viewport)
    {
        Color previousColor = GUI.color;
        const float outerThickness = 3f;
        const float innerThickness = 1f;

        // Draw after the clipped group so the boundary stays visible even
        // when a node is dragged against an edge. The four sides are the
        // exact point where the tree stops being visible.
        GUI.color = new Color(0.95f, 0.72f, 0.22f, 0.95f);
        GUI.DrawTexture(new Rect(viewport.x, viewport.y,
            viewport.width, outerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x, viewport.yMax - outerThickness,
            viewport.width, outerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x, viewport.y,
            outerThickness, viewport.height), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.xMax - outerThickness, viewport.y,
            outerThickness, viewport.height), Texture2D.whiteTexture);

        GUI.color = new Color(1f, 0.9f, 0.52f, 0.48f);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness, viewport.y + outerThickness,
            viewport.width - outerThickness * 2f, innerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness,
            viewport.yMax - outerThickness - innerThickness,
            viewport.width - outerThickness * 2f, innerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness, viewport.y + outerThickness,
            innerThickness, viewport.height - outerThickness * 2f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.xMax - outerThickness - innerThickness,
            viewport.y + outerThickness, innerThickness,
            viewport.height - outerThickness * 2f), Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private string GetDefeatMessage()
    {
        return defeatReason == DefeatReason.HeroDefeated
            ? "ヒーローが倒されました"
            : "魔女が倒されました";
    }
}
