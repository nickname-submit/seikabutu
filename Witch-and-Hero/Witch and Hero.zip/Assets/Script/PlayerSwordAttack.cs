using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerSwordAttack : MonoBehaviour
{
    [SerializeField] private GameObject swordPrefab;
    [SerializeField] private float attackDelay = 0.25f;

    private Vector2 lastDirection = Vector2.down;
    private float nextAttackTime;
    private bool isAttacking;
    private Hero hero;
    private int weaponSkillAttackCount;
    private int trackedWeaponId = -1;
    private bool weaponSkillReady;

    public int WeaponSkillAttackCount
    {
        get
        {
            RefreshWeaponSkillState();
            return weaponSkillAttackCount;
        }
    }

    public int WeaponSkillAttackRequirement
    {
        get { return EquipmentSystem.GetWeaponSkillAttackRequirement(); }
    }

    public bool IsWeaponSkillReady
    {
        get
        {
            RefreshWeaponSkillState();
            return weaponSkillReady;
        }
    }

    public string WeaponSkillName
    {
        get { return EquipmentSystem.GetWeaponSkillName(); }
    }

    private void Awake()
    {
        hero = GetComponent<Hero>();
        ResetWeaponSkillCharge();
    }

    private void Update()
    {
        if (hero != null && hero.IsDead)
        {
            if (isAttacking)
            {
                StopAllCoroutines();
                isAttacking = false;
            }
            return;
        }

        RefreshWeaponSkillState();

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        // Keep the existing attack cadence and delay. Holding Space simply
        // retries the same input while the current cooldown allows it, so
        // tapping and holding produce the same attacks per minute.
        if (!keyboard.spaceKey.wasPressedThisFrame &&
            !keyboard.spaceKey.isPressed)
            return;

        if (isAttacking || Time.time < nextAttackTime)
            return;

        if (swordPrefab == null)
        {
            Debug.LogError("Sword Prefab が設定されていません。", this);
            return;
        }

        Vector2 pressedDirection = ReadPressedDirection(keyboard);
        if (hero != null && pressedDirection.sqrMagnitude > 0.01f)
            hero.SetFacingDirection(pressedDirection);

        // The projectile and the hero sprite must start from the same input
        // event. Otherwise the slash can appear while the hero body remains
        // on its idle pose.
        if (hero != null)
            hero.PlayAttackAnimation();

        bool useWeaponSkill = weaponSkillReady;
        StartCoroutine(AttackAfterDelay(useWeaponSkill));
    }

    private static Vector2 ReadPressedDirection(Keyboard keyboard)
    {
        Vector2 direction = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.aKey.wasPressedThisFrame ||
            keyboard.leftArrowKey.isPressed || keyboard.leftArrowKey.wasPressedThisFrame)
            direction.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.dKey.wasPressedThisFrame ||
            keyboard.rightArrowKey.isPressed || keyboard.rightArrowKey.wasPressedThisFrame)
            direction.x += 1f;
        if (keyboard.wKey.isPressed || keyboard.wKey.wasPressedThisFrame ||
            keyboard.upArrowKey.isPressed || keyboard.upArrowKey.wasPressedThisFrame)
            direction.y += 1f;
        if (keyboard.sKey.isPressed || keyboard.sKey.wasPressedThisFrame ||
            keyboard.downArrowKey.isPressed || keyboard.downArrowKey.wasPressedThisFrame)
            direction.y -= 1f;

        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            direction.y = 0f;
        else if (Mathf.Abs(direction.y) > Mathf.Abs(direction.x))
            direction.x = 0f;

        return direction;
    }

    public void ResetForStage()
    {
        StopAllCoroutines();
        isAttacking = false;
        nextAttackTime = 0f;
        ResetWeaponSkillCharge();
        enabled = true;
    }

    public void SetAttackDirection(Vector2 direction)
    {
        if (direction.sqrMagnitude < 0.01f)
            return;

        lastDirection = direction.normalized;
    }

    public void StopForDeath()
    {
        StopAllCoroutines();
        isAttacking = false;
        enabled = false;

        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++)
            Destroy(projectiles[i].gameObject);
    }

    private IEnumerator AttackAfterDelay(bool useWeaponSkill)
    {
        isAttacking = true;
        float recoveryMultiplier = useWeaponSkill ? 1.35f : 1f;
        nextAttackTime = Time.time +
            GameFlow.GetHeroAttackInterval() * recoveryMultiplier;

        yield return new WaitForSeconds(attackDelay);

        // Hero owns the facing direction. Read it after the delay so a
        // movement key and the attack key pressed in the same frame cannot
        // make the projectile use a stale or opposite direction.
        Vector2 attackDirection = hero != null
            ? hero.FacingDirection
            : lastDirection;

        if (useWeaponSkill)
        {
            FireWeaponSkill(attackDirection);
            ResetWeaponSkillCharge();
        }
        else
        {
            FireProjectile(attackDirection, GameFlow.GetHeroSlashDamage(),
                GameFlow.GetSlashPiercingHits(), 1f, Color.white);
            RegisterNormalAttack();
        }

        isAttacking = false;
    }

    private void RefreshWeaponSkillState()
    {
        int weaponId = EquipmentSystem.GetEquipped(EquipmentSystem.Slot.Weapon);
        if (trackedWeaponId == weaponId)
            return;

        ResetWeaponSkillCharge();
        trackedWeaponId = weaponId;
    }

    private void ResetWeaponSkillCharge()
    {
        trackedWeaponId = EquipmentSystem.GetEquipped(
            EquipmentSystem.Slot.Weapon);
        weaponSkillAttackCount = 0;
        weaponSkillReady = false;
    }

    private void RegisterNormalAttack()
    {
        RefreshWeaponSkillState();
        int requirement = EquipmentSystem.GetWeaponSkillAttackRequirement();
        if (requirement <= 0)
            return;

        if (weaponSkillReady)
            return;

        weaponSkillAttackCount++;
        if (weaponSkillAttackCount >= requirement)
        {
            weaponSkillAttackCount = requirement;
            weaponSkillReady = true;
        }
    }

    private void FireWeaponSkill(Vector2 direction)
    {
        if (!EquipmentSystem.HasWeaponSkill())
            return;

        EquipmentSystem.Rarity rarity =
            EquipmentSystem.GetEquippedWeaponRarity();
        int baseDamage = GameFlow.GetHeroSlashDamage();
        int basePiercing = GameFlow.GetSlashPiercingHits();

        switch (rarity)
        {
            case EquipmentSystem.Rarity.Rare:
                // Rare weapons keep the same one-direction action, but the
                // charged slash is visibly larger and only modestly stronger.
                FireProjectile(direction,
                    Mathf.Max(1, Mathf.RoundToInt(baseDamage * 1.25f)),
                    basePiercing, 1.32f, new Color(0.55f, 0.9f, 1f));
                break;

            case EquipmentSystem.Rarity.Epic:
                // Epic weapons cut a four-way cross around the hero.
                FireProjectile(direction,
                    Mathf.Max(1, Mathf.RoundToInt(baseDamage * 0.7f)),
                    basePiercing, 1.08f, new Color(1f, 0.36f, 0.22f));
                FireProjectile(Rotate(direction, 90f),
                    Mathf.Max(1, Mathf.RoundToInt(baseDamage * 0.4f)),
                    basePiercing, 1.0f, new Color(1f, 0.48f, 0.22f));
                FireProjectile(Rotate(direction, 180f),
                    Mathf.Max(1, Mathf.RoundToInt(baseDamage * 0.4f)),
                    basePiercing, 1.0f, new Color(1f, 0.48f, 0.22f));
                FireProjectile(Rotate(direction, 270f),
                    Mathf.Max(1, Mathf.RoundToInt(baseDamage * 0.4f)),
                    basePiercing, 1.0f, new Color(1f, 0.48f, 0.22f));
                break;

            case EquipmentSystem.Rarity.Legendary:
                // Legendary weapons create a large six-direction burst.
                // The coverage is impressive, but each blade is deliberately
                // light so it does not erase a difficult wave by itself.
                for (int i = 0; i < 6; i++)
                {
                    FireProjectile(Rotate(direction, i * 60f),
                        Mathf.Max(1, Mathf.RoundToInt(baseDamage * 0.4f)),
                        basePiercing, 1.12f,
                        new Color(1f, 0.78f, 0.22f));
                }
                break;

            default:
                return;
        }
    }

    private void FireProjectile(Vector2 direction, int damage, int piercing,
        float scale, Color tint)
    {
        GameObject sword = Instantiate(swordPrefab, transform.position,
            Quaternion.identity);
        SwordProjectile projectile = sword.GetComponent<SwordProjectile>();
        if (projectile == null)
        {
            Debug.LogError("SwordProjectile が見つかりません。", sword);
            Destroy(sword);
            return;
        }

        projectile.SetDamage(damage);
        projectile.SetPiercingHits(piercing);
        projectile.SetWeaponStyle(EquipmentSystem.IsKunaiEquipped());
        projectile.SetSpecialVisual(scale, tint);
        projectile.Launch(direction);
    }

    private static Vector2 Rotate(Vector2 direction, float degrees)
    {
        float radians = degrees * Mathf.Deg2Rad;
        float cos = Mathf.Cos(radians);
        float sin = Mathf.Sin(radians);
        return new Vector2(
            direction.x * cos - direction.y * sin,
            direction.x * sin + direction.y * cos).normalized;
    }
}
