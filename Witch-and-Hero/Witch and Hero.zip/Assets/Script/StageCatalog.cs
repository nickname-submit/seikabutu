using UnityEngine;

[CreateAssetMenu(fileName = "StageCatalog", menuName = "Game/Stage Catalog")]
public class StageCatalog : ScriptableObject
{
    [Header("ワールドマップのヒーロー表示")]
    public Sprite mapHeroIdleSprite;
    public Sprite[] mapHeroRunSprites;
    public StageDefinition[] stages;

    public StageDefinition GetStage(int stageId)
    {
        if (stages == null) return null;

        for (int i = 0; i < stages.Length; i++)
        {
            if (stages[i] != null && stages[i].stageId == stageId)
                return stages[i];
        }

        return null;
    }
}

[System.Serializable]
public class StageDefinition
{
    // stageId is the playable level id. stageGroupId is the stage shown on a
    // map, so the hierarchy is Map -> Stage -> Level.
    public int stageId = 1;
    public string displayName = "LEVEL 1";
    [Header("ワールドマップ")]
    [Min(1)]
    public int mapPage = 1;
    [Min(1)]
    public int stageGroupId = 1;
    public string mapTheme = "草原";
    public string mapConcept = "旅立ち";
    [Tooltip("StageIcons.png の左上から数えたアイコン番号。0～9を指定します。")]
    [Min(-1)]
    public int mapIconId = -1;
    public StageWave[] waves;

    public int TotalMonsterCount
    {
        get
        {
            int total = 0;
            if (waves == null) return total;

            for (int i = 0; i < waves.Length; i++)
            {
                if (waves[i] != null) total += Mathf.Max(0, waves[i].count);
            }

            return total;
        }
    }
}

[System.Serializable]
public class StageWave
{
    [Tooltip("MonsterCatalogのmonsterIdを指定します。色・ステータスはMonsterCatalog側で一括管理します。")]
    public int monsterId;

    [Min(1)]
    public int count = 1;

    [Min(0f)]
    public float startDelay;

    [Min(0f)]
    public float spawnInterval = 0.5f;

    [Min(0.1f)]
    public float minDistanceFromWitch = 6f;
}
