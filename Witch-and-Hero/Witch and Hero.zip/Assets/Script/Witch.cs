using System;
using UnityEngine;

public class Witch : MonoBehaviour
{
    [SerializeField] private int maxHealth = 10;
    [SerializeField] private float damageInterval = 0.5f;
    private int health;
    private bool isDead;
    private float nextDamageTime;
    private SpriteRenderer placeholderRenderer;
    private BoxCollider2D bodyCollider;
    private GameObject worldVisualObject;
    private SpriteRenderer worldVisualRenderer;
    private static Sprite cachedWorldSprite;
    private static Sprite[] cachedIdleSprites;
    // Match the hero's on-screen height in the battle view.
    private const float WorldVisualScale = 0.13f;
    // Contact should follow the witch's body, not the wide hat and robe hem.
    private const float BodyColliderWidthScale = 0.62f;
    private const float BodyColliderHeightScale = 0.72f;
    private const float SkillAnimationDuration = 0.52f;
    private const float IdleFrameDuration = 0.28f;
    private float skillAnimationTimer;
    private float idleAnimationTimer;
    private int idleFrameIndex;
    private Vector3 worldVisualBaseScale;

    public bool IsDead => isDead;
    public int Health => health;
    public int MaxHealth => Mathf.Max(1, maxHealth);

    private void Start()
    {
        EnsureWorldVisual();
        ResetForStage(transform.position);
    }

    private void Awake()
    {
        placeholderRenderer = GetComponent<SpriteRenderer>();
        bodyCollider = GetComponent<BoxCollider2D>();
        ConfigureCollisionBounds();
        EnsureWorldVisual();
    }

    private void Update()
    {
        if (GameFlow.IsBattleGameplayFrozen)
            return;

        UpdateIdleAnimation();
        UpdateSkillAnimation();
    }

    private void ConfigureCollisionBounds()
    {
        if (bodyCollider == null)
            bodyCollider = gameObject.AddComponent<BoxCollider2D>();

        bodyCollider.isTrigger = false;

        // The witch visual is created at runtime, so keep the physical body
        // aligned with the visible pixels instead of relying on a stale
        // prefab-sized collider.
        if (worldVisualRenderer != null && worldVisualRenderer.sprite != null)
        {
            Texture2D texture = worldVisualRenderer.sprite.texture;
            if (texture != null && texture.isReadable)
            {
                Color32[] pixels = texture.GetPixels32();
                Rect spriteRect = worldVisualRenderer.sprite.textureRect;
                int rectMinX = Mathf.Clamp(Mathf.FloorToInt(spriteRect.x),
                    0, texture.width - 1);
                int rectMinY = Mathf.Clamp(Mathf.FloorToInt(spriteRect.y),
                    0, texture.height - 1);
                int rectMaxX = Mathf.Clamp(Mathf.CeilToInt(spriteRect.xMax),
                    rectMinX + 1, texture.width);
                int rectMaxY = Mathf.Clamp(Mathf.CeilToInt(spriteRect.yMax),
                    rectMinY + 1, texture.height);
                int minX = rectMaxX;
                int minY = rectMaxY;
                int maxX = rectMinX - 1;
                int maxY = rectMinY - 1;

                for (int y = rectMinY; y < rectMaxY; y++)
                {
                    for (int x = rectMinX; x < rectMaxX; x++)
                    {
                        if (pixels[y * texture.width + x].a < 8)
                            continue;

                        minX = Mathf.Min(minX, x);
                        minY = Mathf.Min(minY, y);
                        maxX = Mathf.Max(maxX, x);
                        maxY = Mathf.Max(maxY, y);
                    }
                }

                if (maxX >= minX && maxY >= minY)
                {
                    float pixelsPerUnit = worldVisualRenderer.sprite.pixelsPerUnit;
                    float visualScale = Mathf.Abs(
                        worldVisualRenderer.transform.localScale.x);
                    Vector2 pixelSize = new Vector2(
                        maxX - minX + 1,
                        maxY - minY + 1);
                    Vector2 pixelCenter = new Vector2(
                        (minX + maxX + 1) * 0.5f,
                        (minY + maxY + 1) * 0.5f);
                    Vector2 pivotInTexture = spriteRect.position +
                        worldVisualRenderer.sprite.pivot;

                    pixelSize.x *= BodyColliderWidthScale;
                    pixelSize.y *= BodyColliderHeightScale;
                    bodyCollider.size = pixelSize / pixelsPerUnit * visualScale;
                    bodyCollider.offset = (Vector2)worldVisualRenderer
                        .transform.localPosition +
                        (pixelCenter - pivotInTexture) /
                        pixelsPerUnit * visualScale;
                    return;
                }
            }
        }

        // Fallback for a missing or non-readable battle sprite.
        bodyCollider.size = new Vector2(1.05f, 1.55f);
        bodyCollider.offset = new Vector2(0f, 0.1f);
    }

    private void EnsureWorldVisual()
    {
        if (cachedIdleSprites == null)
        {
            Sprite[] loadedIdleSprites = Resources.LoadAll<Sprite>("Witch/WitchIdle");
            if (loadedIdleSprites != null && loadedIdleSprites.Length > 0)
            {
                Array.Sort(loadedIdleSprites,
                    (left, right) => string.CompareOrdinal(left.name, right.name));
                cachedIdleSprites = loadedIdleSprites;
            }
            else
            {
                cachedIdleSprites = Array.Empty<Sprite>();
            }
        }

        if (cachedWorldSprite == null)
        {
            // Keep the original witch artwork. Use the main sliced frame from
            // WitchBattleSprite rather than replacing it with a new portrait.
            Sprite[] sprites = Resources.LoadAll<Sprite>("Witch/WitchBattleSprite");
            for (int i = 0; i < sprites.Length; i++)
            {
                if (sprites[i] != null && sprites[i].name == "WitchBattleSprite_0")
                {
                    cachedWorldSprite = sprites[i];
                    break;
                }
            }

            if (cachedWorldSprite == null && sprites.Length > 0)
                cachedWorldSprite = sprites[0];
        }

        // Keep the original placeholder visible as a safe fallback if the
        // resource is missing. Never leave the witch invisible during play.
        if (cachedWorldSprite == null)
            return;

        if (worldVisualObject == null)
        {
            if (placeholderRenderer != null)
            {
                placeholderRenderer.sprite = null;
                placeholderRenderer.enabled = false;
            }

            worldVisualObject = new GameObject("WitchWorldVisual");
            worldVisualObject.transform.SetParent(transform, false);
            worldVisualObject.transform.localPosition = new Vector3(0f, 0.22f, -0.05f);
            worldVisualObject.transform.localScale = Vector3.one * WorldVisualScale;
            worldVisualBaseScale = worldVisualObject.transform.localScale;
            worldVisualRenderer = worldVisualObject.AddComponent<SpriteRenderer>();
            worldVisualRenderer.sortingOrder = 2;
            worldVisualRenderer.color = Color.white;
        }

        if (worldVisualRenderer == null)
            worldVisualRenderer = worldVisualObject.GetComponent<SpriteRenderer>();

        if (worldVisualRenderer != null)
        {
            if (cachedIdleSprites.Length > 0)
            {
                idleFrameIndex = Mathf.Clamp(idleFrameIndex, 0,
                    cachedIdleSprites.Length - 1);
                worldVisualRenderer.sprite = cachedIdleSprites[idleFrameIndex];
            }
            else
            {
                worldVisualRenderer.sprite = cachedWorldSprite;
            }
            if (worldVisualBaseScale.sqrMagnitude <= 0.001f)
                worldVisualBaseScale = Vector3.one * WorldVisualScale;
            ConfigureCollisionBounds();
        }
    }

    private void UpdateIdleAnimation()
    {
        if (isDead || worldVisualRenderer == null ||
            cachedIdleSprites == null || cachedIdleSprites.Length < 2)
            return;

        idleAnimationTimer -= Time.deltaTime;
        if (idleAnimationTimer > 0f)
            return;

        idleAnimationTimer = IdleFrameDuration;
        idleFrameIndex = (idleFrameIndex + 1) % cachedIdleSprites.Length;
        worldVisualRenderer.sprite = cachedIdleSprites[idleFrameIndex];
    }

    public void ResetForStage(Vector3 startPosition)
    {
        maxHealth = GameFlow.GetWitchMaxHealth();
        transform.position = startPosition;
        health = maxHealth;
        isDead = false;
        nextDamageTime = 0f;
        idleFrameIndex = 0;
        idleAnimationTimer = IdleFrameDuration;
        if (worldVisualRenderer != null && cachedIdleSprites != null &&
            cachedIdleSprites.Length > 0)
        {
            worldVisualRenderer.sprite = cachedIdleSprites[0];
            ConfigureCollisionBounds();
        }
        StopSkillAnimation();
    }

    public void PlaySkillAnimation()
    {
        if (isDead || worldVisualObject == null)
            return;

        skillAnimationTimer = SkillAnimationDuration;
        worldVisualBaseScale = Vector3.one * WorldVisualScale;
        worldVisualObject.transform.localScale = worldVisualBaseScale;
        worldVisualObject.transform.localRotation = Quaternion.identity;
        if (worldVisualRenderer != null)
            worldVisualRenderer.color = Color.white;
    }

    public void StopSkillAnimation()
    {
        skillAnimationTimer = 0f;
        if (worldVisualObject == null)
            return;

        worldVisualObject.transform.localScale = worldVisualBaseScale.sqrMagnitude > 0.001f
            ? worldVisualBaseScale
            : Vector3.one * WorldVisualScale;
        worldVisualObject.transform.localRotation = Quaternion.identity;
        if (worldVisualRenderer != null)
            worldVisualRenderer.color = Color.white;
    }

    private void UpdateSkillAnimation()
    {
        if (skillAnimationTimer <= 0f || worldVisualObject == null)
            return;

        skillAnimationTimer = Mathf.Max(0f, skillAnimationTimer - Time.deltaTime);
        float progress = 1f - skillAnimationTimer / SkillAnimationDuration;
        float pulse = Mathf.Sin(progress * Mathf.PI);
        float wobble = Mathf.Sin(progress * Mathf.PI * 2f);
        worldVisualObject.transform.localScale = worldVisualBaseScale *
            (1f + pulse * 0.14f);
        worldVisualObject.transform.localRotation = Quaternion.Euler(
            0f, 0f, wobble * 7f);

        if (worldVisualRenderer != null)
        {
            worldVisualRenderer.color = Color.Lerp(Color.white,
                new Color(0.62f, 0.95f, 1f, 1f), pulse);
        }

        if (skillAnimationTimer <= 0f)
            StopSkillAnimation();
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        health -= Mathf.Max(1, damage);
        if (health <= 0)
        {
            health = 0;
            isDead = true;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Monster") || Time.time < nextDamageTime)
            return;

        nextDamageTime = Time.time + damageInterval;
        Monster monster = collision.gameObject.GetComponent<Monster>();
        TakeDamage(monster != null ? monster.WitchContactDamage : 1);
    }
}
