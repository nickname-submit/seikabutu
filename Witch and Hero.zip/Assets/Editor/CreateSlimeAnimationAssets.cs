using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

public static class CreateSlimeAnimationAssets
{
    private const string AnimationFolder = "Assets/Animation";
    private const string ControllerPath = AnimationFolder + "/Slime_Controller.controller";
    private const string PrefabPath = "Assets/Prefab/Triangle.prefab";

    [MenuItem("Tools/Witch and Hero/Create Slime Animations")]
    public static void Create()
    {
        Directory.CreateDirectory(AnimationFolder);

        AnimationClip idle = CreateClip(
            AnimationFolder + "/Slime_Idle.anim",
            "Assets/Image/ASEPRITE_slime/Slime1/Idle/Slime1_Idle_front.aseprite", true);
        AnimationClip walk = CreateClip(
            AnimationFolder + "/Slime_Walk.anim",
            "Assets/Image/ASEPRITE_slime/Slime1/Walk/Slime1_Walk_front.aseprite", true);
        AnimationClip attack = CreateClip(
            AnimationFolder + "/Slime_Attack.anim",
            "Assets/Image/ASEPRITE_slime/Slime1/Attack/Slime1_Attack_front.aseprite", false);
        AnimationClip death = CreateClip(
            AnimationFolder + "/Slime_Death.anim",
            "Assets/Image/ASEPRITE_slime/Slime1/Death/Slime1_Death_front.aseprite", false);

        if (AssetDatabase.LoadAssetAtPath<AnimatorController>(ControllerPath) != null)
            AssetDatabase.DeleteAsset(ControllerPath);

        AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(ControllerPath);
        AnimatorStateMachine stateMachine = controller.layers[0].stateMachine;
        AnimatorState idleState = stateMachine.AddState("Idle");
        AnimatorState walkState = stateMachine.AddState("Walk");
        AnimatorState attackState = stateMachine.AddState("Attack");
        AnimatorState deathState = stateMachine.AddState("Death");
        idleState.motion = idle;
        walkState.motion = walk;
        attackState.motion = attack;
        deathState.motion = death;
        stateMachine.defaultState = idleState;

        GameObject prefabContents = PrefabUtility.LoadPrefabContents(PrefabPath);
        prefabContents.transform.localScale = Vector3.one * 3f;
        SpriteRenderer renderer = prefabContents.GetComponent<SpriteRenderer>();
        Sprite[] idleSprites = LoadSprites(
            "Assets/Image/ASEPRITE_slime/Slime1/Idle/Slime1_Idle_front.aseprite");
        if (renderer != null && idleSprites.Length > 0)
            renderer.sprite = idleSprites[0];

        BoxCollider2D collider = prefabContents.GetComponent<BoxCollider2D>();
        if (collider != null)
            collider.size = new Vector2(0.3f, 0.3f);

        Animator animator = prefabContents.GetComponent<Animator>();
        if (animator == null)
            animator = prefabContents.AddComponent<Animator>();
        animator.runtimeAnimatorController = controller;

        PrefabUtility.SaveAsPrefabAsset(prefabContents, PrefabPath);
        PrefabUtility.UnloadPrefabContents(prefabContents);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Slimeの移動・魔女への攻撃・死亡アニメーションをTriangle.prefabへ割り当てました。");
    }

    private static AnimationClip CreateClip(string path, string spriteAssetPath, bool loop)
    {
        AssetDatabase.DeleteAsset(path);
        Sprite[] sprites = LoadSprites(spriteAssetPath);
        AnimationClip clip = new AnimationClip
        {
            name = Path.GetFileNameWithoutExtension(path),
            frameRate = 12f
        };

        ObjectReferenceKeyframe[] keys = sprites
            .Select((sprite, index) => new ObjectReferenceKeyframe
            {
                time = index / clip.frameRate,
                value = sprite
            })
            .ToArray();
        EditorCurveBinding binding = EditorCurveBinding.PPtrCurve(
            "", typeof(SpriteRenderer), "m_Sprite");
        AnimationUtility.SetObjectReferenceCurve(clip, binding, keys);
        AnimationClipSettings settings = AnimationUtility.GetAnimationClipSettings(clip);
        settings.loopTime = loop;
        AnimationUtility.SetAnimationClipSettings(clip, settings);
        AssetDatabase.CreateAsset(clip, path);
        return clip;
    }

    private static Sprite[] LoadSprites(string assetPath)
    {
        return AssetDatabase.LoadAllAssetsAtPath(assetPath)
            .OfType<Sprite>()
            .OrderBy(sprite => sprite.name)
            .ToArray();
    }
}
