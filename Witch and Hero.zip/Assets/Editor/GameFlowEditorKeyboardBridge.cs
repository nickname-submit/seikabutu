#if UNITY_EDITOR
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.InputSystem;

[InitializeOnLoad]
internal static class GameFlowEditorKeyboardBridge
{
    static GameFlowEditorKeyboardBridge()
    {
        EditorApplication.update += Update;
    }

    private static void Update()
    {
        if (!EditorApplication.isPlaying) return;

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null ||
            (!keyboard.enterKey.wasPressedThisFrame &&
             !keyboard.numpadEnterKey.wasPressedThisFrame &&
             !keyboard.spaceKey.wasPressedThisFrame))
            return;

        GameFlow flow = Object.FindAnyObjectByType<GameFlow>();
        if (flow == null) return;

        MethodInfo method = typeof(GameFlow).GetMethod(
            "ActivateTitleSelection", BindingFlags.Instance | BindingFlags.NonPublic);
        method?.Invoke(flow, null);
        EditorApplication.QueuePlayerLoopUpdate();
        InternalEditorUtility.RepaintAllViews();
    }

}
#endif
