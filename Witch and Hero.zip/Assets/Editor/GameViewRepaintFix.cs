#if UNITY_EDITOR
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

[InitializeOnLoad]
internal static class GameViewRepaintFix
{
    private static double nextRepaintTime;

    static GameViewRepaintFix()
    {
        EditorApplication.update += Update;
    }

    private static void Update()
    {
        if (!EditorApplication.isPlaying) return;
        if (EditorApplication.timeSinceStartup < nextRepaintTime) return;

        nextRepaintTime = EditorApplication.timeSinceStartup + 0.05d;
        EditorApplication.QueuePlayerLoopUpdate();
        InternalEditorUtility.RepaintAllViews();

        EditorWindow[] windows = Resources.FindObjectsOfTypeAll<EditorWindow>();
        for (int i = 0; i < windows.Length; i++)
        {
            if (windows[i] != null && windows[i].GetType().Name == "GameView")
                windows[i].Repaint();
        }
    }
}
#endif
