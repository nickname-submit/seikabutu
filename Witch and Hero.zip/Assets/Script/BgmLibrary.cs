using UnityEngine;

[CreateAssetMenu(fileName = "BgmLibrary", menuName = "Witch and Hero/BGM Library")]
public class BgmLibrary : ScriptableObject
{
    public AudioClip titleMusic;
    public AudioClip menuMusic;
    public AudioClip battleMusic;
    public AudioClip confirmSound;
    public AudioClip levelUpSound;
    public AudioClip defeatBell;
}
