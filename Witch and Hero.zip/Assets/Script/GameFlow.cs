using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameFlow : MonoBehaviour
{
    private enum GameState { Title, Menu, Battle, Result, Upgrade }
    private enum DefeatReason { WitchDefeated, HeroDefeated }

    // The front-end scene starts at the title screen.
    private GameState state = GameState.Title;
    private Witch witch;
    private Hero hero;
    private readonly Dictionary<int, GameObject> monsterSources = new Dictionary<int, GameObject>();
    private readonly List<Monster> spawnedMonsters = new List<Monster>();
    private StageCatalog catalog;
    private MonsterCatalog monsterCatalog;
    private StageDefinition currentStage;
    private Coroutine spawnRoutine;
    private int selectedStage;
    private bool stageInfoOpen;
    private int stageInfoStageId;
    private int stageInfoChoice;
    private bool spawning;
    private bool won;
    private DefeatReason defeatReason;
    private int experience;
    private int coins;
    private Sprite experienceOrbSprite;
    private Sprite coinSprite;
    private Texture2D mapCircleTexture;
    private Texture2D mapBackgroundTexture;
    private Texture2D nodeBuildingTexture;
    private Texture2D nodeNatureTexture;
    private Texture2D nodeMonsterTexture;
    private Sprite mapCircleSprite;
    private Sprite nodeBuildingSprite;
    private Sprite nodeNatureSprite;
    private Sprite nodeMonsterSprite;
    private Sprite uiWhiteSprite;
    private Texture2D guiButtonNormalBackground;
    private Texture2D guiButtonHoverBackground;
    private Texture2D guiButtonActiveBackground;
    private Vector2 mapScrollPosition;
    private Vector2 pendingMapScroll;
    private Vector2 pendingSkillTreeScroll;
    private Vector2 pendingMapDrag;
    private Vector2 pendingMapKeyboardPan;
    private bool lowLevelMapMouseHeld;
    private bool mapScrollInitialized;
    private bool mapDragging;
    private bool mapSuppressNodeClick;
    private Vector2 mapLastPointerPosition;
    private bool mapInputPointerHeld;
    private Vector2 mapInputLastPointerPosition;
    private int mapScrollHandledFrame = -1;
    private Vector2 skillTreePan;
    private bool skillTreePointerHeld;
    private bool skillTreeSuppressNodeClick;
    private Vector2 skillTreeLastPointerPosition;
    private int skillTreeScrollHandledFrame = -1;
    private bool mapOnlyScene;
    private GameObject titleButtonCanvasObject;
    private Button titleStageButton;
    private Button titleHelpButton;
    private Button titleHelpBackButton;
    private Button titleUpgradeButton;
    private Button mapTitleButton;
    private readonly Dictionary<Button, int> mapStageButtons = new Dictionary<Button, int>();
    private RectTransform titleStageButtonRect;
    private RectTransform titleHelpButtonRect;
    private RectTransform titleHelpBackButtonRect;
    private RectTransform titleUpgradeButtonRect;
    private RectTransform mapTitleButtonRect;
    private GameObject titleVisualRoot;
    private GameObject titleHelpVisualRoot;
    private GameObject mapVisualRoot;
    private GameObject upgradeVisualRoot;
    private GameObject mapWorldBackground;
    private Sprite mapWorldBackgroundSprite;
    private GameObject mapVisualPanel;
    private GameObject mapPanOverlay;
    private ScrollRect mapPanScrollRect;
    private RectTransform mapPanContent;
    private readonly List<Button> mapPanNodeButtons = new List<Button>();
    private bool updatingMapPanOverlay;
    private GameObject skillTreePanOverlay;
    private ScrollRect skillTreePanScrollRect;
    private RectTransform skillTreePanContent;
    private readonly List<Button> skillTreePanNodeButtons = new List<Button>();
    private bool updatingSkillTreePanOverlay;
    private ScrollRect mapCanvasScrollRect;
    private RectTransform mapCanvasContent;
    private bool updatingMapCanvasScroll;
    private Camera mapCamera;
    private Vector3 mapCameraHomePosition;
    private Vector2 mapCameraPan;
    private bool mapCameraConfigured;
    private int titleSelection;
    private bool titleHelpOpen;
    private bool resetProgressConfirm;
    private bool titleOverlayWasVisible;
    private static bool battleLoadRequested;
    private static bool returnToStageSelectRequested;
    private static bool sceneLoadHooked;
    private static GameFlow runtimeInstance;
    private bool mapVisualBuildPending;
    private bool runtimeInitialized = true;
    private GameObject witchSkillEffectObject;
    private LineRenderer witchSkillRing;
    private Material witchSkillEffectMaterial;
    private float witchSkillEffectTimer;
    private float witchSkillPortraitTimer;
    private Sprite witchPortraitSprite;
    private GameObject witchSkillPortraitCanvasObject;
    private Image witchSkillPortraitFrame;
    private Image witchSkillPortraitImage;
    private RectTransform witchSkillPortraitRect;
    private float nextWitchSkillTime;
    private BgmLibrary bgmLibrary;
    private AudioSource bgmAudioSource;
    private AudioSource sfxAudioSource;
    private AudioClip activeBgmClip;
    private bool bgmLookupAttempted;
#if UNITY_EDITOR
    private Vector2 editorGameViewOrigin;
    private Vector2 editorGameViewSize;
#endif

    private const string MapSceneName = "MapScene";
    private const string BattleSceneName = "SampleScene";
    private const string PendingStageKey = "WitchHero.PendingStage";
    private const string PendingStageInfoKey = "WitchHero.PendingStageInfo";
    private const string CoinBalanceKey = "WitchHero.CoinBalance";
    private const string SlashDamageLevelKey = "WitchHero.SlashDamageLevel";
    private const string HeroHealthLevelKey = "WitchHero.HeroHealthLevel";
    private const string WitchHealthLevelKey = "WitchHero.WitchHealthLevel";
    private const string HeroSpeedLevelKey = "WitchHero.HeroSpeedLevel";
    private const string SlashPierceLevelKey = "WitchHero.SlashPierceLevel";
    private const string AttackSpeedLevelKey = "WitchHero.AttackSpeedLevel";
    private const string CurrentMapStageKey = "WitchHero.CurrentMapStage";
    private const string HighestClearedStageKey = "WitchHero.HighestClearedStage";
    private const int BaseHeroHealth = 10;
    private const int BaseWitchHealth = 10;
    // The initial battle should feel deliberately slow and readable. Upgrade
    // nodes still raise the pace, but a fresh save gets plenty of reaction
    // time before enemies or attacks become hectic.
    private const float BaseHeroMoveSpeed = 2f;
    private const float BaseHeroAttackInterval = 0.8f;
    private const float AttackSpeedUpgradeAmount = 0.06f;
    private const float MinimumHeroAttackInterval = 0.4f;
    // A slash survives its first hit and disappears after the second unique
    // monster. The hitMonsters set prevents the same monster being hit twice.
    // No piercing before the first penetration upgrade. A fresh save should
    // destroy a slash on its first monster hit.
    private const int BaseSlashPiercingHits = 1;
    private const int HealthUpgradeAmount = 2;
    private const float SpeedUpgradeAmount = 0.4f;
    // One is the minimum meaningful hit. Make the fresh-game attack feel
    // weaker by giving the larger waves more time to survive each hit.
    private const int BaseSlashDamage = 1;
    // A clear should not immediately buy an upgrade. With one coin per
    // defeated monster, the first node now takes several completed runs even
    // on the later unlocked stages, making repeated clears meaningful.
    // Make the complete tree a long-term goal. The first node is reachable
    // after a few clears, while later nodes become progressively more costly.
    private const int SlashDamageUpgradeBaseCost = 25;
    private const int UpgradeCostStep = 8;
    private const int WitchSkillExperienceCost = 25;
    private const int WitchSkillDamage = 1;
    private const float WitchSkillCooldown = 0.8f;
    private const float WitchSkillEffectDuration = 0.24f;
    private const float WitchSkillPortraitDuration = 1.25f;
    private const string BgmLibraryResourcePath = "BgmLibrary";
    private const float BgmVolume = 0.45f;
    private const float SfxVolume = 0.55f;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetRuntimeState()
    {
        battleLoadRequested = false;
        returnToStageSelectRequested = false;
        sceneLoadHooked = false;
        runtimeInstance = null;
    }

    private const float MinX = -9.5f;
    private const float MaxX = 9.5f;
    private const float MinY = -5f;
    private const float MaxY = 5f;
    private const float MonsterHealthBarYOffset = 0.72f;
    private const int ExperiencePerOrb = 10;
    private const int ExperienceToNextLevel = 100;
    private const int CoinsPerDrop = 1;
    // More monsters should not turn a single clear into a large payday.
    private const float CoinDropChance = 0.35f;
    private const float MapCanvasScale = 0.01f;
    private const float MapCameraPanPixelsToWorld = 0.01f;
    private static readonly Vector2 MapCameraPanLimit = new Vector2(2.4f, 1.35f);

    // Front-end layout is authored at the same 1280x720 design resolution as
    // the CanvasScaler. Keep the title and world map large enough to use the
    // available Game view instead of leaving a small card in the middle.
    private const float TitlePanelWidth = 1000f;
    private const float TitlePanelHeight = 650f;
    private const float MapPanelWidth = 1180f;
    private const float MapPanelHeight = 680f;
    private const float MapViewportWidth = 1128f;
    private const float MapViewportHeight = 560f;
    private const float MapContentWidth = 1280f;
    private const float MapContentHeight = 800f;
    private const float MapNodeSize = 88f;
    private static readonly Vector2[] MapRoutePoints =
    {
        new Vector2(0.12f, 0.24f),
        new Vector2(0.23f, 0.32f),
        new Vector2(0.36f, 0.41f),
        new Vector2(0.49f, 0.38f),
        new Vector2(0.58f, 0.30f),
        new Vector2(0.72f, 0.32f),
        new Vector2(0.85f, 0.45f),
        new Vector2(0.78f, 0.61f),
        new Vector2(0.64f, 0.72f),
        new Vector2(0.43f, 0.67f)
    };
    // Give the skill tree a little more virtual space than the visible
    // viewport. The nodes stay centered, while drag/trackpad/WASD movement
    // can travel farther in every direction without changing the layout.
    private const float SkillTreeContentWidth = 1650f;
    private const float SkillTreeContentHeight = 1500f;
    // Each branch is made of separate purchase nodes. The saved integer for a
    // branch remains the number of purchased nodes, so old progress continues
    // to work while the UI now exposes level 1, 2, 3 and 4 individually.
    // Keep this data-driven so adding another branch later only needs new data.
    private const int AttackSpeedNodeIndex = 30;
    private const int AttackSpeedUnlockRequiredNodes = 8;
    private const float SkillTreeNodeSize = 112f;
    private const int SkillTreeGridColumns = 5;
    private const int SkillTreeGridRows = 6;
    // Keep the grid regular so every node has clear space around it and the
    // connecting segments are visually consistent in both directions.
    private const float SkillTreeGridSpacingX = 170f;
    private const float SkillTreeGridSpacingY = 150f;
    // Leave a little breathing room below the header so the first row never
    // competes with the title or the coin counter.
    private static readonly Vector2 SkillTreeCenterOffset = new Vector2(110f, 180f);
    private static readonly Vector2 SkillTreeRootOffset = new Vector2(0f, -480f);
    private const float FrontendReferenceWidth = 1280f;
    private const float FrontendReferenceHeight = 720f;
    private const float FrontendCanvasMatch = 0.5f;
    private static readonly string[] SkillUpgradeKeys =
    {
        SlashDamageLevelKey,
        HeroHealthLevelKey,
        WitchHealthLevelKey,
        HeroSpeedLevelKey,
        SlashPierceLevelKey,
        AttackSpeedLevelKey
    };
    private static readonly string[] SkillUpgradeNames =
    {
        "斬撃攻撃力",
        "ヒーロー体力",
        "魔女体力",
        "歩く速度",
        "斬撃貫通",
        "攻撃速度"
    };
    // Keep one attribute in each column so six purchase nodes form a long
    // vertical upgrade path. The final three nodes form the attack-speed branch.
    private static readonly int[] SkillNodeBranches =
    {
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        0, 1, 2, 3, 4,
        5, 5, 5
    };
    private static readonly int[] SkillNodeLevels =
    {
        0, 0, 0, 0, 0,
        1, 1, 1, 1, 1,
        2, 2, 2, 2, 2,
        3, 3, 3, 3, 3,
        4, 4, 4, 4, 4,
        5, 5, 5, 5, 5,
        0, 1, 2
    };
    // The first row is the set of entry nodes. Each later row depends on the
    // node directly above it, so the lines stay short, vertical, and easy to
    // follow while still allowing a different stat branch to be the gate.
    private static readonly int[] SkillNodePrerequisites =
    {
        -1, -1, -1, -1, -1,
        0, 1, 2, 3, 4,
        5, 6, 7, 8, 9,
        10, 11, 12, 13, 14,
        15, 16, 17, 18, 19,
        20, 21, 22, 23, 24,
        9, 30, 31
    };
    private const float MapHeroTokenSize = 76f;
    private const float MapHeroRunFrameDuration = 0.09f;
    private const float MapFocusMoveDuration = 0.65f;

    private Image mapHeroTokenImage;
    private RectTransform mapHeroTokenRect;
    private Coroutine mapHeroMoveRoutine;
    private Coroutine mapFocusRoutine;
    private int mapHeroStageId;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void CreateAtRuntime()
    {
        if (!sceneLoadHooked)
        {
            SceneManager.sceneLoaded += EnsureGameFlowForScene;
            sceneLoadHooked = true;
        }

        EnsureGameFlowForScene(SceneManager.GetActiveScene(), LoadSceneMode.Single);
    }

    private static void EnsureGameFlowForScene(Scene scene, LoadSceneMode mode)
    {
        if (FindAnyObjectByType<GameFlow>() != null) return;

        GameObject gameFlowObject = new GameObject("GameFlow");
        gameFlowObject.AddComponent<GameFlow>();
    }

    private void Awake()
    {
        if (runtimeInstance != null && runtimeInstance != this)
        {
            Destroy(gameObject);
            return;
        }

        runtimeInstance = this;
    }

    private void OnEnable()
    {
        InputSystem.onEvent += CaptureMapScrollEvent;
    }

    private void OnDisable()
    {
        InputSystem.onEvent -= CaptureMapScrollEvent;
    }

    private void CaptureMapScrollEvent(InputEventPtr eventPtr, InputDevice device)
    {
        if (device is Keyboard keyboard)
        {
            if (!eventPtr.IsA<StateEvent>() && !eventPtr.IsA<DeltaStateEvent>())
                return;

            if (keyboard.aKey.ReadValueFromEvent(eventPtr, out float aValue) && aValue > 0.5f)
                pendingMapKeyboardPan.x -= 1f;
            if (keyboard.dKey.ReadValueFromEvent(eventPtr, out float dValue) && dValue > 0.5f)
                pendingMapKeyboardPan.x += 1f;
            if (keyboard.wKey.ReadValueFromEvent(eventPtr, out float wValue) && wValue > 0.5f)
                pendingMapKeyboardPan.y -= 1f;
            if (keyboard.sKey.ReadValueFromEvent(eventPtr, out float sValue) && sValue > 0.5f)
                pendingMapKeyboardPan.y += 1f;
            return;
        }

        if (!(device is Mouse mouse)) return;

        if (mouse.leftButton.ReadValueFromEvent(eventPtr, out float leftButton))
            lowLevelMapMouseHeld = leftButton > 0.5f;

        if (lowLevelMapMouseHeld &&
            mouse.delta.ReadValueFromEvent(eventPtr, out Vector2 dragDelta) &&
            dragDelta.sqrMagnitude > 0.0001f)
        {
            pendingMapDrag += dragDelta;
        }

        if (mouse.scroll.ReadValueFromEvent(eventPtr, out Vector2 scroll) &&
            scroll.sqrMagnitude > 0.0001f)
        {
            pendingMapScroll += scroll;
            pendingSkillTreeScroll += scroll;
        }
    }

    private void Start()
    {
        if (runtimeInstance != this)
            return;

        coins = PlayerPrefs.GetInt(CoinBalanceKey, 0);
        witch = FindAnyObjectByType<Witch>(FindObjectsInactive.Include);
        hero = FindAnyObjectByType<Hero>(FindObjectsInactive.Include);

        Monster[] sceneMonsters = FindObjectsByType<Monster>(FindObjectsInactive.Include);
        for (int i = 0; i < sceneMonsters.Length; i++)
        {
            Monster sceneMonster = sceneMonsters[i];
            if (!monsterSources.ContainsKey(sceneMonster.TypeId))
                monsterSources.Add(sceneMonster.TypeId, sceneMonster.gameObject);
        }

        catalog = Resources.Load<StageCatalog>("StageCatalog");
        monsterCatalog = Resources.Load<MonsterCatalog>("MonsterCatalog");
        selectedStage = PlayerPrefs.GetInt(CurrentMapStageKey, 0);
        ClampSelectedStageToUnlocked();

        // MapScene is always the front-end map, even when battle objects from
        // another editor session are still discoverable during a scene reload.
        mapOnlyScene = SceneManager.GetActiveScene().name == MapSceneName ||
            witch == null || hero == null || monsterSources.Count == 0;
        if (mapOnlyScene)
        {
            bool openStageSelect = returnToStageSelectRequested;
            int pendingStageInfo = PlayerPrefs.GetInt(PendingStageInfoKey, 0);
            returnToStageSelectRequested = false;
            PlayerPrefs.DeleteKey(PendingStageKey);
            PlayerPrefs.DeleteKey(PendingStageInfoKey);
            PlayerPrefs.Save();
            // MapScene is the front end. Start at the title screen and open
            // the world map only after the player confirms.
            state = openStageSelect ? GameState.Menu : GameState.Title;
            ConfigureMapCamera();
            CreateMapWorldBackground();
            mapVisualBuildPending = false;
            mapScrollInitialized = false;
            GameObject[] staleOverlays = Resources.FindObjectsOfTypeAll<GameObject>();
            for (int i = 0; i < staleOverlays.Length; i++)
            {
                if (staleOverlays[i] != null && staleOverlays[i].name.StartsWith("TitleButtonOverlay"))
                {
                    staleOverlays[i].SetActive(false);
                    Destroy(staleOverlays[i]);
                }
            }
            CreateTitleButtonOverlay();
            CreateMapPanOverlay();
            if (openStageSelect)
            {
                if (titleVisualRoot != null)
                    titleVisualRoot.SetActive(false);
                if (mapVisualRoot != null)
                    mapVisualRoot.SetActive(true);
                CreateMapVisual();
                if (pendingStageInfo > 0)
                    OpenStageInfo(pendingStageInfo, false);
            }
            runtimeInitialized = true;
            RequestEditorRepaint();
            return;
        }

        // Keep the boss as a Resources prefab instead of a visible scene
        // object. StageCatalog can then add monsterId 5 without cluttering
        // the battle scene or changing the normal monster source setup.
        GameObject bossSource = Resources.Load<GameObject>("BossMonster");
        if (bossSource != null && !monsterSources.ContainsKey(5))
            monsterSources.Add(5, bossSource);

        ClearBattleObjects();
        witch.gameObject.SetActive(false);
        hero.gameObject.SetActive(false);
        foreach (GameObject source in monsterSources.Values)
        {
            if (source != null && source.scene.IsValid())
                source.SetActive(false);
        }
        if (!battleLoadRequested)
        {
            PlayerPrefs.DeleteKey(PendingStageKey);
            PlayerPrefs.Save();
            SceneManager.LoadScene(MapSceneName);
            return;
        }

        battleLoadRequested = false;
        int stageToStart = PlayerPrefs.GetInt(PendingStageKey, 0);
        PlayerPrefs.DeleteKey(PendingStageKey);
        PlayerPrefs.Save();
        if (stageToStart > 0)
        {
            // BattleSceneへ渡されたステージは、マップ上のボタン操作ではなく
            // シーン初期化から開始するため、StartStageの通常入力ガードを通す。
            state = GameState.Menu;
            mapVisualBuildPending = false;
            StartStage(stageToStart);
        }
        else
        {
            SceneManager.LoadScene(MapSceneName);
        }
    }

    private void UpdateBackgroundMusic()
    {
        if (!bgmLookupAttempted)
        {
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
            bgmLookupAttempted = true;
        }

        if (bgmLibrary == null)
            return;

        AudioClip desiredClip = GetDesiredBackgroundMusic();
        if (desiredClip == activeBgmClip)
        {
            if (desiredClip != null && bgmAudioSource != null && !bgmAudioSource.isPlaying)
                bgmAudioSource.Play();
            return;
        }

        if (bgmAudioSource == null)
        {
            GameObject bgmObject = new GameObject("BackgroundMusic");
            bgmObject.transform.SetParent(transform, false);
            bgmAudioSource = bgmObject.AddComponent<AudioSource>();
            bgmAudioSource.playOnAwake = false;
            bgmAudioSource.loop = true;
            bgmAudioSource.volume = BgmVolume;
            bgmAudioSource.spatialBlend = 0f;
        }

        bgmAudioSource.Stop();
        bgmAudioSource.clip = desiredClip;
        activeBgmClip = desiredClip;
        if (desiredClip != null)
            bgmAudioSource.Play();
    }

    private AudioClip GetDesiredBackgroundMusic()
    {
        bool isMapScene = mapOnlyScene || SceneManager.GetActiveScene().name == MapSceneName;
        if (isMapScene)
        {
            if (state == GameState.Title)
                return bgmLibrary.titleMusic;
            if (state == GameState.Menu || state == GameState.Upgrade)
                return bgmLibrary.menuMusic;
            return null;
        }

        return state == GameState.Battle ? bgmLibrary.battleMusic : null;
    }

    private void PlaySfx(AudioClip clip)
    {
        if (clip == null) return;

        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);

        if (sfxAudioSource == null)
        {
            GameObject sfxObject = new GameObject("SoundEffects");
            sfxObject.transform.SetParent(transform, false);
            sfxAudioSource = sfxObject.AddComponent<AudioSource>();
            sfxAudioSource.playOnAwake = false;
            sfxAudioSource.loop = false;
            sfxAudioSource.volume = SfxVolume;
            sfxAudioSource.spatialBlend = 0f;
        }

        sfxAudioSource.PlayOneShot(clip);
    }

    private void PlayConfirmSound()
    {
        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
        PlaySfx(bgmLibrary != null ? bgmLibrary.confirmSound : null);
    }

    private void PlayResultSound(bool isWin)
    {
        if (bgmLibrary == null)
            bgmLibrary = Resources.Load<BgmLibrary>(BgmLibraryResourcePath);
        PlaySfx(bgmLibrary != null
            ? (isWin ? bgmLibrary.levelUpSound : bgmLibrary.defeatBell)
            : null);
    }

    private void Update()
    {
        if (runtimeInstance != this)
            return;

        UpdateBackgroundMusic();

        // The editor Game view can stop repainting while this runtime-only
        // front end is driven by generated UI. Keep the actual preview and
        // camera movement visible while testing in Play mode.
        if (mapOnlyScene)
            RequestEditorRepaint();

        if (SceneManager.GetActiveScene().name == MapSceneName)
        {
            mapOnlyScene = true;
        }

        if (mapOnlyScene && !mapCameraConfigured)
            ConfigureMapCamera();

        if (mapOnlyScene && mapWorldBackground == null)
            CreateMapWorldBackground();

        EnsureMapVisualInitialized();
        EnsureMapHeroTokenVisible();
        UpdateTitleButtonOverlay();
        UpdateWitchSkillEffect();
        if (witchSkillPortraitTimer > 0f)
            witchSkillPortraitTimer = Mathf.Max(0f,
                witchSkillPortraitTimer - Time.deltaTime);
        UpdateWitchSkillPortrait();
        if (state == GameState.Title)
        {
            HandleTitleInput();
            return;
        }

        if (state == GameState.Menu)
        {
            if (stageInfoOpen)
            {
                HandleStageInfoInput();
                return;
            }

            HandleMapPointerInput();
            HandleMapNodeInput();
            return;
        }

        if (state == GameState.Upgrade)
        {
            HandleUpgradeInput();
            return;
        }

        if (state != GameState.Battle) return;

        spawnedMonsters.RemoveAll(monster => monster == null);
        HandleWitchSkillInput();

        if (witch == null || witch.IsDead)
        {
            Finish(false, DefeatReason.WitchDefeated);
            return;
        }

        if (hero == null || hero.IsDead)
        {
            Finish(false, DefeatReason.HeroDefeated);
            return;
        }

        if (!spawning && spawnedMonsters.Count == 0)
            Finish(true);
    }

    private void HandleWitchSkillInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null || !keyboard.eKey.wasPressedThisFrame)
            return;

        TryCastWitchSkill();
    }

    private void TryCastWitchSkill()
    {
        if (experience < WitchSkillExperienceCost ||
            Time.time < nextWitchSkillTime ||
            witch == null || witch.IsDead)
            return;

        Camera gameCamera = Camera.main;
        int targetCount = 0;
        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (IsMonsterOnScreen(monster, gameCamera))
                targetCount++;
        }

        // Do not consume experience when there is nothing on screen to hit.
        if (targetCount == 0)
            return;

        experience -= WitchSkillExperienceCost;
        nextWitchSkillTime = Time.time + WitchSkillCooldown;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (IsMonsterOnScreen(monster, gameCamera))
                monster.TakeWitchSkillHit(WitchSkillDamage);
        }

        CreateWitchSkillEffect();
        witchSkillPortraitTimer = WitchSkillPortraitDuration;
        CreateWitchSkillPortrait();
    }

    private bool IsMonsterOnScreen(Monster monster, Camera gameCamera)
    {
        if (monster == null || monster.IsDead || !monster.gameObject.activeInHierarchy)
            return false;

        if (gameCamera == null)
            return true;

        Vector3 viewport = gameCamera.WorldToViewportPoint(monster.transform.position);
        return viewport.z > 0f &&
            viewport.x >= -0.05f && viewport.x <= 1.05f &&
            viewport.y >= -0.05f && viewport.y <= 1.05f;
    }

    private void CreateWitchSkillEffect()
    {
        DestroyWitchSkillEffect();
        if (witch == null) return;

        witchSkillEffectObject = new GameObject("WitchSkillEffect");
        witchSkillEffectObject.transform.position = witch.transform.position;

        Shader effectShader = Shader.Find("Sprites/Default");
        if (effectShader == null) return;

        witchSkillEffectMaterial = new Material(effectShader)
        {
            hideFlags = HideFlags.HideAndDontSave
        };

        GameObject ringObject = new GameObject("Ring");
        ringObject.transform.SetParent(witchSkillEffectObject.transform, false);
        witchSkillRing = ringObject.AddComponent<LineRenderer>();
        ConfigureWitchSkillLine(witchSkillRing);

        witchSkillEffectTimer = WitchSkillEffectDuration;
        UpdateWitchSkillEffect();
    }

    private void CreateWitchSkillPortrait()
    {
        DestroyWitchSkillPortrait();

        Sprite portrait = GetWitchPortraitSprite();
        if (portrait == null)
            return;

        witchSkillPortraitCanvasObject = new GameObject(
            "WitchSkillPortraitCanvas");
        Canvas canvas = witchSkillPortraitCanvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 250;
        CanvasScaler scaler = witchSkillPortraitCanvasObject
            .AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = FrontendCanvasMatch;

        GameObject frameObject = new GameObject("PortraitFrame",
            typeof(RectTransform), typeof(Image));
        frameObject.transform.SetParent(
            witchSkillPortraitCanvasObject.transform, false);
        RectTransform frameRect = frameObject.GetComponent<RectTransform>();
        frameRect.anchorMin = new Vector2(0f, 1f);
        frameRect.anchorMax = new Vector2(0f, 1f);
        frameRect.pivot = new Vector2(0f, 1f);
        frameRect.anchoredPosition = new Vector2(18f, -146f);
        frameRect.sizeDelta = new Vector2(236f, 236f);
        witchSkillPortraitFrame = frameObject.GetComponent<Image>();
        witchSkillPortraitFrame.sprite = GetUiWhiteSprite();
        witchSkillPortraitFrame.raycastTarget = false;

        GameObject imageObject = new GameObject("Portrait",
            typeof(RectTransform), typeof(Image));
        imageObject.transform.SetParent(frameObject.transform, false);
        witchSkillPortraitRect = imageObject.GetComponent<RectTransform>();
        witchSkillPortraitRect.anchorMin = new Vector2(0.5f, 0.5f);
        witchSkillPortraitRect.anchorMax = new Vector2(0.5f, 0.5f);
        witchSkillPortraitRect.pivot = new Vector2(0.5f, 0.5f);
        witchSkillPortraitRect.anchoredPosition = Vector2.zero;
        witchSkillPortraitRect.sizeDelta = new Vector2(224f, 224f);
        witchSkillPortraitImage = imageObject.GetComponent<Image>();
        witchSkillPortraitImage.sprite = portrait;
        witchSkillPortraitImage.preserveAspect = true;
        witchSkillPortraitImage.raycastTarget = false;

        UpdateWitchSkillPortrait();
    }

    private void UpdateWitchSkillPortrait()
    {
        if (witchSkillPortraitCanvasObject == null ||
            witchSkillPortraitFrame == null || witchSkillPortraitImage == null)
            return;

        if (witchSkillPortraitTimer <= 0f)
        {
            DestroyWitchSkillPortrait();
            return;
        }

        float progress = 1f - witchSkillPortraitTimer / WitchSkillPortraitDuration;
        float fadeIn = Mathf.Clamp01(progress / 0.16f);
        float fadeOut = Mathf.Clamp01(witchSkillPortraitTimer / 0.22f);
        float alpha = Mathf.SmoothStep(0f, 1f, fadeIn) *
            Mathf.SmoothStep(0f, 1f, fadeOut);
        float scale = Mathf.Lerp(0.82f, 1f,
            Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(progress / 0.28f)));
        witchSkillPortraitRect.localScale = Vector3.one * scale;
        witchSkillPortraitFrame.color = new Color(0.03f, 0.05f, 0.08f,
            0.86f * alpha);
        witchSkillPortraitImage.color = new Color(1f, 1f, 1f, alpha);
    }

    private void DestroyWitchSkillPortrait()
    {
        if (witchSkillPortraitCanvasObject != null)
            Destroy(witchSkillPortraitCanvasObject);
        witchSkillPortraitCanvasObject = null;
        witchSkillPortraitFrame = null;
        witchSkillPortraitImage = null;
        witchSkillPortraitRect = null;
    }

    private void ConfigureWitchSkillLine(LineRenderer line)
    {
        line.useWorldSpace = false;
        line.loop = true;
        line.positionCount = 65;
        line.widthMultiplier = 0.1f;
        line.numCapVertices = 3;
        line.numCornerVertices = 3;
        line.material = witchSkillEffectMaterial;
        line.sortingOrder = 50;
    }

    private void UpdateWitchSkillEffect()
    {
        if (witchSkillEffectObject == null)
            return;

        witchSkillEffectTimer -= Time.deltaTime;
        if (witchSkillEffectTimer <= 0f || witch == null || witch.IsDead)
        {
            DestroyWitchSkillEffect();
            return;
        }

        witchSkillEffectObject.transform.position = witch.transform.position;
        float progress = 1f - witchSkillEffectTimer / WitchSkillEffectDuration;
        Camera gameCamera = Camera.main;
        float halfHeight = gameCamera != null && gameCamera.orthographic
            ? gameCamera.orthographicSize
            : 5f;
        float halfWidth = gameCamera != null && gameCamera.orthographic
            ? halfHeight * gameCamera.aspect
            : 8f;
        float screenRadius = Mathf.Sqrt(halfWidth * halfWidth + halfHeight * halfHeight) + 1f;
        float radius = Mathf.Lerp(0.2f, screenRadius, progress);
        float alpha = Mathf.Clamp01(1f - progress) * 0.78f;
        Color ringColor = new Color(0.38f, 0.9f, 1f, alpha);

        if (witchSkillRing != null)
        {
            witchSkillRing.widthMultiplier = Mathf.Lerp(0.11f, 0.035f, progress);
            witchSkillRing.startColor = ringColor;
            witchSkillRing.endColor = ringColor;
            for (int i = 0; i < 65; i++)
            {
                float angle = Mathf.PI * 2f * i / 64f;
                witchSkillRing.SetPosition(i, new Vector3(
                    Mathf.Cos(angle) * radius,
                    Mathf.Sin(angle) * radius,
                    -0.12f));
            }
        }

    }

    private void DestroyWitchSkillEffect()
    {
        if (witchSkillEffectObject != null)
            Destroy(witchSkillEffectObject);
        witchSkillEffectObject = null;
        witchSkillRing = null;

        if (witchSkillEffectMaterial != null)
            Destroy(witchSkillEffectMaterial);
        witchSkillEffectMaterial = null;
        witchSkillEffectTimer = 0f;
    }

    private void EnsureMapVisualInitialized()
    {
        bool mapPanelExists = mapVisualRoot != null &&
            mapVisualRoot.transform.Find("MapPanel") != null;
        if (state != GameState.Menu ||
            (mapVisualRoot != null && mapVisualPanel != null && mapPanelExists))
            return;

        if (!mapPanelExists)
            mapVisualPanel = null;

        GameObject existingOverlay = GameObject.Find("TitleButtonOverlay");
        if (existingOverlay != null)
        {
            Transform existingMap = existingOverlay.transform.Find("MapVisual");
            Transform existingPanel = existingMap != null
                ? existingMap.Find("MapPanel")
                : null;
            if (existingMap != null && existingPanel != null)
            {
                titleButtonCanvasObject = existingOverlay;
                mapVisualRoot = existingMap.gameObject;
                mapVisualPanel = existingPanel.gameObject;
                titleVisualRoot = existingOverlay.transform.Find("TitleVisual")?.gameObject;
                titleHelpVisualRoot = existingOverlay.transform.Find("TitleHelpVisual")?.gameObject;
                upgradeVisualRoot = existingOverlay.transform.Find("UpgradeVisual")?.gameObject;
                titleStageButton = existingOverlay.transform.Find("StageButton")?.GetComponent<Button>();
                titleHelpButton = existingOverlay.transform.Find("HelpButton")?.GetComponent<Button>();
                titleHelpBackButton = existingOverlay.transform.Find("HelpBackButton")?.GetComponent<Button>();
                titleUpgradeButton = existingOverlay.transform.Find("UpgradeButton")?.GetComponent<Button>();
                mapTitleButton = existingOverlay.transform.Find("MapTitleButton")?.GetComponent<Button>();
                titleStageButtonRect = titleStageButton != null
                    ? titleStageButton.GetComponent<RectTransform>() : null;
                titleHelpButtonRect = titleHelpButton != null
                    ? titleHelpButton.GetComponent<RectTransform>() : null;
                titleHelpBackButtonRect = titleHelpBackButton != null
                    ? titleHelpBackButton.GetComponent<RectTransform>() : null;
                titleUpgradeButtonRect = titleUpgradeButton != null
                    ? titleUpgradeButton.GetComponent<RectTransform>() : null;
                mapTitleButtonRect = mapTitleButton != null
                    ? mapTitleButton.GetComponent<RectTransform>() : null;
                mapPanOverlay = existingOverlay.transform.Find("MapPanInput")?.gameObject;
                skillTreePanOverlay = existingOverlay.transform.Find("SkillTreePanInput")?.gameObject;
                Transform existingMapArea = existingMap.Find("MapPanel/MapArea");
                mapCanvasScrollRect = existingMapArea != null
                    ? existingMapArea.GetComponent<ScrollRect>()
                    : null;
                Transform existingMapContent = existingMap.Find(
                    "MapPanel/MapArea/MapContent");
                mapCanvasContent = existingMapContent != null
                    ? existingMapContent.GetComponent<RectTransform>()
                    : null;
                Transform existingMapHero = existingMap.Find(
                    "MapPanel/MapArea/MapContent/MapHeroToken");
                if (existingMapHero != null)
                {
                    mapHeroTokenRect = existingMapHero.GetComponent<RectTransform>();
                    mapHeroTokenImage = existingMapHero.GetComponent<Image>();
                    RestoreMapHeroTokenVisual();
                }
                if (mapPanOverlay != null)
                {
                    mapPanScrollRect = mapPanOverlay.GetComponent<ScrollRect>();
                    mapPanContent = mapPanScrollRect != null
                        ? mapPanScrollRect.content
                        : null;
                }
                if (skillTreePanOverlay != null)
                {
                    skillTreePanScrollRect = skillTreePanOverlay.GetComponent<ScrollRect>();
                    skillTreePanContent = skillTreePanScrollRect != null
                        ? skillTreePanScrollRect.content
                        : null;
                    ConfigureSkillTreePanOverlayGeometry();
                }
                else
                {
                    CreateSkillTreePanOverlay();
                }
                if (mapHeroTokenRect == null && mapCanvasContent != null)
                    CreateMapHeroToken(GetStages());
                return;
            }
        }

        // A previous scene reload can leave a runtime overlay object behind
        // while the new GameFlow has lost its private references. Rebuild the
        // whole runtime UI so the visible map and its input ScrollRect always
        // belong to this GameFlow instance.
        GameObject staleOverlay = GameObject.Find("TitleButtonOverlay");
        if (staleOverlay != null)
            Destroy(staleOverlay);

        titleButtonCanvasObject = null;
        titleVisualRoot = null;
        titleHelpVisualRoot = null;
        mapVisualRoot = null;
        upgradeVisualRoot = null;
        titleStageButton = null;
        titleHelpButton = null;
        titleHelpBackButton = null;
        titleUpgradeButton = null;
        mapTitleButton = null;
        titleStageButtonRect = null;
        titleHelpButtonRect = null;
        titleHelpBackButtonRect = null;
        titleUpgradeButtonRect = null;
        mapTitleButtonRect = null;
        mapVisualPanel = null;
        mapPanOverlay = null;
        mapPanScrollRect = null;
        mapPanContent = null;
        skillTreePanOverlay = null;
        skillTreePanScrollRect = null;
        skillTreePanContent = null;
        skillTreePanNodeButtons.Clear();
        mapCanvasScrollRect = null;
        mapCanvasContent = null;
        CreateTitleButtonOverlay();
        CreateMapVisual();
        CreateMapPanOverlay();
        CreateSkillTreePanOverlay();
    }

    private void HandleTitleInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (titleHelpOpen)
        {
            bool closeWithKeyboard = keyboard != null &&
                (keyboard.escapeKey.wasPressedThisFrame ||
                 keyboard.enterKey.wasPressedThisFrame ||
                 keyboard.numpadEnterKey.wasPressedThisFrame ||
                 keyboard.spaceKey.wasPressedThisFrame);
            if (closeWithKeyboard)
                CloseTitleHelp();
            return;
        }

        HandleTitleKeyboardNavigation();
        bool confirmPressed = keyboard != null &&
            (keyboard.enterKey.wasPressedThisFrame ||
             keyboard.numpadEnterKey.wasPressedThisFrame ||
             keyboard.spaceKey.wasPressedThisFrame);
        // Mouse clicks are handled by the transparent IMGUI targets in
        // DrawOverlayInputTargets. Handling the global mouse button here
        // would make clicking the help button open the stage map first.
        if (confirmPressed)
        {
            ActivateTitleSelection();
        }
    }

    private void HandleTitleKeyboardNavigation()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        bool movedUp = keyboard.upArrowKey.wasPressedThisFrame ||
            keyboard.wKey.wasPressedThisFrame;
        bool movedDown = keyboard.downArrowKey.wasPressedThisFrame ||
            keyboard.sKey.wasPressedThisFrame;

        if (movedUp || movedDown)
        {
            // Title menu entries are stage select and operation help.
            titleSelection = titleSelection == 0 ? 1 : 0;
            EventSystem.current?.SetSelectedGameObject(
                titleSelection == 0 ? titleStageButton?.gameObject : titleHelpButton?.gameObject);
        }
    }

    private void ActivateTitleSelection()
    {
        if (state != GameState.Title) return;
        if (titleSelection == 0)
            OpenStageMenu();
        else
            OpenTitleHelp();
    }

    private void OpenTitleHelp()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = true;
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(false);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(true);
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void CloseTitleHelp()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = false;
        titleSelection = 0;
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(false);
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(true);
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void HandleMapNodeInput()
    {
        List<StageDefinition> stages = GetStages();
        if (stages.Count == 0) return;

        if (selectedStage <= 0)
            selectedStage = stages[0].stageId;

        int lastUnlockedIndex = GetLastUnlockedStageIndex(stages);
        int selectedIndex = stages.FindIndex(stage =>
            stage.stageId == selectedStage);
        if (selectedIndex < 0 || selectedIndex > lastUnlockedIndex)
        {
            selectedIndex = Mathf.Clamp(lastUnlockedIndex, 0, stages.Count - 1);
            selectedStage = stages[selectedIndex].stageId;
        }

        Vector2 lowLevelKeyboardDirection = pendingMapKeyboardPan;
        pendingMapKeyboardPan = Vector2.zero;
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            bool moveNext = keyboard.rightArrowKey.wasPressedThisFrame ||
                keyboard.downArrowKey.wasPressedThisFrame ||
                keyboard.dKey.wasPressedThisFrame ||
                keyboard.sKey.wasPressedThisFrame ||
                lowLevelKeyboardDirection.x > 0.5f ||
                lowLevelKeyboardDirection.y > 0.5f;
            bool movePrevious = keyboard.leftArrowKey.wasPressedThisFrame ||
                keyboard.upArrowKey.wasPressedThisFrame ||
                keyboard.aKey.wasPressedThisFrame ||
                keyboard.wKey.wasPressedThisFrame ||
                lowLevelKeyboardDirection.x < -0.5f ||
                lowLevelKeyboardDirection.y < -0.5f;
            int currentIndex = stages.FindIndex(stage => stage.stageId == selectedStage);
            if (currentIndex < 0 || currentIndex > lastUnlockedIndex)
                currentIndex = selectedIndex;

            if (moveNext || movePrevious)
            {
                int direction = moveNext ? 1 : -1;
                int nextIndex = currentIndex + direction;
                // The route has two ends. Do not wrap the keyboard selection
                // from the first stage to the last (or vice versa).
                if (nextIndex < 0 || nextIndex > lastUnlockedIndex)
                    return;

                selectedStage = stages[nextIndex].stageId;
                EventSystem.current?.SetSelectedGameObject(null);
                MoveMapHeroToStage(selectedStage);
                RequestEditorRepaint();
                return;
            }

            bool confirmPressed = keyboard.enterKey.wasPressedThisFrame ||
                keyboard.numpadEnterKey.wasPressedThisFrame ||
                keyboard.spaceKey.wasPressedThisFrame;
            if (confirmPressed)
            {
                EventSystem.current?.SetSelectedGameObject(null);
                OpenStageInfo(selectedStage);
                return;
            }
        }

        // Pointer selection and panning are handled by HandleMapPointerInput
        // so the map has one input path and never needs a second click.
    }

    private void HandleStageInfoInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.escapeKey.wasPressedThisFrame)
            {
                CloseStageInfo();
                return;
            }

            bool moveLeft = keyboard.leftArrowKey.wasPressedThisFrame ||
                keyboard.aKey.wasPressedThisFrame;
            bool moveRight = keyboard.rightArrowKey.wasPressedThisFrame ||
                keyboard.dKey.wasPressedThisFrame;
            if (moveLeft || moveRight)
            {
                stageInfoChoice = stageInfoChoice == 0 ? 1 : 0;
                RequestEditorRepaint();
                return;
            }

            bool confirmPressed = keyboard.enterKey.wasPressedThisFrame ||
                keyboard.numpadEnterKey.wasPressedThisFrame ||
                keyboard.spaceKey.wasPressedThisFrame;
            if (confirmPressed)
            {
                if (stageInfoChoice == 0)
                    ConfirmStageInfo();
                else
                    CloseStageInfo();
                return;
            }
        }

        Mouse mouse = Mouse.current;
        if (mouse == null || !mouse.leftButton.wasPressedThisFrame) return;

        Vector2 guiPoint = mouse.position.ReadValue();
        guiPoint.y = Screen.height - guiPoint.y;
        GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect);
        if (challengeRect.Contains(guiPoint))
            ConfirmStageInfo();
        else if (cancelRect.Contains(guiPoint))
            CloseStageInfo();
    }

    private void OpenStageInfo(int stageId, bool playConfirmSound = true)
    {
        if (state != GameState.Menu || mapVisualBuildPending) return;

        List<StageDefinition> stages = GetStages();
        int stageIndex = stages.FindIndex(stage => stage.stageId == stageId);
        if (stageIndex < 0 || !IsStageUnlocked(stages, stageIndex)) return;

        if (playConfirmSound)
            PlayConfirmSound();

        selectedStage = stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, stageId);
        PlayerPrefs.Save();
        MoveMapHeroToStage(stageId);
        stageInfoStageId = stageId;
        stageInfoChoice = 0;
        stageInfoOpen = true;
        mapDragging = false;
        mapInputPointerHeld = false;
        mapSuppressNodeClick = true;
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void ConfirmStageInfo()
    {
        if (!stageInfoOpen) return;

        PlayConfirmSound();
        int stageId = stageInfoStageId;
        stageInfoOpen = false;
        stageInfoStageId = 0;
        StartStage(stageId);
    }

    private void CloseStageInfo()
    {
        PlayConfirmSound();
        stageInfoOpen = false;
        stageInfoStageId = 0;
        stageInfoChoice = 0;
        mapSuppressNodeClick = false;
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private StageDefinition GetStageInfoDefinition()
    {
        List<StageDefinition> stages = GetStages();
        return stages.Find(stage => stage.stageId == stageInfoStageId);
    }

    private void GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect)
    {
        const float popupWidth = 560f;
        const float popupHeight = 380f;
        float popupX = (Screen.width - popupWidth) * 0.5f;
        float popupY = (Screen.height - popupHeight) * 0.5f;
        float buttonWidth = popupWidth - 110f;
        float buttonHeight = 64f;
        float buttonX = popupX + 55f;
        challengeRect = new Rect(buttonX, popupY + 198f, buttonWidth, buttonHeight);
        cancelRect = new Rect(buttonX, popupY + 274f, buttonWidth, buttonHeight);
    }

    private void HandleMapPointerInput()
    {
        Mouse mouse = Mouse.current;
        if (mouse == null) return;

        Vector2 lowLevelDrag = pendingMapDrag;
        pendingMapDrag = Vector2.zero;

        float panelWidth = Mathf.Min(MapPanelWidth, Screen.width - 20f);
        float panelHeight = Mathf.Min(MapPanelHeight, Screen.height - 20f);
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            (Screen.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
        Rect viewport = GetMapViewportScreenRect();
        Rect content = new Rect(0f, 0f, 1280f, 800f);

        Vector2 pointer = mouse.position.ReadValue();
        pointer.y = Screen.height - pointer.y;
        bool inside = viewport.Contains(pointer);
        Vector2 pointerDelta = mouse.delta.ReadValue();

        // Keep the last idle position as a fallback for editor/GameView
        // backends that deliver a complete drag as one pressed+released
        // frame and omit Mouse.delta.
        if (!mapInputPointerHeld && !mouse.leftButton.wasPressedThisFrame)
            mapInputLastPointerPosition = pointer;

        if (mouse.leftButton.wasPressedThisFrame && inside)
        {
            mapInputPointerHeld = true;
            mapSuppressNodeClick = false;
            mapInputLastPointerPosition = pointer;
        }

        if (lowLevelDrag.sqrMagnitude > 0.01f && (inside || mapInputPointerHeld))
        {
            mapSuppressNodeClick = true;
            // A left-drag moves the map together with the pointer. Convert
            // pointer movement to the content scroll offset on both axes.
            ApplyMapScroll(-lowLevelDrag, content, viewport);
        }

        if (mapInputPointerHeld && mouse.leftButton.isPressed)
        {
            Vector2 delta = pointer - mapInputLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                mapSuppressNodeClick = true;
                ApplyMapScroll(-delta, content, viewport);
                mapInputLastPointerPosition = pointer;
            }
        }

        // Some editor/GameView input backends deliver a complete drag as a
        // press and release in the same frame. Use the Input System delta as
        // a fallback so that drag still pans the map in that case.
        if (mouse.leftButton.wasPressedThisFrame &&
            mouse.leftButton.wasReleasedThisFrame &&
            pointerDelta.sqrMagnitude > 0.01f && inside)
        {
            mapSuppressNodeClick = true;
            ApplyMapScroll(-pointerDelta, content, viewport);
        }

        if (mapInputPointerHeld && mouse.leftButton.wasReleasedThisFrame)
        {
            if (!mapSuppressNodeClick && inside)
            {
                List<StageDefinition> stages = GetStages();
                Vector2 contentPoint = pointer - viewport.position + mapScrollPosition;
                for (int i = 0; i < stages.Count; i++)
                {
                    Vector2 nodePosition = GetStageNodePosition(content, i, stages.Count);
                    Rect nodeRect = new Rect(nodePosition.x - MapNodeSize * 0.5f,
                        nodePosition.y - MapNodeSize * 0.5f, MapNodeSize, MapNodeSize);
                    if (nodeRect.Contains(contentPoint))
                    {
                        OpenStageInfo(stages[i].stageId);
                        break;
                    }
                }
            }
            mapInputPointerHeld = false;
        }

        Vector2 wheel = pendingMapScroll;
        pendingMapScroll = Vector2.zero;
        if (wheel.sqrMagnitude <= 0.0001f)
            wheel = mouse.scroll.ReadValue();
        if (wheel.sqrMagnitude <= 0.0001f)
        {
            // macOS trackpads can appear as a separate Mouse device from the
            // device returned by Mouse.current. Check every connected Mouse
            // so their scroll events reach the same map position.
            for (int i = 0; i < InputSystem.devices.Count; i++)
            {
                Mouse otherMouse = InputSystem.devices[i] as Mouse;
                if (otherMouse == null || otherMouse == mouse) continue;

                wheel = otherMouse.scroll.ReadValue();
                if (wheel.sqrMagnitude > 0.0001f)
                    break;
            }
        }

        if (wheel.sqrMagnitude > 0.0001f &&
            mapScrollHandledFrame != Time.frameCount)
        {
            // Trackpad horizontal scrolling has the opposite sign from the
            // vertical scroll convention used by the map camera.
            ApplyMapScroll(new Vector2(wheel.x, -wheel.y) * 24f,
                content, viewport);
        }
    }

    private void ApplyMapScroll(Vector2 delta, Rect content, Rect viewport)
    {
        if (delta.sqrMagnitude <= 0.0001f) return;

        // The map is a world-space canvas. Panning changes the actual MapScene
        // camera, so the whole map moves together instead of only changing a
        // UI content offset.
        if (mapCameraConfigured)
        {
            ApplyMapCameraPan(delta);
            mapScrollHandledFrame = Time.frameCount;
            RequestEditorRepaint();
            return;
        }

        if (mapCanvasScrollRect != null && mapVisualRoot != null &&
            mapVisualRoot.activeInHierarchy)
        {
            float maxX = Mathf.Max(0f, mapCanvasContent.rect.width - MapViewportWidth);
            float maxY = Mathf.Max(0f, mapCanvasContent.rect.height - MapViewportHeight);
            Vector2 normalized = mapCanvasScrollRect.normalizedPosition;
            normalized.x = maxX <= 0f
                ? 0.5f
                : Mathf.Clamp01(normalized.x + delta.x / maxX);
            normalized.y = maxY <= 0f
                ? 0.5f
                : Mathf.Clamp01(normalized.y - delta.y / maxY);

            updatingMapCanvasScroll = true;
            mapCanvasScrollRect.normalizedPosition = normalized;
            updatingMapCanvasScroll = false;
            mapScrollPosition = new Vector2(
                normalized.x * maxX,
                (1f - normalized.y) * maxY);
            mapScrollInitialized = true;
            mapScrollHandledFrame = Time.frameCount;
            RequestEditorRepaint();
            return;
        }

        mapScrollPosition += delta;
        ClampMapScroll(content, viewport);
        SyncMapPanOverlayFromPosition();
        mapScrollHandledFrame = Time.frameCount;
        RequestEditorRepaint();
    }

    private void HandleMapKeyboardPan()
    {
        // WASD and the arrow keys select the adjacent stage. Keep map
        // panning on pointer/trackpad input so one key press cannot move the
        // map and the hero in different directions at the same time.
        pendingMapKeyboardPan = Vector2.zero;
    }

    private void ConfigureMapCamera()
    {
        mapCamera = FindActiveSceneCamera();
        if (mapCamera == null)
            mapCamera = FindAnyObjectByType<Camera>(FindObjectsInactive.Include);
        if (mapCamera == null)
        {
            Camera[] sceneCameras = FindObjectsByType<Camera>(
                FindObjectsInactive.Include);
            if (sceneCameras.Length > 0)
                mapCamera = sceneCameras[0];
        }
        if (mapCamera == null) return;

        Camera[] allCameras = FindObjectsByType<Camera>(
            FindObjectsInactive.Include);
        for (int i = 0; i < allCameras.Length; i++)
        {
            if (allCameras[i] != null && allCameras[i] != mapCamera)
                allCameras[i].enabled = false;
        }

        mapCamera.orthographic = true;
        mapCamera.orthographicSize = 3.6f;
        mapCamera.enabled = true;
        mapCamera.targetTexture = null;
        mapCamera.targetDisplay = 0;
        mapCamera.forceIntoRenderTexture = false;
        mapCamera.rect = new Rect(0f, 0f, 1f, 1f);
        mapCamera.depth = 100f;
        mapCamera.clearFlags = CameraClearFlags.SolidColor;
        mapCamera.backgroundColor = new Color(0.025f, 0.06f, 0.10f, 1f);
        mapCamera.cullingMask = ~0;
        mapCamera.transform.position = new Vector3(0f, 0f, -10f);
        mapCamera.transform.rotation = Quaternion.identity;
        mapCameraHomePosition = mapCamera.transform.position;
        mapCameraPan = Vector2.zero;
        mapCameraConfigured = true;
    }

    private void CreateMapWorldBackground()
    {
        if (mapWorldBackground != null) return;

        Texture2D texture = GetMapBackgroundTexture();
        if (texture == null) return;

        mapWorldBackground = new GameObject("MapWorldBackground");
        mapWorldBackground.transform.position = new Vector3(0f, 0f, 1f);
        SpriteRenderer renderer = mapWorldBackground.AddComponent<SpriteRenderer>();
        float pixelsPerUnit = texture.width / 12.8f;
        mapWorldBackgroundSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            pixelsPerUnit);
        mapWorldBackgroundSprite.name = "RuntimeMapBackgroundSprite";
        renderer.sprite = mapWorldBackgroundSprite;
        // MapScene has no 2D light. Sprite-Lit-Default therefore renders the
        // background black in the Editor Game view; use an unlit shader.
        Shader unlitShader = Shader.Find("Universal Render Pipeline/2D/Sprite-Unlit-Default");
        if (unlitShader == null)
            unlitShader = Shader.Find("Sprites/Default");
        if (unlitShader != null)
        {
            Material unlitMaterial = new Material(unlitShader)
            {
                name = "RuntimeMapBackgroundUnlit",
                hideFlags = HideFlags.HideAndDontSave
            };
            renderer.sharedMaterial = unlitMaterial;
        }
        renderer.sortingOrder = -10;
    }

    private Camera FindActiveSceneCamera()
    {
        Scene activeScene = SceneManager.GetActiveScene();
        Camera[] cameras = FindObjectsByType<Camera>(
            FindObjectsInactive.Include);
        Camera fallback = null;
        for (int i = 0; i < cameras.Length; i++)
        {
            Camera candidate = cameras[i];
            if (candidate == null || candidate.gameObject.scene != activeScene)
                continue;
            if (fallback == null)
                fallback = candidate;
            if (candidate.gameObject.name == "Main Camera")
                return candidate;
        }

        return fallback;
    }

    private void ApplyMapCameraPan(Vector2 screenDelta)
    {
        if (!mapCameraConfigured || mapCamera == null) return;

        mapCameraPan += screenDelta * MapCameraPanPixelsToWorld;
        mapCameraPan.x = Mathf.Clamp(mapCameraPan.x,
            -MapCameraPanLimit.x, MapCameraPanLimit.x);
        mapCameraPan.y = Mathf.Clamp(mapCameraPan.y,
            -MapCameraPanLimit.y, MapCameraPanLimit.y);
        mapCamera.transform.position = mapCameraHomePosition +
            new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);

        // Apply the same input delta to the visible map immediately. The
        // visible map is drawn in the Game view, so this keeps its movement
        // deterministic even while the Editor is repainting the camera.
        mapScrollPosition += screenDelta;
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f,
            MapContentWidth - MapViewportWidth);
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f,
            MapContentHeight - MapViewportHeight);
        mapScrollInitialized = true;
        ApplyMapCanvasContentOffset();
    }

    private void ApplyMapCanvasContentOffset()
    {
        if (mapCanvasContent == null || mapVisualRoot == null) return;

        Canvas canvas = mapVisualRoot.GetComponentInParent<Canvas>();
        if (canvas == null || canvas.renderMode != RenderMode.ScreenSpaceOverlay)
            return;

        mapCanvasContent.anchoredPosition = new Vector2(
            -mapScrollPosition.x, mapScrollPosition.y);
    }

    private void SyncMapVisualToCamera()
    {
        Camera activeSceneCamera = FindActiveSceneCamera();
        if (activeSceneCamera != null)
            mapCamera = activeSceneCamera;

        if (!mapCameraConfigured || mapCamera == null) return;

        const float contentWidth = MapContentWidth;
        const float contentHeight = MapContentHeight;
        const float viewportWidth = MapViewportWidth;
        const float viewportHeight = MapViewportHeight;
        float maxScrollX = contentWidth - viewportWidth;
        float maxScrollY = contentHeight - viewportHeight;

        Vector2 cameraOffset = new Vector2(
            mapCamera.transform.position.x - mapCameraHomePosition.x,
            mapCameraHomePosition.y - mapCamera.transform.position.y);
        mapScrollPosition = new Vector2(
            maxScrollX * 0.5f + cameraOffset.x / MapCameraPanLimit.x * maxScrollX * 0.5f,
            maxScrollY * 0.5f + cameraOffset.y / MapCameraPanLimit.y * maxScrollY * 0.5f);
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f, maxScrollX);
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f, maxScrollY);
        mapScrollInitialized = true;
        ApplyMapCanvasContentOffset();
    }

    private Rect GetMapViewportScreenRect()
    {
        Canvas mapCanvas = mapVisualRoot != null
            ? mapVisualRoot.GetComponentInParent<Canvas>()
            : null;
        if (mapCanvas != null && mapCanvas.renderMode == RenderMode.WorldSpace &&
            mapCamera != null && mapVisualRoot != null && mapVisualRoot.activeInHierarchy)
        {
            Transform viewportTransform = mapVisualRoot.transform.Find("MapPanel/MapArea");
            RectTransform viewportRect = viewportTransform != null
                ? viewportTransform.GetComponent<RectTransform>()
                : null;
            if (viewportRect != null)
            {
                Vector3[] corners = new Vector3[4];
                viewportRect.GetWorldCorners(corners);
                float minX = float.MaxValue;
                float maxX = float.MinValue;
                float minY = float.MaxValue;
                float maxY = float.MinValue;
                for (int i = 0; i < corners.Length; i++)
                {
                    Vector3 screen = mapCamera.WorldToScreenPoint(corners[i]);
                    float guiY = Screen.height - screen.y;
                    minX = Mathf.Min(minX, screen.x);
                    maxX = Mathf.Max(maxX, screen.x);
                    minY = Mathf.Min(minY, guiY);
                    maxY = Mathf.Max(maxY, guiY);
                }

                return Rect.MinMaxRect(minX, minY, maxX, maxY);
            }
        }

        float panelWidth = Mathf.Min(MapPanelWidth, Screen.width - 20f);
        float panelHeight = Mathf.Min(MapPanelHeight, Screen.height - 20f);
        Rect panel = new Rect(
            (Screen.width - panelWidth) * 0.5f,
            (Screen.height - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
        return new Rect(panel.x + 22f, panel.y + 58f,
            panel.width - 44f, panel.height - 76f);
    }

    private void CreateTitleButtonOverlay()
    {
        if (titleButtonCanvasObject != null) return;

        GameObject eventSystemObject = FindAnyObjectByType<EventSystem>()?.gameObject;
        if (eventSystemObject == null)
        {
            eventSystemObject = new GameObject("UI EventSystem");
            eventSystemObject.AddComponent<EventSystem>();
        }

        InputSystemUIInputModule inputModule =
            eventSystemObject.GetComponent<InputSystemUIInputModule>();
        if (inputModule == null)
            inputModule = eventSystemObject.AddComponent<InputSystemUIInputModule>();
        inputModule.AssignDefaultActions();
        inputModule.enabled = true;

        BaseInputModule[] otherInputModules =
            eventSystemObject.GetComponents<BaseInputModule>();
        for (int i = 0; i < otherInputModules.Length; i++)
        {
            if (otherInputModules[i] != inputModule)
                otherInputModules[i].enabled = false;
        }

        titleButtonCanvasObject = new GameObject("TitleButtonOverlay");
        Canvas canvas = titleButtonCanvasObject.AddComponent<Canvas>();
        // Screen-space rendering is reliable in the Unity Editor Game view.
        // Camera panning is mirrored to MapContent so the visible map moves
        // together with the real MapScene camera.
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;
        CanvasScaler scaler = titleButtonCanvasObject.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        RectTransform canvasRect = titleButtonCanvasObject.GetComponent<RectTransform>();
        canvasRect.sizeDelta = new Vector2(1280f, 720f);
        titleButtonCanvasObject.transform.position = Vector3.zero;
        titleButtonCanvasObject.transform.rotation = Quaternion.identity;
        titleButtonCanvasObject.transform.localScale = Vector3.one;
        titleButtonCanvasObject.AddComponent<GraphicRaycaster>();

        titleStageButton = CreateTitleButton("StageButton", OpenStageMenu, out titleStageButtonRect);
        titleHelpButton = CreateTitleButton("HelpButton", OpenTitleHelp, out titleHelpButtonRect);
        titleHelpBackButton = CreateTitleButton("HelpBackButton", CloseTitleHelp,
            out titleHelpBackButtonRect);
        titleUpgradeButton = CreateTitleButton("UpgradeButton", OpenUpgradeMenu, out titleUpgradeButtonRect);
        mapTitleButton = CreateTitleButton("MapTitleButton", ReturnToTitle,
            out mapTitleButtonRect);
        titleStageButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleHelpButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleHelpBackButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        titleUpgradeButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        mapTitleButton.transform.SetParent(titleButtonCanvasObject.transform, false);
        SetTitleButtonRect(titleStageButtonRect, 240f, 335f, 800f, 86f);
        SetTitleButtonRect(titleHelpButtonRect, 240f, 435f, 800f, 70f);
        SetTitleButtonRect(titleHelpBackButtonRect, 240f, 570f, 800f, 58f);
        SetTitleButtonRect(titleUpgradeButtonRect, 980f, 650f, 220f, 42f);
        SetTitleButtonRect(mapTitleButtonRect, 80f, 650f, 220f, 42f);


        Navigation stageNavigation = new Navigation { mode = Navigation.Mode.Explicit };
        stageNavigation.selectOnDown = titleHelpButton;
        titleStageButton.navigation = stageNavigation;

        Navigation helpNavigation = new Navigation { mode = Navigation.Mode.Explicit };
        helpNavigation.selectOnUp = titleStageButton;
        titleHelpButton.navigation = helpNavigation;

        CreateUiText(titleStageButton.transform, "ステージを選ぶ", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleHelpButton.transform, "操作説明", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleHelpBackButton.transform, "タイトルへ戻る", 18, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(titleUpgradeButton.transform, "強化画面", 20, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);
        CreateUiText(mapTitleButton.transform, "タイトルへ戻る", 18, Color.white,
            TextAnchor.MiddleCenter, Vector2.zero, Vector2.zero);

        titleVisualRoot = CreateUiRoot("TitleVisual");
        titleHelpVisualRoot = CreateUiRoot("TitleHelpVisual");
        mapVisualRoot = CreateUiRoot("MapVisual");
        RectTransform mapRootRect = mapVisualRoot.GetComponent<RectTransform>();
        mapRootRect.anchorMin = new Vector2(0.5f, 0.5f);
        mapRootRect.anchorMax = new Vector2(0.5f, 0.5f);
        mapRootRect.sizeDelta = new Vector2(1280f, 720f);
        mapRootRect.anchoredPosition = Vector2.zero;
        upgradeVisualRoot = CreateUiRoot("UpgradeVisual");
        CreateTitleVisual(titleVisualRoot.transform);
        CreateTitleHelpVisual(titleHelpVisualRoot.transform);
        CreateUpgradeVisual(upgradeVisualRoot.transform);
        CreateSkillTreePanOverlay();
        // Keep the title background behind the two visible button objects.
        titleVisualRoot.transform.SetAsFirstSibling();
        titleHelpVisualRoot.transform.SetAsFirstSibling();
        titleHelpVisualRoot.SetActive(false);
    }

    private GameObject CreateUiRoot(string objectName)
    {
        GameObject root = new GameObject(objectName, typeof(RectTransform));
        root.transform.SetParent(titleButtonCanvasObject.transform, false);
        RectTransform rect = root.GetComponent<RectTransform>();
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
        return root;
    }

    private void CreateTitleVisual(Transform root)
    {
        CreateUiImage(root, "TitleBackground", Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);

        GameObject panel = CreateUiImage(root, "TitlePanel", Vector2.zero,
            new Vector2(TitlePanelWidth, TitlePanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        CreateUiImage(panel.transform, "TitlePanelTopLine", new Vector2(0f, 313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "TitlePanelBottomLine", new Vector2(0f, -313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiText(panel.transform, "WITCH & HERO", 52, Color.white,
            TextAnchor.MiddleCenter, new Vector2(0f, 148f), new Vector2(860f, 80f));
        CreateUiText(panel.transform, "魔女と勇者の小さな冒険", 22,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, 82f), new Vector2(860f, 42f));
        CreateUiText(panel.transform, "↑↓で選択 / ENTER・SPACEで決定", 18,
            new Color(0.72f, 0.82f, 0.88f), TextAnchor.MiddleCenter,
            new Vector2(0f, -276f), new Vector2(860f, 34f));
    }

    private void CreateTitleHelpVisual(Transform root)
    {
        CreateUiImage(root, "HelpBackground", Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);

        GameObject panel = CreateUiImage(root, "HelpPanel", Vector2.zero,
            new Vector2(TitlePanelWidth, TitlePanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        CreateUiImage(panel.transform, "HelpPanelTopLine", new Vector2(0f, 313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "HelpPanelBottomLine", new Vector2(0f, -313f),
            new Vector2(920f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiText(panel.transform, "操作説明", 42, Color.white,
            TextAnchor.MiddleCenter, new Vector2(0f, 235f), new Vector2(860f, 64f));
        CreateUiText(panel.transform, "タイトル画面・ワールドマップ", 18,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, 190f), new Vector2(860f, 34f));

        CreateUiText(panel.transform, "WASD / 矢印キー", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, 115f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "メニューの移動・ステージ選択", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, 115f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "ENTER / SPACE", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, 55f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "決定・ステージ情報を開く", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, 55f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "クリック / ドラッグ", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, -5f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "ノードを選ぶ・マップを動かす", 20,
            new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, -5f), new Vector2(500f, 42f));

        CreateUiText(panel.transform, "戦闘中", 24, Color.white,
            TextAnchor.MiddleLeft, new Vector2(-300f, -65f), new Vector2(300f, 42f));
        CreateUiText(panel.transform, "WASD / 矢印キー：ヒーロー移動　 E：魔女スキル",
            18, new Color(0.78f, 0.88f, 0.92f), TextAnchor.MiddleLeft,
            new Vector2(25f, -65f), new Vector2(560f, 42f));

        CreateUiText(panel.transform, "ESC：前の画面へ戻る", 20,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(0f, -145f), new Vector2(860f, 34f));
    }

    private void CreateUpgradeVisual(Transform root)
    {
        CreateUiImage(root, "UpgradeBackground", Vector2.zero, Vector2.zero,
            new Color(0.018f, 0.045f, 0.075f, 0.98f), true);
        GameObject panel = CreateUiImage(root, "UpgradePanel", Vector2.zero,
            new Vector2(MapPanelWidth, MapPanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.96f), true);
        CreateUiImage(panel.transform, "UpgradePanelTopLine", new Vector2(0f, 338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel.transform, "UpgradePanelBottomLine", new Vector2(0f, -338f),
            new Vector2(1120f, 4f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
    }

    private GameObject CreateUiImage(Transform parent, string objectName,
        Vector2 anchoredPosition, Vector2 size, Color color, bool stretchToParent)
    {
        GameObject imageObject = new GameObject(objectName, typeof(RectTransform), typeof(Image));
        imageObject.transform.SetParent(parent, false);
        RectTransform rect = imageObject.GetComponent<RectTransform>();
        rect.anchorMin = stretchToParent ? Vector2.zero : new Vector2(0.5f, 0.5f);
        rect.anchorMax = stretchToParent ? Vector2.one : new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        if (stretchToParent)
        {
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
        }
        else
        {
            rect.sizeDelta = size;
            rect.anchoredPosition = anchoredPosition;
        }
        Image image = imageObject.GetComponent<Image>();
        image.sprite = GetUiWhiteSprite();
        image.color = color;
        image.raycastTarget = false;
        return imageObject;
    }

    private Sprite GetUiWhiteSprite()
    {
        if (uiWhiteSprite == null)
        {
            uiWhiteSprite = Sprite.Create(Texture2D.whiteTexture,
                new Rect(0f, 0f, 1f, 1f), new Vector2(0.5f, 0.5f), 1f);
            uiWhiteSprite.name = "RuntimeUIWhiteSprite";
        }

        return uiWhiteSprite;
    }

    private Text CreateUiText(Transform parent, string textValue, int fontSize,
        Color color, TextAnchor alignment, Vector2 anchoredPosition, Vector2 size)
    {
        GameObject textObject = new GameObject("Text", typeof(RectTransform), typeof(Text));
        textObject.transform.SetParent(parent, false);
        RectTransform rect = textObject.GetComponent<RectTransform>();
        rect.anchorMin = new Vector2(0.5f, 0.5f);
        rect.anchorMax = new Vector2(0.5f, 0.5f);
        rect.pivot = new Vector2(0.5f, 0.5f);
        rect.sizeDelta = size == Vector2.zero ? new Vector2(360f, 58f) : size;
        rect.anchoredPosition = anchoredPosition;
        Text text = textObject.GetComponent<Text>();
        text.text = textValue;
        text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        text.fontSize = fontSize;
        text.alignment = alignment;
        text.color = color;
        text.horizontalOverflow = HorizontalWrapMode.Overflow;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.raycastTarget = false;
        return text;
    }

    private Button CreateTitleButton(string objectName, UnityEngine.Events.UnityAction onClick,
        out RectTransform buttonRect)
    {
        GameObject buttonObject = new GameObject(objectName, typeof(RectTransform), typeof(Image), typeof(Button));
        buttonRect = buttonObject.GetComponent<RectTransform>();
        buttonRect.anchorMin = new Vector2(0.5f, 0.5f);
        buttonRect.anchorMax = new Vector2(0.5f, 0.5f);
        buttonRect.pivot = new Vector2(0.5f, 0.5f);

        Image image = buttonObject.GetComponent<Image>();
        image.color = new Color(0.12f, 0.34f, 0.48f, 0.96f);
        image.raycastTarget = true;

        Button button = buttonObject.GetComponent<Button>();
        button.targetGraphic = image;
        button.transition = Selectable.Transition.None;
        button.navigation = new Navigation { mode = Navigation.Mode.None };
        // Visual-only button. Input is handled by the single OnGUI target so
        // the same click cannot be delivered to both title and map buttons.
        button.interactable = false;
        return button;
    }

    private Texture2D GetGuiButtonBackground(ref Texture2D cache, Color color,
        string textureName)
    {
        if (cache != null) return cache;

        cache = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        cache.name = textureName;
        cache.hideFlags = HideFlags.HideAndDontSave;
        cache.SetPixel(0, 0, color);
        cache.Apply();
        return cache;
    }

    private GUIStyle CreateHoverButtonStyle(int fontSize, FontStyle fontStyle = FontStyle.Normal)
    {
        GUIStyle style = new GUIStyle(GUI.skin.button)
        {
            fontSize = fontSize,
            fontStyle = fontStyle,
            alignment = TextAnchor.MiddleCenter
        };
        style.border = new RectOffset(6, 6, 6, 6);
        style.normal.background = GetGuiButtonBackground(ref guiButtonNormalBackground,
            new Color(0.10f, 0.28f, 0.40f, 0.96f), "GuiButtonNormal");
        style.hover.background = GetGuiButtonBackground(ref guiButtonHoverBackground,
            new Color(0.25f, 0.55f, 0.68f, 1f), "GuiButtonHover");
        style.active.background = GetGuiButtonBackground(ref guiButtonActiveBackground,
            new Color(0.85f, 0.62f, 0.20f, 1f), "GuiButtonActive");
        style.focused.background = style.hover.background;
        style.normal.textColor = Color.white;
        style.hover.textColor = new Color(1f, 0.95f, 0.62f);
        style.active.textColor = Color.white;
        style.focused.textColor = style.hover.textColor;
        return style;
    }

    private bool IsGuiRectHovered(Rect rect)
    {
        return TryGetGuiPointerPosition(out Vector2 pointer) &&
            rect.Contains(pointer);
    }

    private bool TryGetGuiPointerPosition(out Vector2 pointer)
    {
        pointer = Vector2.zero;

        bool hasPointerEvent = Event.current != null &&
            (Event.current.type == EventType.MouseMove ||
             Event.current.type == EventType.MouseDown ||
             Event.current.type == EventType.MouseUp ||
             Event.current.type == EventType.MouseDrag ||
             Event.current.type == EventType.ScrollWheel);
        if (hasPointerEvent)
        {
            // Convert the editor's local IMGUI event through the actual Game
            // view bounds. This remains correct when the Game view is scaled,
            // docked, or shown on a Retina display.
            Vector2 screenPoint = GUIUtility.GUIToScreenPoint(
                Event.current.mousePosition);
            pointer = GetPointerScreenPoint(screenPoint);
            pointer.y = Screen.height - pointer.y;
            pointer = PhysicalGuiPointToFrontendPoint(pointer);
            return true;
        }

        Mouse mouse = Mouse.current;
        if (mouse == null) return false;

        // Input System mouse coordinates are already relative to the Game
        // view and use a bottom-left origin. Do not subtract the Editor
        // window origin here; that conversion is only for IMGUI event
        // coordinates obtained through GUIToScreenPoint above.
        pointer = mouse.position.ReadValue();
        pointer.y = Screen.height - pointer.y;
        pointer = PhysicalGuiPointToFrontendPoint(pointer);
        return true;
    }

    private void UpdateTitleButtonHover(Button button, Rect designRect, bool selected)
    {
        if (button == null) return;

        Image image = button.GetComponent<Image>();
        if (image == null) return;

        // The visible Canvas is authored in the 1280x720 frontend coordinate
        // system. Use the same converted pointer as the IMGUI hit tests; the
        // old code compared a physical Screen rect with an editor-local
        // mouse position, which could make the highlight appear mirrored or
        // offset when the Game view was scaled/docked.
        bool hovered = TryGetGuiPointerPosition(out Vector2 pointer) &&
            designRect.Contains(pointer);

        image.color = hovered
            ? new Color(0.25f, 0.55f, 0.68f, 1f)
            : selected
                ? new Color(0.18f, 0.43f, 0.58f, 1f)
                : new Color(0.12f, 0.34f, 0.48f, 0.96f);
    }

    private void UpdateTitleButtonOverlay()
    {
        if (titleButtonCanvasObject == null) return;

        // Stage selection is driven by GameFlow so WASD/arrow selection and
        // Enter confirmation always use the same selectedStage value. Pointer
        // clicks still reach the node Buttons, but Unity's automatic submit
        // navigation must not activate a stale node behind the map.
        if (EventSystem.current != null)
            EventSystem.current.sendNavigationEvents = state != GameState.Menu;

        // The canvas is visual-only. Input is handled by OnGUI so the same
        // pointer event cannot be delivered to both title and map controls.
        bool overlayVisible = state == GameState.Title ||
            state == GameState.Menu || state == GameState.Upgrade;
        titleButtonCanvasObject.SetActive(overlayVisible);
        bool showingTitle = state == GameState.Title && !titleHelpOpen;
        bool showingTitleHelp = state == GameState.Title && titleHelpOpen;
        if (titleVisualRoot != null) titleVisualRoot.SetActive(showingTitle);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(showingTitleHelp);
        if (titleStageButton != null)
        {
            titleStageButton.gameObject.SetActive(showingTitle);
            UpdateTitleButtonHover(titleStageButton, GetTitleStageButtonDesignRect(),
                showingTitle && titleSelection == 0);
        }
        if (titleHelpButton != null)
        {
            titleHelpButton.gameObject.SetActive(showingTitle);
            UpdateTitleButtonHover(titleHelpButton, GetTitleHelpButtonDesignRect(),
                showingTitle && titleSelection == 1);
        }
        if (titleHelpBackButton != null)
        {
            titleHelpBackButton.gameObject.SetActive(showingTitleHelp);
            UpdateTitleButtonHover(titleHelpBackButton,
                GetTitleHelpBackButtonDesignRect(), showingTitleHelp);
        }
        if (titleUpgradeButton != null)
        {
            bool showMapUpgradeButton = state == GameState.Menu;
            titleUpgradeButton.gameObject.SetActive(showMapUpgradeButton);
            if (showMapUpgradeButton)
                titleUpgradeButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(titleUpgradeButton, GetMapUpgradeButtonDesignRect(),
                false);
        }
        if (mapTitleButton != null)
        {
            bool showMapTitleButton = state == GameState.Menu;
            mapTitleButton.gameObject.SetActive(showMapTitleButton);
            if (showMapTitleButton)
                mapTitleButton.transform.SetAsLastSibling();
            UpdateTitleButtonHover(mapTitleButton, GetMapTitleButtonDesignRect(),
                false);
        }
        // The map is both rendered and interacted with by the same Canvas
        // ScrollRect. Keeping a separate transparent input overlay here made
        // it possible for the editor to send the drag to one surface while
        // the visible map was drawn by another surface.
        // MapScene uses the single IMGUI map below so camera movement and
        // the visible map always share one rendering path.
        if (mapVisualRoot != null) mapVisualRoot.SetActive(state == GameState.Menu);
        if (mapPanOverlay != null) mapPanOverlay.SetActive(false);
        if (upgradeVisualRoot != null) upgradeVisualRoot.SetActive(state == GameState.Upgrade);
        if (skillTreePanOverlay != null)
        {
            bool showSkillTreeInput = state == GameState.Upgrade;
            skillTreePanOverlay.SetActive(showSkillTreeInput);
            if (showSkillTreeInput)
            {
                skillTreePanOverlay.transform.SetAsLastSibling();
                SyncSkillTreePanOverlayFromPosition();
            }
        }

        if (state == GameState.Menu && mapVisualBuildPending)
        {
            mapVisualBuildPending = false;
            CreateMapVisual();
        }
    }

    private void SetTitleButtonRect(RectTransform buttonRect, float x, float y,
        float width, float height)
    {
        const float designWidth = 1280f;
        const float designHeight = 720f;
        buttonRect.sizeDelta = new Vector2(width, height);
        buttonRect.anchoredPosition = new Vector2(
            x + width * 0.5f - designWidth * 0.5f,
            designHeight * 0.5f - (y + height * 0.5f));
    }

    private void OpenStageMenu()
    {
        if (state != GameState.Title) return;

        PlayConfirmSound();
        titleHelpOpen = false;
        state = GameState.Menu;
        ClampSelectedStageToUnlocked();
        mapVisualBuildPending = false;
        if (titleVisualRoot != null) titleVisualRoot.SetActive(false);
        if (mapVisualRoot != null) mapVisualRoot.SetActive(true);
        CreateMapVisual();
        RefreshMapStagePresentation();
        EventSystem.current?.SetSelectedGameObject(null);
        RequestEditorRepaint();
    }

    private void ReturnToTitle()
    {
        if (state != GameState.Menu) return;

        PlayConfirmSound();
        if (mapHeroMoveRoutine != null)
        {
            StopCoroutine(mapHeroMoveRoutine);
            mapHeroMoveRoutine = null;
        }
        if (mapFocusRoutine != null)
        {
            StopCoroutine(mapFocusRoutine);
            mapFocusRoutine = null;
        }

        stageInfoOpen = false;
        stageInfoStageId = 0;
        titleHelpOpen = false;
        titleSelection = 0;
        state = GameState.Title;
        if (mapVisualRoot != null)
            mapVisualRoot.SetActive(false);
        if (titleVisualRoot != null)
            titleVisualRoot.SetActive(true);
        if (titleHelpVisualRoot != null)
            titleHelpVisualRoot.SetActive(false);
        EventSystem.current?.SetSelectedGameObject(null);
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private void OpenUpgradeMenu()
    {
        PlayConfirmSound();
        state = GameState.Upgrade;
        resetProgressConfirm = false;
        skillTreePan = Vector2.zero;
        pendingSkillTreeScroll = Vector2.zero;
        skillTreePointerHeld = false;
        skillTreeSuppressNodeClick = false;
        SyncSkillTreePanOverlayFromPosition();
        RequestEditorRepaint();
    }

    private void RequestProgressReset()
    {
        PlayConfirmSound();
        resetProgressConfirm = true;
        RequestEditorRepaint();
    }

    private void ResetSavedProgress()
    {
        PlayConfirmSound();
        coins = 0;
        PlayerPrefs.DeleteKey(CoinBalanceKey);
        PlayerPrefs.DeleteKey(SlashDamageLevelKey);
        PlayerPrefs.DeleteKey(HeroHealthLevelKey);
        PlayerPrefs.DeleteKey(WitchHealthLevelKey);
        PlayerPrefs.DeleteKey(HeroSpeedLevelKey);
        PlayerPrefs.DeleteKey(SlashPierceLevelKey);
        PlayerPrefs.DeleteKey(CurrentMapStageKey);
        PlayerPrefs.DeleteKey(HighestClearedStageKey);
        PlayerPrefs.DeleteKey(PendingStageInfoKey);
        PlayerPrefs.Save();
        resetProgressConfirm = false;
        RequestEditorRepaint();
    }

    private Rect GetUpgradePanelRect()
    {
        GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
            out float logicalHeight);
        float panelWidth = Mathf.Min(MapPanelWidth, Mathf.Max(0f, logicalWidth - 20f));
        float panelHeight = Mathf.Min(MapPanelHeight, Mathf.Max(0f, logicalHeight - 20f));
        return new Rect(
            (logicalWidth - panelWidth) * 0.5f,
            (logicalHeight - panelHeight) * 0.5f,
            panelWidth,
            panelHeight);
    }

    private Rect GetSkillTreeViewport(Rect panel)
    {
        GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
            out float logicalHeight);
        float viewportWidth = Mathf.Min(MapViewportWidth,
            Mathf.Max(0f, panel.width - 52f));
        float viewportHeight = Mathf.Min(425f,
            Mathf.Max(0f, panel.height - 250f));
        float viewportX = panel.x + (panel.width - viewportWidth) * 0.5f;
        float viewportY = panel.y + 145f;

        // Keep every edge inside the actual logical Game view, including
        // narrow or unusually tall aspect ratios.
        viewportX = Mathf.Clamp(viewportX, 0f,
            Mathf.Max(0f, logicalWidth - viewportWidth));
        viewportY = Mathf.Clamp(viewportY, 0f,
            Mathf.Max(0f, logicalHeight - viewportHeight));
        return new Rect(viewportX, viewportY, viewportWidth, viewportHeight);
    }

    private void GetFrontendGuiMetrics(out float scale, out Vector2 offset,
        out float logicalWidth, out float logicalHeight)
    {
        float widthScale = Mathf.Max(0.0001f,
            Screen.width / FrontendReferenceWidth);
        float heightScale = Mathf.Max(0.0001f,
            Screen.height / FrontendReferenceHeight);
        // Match CanvasScaler.MatchWidthOrHeight using its logarithmic
        // interpolation. This keeps IMGUI and the Canvas on one coordinate
        // system instead of making the skill-tree frame smaller than the UI.
        scale = Mathf.Exp(Mathf.Lerp(Mathf.Log(widthScale),
            Mathf.Log(heightScale), FrontendCanvasMatch));
        logicalWidth = Screen.width / scale;
        logicalHeight = Screen.height / scale;
        offset = new Vector2(
            (Screen.width - FrontendReferenceWidth * scale) * 0.5f,
            (Screen.height - FrontendReferenceHeight * scale) * 0.5f);
    }

    private Vector2 PhysicalGuiPointToFrontendPoint(Vector2 physicalPoint)
    {
        GetFrontendGuiMetrics(out float scale, out Vector2 offset,
            out _, out _);
        return (physicalPoint - offset) / Mathf.Max(scale, 0.0001f);
    }

    private static int GetSkillNodeCount()
    {
        return SkillNodeBranches != null ? SkillNodeBranches.Length : 0;
    }

    private static int GetSkillBranchIndex(int nodeIndex)
    {
        if (SkillNodeBranches == null || SkillNodeBranches.Length == 0)
            return 0;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodeBranches.Length - 1);
        return SkillNodeBranches[index];
    }

    private static int GetSkillLevelIndex(int nodeIndex)
    {
        if (SkillNodeLevels == null || SkillNodeLevels.Length == 0)
            return 0;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodeLevels.Length - 1);
        return SkillNodeLevels[index];
    }

    private static Vector2 GetSkillTreeNodePosition(Vector2 treeCenter, int nodeIndex)
    {
        int safeIndex = Mathf.Clamp(nodeIndex, 0, GetSkillNodeCount() - 1);
        if (safeIndex >= AttackSpeedNodeIndex)
        {
            // Keep the attack-speed branch as a clean sixth column. Its first
            // node shares the second grid row with the rightmost regular
            // node, so the prerequisite line is short and never crosses the
            // other columns.
            int attackSpeedRow = safeIndex - AttackSpeedNodeIndex + 1;
            float y = (attackSpeedRow - (SkillTreeGridRows - 1) * 0.5f) *
                SkillTreeGridSpacingY;
            return treeCenter + new Vector2(
                SkillTreeGridSpacingX * 3f, y);
        }

        int column = safeIndex % SkillTreeGridColumns;
        int row = safeIndex / SkillTreeGridColumns;
        Vector2 gridOffset = new Vector2(
            (column - (SkillTreeGridColumns - 1) * 0.5f) * SkillTreeGridSpacingX,
            (row - (SkillTreeGridRows - 1) * 0.5f) * SkillTreeGridSpacingY);
        return treeCenter + gridOffset;
    }

    private static int GetSkillNodePrerequisite(int nodeIndex)
    {
        if (SkillNodePrerequisites == null || SkillNodePrerequisites.Length == 0)
            return -1;
        int index = Mathf.Clamp(nodeIndex, 0, SkillNodePrerequisites.Length - 1);
        return SkillNodePrerequisites[index];
    }

    private static bool IsSkillNodePurchased(int nodeIndex)
    {
        string key = SkillUpgradeKeys[GetSkillBranchIndex(nodeIndex)];
        return GetUpgradeLevel(key) > GetSkillLevelIndex(nodeIndex);
    }

    private static bool IsSkillNodeUnlocked(int nodeIndex)
    {
        if (IsSkillNodePurchased(nodeIndex)) return true;

        int branchIndex = GetSkillBranchIndex(nodeIndex);
        string key = SkillUpgradeKeys[branchIndex];
        if (branchIndex == 5 &&
            GetPurchasedSkillNodeCount() < AttackSpeedUnlockRequiredNodes)
            return false;

        int levelIndex = GetSkillLevelIndex(nodeIndex);
        // A branch still advances one level at a time, while the prerequisite
        // below can come from any other branch.
        if (GetUpgradeLevel(key) != levelIndex) return false;

        int prerequisite = GetSkillNodePrerequisite(nodeIndex);
        return prerequisite < 0 || IsSkillNodePurchased(prerequisite);
    }

    private static int GetPurchasedSkillNodeCount()
    {
        int purchasedCount = 0;
        for (int i = 0; i < GetSkillNodeCount(); i++)
        {
            if (GetSkillBranchIndex(i) == 5) continue;
            if (IsSkillNodePurchased(i))
                purchasedCount++;
        }
        return purchasedCount;
    }

    private string GetSkillBranchValue(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return $"{GetHeroSlashDamage()}";
            case 1: return $"HP {GetHeroMaxHealth()}";
            case 2: return $"HP {GetWitchMaxHealth()}";
            case 3: return $"{GetHeroMoveSpeed():0.0}";
            case 4: return $"{GetSlashPiercingHits()}体まで";
            case 5: return $"間隔 {GetHeroAttackInterval():0.00}秒";
            default: return string.Empty;
        }
    }

    private static string GetSkillBranchIcon(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return "剣";
            case 1: return "体";
            case 2: return "魔";
            case 3: return "速";
            case 4: return "貫";
            case 5: return "連";
            default: return "?";
        }
    }

    private static Color GetSkillBranchAccent(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return new Color(1f, 0.62f, 0.22f, 1f);
            case 1: return new Color(0.95f, 0.35f, 0.38f, 1f);
            case 2: return new Color(0.72f, 0.46f, 0.95f, 1f);
            case 3: return new Color(0.25f, 0.82f, 0.9f, 1f);
            case 4: return new Color(0.48f, 0.85f, 0.36f, 1f);
            case 5: return new Color(1f, 0.52f, 0.22f, 1f);
            default: return Color.white;
        }
    }

    private static string GetSkillEffectText(int branchIndex)
    {
        switch (branchIndex)
        {
            case 0: return "+1 ダメージ";
            case 1: return "+2 HP";
            case 2: return "+2 HP";
            case 3: return "+0.5 速度";
            case 4: return "+1体 貫通";
            case 5: return "+0.06秒短縮";
            default: return "+0";
        }
    }

    private void ClampSkillTreePan(Rect viewport)
    {
        // Keep a generous content area for panning. The tree is rendered
        // inside the clipped viewport group, so anything beyond its frame is
        // intentionally hidden.
        float maxPanX = Mathf.Max(0f, (SkillTreeContentWidth - viewport.width) * 0.5f);
        float maxPanY = Mathf.Max(0f, (SkillTreeContentHeight - viewport.height) * 0.5f);
        skillTreePan.x = Mathf.Clamp(skillTreePan.x, -maxPanX, maxPanX);
        skillTreePan.y = Mathf.Clamp(skillTreePan.y, -maxPanY, maxPanY);
    }

    private void HandleUpgradeInput()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null && keyboard.escapeKey.wasPressedThisFrame)
        {
            ReturnToMenu();
            return;
        }

        Rect viewport = GetSkillTreeViewport(GetUpgradePanelRect());
        Vector2 wheel = pendingSkillTreeScroll;
        pendingSkillTreeScroll = Vector2.zero;
        Mouse mouse = Mouse.current;
        if (wheel.sqrMagnitude <= 0.0001f && mouse != null)
            wheel = mouse.scroll.ReadValue();

        if (wheel.sqrMagnitude > 0.0001f)
        {
            // Match the stage map's two-finger direction: scrolling upward
            // moves the visible tree downward, and vice versa.
            skillTreePan += new Vector2(-wheel.x, wheel.y) * 24f;
            skillTreeScrollHandledFrame = Time.frameCount;
            ClampSkillTreePan(viewport);
            SyncSkillTreePanOverlayFromPosition();
            RequestEditorRepaint();
        }

        if (keyboard == null) return;

        Vector2 direction = Vector2.zero;
        if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) direction.x -= 1f;
        if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) direction.x += 1f;
        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) direction.y -= 1f;
        if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) direction.y += 1f;
        if (direction.sqrMagnitude <= 0.0001f) return;

        skillTreePan += direction.normalized * 6f;
        ClampSkillTreePan(viewport);
        // Keyboard panning changes the visible IMGUI tree immediately. Keep
        // the transparent Canvas hitboxes on that exact same offset instead
        // of leaving them at the previous frame's positions.
        SyncSkillTreePanOverlayFromPosition();
        RequestEditorRepaint();
    }

    private void UpdateSkillTreeEventInput(Event currentEvent, Rect viewport)
    {
        if (currentEvent == null) return;

        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
        {
            Vector2 eventPosition = PhysicalGuiPointToFrontendPoint(
                currentEvent.mousePosition);
            if (!viewport.Contains(eventPosition)) return;

            skillTreePointerHeld = true;
            skillTreeSuppressNodeClick = false;
            skillTreeLastPointerPosition = eventPosition;
            return;
        }

        if (currentEvent.type == EventType.MouseDrag && skillTreePointerHeld)
        {
            Vector2 eventPosition = PhysicalGuiPointToFrontendPoint(
                currentEvent.mousePosition);
            Vector2 delta = eventPosition - skillTreeLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                // Match the stage map's drag direction in the Unity Game view.
                // The editor event reports the drag delta with the opposite
                // sign, so add it here to move the tree with the pointer.
                skillTreePan += delta;
                skillTreeSuppressNodeClick = true;
                skillTreeLastPointerPosition = eventPosition;
                ClampSkillTreePan(viewport);
                SyncSkillTreePanOverlayFromPosition();
                currentEvent.Use();
                RequestEditorRepaint();
            }
            return;
        }

        if (currentEvent.type == EventType.MouseUp && skillTreePointerHeld)
        {
            if (skillTreeSuppressNodeClick)
                currentEvent.Use();
            skillTreePointerHeld = false;
            return;
        }

        // Trackpad two-finger scrolling arrives in the Unity Editor as an
        // IMGUI scroll-wheel event. Handle it here as well as through the
        // Input System path above so it works reliably in the Game view.
        if (currentEvent.type == EventType.ScrollWheel &&
            (skillTreePanOverlay == null || !skillTreePanOverlay.activeSelf) &&
            skillTreeScrollHandledFrame != Time.frameCount)
        {
            Vector2 scrollDelta = currentEvent.delta;
            if (currentEvent.shift &&
                Mathf.Abs(scrollDelta.x) <= 0.001f &&
                Mathf.Abs(scrollDelta.y) > 0.001f)
            {
                scrollDelta.x = scrollDelta.y;
                scrollDelta.y = 0f;
            }
            skillTreePan += new Vector2(-scrollDelta.x, scrollDelta.y) * 24f;
            skillTreeScrollHandledFrame = Time.frameCount;
            ClampSkillTreePan(viewport);
            currentEvent.Use();
            RequestEditorRepaint();
        }
    }

    private void CreateMapVisual()
    {
        if (mapVisualRoot == null || mapVisualPanel != null)
        {
            Debug.LogWarning($"[GameFlow] CreateMapVisual skipped root={(mapVisualRoot != null)} panel={(mapVisualPanel != null)}");
            return;
        }

        mapStageButtons.Clear();

        GameObject mapBackground = CreateUiImage(mapVisualRoot.transform, "MapBackground",
            Vector2.zero, Vector2.zero,
            new Color(0.025f, 0.06f, 0.10f, 0.98f), true);
        RectTransform mapBackgroundRect = mapBackground.GetComponent<RectTransform>();
        mapBackgroundRect.anchorMin = new Vector2(0.5f, 0.5f);
        mapBackgroundRect.anchorMax = new Vector2(0.5f, 0.5f);
        mapBackgroundRect.sizeDelta = new Vector2(2200f, 1400f);
        mapBackgroundRect.anchoredPosition = Vector2.zero;
        mapVisualPanel = CreateUiImage(mapVisualRoot.transform, "MapPanel", Vector2.zero,
            new Vector2(MapPanelWidth, MapPanelHeight),
            new Color(0.055f, 0.13f, 0.19f, 0.98f), false);
        Transform panel = mapVisualPanel.transform;
        CreateUiImage(panel, "MapPanelTopLine", new Vector2(0f, 338f),
            new Vector2(1120f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiImage(panel, "MapPanelBottomLine", new Vector2(0f, -338f),
            new Vector2(1120f, 5f), new Color(0.95f, 0.78f, 0.25f, 0.9f), false);
        CreateUiText(panel, "WORLD MAP", 18, Color.white, TextAnchor.MiddleCenter,
            new Vector2(-355f, 306f), new Vector2(420f, 38f));
        GameObject mapCoinCounter = CreateUiImage(panel, "MapCoinCounter",
            new Vector2(390f, 306f), new Vector2(180f, 42f),
            new Color(0.01f, 0.025f, 0.04f, 0.88f), false);
        CreateUiImage(mapCoinCounter.transform, "MapCoinCounterTopLine",
            new Vector2(0f, 19f), new Vector2(180f, 2f),
            new Color(0.95f, 0.78f, 0.25f, 0.75f), false);
        CreateUiImage(mapCoinCounter.transform, "MapCoinCounterBottomLine",
            new Vector2(0f, -19f), new Vector2(180f, 2f),
            new Color(0.95f, 0.78f, 0.25f, 0.75f), false);
        Image mapCoinIcon = CreateUiImage(mapCoinCounter.transform, "CoinIcon",
            new Vector2(-40f, 0f), new Vector2(28f, 28f), Color.white, false)
            .GetComponent<Image>();
        mapCoinIcon.sprite = GetCoinSprite();
        mapCoinIcon.preserveAspect = true;
        CreateUiText(mapCoinCounter.transform, $"x{coins}", 19, Color.white,
            TextAnchor.MiddleLeft, new Vector2(16f, 0f), new Vector2(80f, 34f));

        GameObject viewportObject = CreateUiImage(panel, "MapArea", new Vector2(0f, -10f),
            new Vector2(MapViewportWidth, MapViewportHeight),
            new Color(0.02f, 0.08f, 0.14f, 0.55f), false);
        RectTransform viewport = viewportObject.GetComponent<RectTransform>();
        viewportObject.AddComponent<RectMask2D>();
        Image viewportImage = viewportObject.GetComponent<Image>();
        viewportImage.raycastTarget = true;

        mapCanvasContent = new GameObject("MapContent", typeof(RectTransform)).GetComponent<RectTransform>();
        mapCanvasContent.SetParent(viewport, false);
        // ScrollRect content must use a fixed top-left anchor. Center
        // anchoring makes normalizedPosition changes appear to do nothing.
        mapCanvasContent.anchorMin = new Vector2(0f, 1f);
        mapCanvasContent.anchorMax = new Vector2(0f, 1f);
        mapCanvasContent.pivot = new Vector2(0f, 1f);
        mapCanvasContent.sizeDelta = new Vector2(MapContentWidth, MapContentHeight);
        mapCanvasContent.anchoredPosition = Vector2.zero;

        GameObject mapArt = new GameObject("MapArt", typeof(RectTransform), typeof(RawImage));
        mapArt.transform.SetParent(mapCanvasContent, false);
        RectTransform mapArtRect = mapArt.GetComponent<RectTransform>();
        mapArtRect.anchorMin = Vector2.zero;
        mapArtRect.anchorMax = Vector2.one;
        mapArtRect.offsetMin = Vector2.zero;
        mapArtRect.offsetMax = Vector2.zero;
        RawImage mapArtImage = mapArt.GetComponent<RawImage>();
        mapArtImage.texture = GetMapBackgroundTexture();
        mapArtImage.color = Color.white;
        mapArtImage.raycastTarget = false;

        mapCanvasScrollRect = viewportObject.AddComponent<ScrollRect>();
        mapCanvasScrollRect.viewport = viewport;
        mapCanvasScrollRect.content = mapCanvasContent;
        mapCanvasScrollRect.horizontal = true;
        mapCanvasScrollRect.vertical = true;
        mapCanvasScrollRect.movementType = ScrollRect.MovementType.Clamped;
        mapCanvasScrollRect.inertia = false;
        mapCanvasScrollRect.scrollSensitivity = 1f;
        mapCanvasScrollRect.horizontalScrollbar = null;
        mapCanvasScrollRect.verticalScrollbar = null;
        mapCanvasScrollRect.onValueChanged.AddListener(OnMapCanvasScrollChanged);
        // The map is panned by the MapScene camera. Keep this component only
        // for the existing viewport/content hierarchy and clipping.
        mapCanvasScrollRect.enabled = false;

        List<StageDefinition> stages = GetStages();
        Vector2[] nodePositions = new Vector2[stages.Count];
        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        for (int i = 0; i < stages.Count; i++)
        {
            Vector2 mapPosition = GetStageNodePosition(mapContent, i, stages.Count);
            nodePositions[i] = new Vector2(mapPosition.x, -mapPosition.y);
        }

        for (int i = 0; i < nodePositions.Length - 1; i++)
            CreateMapLine(mapCanvasContent, nodePositions[i], nodePositions[i + 1], i);

        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            bool unlocked = IsStageUnlocked(stages, i);
            bool cleared = IsStageCleared(stages, i);
            GameObject nodeObject = new GameObject($"StageNode_{stage.stageId}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(mapCanvasContent, false);
            nodeObject.SetActive(unlocked);
            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(MapNodeSize, MapNodeSize);
            nodeRect.anchoredPosition = nodePositions[i];

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.sprite = GetMapCircleSprite();
            nodeImage.color = GetStageNodeColor(unlocked, cleared);
            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            ConfigureButtonHover(nodeButton, nodeImage.color,
                unlocked ? new Color(1f, 0.84f, 0.36f, 1f) : nodeImage.color);
            nodeButton.interactable = unlocked;
            int stageId = stage.stageId;
            nodeButton.onClick.AddListener(() => OpenStageInfo(stageId));
            mapStageButtons[nodeButton] = stage.stageId;

            GameObject iconObject = new GameObject("StageIcon", typeof(RectTransform), typeof(Image));
            iconObject.transform.SetParent(nodeObject.transform, false);
            RectTransform iconRect = iconObject.GetComponent<RectTransform>();
            iconRect.anchorMin = Vector2.zero;
            iconRect.anchorMax = Vector2.one;
            iconRect.offsetMin = new Vector2(12f, 12f);
            iconRect.offsetMax = new Vector2(-12f, -12f);
            Image iconImage = iconObject.GetComponent<Image>();
            iconImage.sprite = GetNodeIconSprite(i % 3);
            iconImage.color = unlocked
                ? Color.white
                : new Color(0.42f, 0.46f, 0.48f, 0.52f);
            iconImage.preserveAspect = true;
            iconImage.raycastTarget = false;

            GameObject lockShade = CreateUiImage(nodeObject.transform,
                "StageLockShade", Vector2.zero,
                new Vector2(MapNodeSize - 12f, MapNodeSize - 12f),
                new Color(0.01f, 0.02f, 0.03f, 0.56f), false);
            lockShade.SetActive(!unlocked);

            GameObject numberBadge = CreateUiImage(nodeObject.transform,
                "StageNumberBadge", new Vector2(0f, 54f),
                new Vector2(62f, 28f),
                new Color(0.01f, 0.025f, 0.04f, 0.94f), false);
            CreateUiText(numberBadge.transform, stage.stageId.ToString(), 18,
                unlocked ? new Color(1f, 0.91f, 0.48f) :
                    new Color(0.62f, 0.66f, 0.68f),
                TextAnchor.MiddleCenter, Vector2.zero, new Vector2(62f, 28f));

            GameObject lockBadge = CreateUiImage(nodeObject.transform,
                "StageLockBadge", new Vector2(0f, -53f),
                new Vector2(86f, 22f),
                new Color(0.01f, 0.02f, 0.03f, 0.88f), false);
            CreateUiText(lockBadge.transform, "LOCKED", 11,
                new Color(0.72f, 0.76f, 0.78f), TextAnchor.MiddleCenter,
                Vector2.zero, new Vector2(86f, 22f));
            lockBadge.SetActive(!unlocked);
        }

        CreateMapHeroToken(stages);

        CreateUiText(panel, "ステージ番号をクリックして出発", 14,
            new Color(1f, 0.93f, 0.72f), TextAnchor.MiddleCenter,
            new Vector2(-180f, -316f), new Vector2(760f, 34f));

        mapCanvasScrollRect.normalizedPosition = new Vector2(0.5f, 0.5f);
        RefreshMapStagePresentation();
    }

    private void CreateMapHeroToken(List<StageDefinition> stages)
    {
        if (mapCanvasContent == null || mapHeroTokenRect != null || stages == null ||
            stages.Count == 0)
            return;

        GameObject heroObject = new GameObject("MapHeroToken",
            typeof(RectTransform), typeof(Image));
        heroObject.transform.SetParent(mapCanvasContent, false);

        mapHeroTokenRect = heroObject.GetComponent<RectTransform>();
        mapHeroTokenRect.anchorMin = new Vector2(0f, 1f);
        mapHeroTokenRect.anchorMax = new Vector2(0f, 1f);
        mapHeroTokenRect.pivot = new Vector2(0.5f, 0.5f);
        mapHeroTokenRect.sizeDelta = new Vector2(MapHeroTokenSize, MapHeroTokenSize);

        mapHeroTokenImage = heroObject.GetComponent<Image>();
        mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;

        int stageIndex = GetStageIndex(selectedStage, stages);
        mapHeroStageId = stages[stageIndex].stageId;
        mapHeroTokenRect.anchoredPosition = GetMapStageCanvasPosition(
            stageIndex, stages.Count);
        heroObject.transform.SetAsLastSibling();
    }

    private Sprite GetMapHeroIdleSprite()
    {
        if (catalog == null)
            catalog = Resources.Load<StageCatalog>("StageCatalog");
        return catalog != null ? catalog.mapHeroIdleSprite : null;
    }

    private Sprite[] GetMapHeroRunSprites()
    {
        if (catalog == null)
            catalog = Resources.Load<StageCatalog>("StageCatalog");
        return catalog != null ? catalog.mapHeroRunSprites : null;
    }

    private void EnsureMapHeroTokenVisible()
    {
        if (state != GameState.Menu || mapCanvasContent == null) return;

        if (mapHeroTokenRect == null)
        {
            CreateMapHeroToken(GetStages());
            return;
        }

        if (mapHeroTokenImage == null)
            mapHeroTokenImage = mapHeroTokenRect.GetComponent<Image>();
        if (mapHeroTokenImage == null) return;

        if (mapHeroTokenImage.sprite == null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenRect.gameObject.SetActive(true);
        mapHeroTokenImage.enabled = true;
        mapHeroTokenImage.color = Color.white;
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;
        mapHeroTokenRect.SetAsLastSibling();
    }

    private void RestoreMapHeroTokenVisual()
    {
        if (mapHeroTokenRect == null) return;

        mapHeroTokenRect.gameObject.SetActive(true);
        mapHeroTokenRect.SetAsLastSibling();
        if (mapHeroTokenImage == null)
            mapHeroTokenImage = mapHeroTokenRect.GetComponent<Image>();
        if (mapHeroTokenImage == null) return;

        if (mapHeroTokenImage.sprite == null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroTokenImage.enabled = true;
        mapHeroTokenImage.color = Color.white;
        mapHeroTokenImage.preserveAspect = true;
        mapHeroTokenImage.raycastTarget = false;
    }

    private int GetStageIndex(int stageId, List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0) return 0;

        int index = stages.FindIndex(stage => stage != null && stage.stageId == stageId);
        return index >= 0 ? index : 0;
    }

    private Vector2 GetMapStageCanvasPosition(int stageIndex, int stageCount)
    {
        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        Vector2 mapPosition = GetStageNodePosition(mapContent, stageIndex, stageCount);
        return new Vector2(mapPosition.x, -mapPosition.y);
    }

    private void MoveMapHeroToStage(int stageId)
    {
        List<StageDefinition> stages = GetStages();
        if (stages.Count == 0) return;

        if (!IsStageUnlocked(stageId, stages))
            return;

        int stageIndex = GetStageIndex(stageId, stages);
        selectedStage = stages[stageIndex].stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();

        if (mapHeroTokenRect == null)
            return;

        FocusMapOnStage(stageIndex, stages.Count);
        if (mapHeroMoveRoutine != null)
            StopCoroutine(mapHeroMoveRoutine);

        mapHeroMoveRoutine = StartCoroutine(AnimateMapHeroAlongRoute(
            stages, stageIndex, selectedStage));
    }

    private void FocusMapOnStage(int stageIndex, int stageCount)
    {
        if (stageCount <= 0) return;

        Rect mapContent = new Rect(0f, 0f, MapContentWidth, MapContentHeight);
        Vector2 mapPosition = GetStageNodePosition(mapContent, stageIndex, stageCount);
        float maxScrollX = Mathf.Max(0f, MapContentWidth - MapViewportWidth);
        float maxScrollY = Mathf.Max(0f, MapContentHeight - MapViewportHeight);
        Vector2 targetScroll = new Vector2(
            Mathf.Clamp(mapPosition.x - MapViewportWidth * 0.5f, 0f, maxScrollX),
            Mathf.Clamp(mapPosition.y - MapViewportHeight * 0.5f, 0f, maxScrollY));

        Vector2 targetCameraPan = Vector2.zero;
        if (mapCameraConfigured && mapCamera != null)
        {
            float cameraX = maxScrollX <= 0f
                ? 0f
                : (targetScroll.x - maxScrollX * 0.5f) /
                    (maxScrollX * 0.5f) * MapCameraPanLimit.x;
            float cameraY = maxScrollY <= 0f
                ? 0f
                : (targetScroll.y - maxScrollY * 0.5f) /
                    (maxScrollY * 0.5f) * MapCameraPanLimit.y;
            targetCameraPan = new Vector2(
                Mathf.Clamp(cameraX, -MapCameraPanLimit.x, MapCameraPanLimit.x),
                Mathf.Clamp(cameraY, -MapCameraPanLimit.y, MapCameraPanLimit.y));
        }

        if (mapFocusRoutine != null)
            StopCoroutine(mapFocusRoutine);
        mapFocusRoutine = StartCoroutine(AnimateMapFocusTo(
            targetScroll, targetCameraPan));
    }

    private IEnumerator AnimateMapFocusTo(Vector2 targetScroll, Vector2 targetCameraPan)
    {
        Vector2 startScroll = mapScrollPosition;
        Vector2 startCameraPan = mapCameraPan;
        float elapsed = 0f;

        while (elapsed < MapFocusMoveDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / MapFocusMoveDuration);
            float easedProgress = Mathf.SmoothStep(0f, 1f, progress);
            mapScrollPosition = Vector2.Lerp(startScroll, targetScroll, easedProgress);
            mapCameraPan = Vector2.Lerp(startCameraPan, targetCameraPan, easedProgress);
            mapScrollInitialized = true;

            if (mapCameraConfigured && mapCamera != null)
            {
                mapCamera.transform.position = mapCameraHomePosition +
                    new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);
            }

            ApplyMapCanvasContentOffset();
            SyncMapPanOverlayFromPosition();
            RequestEditorRepaint();
            yield return null;
        }

        mapScrollPosition = targetScroll;
        mapCameraPan = targetCameraPan;
        mapScrollInitialized = true;
        if (mapCameraConfigured && mapCamera != null)
        {
            mapCamera.transform.position = mapCameraHomePosition +
                new Vector3(mapCameraPan.x, -mapCameraPan.y, 0f);
        }
        ApplyMapCanvasContentOffset();
        SyncMapPanOverlayFromPosition();
        RequestEditorRepaint();
        mapFocusRoutine = null;
    }

    private IEnumerator AnimateMapHeroAlongRoute(
        List<StageDefinition> stages, int targetStageIndex, int targetStageId)
    {
        if (mapHeroTokenRect == null || stages == null || stages.Count == 0)
            yield break;

        Vector2[] nodePositions = new Vector2[stages.Count];
        for (int i = 0; i < stages.Count; i++)
            nodePositions[i] = GetMapStageCanvasPosition(i, stages.Count);

        Vector2 currentPosition = mapHeroTokenRect.anchoredPosition;
        List<Vector2> waypoints = new List<Vector2>();
        int nearestNodeIndex = -1;
        float nearestNodeDistance = float.MaxValue;
        float nodeSnapDistance = MapNodeSize * 0.35f;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            float distance = Vector2.Distance(currentPosition, nodePositions[i]);
            if (distance < nearestNodeDistance)
            {
                nearestNodeDistance = distance;
                nearestNodeIndex = i;
            }
        }

        if (nearestNodeDistance <= nodeSnapDistance)
        {
            int direction = targetStageIndex >= nearestNodeIndex ? 1 : -1;
            for (int i = nearestNodeIndex + direction;
                direction > 0 ? i <= targetStageIndex : i >= targetStageIndex;
                i += direction)
            {
                waypoints.Add(nodePositions[i]);
            }
        }
        else
        {
            int segmentIndex = FindClosestMapRouteSegment(currentPosition, nodePositions);
            if (targetStageIndex > segmentIndex)
            {
                for (int i = segmentIndex + 1; i <= targetStageIndex; i++)
                    waypoints.Add(nodePositions[i]);
            }
            else
            {
                for (int i = segmentIndex; i >= targetStageIndex; i--)
                    waypoints.Add(nodePositions[i]);
            }
        }

        for (int i = 0; i < waypoints.Count; i++)
        {
            Vector2 target = waypoints[i];
            yield return AnimateMapHeroSegment(currentPosition, target);
            currentPosition = target;

            int reachedNode = FindClosestMapNode(target, nodePositions);
            if (reachedNode >= 0)
                mapHeroStageId = stages[reachedNode].stageId;
        }

        mapHeroTokenRect.anchoredPosition = nodePositions[targetStageIndex];
        if (mapHeroTokenImage != null)
            mapHeroTokenImage.sprite = GetMapHeroIdleSprite();
        mapHeroStageId = targetStageId;
        mapHeroMoveRoutine = null;
    }

    private IEnumerator AnimateMapHeroSegment(Vector2 start, Vector2 target)
    {
        float distance = Vector2.Distance(start, target);
        if (distance <= 0.5f)
        {
            mapHeroTokenRect.anchoredPosition = target;
            yield break;
        }

        Sprite[] runSprites = GetMapHeroRunSprites();
        float duration = Mathf.Clamp(distance / 420f, 0.28f, 1.1f);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.unscaledDeltaTime;
            float progress = Mathf.Clamp01(elapsed / duration);
            mapHeroTokenRect.anchoredPosition = Vector2.Lerp(start, target, progress);

            if (mapHeroTokenImage != null && runSprites != null && runSprites.Length > 0)
            {
                int frame = Mathf.FloorToInt(elapsed / MapHeroRunFrameDuration) %
                    runSprites.Length;
                mapHeroTokenImage.sprite = runSprites[frame];
            }

            yield return null;
        }

        mapHeroTokenRect.anchoredPosition = target;
    }

    private int FindClosestMapRouteSegment(Vector2 position, Vector2[] nodePositions)
    {
        if (nodePositions == null || nodePositions.Length < 2)
            return 0;

        int closestSegment = 0;
        float closestDistance = float.MaxValue;
        for (int i = 0; i < nodePositions.Length - 1; i++)
        {
            Vector2 start = nodePositions[i];
            Vector2 direction = nodePositions[i + 1] - start;
            float lengthSquared = direction.sqrMagnitude;
            float projection = lengthSquared <= 0.001f
                ? 0f
                : Mathf.Clamp01(Vector2.Dot(position - start, direction) / lengthSquared);
            Vector2 pointOnSegment = start + direction * projection;
            float distance = (position - pointOnSegment).sqrMagnitude;
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestSegment = i;
            }
        }

        return closestSegment;
    }

    private int FindClosestMapNode(Vector2 position, Vector2[] nodePositions)
    {
        if (nodePositions == null || nodePositions.Length == 0)
            return -1;

        int closestNode = 0;
        float closestDistance = float.MaxValue;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            float distance = (position - nodePositions[i]).sqrMagnitude;
            if (distance < closestDistance)
            {
                closestDistance = distance;
                closestNode = i;
            }
        }

        return closestNode;
    }

    private void OnMapCanvasScrollChanged(Vector2 normalizedPosition)
    {
        if (updatingMapCanvasScroll || mapCanvasContent == null) return;

        float maxX = Mathf.Max(0f, mapCanvasContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapCanvasContent.rect.height - MapViewportHeight);
        mapScrollPosition = new Vector2(
            normalizedPosition.x * maxX,
            (1f - normalizedPosition.y) * maxY);
    }

    private void CreateMapPanOverlay()
    {
        if (mapPanOverlay != null || titleButtonCanvasObject == null) return;

        // This transparent ScrollRect is the real input surface for the map.
        // The map itself remains drawn by OnGUI, while Unity's UI input module
        // receives mouse, trackpad and touchpad drag events reliably.
        mapPanOverlay = new GameObject("MapPanInput", typeof(RectTransform),
            typeof(Image), typeof(ScrollRect));
        mapPanOverlay.transform.SetParent(titleButtonCanvasObject.transform, false);

        RectTransform viewport = mapPanOverlay.GetComponent<RectTransform>();
        viewport.anchorMin = new Vector2(0.5f, 0.5f);
        viewport.anchorMax = new Vector2(0.5f, 0.5f);
        viewport.pivot = new Vector2(0.5f, 0.5f);
        viewport.sizeDelta = new Vector2(MapViewportWidth, MapViewportHeight);
        viewport.anchoredPosition = new Vector2(0f, -10f);

        Image inputImage = mapPanOverlay.GetComponent<Image>();
        inputImage.color = new Color(0f, 0f, 0f, 0f);
        inputImage.raycastTarget = true;

        mapPanContent = new GameObject("MapPanContent", typeof(RectTransform),
            typeof(Image)).GetComponent<RectTransform>();
        mapPanContent.SetParent(viewport, false);
        mapPanContent.anchorMin = new Vector2(0f, 1f);
        mapPanContent.anchorMax = new Vector2(0f, 1f);
        mapPanContent.pivot = new Vector2(0f, 1f);
        mapPanContent.sizeDelta = new Vector2(MapContentWidth, MapContentHeight);
        mapPanContent.anchoredPosition = Vector2.zero;
        Image contentImage = mapPanContent.GetComponent<Image>();
        contentImage.color = new Color(0f, 0f, 0f, 0f);
        contentImage.raycastTarget = false;

        mapPanScrollRect = mapPanOverlay.GetComponent<ScrollRect>();
        mapPanScrollRect.viewport = viewport;
        mapPanScrollRect.content = mapPanContent;
        mapPanScrollRect.horizontal = true;
        mapPanScrollRect.vertical = true;
        mapPanScrollRect.movementType = ScrollRect.MovementType.Clamped;
        mapPanScrollRect.inertia = false;
        mapPanScrollRect.scrollSensitivity = 1f;
        mapPanScrollRect.horizontalScrollbar = null;
        mapPanScrollRect.verticalScrollbar = null;
        mapPanScrollRect.onValueChanged.AddListener(OnMapPanScrollRectChanged);

        CreateMapPanNodeButtons();
        mapPanOverlay.transform.SetAsLastSibling();
        SyncMapPanOverlayFromPosition();
    }

    private void CreateMapPanNodeButtons()
    {
        if (mapPanContent == null) return;

        List<StageDefinition> stages = GetStages();
        Rect mapContent = new Rect(0f, 0f, 1280f, 800f);
        for (int i = 0; i < stages.Count; i++)
        {
            int stageId = stages[i].stageId;
            Vector2 position = GetStageNodePosition(mapContent, i, stages.Count);
            GameObject nodeObject = new GameObject($"MapPanNode_{stageId}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(mapPanContent, false);

            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(90f, 90f);
            nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.color = new Color(1f, 1f, 1f, 0f);
            nodeImage.raycastTarget = true;

            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.transition = Selectable.Transition.None;
            nodeButton.navigation = new Navigation { mode = Navigation.Mode.None };
            nodeButton.interactable = IsStageUnlocked(stages, i);
            nodeButton.onClick.AddListener(() => OpenStageInfo(stageId));
            mapPanNodeButtons.Add(nodeButton);
        }
    }

    private void CreateSkillTreePanOverlay()
    {
        if (skillTreePanOverlay != null || titleButtonCanvasObject == null) return;

        // Use a real ScrollRect as the input surface. IMGUI receives trackpad
        // wheel events only when the Game view has focus, while ScrollRect is
        // also fed by Unity's Input System UI module and handles two-finger
        // scrolling/dragging consistently.
        skillTreePanOverlay = new GameObject("SkillTreePanInput",
            typeof(RectTransform), typeof(Image), typeof(ScrollRect));
        skillTreePanOverlay.transform.SetParent(titleButtonCanvasObject.transform, false);

        RectTransform viewport = skillTreePanOverlay.GetComponent<RectTransform>();
        viewport.anchorMin = new Vector2(0.5f, 0.5f);
        viewport.anchorMax = new Vector2(0.5f, 0.5f);
        viewport.pivot = new Vector2(0.5f, 0.5f);
        viewport.sizeDelta = new Vector2(MapViewportWidth, 425f);
        viewport.anchoredPosition = new Vector2(0f, -17.5f);

        Image viewportImage = skillTreePanOverlay.GetComponent<Image>();
        viewportImage.color = new Color(0f, 0f, 0f, 0f);
        viewportImage.raycastTarget = true;
        // The input overlay must have the same clipping boundary as the
        // visible IMGUI tree. Otherwise a transparent node button can remain
        // clickable after its visual node has moved outside the frame.
        skillTreePanOverlay.AddComponent<RectMask2D>();

        skillTreePanContent = new GameObject("SkillTreePanContent",
            typeof(RectTransform), typeof(Image)).GetComponent<RectTransform>();
        skillTreePanContent.SetParent(viewport, false);
        skillTreePanContent.anchorMin = new Vector2(0f, 1f);
        skillTreePanContent.anchorMax = new Vector2(0f, 1f);
        skillTreePanContent.pivot = new Vector2(0f, 1f);
        skillTreePanContent.sizeDelta = new Vector2(
            SkillTreeContentWidth, SkillTreeContentHeight);
        skillTreePanContent.anchoredPosition = Vector2.zero;
        Image contentImage = skillTreePanContent.GetComponent<Image>();
        contentImage.color = new Color(0f, 0f, 0f, 0f);
        contentImage.raycastTarget = false;

        skillTreePanScrollRect = skillTreePanOverlay.GetComponent<ScrollRect>();
        skillTreePanScrollRect.viewport = viewport;
        skillTreePanScrollRect.content = skillTreePanContent;
        skillTreePanScrollRect.horizontal = true;
        skillTreePanScrollRect.vertical = true;
        skillTreePanScrollRect.movementType = ScrollRect.MovementType.Clamped;
        skillTreePanScrollRect.inertia = false;
        // Wheel/trackpad deltas are applied from InputSystem.onEvent above;
        // keep ScrollRect for the reliable drag surface without applying the
        // same two-finger delta a second time.
        skillTreePanScrollRect.scrollSensitivity = 0f;
        skillTreePanScrollRect.horizontalScrollbar = null;
        skillTreePanScrollRect.verticalScrollbar = null;
        skillTreePanScrollRect.onValueChanged.AddListener(OnSkillTreePanScrollRectChanged);

        CreateSkillTreePanNodeButtons();
        ConfigureSkillTreePanOverlayGeometry();
        skillTreePanScrollRect.normalizedPosition = new Vector2(0.5f, 0.5f);
        skillTreePanOverlay.SetActive(false);
    }

    private void ConfigureSkillTreePanOverlayGeometry()
    {
        if (skillTreePanOverlay == null) return;

        RectTransform viewport = skillTreePanOverlay.GetComponent<RectTransform>();
        if (viewport != null)
        {
            Rect guiViewport = GetSkillTreeViewport(GetUpgradePanelRect());
            GetFrontendGuiMetrics(out _, out _, out float logicalWidth,
                out float logicalHeight);
            viewport.sizeDelta = guiViewport.size;
            viewport.anchoredPosition = new Vector2(
                guiViewport.center.x - logicalWidth * 0.5f,
                -(guiViewport.center.y - logicalHeight * 0.5f));
        }

        if (skillTreePanOverlay.GetComponent<RectMask2D>() == null)
            skillTreePanOverlay.AddComponent<RectMask2D>();

        if (skillTreePanContent == null) return;

        skillTreePanContent.sizeDelta = new Vector2(
            SkillTreeContentWidth, SkillTreeContentHeight);

        Vector2 treeCenter = new Vector2(
            SkillTreeContentWidth * 0.5f, SkillTreeContentHeight * 0.5f) +
            SkillTreeCenterOffset;
        int count = Mathf.Min(skillTreePanNodeButtons.Count, GetSkillNodeCount());
        for (int i = 0; i < count; i++)
        {
            Vector2 position = GetSkillTreeNodePosition(treeCenter, i);
            RectTransform nodeRect = skillTreePanNodeButtons[i].GetComponent<RectTransform>();
            if (nodeRect != null)
            {
                nodeRect.sizeDelta = new Vector2(SkillTreeNodeSize, SkillTreeNodeSize);
                nodeRect.anchoredPosition = new Vector2(position.x, -position.y);
            }
        }
    }

    private void CreateSkillTreePanNodeButtons()
    {
        if (skillTreePanContent == null) return;

        Vector2 treeCenter = new Vector2(
            SkillTreeContentWidth * 0.5f, SkillTreeContentHeight * 0.5f);

        for (int i = 0; i < GetSkillNodeCount(); i++)
        {
            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            int nodeIndex = i;
            GameObject nodeObject = new GameObject(
                $"SkillTreePanNode_{branchIndex + 1}_{levelIndex + 1}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            nodeObject.transform.SetParent(skillTreePanContent, false);

            Vector2 position = GetSkillTreeNodePosition(treeCenter, nodeIndex);
            RectTransform nodeRect = nodeObject.GetComponent<RectTransform>();
            nodeRect.anchorMin = new Vector2(0f, 1f);
            nodeRect.anchorMax = new Vector2(0f, 1f);
            nodeRect.pivot = new Vector2(0.5f, 0.5f);
            nodeRect.sizeDelta = new Vector2(SkillTreeNodeSize, SkillTreeNodeSize);
            nodeRect.anchoredPosition = new Vector2(position.x, -position.y);

            Image nodeImage = nodeObject.GetComponent<Image>();
            nodeImage.color = new Color(0f, 0f, 0f, 0f);
            nodeImage.raycastTarget = true;

            Button nodeButton = nodeObject.GetComponent<Button>();
            nodeButton.targetGraphic = nodeImage;
            nodeButton.transition = Selectable.Transition.None;
            nodeButton.onClick.AddListener(() =>
            {
                TryBuySkillNode(nodeIndex);
                RequestEditorRepaint();
            });
            skillTreePanNodeButtons.Add(nodeButton);
        }
    }

    private void OnSkillTreePanScrollRectChanged(Vector2 normalizedPosition)
    {
        if (updatingSkillTreePanOverlay) return;

        Vector2 viewportSize = GetSkillTreeViewport(GetUpgradePanelRect()).size;
        float maxX = Mathf.Max(0f,
            SkillTreeContentWidth - viewportSize.x);
        float maxY = Mathf.Max(0f,
            SkillTreeContentHeight - viewportSize.y);
        skillTreePan = new Vector2(
            maxX <= 0f ? 0f : (0.5f - normalizedPosition.x) * maxX,
            maxY <= 0f ? 0f : (0.5f - normalizedPosition.y) * maxY);
        ClampSkillTreePan(GetSkillTreeViewport(GetUpgradePanelRect()));
        RequestEditorRepaint();
    }

    private void SyncSkillTreePanOverlayFromPosition()
    {
        if (skillTreePanScrollRect == null) return;

        Vector2 viewportSize = GetSkillTreeViewport(GetUpgradePanelRect()).size;
        float maxX = Mathf.Max(0f,
            SkillTreeContentWidth - viewportSize.x);
        float maxY = Mathf.Max(0f,
            SkillTreeContentHeight - viewportSize.y);
        updatingSkillTreePanOverlay = true;
        skillTreePanScrollRect.normalizedPosition = new Vector2(
            maxX <= 0f ? 0.5f : 0.5f - skillTreePan.x / maxX,
            maxY <= 0f ? 0.5f : 0.5f - skillTreePan.y / maxY);
        updatingSkillTreePanOverlay = false;
    }

    private void UpdateSkillTreePanNodeButtons()
    {
        int count = Mathf.Min(skillTreePanNodeButtons.Count, GetSkillNodeCount());
        for (int i = 0; i < count; i++)
        {
            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            string upgradeKey = SkillUpgradeKeys[branchIndex];
            skillTreePanNodeButtons[i].interactable =
                !IsSkillNodePurchased(i) &&
                IsSkillNodeUnlocked(i) &&
                coins >= GetUpgradeCostForLevel(upgradeKey, levelIndex);
        }
    }

    private void OnMapPanScrollRectChanged(Vector2 normalizedPosition)
    {
        if (updatingMapPanOverlay || mapPanContent == null) return;

        float maxX = Mathf.Max(0f, mapPanContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapPanContent.rect.height - MapViewportHeight);
        mapScrollPosition = new Vector2(
            normalizedPosition.x * maxX,
            (1f - normalizedPosition.y) * maxY);
        mapScrollInitialized = true;
        RequestEditorRepaint();
    }

    private void SyncMapPanOverlayFromPosition()
    {
        if (mapPanScrollRect == null || mapPanContent == null) return;

        float maxX = Mathf.Max(0f, mapPanContent.rect.width - MapViewportWidth);
        float maxY = Mathf.Max(0f, mapPanContent.rect.height - MapViewportHeight);
        updatingMapPanOverlay = true;
        mapPanScrollRect.normalizedPosition = new Vector2(
            maxX <= 0f ? 0f : mapScrollPosition.x / maxX,
            maxY <= 0f ? 1f : 1f - mapScrollPosition.y / maxY);
        updatingMapPanOverlay = false;
    }

    private void CreateMapLine(Transform parent, Vector2 start, Vector2 end,
        int lineIndex)
    {
        GameObject lineObject = CreateUiImage(parent, $"MapLine_{lineIndex}", Vector2.zero,
            Vector2.one, new Color(0.72f, 0.53f, 0.28f, 0.95f), false);
        RectTransform lineRect = lineObject.GetComponent<RectTransform>();
        lineRect.anchorMin = new Vector2(0f, 1f);
        lineRect.anchorMax = new Vector2(0f, 1f);
        lineRect.pivot = new Vector2(0.5f, 0.5f);
        Vector2 direction = end - start;
        float length = direction.magnitude;
        lineRect.sizeDelta = new Vector2(Mathf.Max(0f, length - 76f), 8f);
        lineRect.anchoredPosition = (start + end) * 0.5f;
        lineRect.localRotation = Quaternion.Euler(0f, 0f,
            Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg);
    }

    private void ConfigureButtonHover(Button button, Color normalColor, Color hoverColor)
    {
        if (button == null) return;

        ColorBlock colors = button.colors;
        colors.normalColor = normalColor;
        colors.highlightedColor = hoverColor;
        colors.pressedColor = new Color(
            hoverColor.r * 0.78f, hoverColor.g * 0.78f, hoverColor.b * 0.78f,
            hoverColor.a);
        colors.selectedColor = hoverColor;
        colors.disabledColor = new Color(
            normalColor.r, normalColor.g, normalColor.b, normalColor.a * 0.45f);
        colors.fadeDuration = 0.08f;
        button.colors = colors;
        button.transition = Selectable.Transition.ColorTint;
    }

    private void RequestEditorRepaint()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
        UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
#endif
    }

    private bool IsConfirmHeld()
    {
        Keyboard keyboard = Keyboard.current;
        return keyboard != null &&
            (keyboard.enterKey.isPressed || keyboard.numpadEnterKey.isPressed || keyboard.spaceKey.isPressed);
    }

    private List<StageDefinition> GetStages()
    {
        List<StageDefinition> stages = new List<StageDefinition>();
        if (catalog != null && catalog.stages != null)
        {
            for (int i = 0; i < catalog.stages.Length; i++)
            {
                if (catalog.stages[i] != null) stages.Add(catalog.stages[i]);
            }
        }

        if (stages.Count == 0)
        {
            stages.Add(new StageDefinition
            {
                stageId = 1,
                displayName = "STAGE 1",
                waves = new[]
                {
                    new StageWave { monsterId = 0, count = 4, spawnInterval = 0.5f, minDistanceFromWitch = 6f }
                }
            });
        }

        return stages;
    }

    private int GetHighestClearedStageIndex(List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0)
            return -1;

        int savedIndex = PlayerPrefs.GetInt(HighestClearedStageKey, -1);
        return Mathf.Clamp(savedIndex, -1, stages.Count - 1);
    }

    private int GetLastUnlockedStageIndex(List<StageDefinition> stages)
    {
        if (stages == null || stages.Count == 0)
            return -1;

        return Mathf.Min(stages.Count - 1,
            GetHighestClearedStageIndex(stages) + 1);
    }

    private bool IsStageUnlocked(List<StageDefinition> stages, int stageIndex)
    {
        return stages != null && stageIndex >= 0 &&
            stageIndex <= GetLastUnlockedStageIndex(stages);
    }

    private bool IsStageCleared(List<StageDefinition> stages, int stageIndex)
    {
        return stages != null && stageIndex >= 0 &&
            stageIndex <= GetHighestClearedStageIndex(stages);
    }

    private bool IsStageUnlocked(int stageId, List<StageDefinition> stages)
    {
        if (stages == null) return false;
        int stageIndex = stages.FindIndex(stage => stage != null &&
            stage.stageId == stageId);
        return stageIndex >= 0 && IsStageUnlocked(stages, stageIndex);
    }

    private Color GetStageNodeColor(bool unlocked, bool cleared)
    {
        if (!unlocked)
            return new Color(0.16f, 0.20f, 0.23f, 1f);

        if (cleared)
            return new Color(0.25f, 0.68f, 0.46f, 1f);

        return new Color(0.95f, 0.55f, 0.18f, 1f);
    }

    private void RefreshMapStagePresentation()
    {
        List<StageDefinition> stages = GetStages();
        if (stages == null || stages.Count == 0)
            return;

        int lastUnlockedIndex = GetLastUnlockedStageIndex(stages);
        for (int i = 0; i < stages.Count - 1; i++)
        {
            Transform line = mapCanvasContent != null
                ? mapCanvasContent.Find($"MapLine_{i}")
                : null;
            if (line != null)
                line.gameObject.SetActive(i < lastUnlockedIndex);
        }

        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            if (stage == null)
                continue;

            bool unlocked = IsStageUnlocked(stages, i);
            bool cleared = IsStageCleared(stages, i);

            if (mapCanvasContent != null)
            {
                Transform node = mapCanvasContent.Find($"StageNode_{stage.stageId}");
                if (node != null)
                {
                    // Locked stages are omitted from the map entirely. The
                    // player sees only the currently available route and no
                    // LOCKED badge or dark placeholder.
                    node.gameObject.SetActive(unlocked);
                    Image nodeImage = node.GetComponent<Image>();
                    if (nodeImage != null)
                        nodeImage.color = GetStageNodeColor(unlocked, cleared);

                    Button nodeButton = node.GetComponent<Button>();
                    if (nodeButton != null)
                    {
                        nodeButton.interactable = unlocked;
                        if (nodeImage != null)
                        {
                            ConfigureButtonHover(nodeButton, nodeImage.color,
                                unlocked
                                    ? new Color(1f, 0.84f, 0.36f, 1f)
                                    : nodeImage.color);
                        }
                    }

                    Transform icon = node.Find("StageIcon");
                    Image iconImage = icon != null
                        ? icon.GetComponent<Image>() : null;
                    if (iconImage != null)
                    {
                        iconImage.color = unlocked
                            ? Color.white
                            : new Color(0.42f, 0.46f, 0.48f, 0.52f);
                    }

                    Transform lockShade = node.Find("StageLockShade");
                    if (lockShade != null)
                        lockShade.gameObject.SetActive(!unlocked);

                    Transform numberBadge = node.Find("StageNumberBadge");
                    if (numberBadge != null)
                    {
                        Image badgeImage = numberBadge.GetComponent<Image>();
                        if (badgeImage != null)
                            badgeImage.color = new Color(0.01f, 0.025f,
                                0.04f, 0.94f);

                        Transform numberTextTransform = numberBadge.Find("Text");
                        Text numberText = numberTextTransform != null
                            ? numberTextTransform.GetComponent<Text>()
                            : null;
                        if (numberText != null)
                        {
                            numberText.text = stage.stageId.ToString();
                            numberText.color = unlocked
                                ? new Color(1f, 0.91f, 0.48f)
                                : new Color(0.62f, 0.66f, 0.68f);
                        }
                    }

                    Transform lockBadge = node.Find("StageLockBadge");
                    if (lockBadge != null)
                        lockBadge.gameObject.SetActive(!unlocked);
                }
            }

            if (mapPanNodeButtons != null && i < mapPanNodeButtons.Count &&
                mapPanNodeButtons[i] != null)
            {
                mapPanNodeButtons[i].gameObject.SetActive(unlocked);
                mapPanNodeButtons[i].interactable = unlocked;
            }
        }
    }

    private void ClampSelectedStageToUnlocked()
    {
        List<StageDefinition> stages = GetStages();
        if (stages.Count == 0) return;

        int selectedIndex = GetStageIndex(selectedStage, stages);
        int lastUnlockedIndex = GetLastUnlockedStageIndex(stages);
        if (selectedIndex < 0 || selectedIndex > lastUnlockedIndex)
            selectedIndex = Mathf.Clamp(lastUnlockedIndex, 0, stages.Count - 1);

        selectedStage = stages[selectedIndex].stageId;
        PlayerPrefs.SetInt(CurrentMapStageKey, selectedStage);
        PlayerPrefs.Save();
    }

    private void MarkStageCleared(int stageId)
    {
        List<StageDefinition> stages = GetStages();
        int stageIndex = GetStageIndex(stageId, stages);
        if (stageIndex < 0) return;

        int highestCleared = GetHighestClearedStageIndex(stages);
        if (stageIndex <= highestCleared) return;

        PlayerPrefs.SetInt(HighestClearedStageKey, stageIndex);
        PlayerPrefs.Save();
    }

    private void StartStage(int stageId)
    {
        if (state != GameState.Menu || mapVisualBuildPending)
            return;

        List<StageDefinition> availableStages = GetStages();
        if (!IsStageUnlocked(stageId, availableStages))
            return;

        if (mapOnlyScene)
        {
            battleLoadRequested = true;
            PlayerPrefs.SetInt(PendingStageKey, stageId);
            PlayerPrefs.Save();
            SceneManager.LoadScene(BattleSceneName);
            return;
        }

        selectedStage = stageId;
        currentStage = catalog != null ? catalog.GetStage(stageId) : null;
        if (currentStage == null)
        {
            List<StageDefinition> stages = GetStages();
            currentStage = stages[0];
            selectedStage = currentStage.stageId;
        }

        won = false;
        experience = 0;
        ClearBattleObjects();
        spawning = true;

        witch.gameObject.SetActive(true);
        hero.gameObject.SetActive(true);
        witch.ResetForStage(Vector3.zero);
        hero.ResetForStage(new Vector3(-2f, 0f, 0f));

        state = GameState.Battle;
        spawnRoutine = StartCoroutine(SpawnWaves(currentStage));
    }

    private IEnumerator SpawnWaves(StageDefinition stage)
    {
        if (stage.waves != null)
        {
            for (int waveIndex = 0; waveIndex < stage.waves.Length; waveIndex++)
            {
                StageWave wave = stage.waves[waveIndex];
                if (wave == null) continue;

                if (wave.startDelay > 0f)
                    yield return new WaitForSeconds(wave.startDelay);

                for (int i = 0; i < Mathf.Max(0, wave.count); i++)
                {
                    if (state != GameState.Battle) yield break;

                    SpawnMonster(wave.monsterId, wave.minDistanceFromWitch, i);
                    if (wave.spawnInterval > 0f)
                        yield return new WaitForSeconds(wave.spawnInterval);
                }
            }
        }

        spawning = false;
        spawnRoutine = null;
    }

    private void SpawnMonster(int monsterId, float minDistanceFromWitch, int indexInWave)
    {
        MonsterDefinition definition = monsterCatalog != null
            ? monsterCatalog.GetMonster(monsterId)
            : null;

        GameObject source;
        if (!monsterSources.TryGetValue(monsterId, out source) &&
            !monsterSources.TryGetValue(0, out source))
        {
            source = null;
            foreach (GameObject fallback in monsterSources.Values)
            {
                source = fallback;
                break;
            }
        }

        if (source == null) return;

        GameObject monsterObject = Instantiate(source);
        monsterObject.name = $"Monster_{monsterId}_{spawnedMonsters.Count + 1}";
        monsterObject.SetActive(true);
        monsterObject.transform.position = GetSpawnPosition(witch.transform.position, minDistanceFromWitch);

        Monster monster = monsterObject.GetComponent<Monster>();
        if (monster == null)
        {
            Destroy(monsterObject);
            return;
        }

        monster.ApplyDefinition(definition);
        monster.SetTarget(witch.transform);
        spawnedMonsters.Add(monster);
    }

    public void SpawnExperienceOrb(Vector3 position)
    {
        if (state != GameState.Battle) return;

        Sprite orbSprite = GetExperienceOrbSprite();
        if (orbSprite == null) return;

        GameObject orbObject = new GameObject("ExperienceOrb");
        orbObject.transform.position = position;
        orbObject.transform.localScale = Vector3.one * 0.87f;

        SpriteRenderer renderer = orbObject.AddComponent<SpriteRenderer>();
        renderer.sprite = orbSprite;
        renderer.sortingOrder = 1;

        CircleCollider2D pickupCollider = orbObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.42f;

        ExperienceOrb orb = orbObject.AddComponent<ExperienceOrb>();
        orb.Initialize(this, hero != null ? hero.transform : null, ExperiencePerOrb);
    }

    private Sprite GetExperienceOrbSprite()
    {
        if (experienceOrbSprite != null) return experienceOrbSprite;

        Texture2D texture = Resources.Load<Texture2D>("ExperienceOrb/ExperienceOrb");
        if (texture == null)
        {
            Debug.LogError("経験値オーブの画像が見つかりません。Resources/ExperienceOrb/ExperienceOrb.pngを確認してください。");
            return null;
        }

        experienceOrbSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            1024f);
        return experienceOrbSprite;
    }

    private Sprite GetWitchPortraitSprite()
    {
        if (witchPortraitSprite != null)
            return witchPortraitSprite;

        Texture2D texture = Resources.Load<Texture2D>("Witch/WitchBattleSprite");
        if (texture != null)
        {
            witchPortraitSprite = Sprite.Create(
                texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f),
                100f);
            witchPortraitSprite.name = "RuntimeWitchPortrait";
        }

        if (witchPortraitSprite == null)
            Debug.LogError("魔女の立ち絵が見つかりません。Resources/Witch/WitchBattleSprite.pngを確認してください。");
        return witchPortraitSprite;
    }

    public void CollectExperience(int amount)
    {
        experience = Mathf.Clamp(experience + Mathf.Max(0, amount), 0, ExperienceToNextLevel);
    }

    public void SpawnCoin(Vector3 position)
    {
        SpawnCoin(position, false);
    }

    public void SpawnCoin(Vector3 position, bool guaranteed)
    {
        if (state != GameState.Battle) return;
        if (!guaranteed && Random.value > CoinDropChance) return;

        Sprite sprite = GetCoinSprite();
        if (sprite == null) return;

        GameObject coinObject = new GameObject("Coin");
        coinObject.transform.position = position + Vector3.right * 0.32f;
        coinObject.transform.localScale = Vector3.one * 0.63f;

        SpriteRenderer renderer = coinObject.AddComponent<SpriteRenderer>();
        renderer.sprite = sprite;
        renderer.sortingOrder = 1;

        CircleCollider2D pickupCollider = coinObject.AddComponent<CircleCollider2D>();
        pickupCollider.isTrigger = true;
        pickupCollider.radius = 0.42f;

        CoinPickup coin = coinObject.AddComponent<CoinPickup>();
        coin.Initialize(this, hero != null ? hero.transform : null, CoinsPerDrop);
    }

    private Sprite GetCoinSprite()
    {
        if (coinSprite != null) return coinSprite;

        Texture2D texture = Resources.Load<Texture2D>("Coin/Coin");
        if (texture == null)
        {
            Debug.LogError("コインの画像が見つかりません。Resources/Coin/Coin.pngを確認してください。");
            return null;
        }

        coinSprite = Sprite.Create(
            texture,
            new Rect(0f, 0f, texture.width, texture.height),
            new Vector2(0.5f, 0.5f),
            1024f);
        return coinSprite;
    }

    public void CollectCoins(int amount)
    {
        coins += Mathf.Max(0, amount);
        SaveProgress();
    }

    private static int GetUpgradeLevel(string key)
    {
        return Mathf.Max(0, PlayerPrefs.GetInt(key, 0));
    }

    private static int GetUpgradeCostForLevel(string key, int levelIndex)
    {
        return SlashDamageUpgradeBaseCost + Mathf.Max(0, levelIndex) * UpgradeCostStep;
    }

    private static int GetUpgradeCost(string key)
    {
        return GetUpgradeCostForLevel(key, GetUpgradeLevel(key));
    }

    public static int GetHeroMaxHealth()
    {
        return BaseHeroHealth + GetUpgradeLevel(HeroHealthLevelKey) * HealthUpgradeAmount;
    }

    public static int GetWitchMaxHealth()
    {
        return BaseWitchHealth + GetUpgradeLevel(WitchHealthLevelKey) * HealthUpgradeAmount;
    }

    public static float GetHeroMoveSpeed()
    {
        return BaseHeroMoveSpeed + GetUpgradeLevel(HeroSpeedLevelKey) * SpeedUpgradeAmount;
    }

    public static float GetHeroAttackInterval()
    {
        return Mathf.Max(
            MinimumHeroAttackInterval,
            BaseHeroAttackInterval -
            GetUpgradeLevel(AttackSpeedLevelKey) * AttackSpeedUpgradeAmount);
    }

    public static int GetSlashPiercingHits()
    {
        return BaseSlashPiercingHits + GetUpgradeLevel(SlashPierceLevelKey);
    }

    public static int GetHeroSlashDamage()
    {
        int level = Mathf.Max(0, PlayerPrefs.GetInt(SlashDamageLevelKey, 0));
        return BaseSlashDamage + level;
    }

    private bool TryBuySkillNode(int nodeIndex)
    {
        if (nodeIndex < 0 || nodeIndex >= GetSkillNodeCount()) return false;
        if (IsSkillNodePurchased(nodeIndex) || !IsSkillNodeUnlocked(nodeIndex))
            return false;

        string key = SkillUpgradeKeys[GetSkillBranchIndex(nodeIndex)];
        return TryBuyUpgrade(key, GetSkillLevelIndex(nodeIndex));
    }

    private bool TryBuyUpgrade(string key, int levelIndex)
    {
        int currentLevel = GetUpgradeLevel(key);
        if (currentLevel != levelIndex) return false;

        int cost = GetUpgradeCostForLevel(key, levelIndex);
        if (coins < cost) return false;

        coins -= cost;
        PlayerPrefs.SetInt(key, currentLevel + 1);
        SaveProgress();
        PlayConfirmSound();
        return true;
    }

    private void SaveProgress()
    {
        PlayerPrefs.SetInt(CoinBalanceKey, Mathf.Max(0, coins));
        PlayerPrefs.Save();
    }

    private Vector3 GetSpawnPosition(Vector3 witchPosition, float minDistance)
    {
        for (int attempt = 0; attempt < 100; attempt++)
        {
            Vector3 position = new Vector3(
                Random.Range(MinX, MaxX),
                Random.Range(MinY, MaxY),
                0f);

            if (Vector3.Distance(position, witchPosition) >= Mathf.Max(0.1f, minDistance))
                return position;
        }

        return new Vector3(MaxX, MaxY, 0f);
    }

    private void Finish(bool isWin, DefeatReason reason = DefeatReason.WitchDefeated)
    {
        if (state != GameState.Battle) return;

        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
        spawning = false;
        won = isWin;
        defeatReason = reason;
        PlayResultSound(isWin);

        if (isWin)
        {
            MarkStageCleared(currentStage != null
                ? currentStage.stageId
                : selectedStage);
            CollectFieldPickups();
        }

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            if (spawnedMonsters[i] != null)
                spawnedMonsters[i].StopMovement();
        }

        // Result screens are static. In particular, a witch defeat must not
        // leave a living hero controllable behind the failure message.
        if (hero != null)
            hero.StopForResult();

        // Do not let a slash that was already spawned remain visible after
        // the hero dies or the battle has ended.
        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++)
            Destroy(projectiles[i].gameObject);

        state = GameState.Result;
    }

    private void CollectFieldPickups()
    {
        ExperienceOrb[] orbs = FindObjectsByType<ExperienceOrb>(FindObjectsInactive.Include);
        for (int i = 0; i < orbs.Length; i++)
        {
            if (orbs[i] != null)
                orbs[i].CollectImmediately();
        }

        CoinPickup[] coinPickups = FindObjectsByType<CoinPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < coinPickups.Length; i++)
        {
            if (coinPickups[i] != null)
                coinPickups[i].CollectImmediately();
        }
    }

    private void ReturnToMenu()
    {
        PlayConfirmSound();
        if (!mapOnlyScene)
        {
            // Returning from the battle/result scene should land on the
            // stage-select map, not make the player confirm the title again.
            returnToStageSelectRequested = true;
            SceneManager.LoadScene(MapSceneName);
            return;
        }

        ClearBattleObjects();
        if (witch != null)
            witch.gameObject.SetActive(false);
        if (hero != null)
            hero.gameObject.SetActive(false);
        stageInfoOpen = false;
        stageInfoStageId = 0;
        state = GameState.Menu;
        RefreshMapStagePresentation();
        UpdateTitleButtonOverlay();
        RequestEditorRepaint();
    }

    private bool TryGetNextStageId(out int nextStageId)
    {
        nextStageId = 0;
        if (!won)
            return false;

        List<StageDefinition> stages = GetStages();
        int currentIndex = stages.FindIndex(stage => stage != null &&
            stage.stageId == selectedStage);
        int nextIndex = currentIndex + 1;
        if (currentIndex < 0 || nextIndex >= stages.Count ||
            !IsStageUnlocked(stages, nextIndex))
            return false;

        nextStageId = stages[nextIndex].stageId;
        return true;
    }

    private void OpenNextStageInfo()
    {
        if (!TryGetNextStageId(out int nextStageId))
            return;

        PlayConfirmSound();
        // The result screen is in the battle scene. Return to the map scene
        // and ask it to open the same stage-information modal automatically.
        PlayerPrefs.SetInt(PendingStageInfoKey, nextStageId);
        PlayerPrefs.Save();
        returnToStageSelectRequested = true;
        SceneManager.LoadScene(MapSceneName);
    }

    private void ClearBattleObjects()
    {
        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
        spawning = false;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            if (spawnedMonsters[i] != null) Destroy(spawnedMonsters[i].gameObject);
        }
        spawnedMonsters.Clear();
        DestroyWitchSkillEffect();
        DestroyWitchSkillPortrait();

        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++) Destroy(projectiles[i].gameObject);

        ExperienceOrb[] orbs = FindObjectsByType<ExperienceOrb>(FindObjectsInactive.Include);
        for (int i = 0; i < orbs.Length; i++) Destroy(orbs[i].gameObject);

        CoinPickup[] coinPickups = FindObjectsByType<CoinPickup>(FindObjectsInactive.Include);
        for (int i = 0; i < coinPickups.Length; i++) Destroy(coinPickups[i].gameObject);
    }

    private void OnGUI()
    {
        if (!runtimeInitialized) return;
#if UNITY_EDITOR
        Vector2 guiOrigin = GUIUtility.GUIToScreenPoint(Vector2.zero);
        Vector2 guiEnd = GUIUtility.GUIToScreenPoint(new Vector2(Screen.width, Screen.height));
        editorGameViewOrigin = guiOrigin;
        editorGameViewSize = guiEnd - guiOrigin;
#endif

        if (state == GameState.Battle)
        {
            DrawBattleHud();
            return;
        }

        // Menu map rendering/input lives only in the Canvas ScrollRect. Do
        // not draw the old IMGUI map over it, or the visible position can
        // differ from the ScrollRect position receiving the user's drag.
        if (state == GameState.Menu)
        {
            if (!mapCameraConfigured)
                ConfigureMapCamera();

            SyncMapVisualToCamera();
            UpdateTitleButtonHover(titleUpgradeButton, GetMapUpgradeButtonDesignRect(),
                false);
            UpdateTitleButtonHover(mapTitleButton, GetMapTitleButtonDesignRect(),
                false);
            if (stageInfoOpen)
            {
                StageDefinition infoStage = GetStageInfoDefinition();
                if (infoStage != null)
                    DrawStageInfoModal(infoStage);
            }
            else
            {
                DrawMapUpgradeInputTarget();
            }
            return;
        }

        if (state == GameState.Title)
        {
            // The title visuals are rendered by the runtime Canvas. Keep a
            // single transparent IMGUI target for mouse clicks, while
            // keyboard confirmation is handled in Update().
            if (titleHelpOpen)
            {
                UpdateTitleButtonHover(titleHelpBackButton,
                    GetTitleHelpBackButtonDesignRect(), true);
            }
            else
            {
                UpdateTitleButtonHover(titleStageButton,
                    GetTitleStageButtonDesignRect(), titleSelection == 0);
                UpdateTitleButtonHover(titleHelpButton,
                    GetTitleHelpButtonDesignRect(), titleSelection == 1);
            }
            DrawOverlayInputTargets();
            return;
        }

        const float resultPanelWidth = 680f;
        float resultPanelHeight = 480f;
        if (state == GameState.Result)
        {
            int nextStageId;
            if (TryGetNextStageId(out nextStageId))
                resultPanelHeight = 560f;
        }

        Rect panel = state == GameState.Upgrade
            ? GetUpgradePanelRect()
            : new Rect(
                (Screen.width - Mathf.Min(resultPanelWidth, Screen.width - 40f)) * 0.5f,
                (Screen.height - Mathf.Min(resultPanelHeight, Screen.height - 28f)) * 0.5f,
                Mathf.Min(resultPanelWidth, Screen.width - 40f),
                Mathf.Min(resultPanelHeight, Screen.height - 28f));

        if (state == GameState.Result)
        {
            DrawResult(panel);
        }
        else
        {
            // Canvas UI is authored at 1280x720 and CanvasScaler enlarges it
            // for the actual Game view. Apply the same transform to IMGUI so
            // the upgrade panel and its clipping frame use the full screen
            // instead of remaining at an unscaled 1180x680 pixel size.
            GetFrontendGuiMetrics(out float scale, out Vector2 offset,
                out _, out _);
            Matrix4x4 previousMatrix = GUI.matrix;
            GUI.matrix = Matrix4x4.TRS(offset, Quaternion.identity,
                Vector3.one * scale);
            DrawUpgrade(panel);
            GUI.matrix = previousMatrix;
        }
    }

    private Vector2 GetPointerScreenPoint(Vector2 inputPosition)
    {
#if UNITY_EDITOR
        if (editorGameViewSize.x > 1f && editorGameViewSize.y > 1f)
        {
            Vector2 localPoint = inputPosition - editorGameViewOrigin;
            return new Vector2(
                localPoint.x / editorGameViewSize.x * Screen.width,
                (1f - localPoint.y / editorGameViewSize.y) * Screen.height);
        }
#endif
        return inputPosition;
    }

    private void HandleOverlayEditorInput()
    {
        if (Event.current == null) return;

        if (state == GameState.Title && Event.current.type == EventType.KeyDown &&
            (Event.current.keyCode == KeyCode.Return ||
             Event.current.keyCode == KeyCode.KeypadEnter ||
             Event.current.keyCode == KeyCode.Space))
        {
            ActivateTitleSelection();
            Event.current.Use();
            RequestEditorRepaint();
            return;
        }

    }

    private Rect DesignRectToGuiRect(Rect designRect)
    {
        return new Rect(
            designRect.x * Screen.width / 1280f,
            designRect.y * Screen.height / 720f,
            designRect.width * Screen.width / 1280f,
            designRect.height * Screen.height / 720f);
    }

    private Rect GetTitleStageButtonDesignRect()
    {
        const float panelHeight = TitlePanelHeight;
        const float buttonWidth = 800f;
        const float buttonHeight = 86f;
        float panelTop = (720f - panelHeight) * 0.5f;
        float buttonX = (1280f - TitlePanelWidth) * 0.5f + 100f;
        return new Rect(buttonX, panelTop + 300f, buttonWidth, buttonHeight);
    }

    private Rect GetMapStageDesignRect(int index, int stageCount)
    {
        const float panelWidth = MapPanelWidth;
        const float panelHeight = MapPanelHeight;
        const float nodeSize = MapNodeSize;
        float panelLeft = (1280f - panelWidth) * 0.5f;
        float panelTop = (720f - panelHeight) * 0.5f;
        Rect mapArea = new Rect(26f, 60f, MapViewportWidth, MapViewportHeight);
        Vector2 mapPosition = GetStageNodePosition(mapArea, index, stageCount);
        Vector2 nodeCenter = new Vector2(
            panelLeft + panelWidth * 0.5f + mapPosition.x - mapArea.center.x,
            panelTop + panelHeight * 0.5f - (mapPosition.y - mapArea.center.y));
        return new Rect(
            nodeCenter.x - nodeSize * 0.5f,
            nodeCenter.y - nodeSize * 0.5f,
            nodeSize,
            nodeSize);
    }

    private void DrawOverlayInputTargets()
    {
        if (state == GameState.Title)
        {
            if (titleHelpOpen)
            {
                if (GUI.Button(DesignRectToGuiRect(GetTitleHelpBackButtonDesignRect()),
                    GUIContent.none, GUIStyle.none))
                    CloseTitleHelp();
                return;
            }

            if (GUI.Button(DesignRectToGuiRect(GetTitleStageButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
                OpenStageMenu();
            if (GUI.Button(DesignRectToGuiRect(GetTitleHelpButtonDesignRect()),
                GUIContent.none, GUIStyle.none))
                OpenTitleHelp();
            return;
        }

        if (state != GameState.Menu) return;
        List<StageDefinition> stages = GetStages();
        for (int i = 0; i < stages.Count; i++)
        {
            if (GUI.Button(DesignRectToGuiRect(GetMapStageDesignRect(i, stages.Count)),
                GUIContent.none, GUIStyle.none))
            {
                OpenStageInfo(stages[i].stageId);
            }
        }
    }

    private Rect GetMapUpgradeButtonDesignRect()
    {
        return new Rect(980f, 650f, 220f, 42f);
    }

    private Rect GetMapTitleButtonDesignRect()
    {
        return new Rect(80f, 650f, 220f, 42f);
    }

    private Rect GetTitleHelpButtonDesignRect()
    {
        return new Rect(240f, 435f, 800f, 70f);
    }

    private Rect GetTitleHelpBackButtonDesignRect()
    {
        return new Rect(240f, 570f, 800f, 58f);
    }

    private void DrawMapUpgradeInputTarget()
    {
        if (state != GameState.Menu) return;

        if (GUI.Button(DesignRectToGuiRect(GetMapUpgradeButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            OpenUpgradeMenu();
        }
        if (GUI.Button(DesignRectToGuiRect(GetMapTitleButtonDesignRect()),
            GUIContent.none, GUIStyle.none))
        {
            ReturnToTitle();
        }
    }

    private void DrawTitle(Rect panel)
    {
        if (Event.current != null && Event.current.type == EventType.KeyDown)
        {
            if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.KeypadEnter ||
                Event.current.keyCode == KeyCode.Space)
            {
                ActivateTitleSelection();
                Event.current.Use();
                return;
            }
        }

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 38,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUIStyle subtitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };
        subtitle.normal.textColor = new Color(1f, 0.93f, 0.72f);

        DrawMenuBackdrop(panel, true);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 62f, panel.width - 40f, 64f),
            "WITCH & HERO", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 128f, panel.width - 40f, 30f),
            "魔女と勇者の小さな冒険", subtitle);

        float buttonWidth = panel.width - 100f;
        float buttonX = panel.x + 50f;
        Rect stageButton = new Rect(buttonX, panel.y + 205f, buttonWidth, 58f);
        if (GUI.Button(stageButton, "ステージを選ぶ",
            CreateHoverButtonStyle(20, FontStyle.Bold)))
        {
            OpenStageMenu();
        }

        Rect upgradeButton = new Rect(buttonX, panel.y + 275f, buttonWidth, 58f);
        if (GUI.Button(upgradeButton, "強化画面",
            CreateHoverButtonStyle(20, FontStyle.Bold)))
        {
            OpenUpgradeMenu();
        }
    }

    private void DrawMenu(Rect panel, List<StageDefinition> stages)
    {
        GUIStyle worldMapLabel = new GUIStyle(GUI.skin.label)
        {
            fontSize = 15,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        worldMapLabel.normal.textColor = Color.white;
        GUIStyle coinLabel = new GUIStyle(GUI.skin.label)
        {
            fontSize = 14,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        coinLabel.normal.textColor = Color.white;
        DrawMenuBackdrop(panel, false);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 20f, panel.width - 40f, 26f),
            "WORLD MAP", worldMapLabel);
        DrawCoinCounter(new Rect(panel.x + panel.width - 180f, panel.y + 18f, 150f, 34f), coinLabel);

        Rect mapViewport = new Rect(panel.x + 22f, panel.y + 58f,
            panel.width - 44f, panel.height - 76f);
        Rect mapContent = new Rect(0f, 0f, 1280f, 800f);
        if (!mapScrollInitialized)
        {
            // Start in the middle so a natural drag in any direction has
            // room to move. Starting at an edge made one drag direction
            // appear to do nothing because the scroll was already clamped.
            mapScrollPosition = new Vector2(
                Mathf.Max(0f, (mapContent.width - mapViewport.width) * 0.5f),
                Mathf.Max(0f, (mapContent.height - mapViewport.height) * 0.5f));
            mapScrollInitialized = true;
            SyncMapPanOverlayFromPosition();
        }

        Event currentEvent = Event.current;
        UpdateMapScroll(mapViewport, mapContent);
        HandleMapEventKeyboardPan(currentEvent, mapContent, mapViewport);

        // Translate the map explicitly. This keeps the visual offset tied to
        // mapScrollPosition instead of letting an IMGUI ScrollView restore its
        // own internal position between frames.
        GUI.BeginGroup(mapViewport);
        GUI.BeginGroup(new Rect(-mapScrollPosition.x, -mapScrollPosition.y,
            mapContent.width, mapContent.height));
        DrawMapContentBackdrop(mapContent);

        Vector2[] nodePositions = new Vector2[stages.Count];
        for (int i = 0; i < stages.Count; i++)
            nodePositions[i] = GetStageNodePosition(mapContent, i, stages.Count);

        for (int i = 0; i < nodePositions.Length - 1; i++)
        {
            DrawMapLine(nodePositions[i], nodePositions[i + 1],
                new Color(0.72f, 0.53f, 0.28f, 0.95f), 10f);
        }

        StageDefinition hoveredStage = null;
        Vector2 hoveredNodePosition = Vector2.zero;
        for (int i = 0; i < stages.Count; i++)
        {
            StageDefinition stage = stages[i];
            Vector2 nodePosition = nodePositions[i];
            const float nodeSize = 72f;

            Vector2 contentPointer = Event.current.mousePosition - mapViewport.position +
                mapScrollPosition;
            Rect nodeButton = new Rect(nodePosition.x - nodeSize * 0.5f,
                nodePosition.y - nodeSize * 0.5f, nodeSize, nodeSize);
            bool hovered = nodeButton.Contains(contentPointer);
            Color nodeColor = i == stages.Count - 1
                ? new Color(0.95f, 0.55f, 0.18f)
                : new Color(0.22f, 0.65f, 0.9f);
            if (hovered)
                nodeColor = Color.Lerp(nodeColor, new Color(1f, 0.84f, 0.36f), 0.42f);

            DrawMapNode(nodePosition, nodeColor, nodeSize, i % 3);

            if (hovered)
            {
                hoveredStage = stage;
                hoveredNodePosition = nodePosition;
            }
        }

        if (hoveredStage != null)
            DrawStagePopup(mapContent, hoveredNodePosition, hoveredStage);

        GUI.EndGroup();
        GUI.EndGroup();
    }

    private void HandleMapEventKeyboardPan(Event currentEvent, Rect content, Rect viewport)
    {
        if (currentEvent == null || currentEvent.type != EventType.KeyDown)
            return;

        Vector2 direction = Vector2.zero;
        switch (currentEvent.keyCode)
        {
            case KeyCode.A:
            case KeyCode.LeftArrow:
                direction.x = -1f;
                break;
            case KeyCode.D:
            case KeyCode.RightArrow:
                direction.x = 1f;
                break;
            case KeyCode.W:
            case KeyCode.UpArrow:
                direction.y = -1f;
                break;
            case KeyCode.S:
            case KeyCode.DownArrow:
                direction.y = 1f;
                break;
        }

        if (direction.sqrMagnitude <= 0.0001f)
            return;

        ApplyMapScroll(direction * 48f, content, viewport);
        currentEvent.Use();
    }

    private void UpdateMapScroll(Rect viewport, Rect content)
    {
        Event currentEvent = Event.current;
        if (currentEvent.type == EventType.MouseDown && currentEvent.button == 0)
        {
            if (!viewport.Contains(currentEvent.mousePosition))
                return;

            mapDragging = true;
            mapSuppressNodeClick = false;
            mapLastPointerPosition = currentEvent.mousePosition;
            return;
        }

        if (currentEvent.type == EventType.MouseDrag && mapDragging)
        {
            Vector2 pointerPosition = currentEvent.mousePosition;
            Vector2 delta = pointerPosition - mapLastPointerPosition;
            if (delta.sqrMagnitude > 0.01f)
            {
                mapSuppressNodeClick = true;
                ApplyMapScroll(-delta, content, viewport);
                mapLastPointerPosition = pointerPosition;
                currentEvent.Use();
            }
            return;
        }

        if (currentEvent.type == EventType.MouseUp && mapDragging)
        {
            if (!mapSuppressNodeClick)
            {
                List<StageDefinition> stages = GetStages();
                Vector2 contentPoint = currentEvent.mousePosition - viewport.position +
                    mapScrollPosition;
                for (int i = 0; i < stages.Count; i++)
                {
                    Vector2 nodePosition = GetStageNodePosition(content, i, stages.Count);
                    Rect nodeRect = new Rect(nodePosition.x - 36f, nodePosition.y - 36f,
                        72f, 72f);
                    if (nodeRect.Contains(contentPoint))
                    {
                        OpenStageInfo(stages[i].stageId);
                        currentEvent.Use();
                        break;
                    }
                }
            }

            mapDragging = false;
            if (mapSuppressNodeClick)
                currentEvent.Use();
            return;
        }

        if (currentEvent.type == EventType.ScrollWheel)
        {
            if (!viewport.Contains(currentEvent.mousePosition))
                return;
            Vector2 scrollDelta = currentEvent.shift
                ? new Vector2(currentEvent.delta.y * 24f, 0f)
                : new Vector2(0f, currentEvent.delta.y * 24f);
            ApplyMapScroll(scrollDelta, content, viewport);
            currentEvent.Use();
        }
    }

    private void ClampMapScroll(Rect content, Rect viewport)
    {
        mapScrollPosition.x = Mathf.Clamp(mapScrollPosition.x, 0f,
            Mathf.Max(0f, content.width - viewport.width));
        mapScrollPosition.y = Mathf.Clamp(mapScrollPosition.y, 0f,
            Mathf.Max(0f, content.height - viewport.height));
    }

    private void DrawMapContentBackdrop(Rect contentRect)
    {
        Color previousColor = GUI.color;
        Texture2D background = GetMapBackgroundTexture();
        GUI.color = Color.white;
        if (background != null)
            GUI.DrawTexture(contentRect, background, ScaleMode.StretchToFill);
        GUI.color = new Color(0.02f, 0.08f, 0.14f, 0.34f);
        GUI.DrawTexture(contentRect, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawStagePopup(Rect panel, Vector2 nodePosition, StageDefinition stage)
    {
        const float popupWidth = 280f;
        const float popupHeight = 124f;
        float popupX = nodePosition.x + 48f;
        float popupY = nodePosition.y - popupHeight * 0.5f;
        if (popupX + popupWidth > panel.xMax - 12f)
            popupX = nodePosition.x - popupWidth - 48f;
        popupX = Mathf.Clamp(popupX, panel.x + 12f, panel.xMax - popupWidth - 12f);
        popupY = Mathf.Clamp(popupY, panel.y + 48f, panel.yMax - popupHeight - 18f);

        GUIStyle popupTitle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        popupTitle.normal.textColor = Color.white;
        GUIStyle popupText = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleCenter
        };
        popupText.normal.textColor = new Color(1f, 0.93f, 0.72f);

        Rect popup = new Rect(popupX, popupY, popupWidth, popupHeight);
        GUI.Box(popup, GUIContent.none);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 8f, popup.width - 16f, 34f),
            stage.displayName, popupTitle);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 48f, popup.width - 16f, 28f),
            $"モンスター  {stage.TotalMonsterCount}体", popupText);
        GUI.Label(new Rect(popup.x + 8f, popup.y + 82f, popup.width - 16f, 28f),
            "クリックで詳細", popupText);
    }

    private void DrawStageInfoModal(StageDefinition stage)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.62f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = previousColor;

        const float popupWidth = 560f;
        const float popupHeight = 380f;
        Rect popup = new Rect(
            (Screen.width - popupWidth) * 0.5f,
            (Screen.height - popupHeight) * 0.5f,
            popupWidth,
            popupHeight);

        GUI.Box(popup, GUIContent.none);

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 40,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        title.normal.textColor = Color.white;
        GUI.Label(new Rect(popup.x + 20f, popup.y + 18f, popup.width - 40f, 58f),
            stage.displayName, title);

        GUIStyle info = new GUIStyle(GUI.skin.label)
        {
            fontSize = 26,
            alignment = TextAnchor.MiddleCenter
        };
        info.normal.textColor = new Color(1f, 0.93f, 0.72f);
        int waveCount = stage.waves == null ? 0 : stage.waves.Length;
        GUI.Label(new Rect(popup.x + 24f, popup.y + 88f, popup.width - 48f, 42f),
            $"モンスター  {stage.TotalMonsterCount}体", info);
        GUI.Label(new Rect(popup.x + 24f, popup.y + 130f, popup.width - 48f, 42f),
            $"ウェーブ  {waveCount}", info);

        GetStageInfoButtonRects(out Rect challengeRect, out Rect cancelRect);
        GUIStyle button = CreateHoverButtonStyle(26, FontStyle.Bold);
        GUIStyle selectedButton = new GUIStyle(button);
        selectedButton.normal.textColor = new Color(1f, 0.9f, 0.35f);

        if (GUI.Button(challengeRect, "挑む", stageInfoChoice == 0 ? selectedButton : button))
            ConfirmStageInfo();
        if (GUI.Button(cancelRect, "やめる", stageInfoChoice == 1 ? selectedButton : button))
            CloseStageInfo();

        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 18,
            alignment = TextAnchor.MiddleCenter
        };
        hint.normal.textColor = new Color(0.72f, 0.82f, 0.88f);
        GUI.Label(new Rect(popup.x + 20f, popup.y + 344f, popup.width - 40f, 26f),
            "← →で選択　Enterで決定　Escで戻る", hint);
    }

    private void DrawMenuBackdrop(Rect panel, bool includeBackground)
    {
        Color previousColor = GUI.color;
        if (includeBackground)
        {
            Texture2D background = GetMapBackgroundTexture();
            GUI.color = Color.white;
            if (background != null)
                GUI.DrawTexture(panel, background, ScaleMode.StretchToFill);
            else
                GUI.DrawTexture(panel, Texture2D.whiteTexture);
        }

        GUI.color = new Color(0.02f, 0.08f, 0.14f, 0.45f);
        GUI.DrawTexture(panel, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.55f);
        GUI.DrawTexture(new Rect(panel.x + 10f, panel.y + 10f, panel.width - 20f, 3f),
            Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panel.x + 10f, panel.y + panel.height - 13f,
            panel.width - 20f, 3f), Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private Texture2D GetMapBackgroundTexture()
    {
        if (mapBackgroundTexture != null) return mapBackgroundTexture;
        mapBackgroundTexture = Resources.Load<Texture2D>("StageMap/StageMapBackground");
        return mapBackgroundTexture;
    }

    private void DrawCoinCounter(Rect area, GUIStyle labelStyle)
    {
        float iconSize = Mathf.Min(32f, area.height);
        float textWidth = Mathf.Max(40f, area.width - iconSize - 8f);
        float contentWidth = iconSize + 8f + textWidth;
        float contentX = area.center.x - contentWidth * 0.5f;
        Rect frame = new Rect(contentX - 6f, area.y - 3f,
            contentWidth + 12f, area.height + 6f);
        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.68f);
        GUI.DrawTexture(frame, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.65f);
        GUI.DrawTexture(new Rect(frame.x, frame.y, frame.width, 2f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(frame.x, frame.yMax - 2f, frame.width, 2f), Texture2D.whiteTexture);
        GUI.color = Color.white;

        Sprite sprite = GetCoinSprite();
        if (sprite != null && sprite.texture != null)
        {
            GUI.DrawTexture(new Rect(contentX, area.y, iconSize, iconSize), sprite.texture,
                ScaleMode.ScaleToFit);
        }

        GUI.Label(new Rect(contentX + iconSize + 8f, area.y + 1f, textWidth,
            Mathf.Max(24f, area.height - 2f)),
            $"x{coins}", labelStyle);
        GUI.color = previousColor;
    }

    private Vector2 GetStageNodePosition(Rect mapArea, int index, int count)
    {
        if (count <= 1)
            return new Vector2(mapArea.center.x, mapArea.center.y);

        // Follow the roads and landmarks in StageMapBackground instead of
        // drawing a straight diagonal. The points are normalized so the same
        // route is used by the IMGUI map, the Canvas map, the drag overlay,
        // and the camera focus code. When fewer than ten stages are defined,
        // sample this route evenly; when more are added, continue from the
        // last point so the catalog remains extensible.
        float routePosition = count <= MapRoutePoints.Length
            ? (float)index / Mathf.Max(1, count - 1) * (MapRoutePoints.Length - 1)
            : index;
        int lowerIndex = Mathf.Clamp(Mathf.FloorToInt(routePosition), 0, MapRoutePoints.Length - 1);
        int upperIndex = Mathf.Min(lowerIndex + 1, MapRoutePoints.Length - 1);
        Vector2 normalizedPoint = Vector2.Lerp(MapRoutePoints[lowerIndex], MapRoutePoints[upperIndex],
            routePosition - lowerIndex);

        if (count > MapRoutePoints.Length)
        {
            float extraIndex = index - (MapRoutePoints.Length - 1);
            normalizedPoint += new Vector2(0.08f * extraIndex, -0.06f * extraIndex);
        }

        normalizedPoint.x = Mathf.Clamp(normalizedPoint.x, 0.08f, 0.92f);
        normalizedPoint.y = Mathf.Clamp(normalizedPoint.y, 0.12f, 0.86f);
        return new Vector2(
            Mathf.Lerp(mapArea.x, mapArea.xMax, normalizedPoint.x),
            Mathf.Lerp(mapArea.y, mapArea.yMax, normalizedPoint.y));
    }

    private void DrawMapLine(Vector2 start, Vector2 end, Color color, float width)
    {
        Color previousColor = GUI.color;
        Matrix4x4 previousMatrix = GUI.matrix;
        Vector2 direction = end - start;
        float distance = direction.magnitude;
        Vector2 unitDirection = direction / Mathf.Max(distance, 0.001f);
        const float lineInset = 58f;
        start += unitDirection * lineInset;
        end -= unitDirection * lineInset;
        direction = end - start;
        float length = direction.magnitude;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        GUIUtility.RotateAroundPivot(angle, start);
        GUI.color = new Color(0.16f, 0.1f, 0.05f, 0.78f);
        GUI.DrawTexture(new Rect(start.x, start.y - (width + 6f) * 0.5f,
                length, width + 6f), Texture2D.whiteTexture);
        GUI.color = color;
        GUI.DrawTexture(new Rect(start.x, start.y - width * 0.5f,
                length, width),
            Texture2D.whiteTexture);
        GUI.matrix = previousMatrix;
        GUI.color = previousColor;
    }

    private int GetHoveredSkillTreeNodeIndex(Vector2[] nodePositions,
        Vector2 treeGuiOrigin, Rect viewport)
    {
        if (nodePositions == null || nodePositions.Length == 0)
            return -1;

        bool hasPointer = TryGetGuiPointerPosition(out Vector2 pointer);
        if (!hasPointer || !viewport.Contains(pointer))
            return -1;
        pointer -= treeGuiOrigin;

        int hoveredIndex = -1;
        float nearestDistance = float.PositiveInfinity;
        float halfSize = SkillTreeNodeSize * 0.5f;
        for (int i = 0; i < nodePositions.Length; i++)
        {
            Rect nodeRect = new Rect(
                nodePositions[i].x - halfSize,
                nodePositions[i].y - halfSize,
                SkillTreeNodeSize,
                SkillTreeNodeSize);
            if (!hasPointer || !nodeRect.Contains(pointer))
                continue;

            // If a stale editor event or a scaled Game view ever makes two
            // hit rectangles overlap, resolve the hover to the closest node
            // instead of highlighting every matching rectangle.
            float distance = hasPointer
                ? (nodePositions[i] - pointer).sqrMagnitude
                : i;
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                hoveredIndex = i;
            }
        }

        return hoveredIndex;
    }

    private void DrawSkillTreeLine(Vector2 start, Vector2 end, Color color,
        float width)
    {
        Color previousColor = GUI.color;
        Vector2 direction = end - start;
        float distance = direction.magnitude;
        Vector2 unitDirection = direction / Mathf.Max(distance, 0.001f);
        const float startInset = 56f;
        const float endInset = 56f;
        start += unitDirection * startInset;
        end -= unitDirection * endInset;

        GUI.color = new Color(0.03f, 0.05f, 0.08f, 0.95f);
        DrawSkillTreeSegment(start, end, width + 5f);
        GUI.color = color;
        DrawSkillTreeSegment(start, end, width);
        GUI.color = previousColor;
    }

    private void DrawSkillTreeSegment(Vector2 start, Vector2 end, float width)
    {
        Vector2 direction = end - start;
        float length = direction.magnitude;
        int steps = Mathf.Max(1, Mathf.CeilToInt(length /
            Mathf.Max(1f, width * 0.5f)));
        for (int i = 0; i <= steps; i++)
        {
            float t = i / (float)steps;
            Vector2 point = Vector2.Lerp(start, end, t);
            GUI.DrawTexture(new Rect(point.x - width * 0.5f,
                point.y - width * 0.5f, width, width),
                Texture2D.whiteTexture);
        }
    }

    private void DrawSkillTreeNode(Vector2 center, float size, Color color,
        Color accent, string icon, string title, string value, string footer)
    {
        Texture2D circle = GetMapCircleTexture();
        if (circle == null)
            circle = Texture2D.whiteTexture;

        Color previousColor = GUI.color;
        Rect shadowRect = new Rect(center.x - size * 0.5f - 6f,
            center.y - size * 0.5f - 6f, size + 12f, size + 12f);
        Rect nodeRect = new Rect(center.x - size * 0.5f,
            center.y - size * 0.5f, size, size);
        GUI.color = new Color(0.01f, 0.02f, 0.04f, 0.95f);
        GUI.DrawTexture(shadowRect, circle, ScaleMode.StretchToFill);
        GUI.color = color;
        GUI.DrawTexture(nodeRect, circle, ScaleMode.StretchToFill);
        GUI.color = Color.white;

        float iconSize = Mathf.Clamp(size * 0.28f, 22f, 32f);
        Rect iconRect = new Rect(center.x - iconSize * 0.5f,
            nodeRect.y + size * 0.055f, iconSize, iconSize);
        GUI.color = accent;
        GUI.DrawTexture(iconRect, circle, ScaleMode.StretchToFill);
        GUI.color = Color.white;

        GUIStyle iconStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = Mathf.RoundToInt(iconSize * 0.66f),
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        iconStyle.normal.textColor = new Color(0.03f, 0.08f, 0.12f, 1f);
        GUI.Label(iconRect, icon, iconStyle);

        GUIStyle titleStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = title == "強化ツリー" ? 14 : size >= 100f ? 13 : 11,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold,
            wordWrap = true
        };
        GUIStyle valueStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = size >= 100f ? 13 : 11,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle footerStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = size >= 100f ? 10 : 9,
            alignment = TextAnchor.MiddleCenter,
            wordWrap = true
        };
        footerStyle.normal.textColor = new Color(1f, 0.92f, 0.62f, 1f);

        GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.31f,
            nodeRect.width - 14f, size * 0.21f), title, titleStyle);
        GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.52f,
            nodeRect.width - 14f, size * 0.17f), value, valueStyle);
        if (footer.StartsWith("コイン "))
        {
            Sprite coinSprite = GetCoinSprite();
            Texture2D coinTexture = coinSprite != null ? coinSprite.texture : null;
            float badgeWidth = Mathf.Clamp(size * 0.66f, 72f, 84f);
            const float badgeHeight = 26f;
            Rect costBadgeRect = new Rect(
                center.x - badgeWidth * 0.5f,
                nodeRect.y + size * 0.685f,
                badgeWidth,
                badgeHeight);
            GUI.color = new Color(0.015f, 0.025f, 0.04f, 0.9f);
            GUI.DrawTexture(costBadgeRect, Texture2D.whiteTexture);
            GUI.color = new Color(1f, 0.78f, 0.25f, 0.8f);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.y,
                costBadgeRect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.yMax - 2f,
                costBadgeRect.width, 2f), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.x, costBadgeRect.y,
                2f, costBadgeRect.height), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(costBadgeRect.xMax - 2f, costBadgeRect.y,
                2f, costBadgeRect.height), Texture2D.whiteTexture);

            float coinIconSize = Mathf.Clamp(size * 0.18f, 18f, 23f);
            Rect coinIconRect = new Rect(
                costBadgeRect.x + 7f,
                costBadgeRect.y + (badgeHeight - coinIconSize) * 0.5f,
                coinIconSize,
                coinIconSize);
            if (coinTexture != null)
            {
                GUI.color = Color.white;
                GUI.DrawTexture(coinIconRect, coinTexture, ScaleMode.ScaleToFit,
                    true);
            }

            string costText = footer.Substring("コイン ".Length);
            GUIStyle costStyle = new GUIStyle(footerStyle)
            {
                fontSize = 15,
                alignment = TextAnchor.MiddleLeft,
                fontStyle = FontStyle.Bold
            };
            GUI.Label(new Rect(coinIconRect.xMax + 4f,
                costBadgeRect.y,
                costBadgeRect.width - coinIconSize - 16f,
                badgeHeight), $"×{costText}", costStyle);
        }
        else
        {
            GUI.Label(new Rect(nodeRect.x + 7f, nodeRect.y + size * 0.70f,
                nodeRect.width - 14f, size * 0.20f), footer, footerStyle);
        }
        GUI.color = previousColor;
    }

    private void DrawMapNode(Vector2 center, Color color, float size, int iconType)
    {
        Texture2D circle = GetMapCircleTexture();
        Color previousColor = GUI.color;
        GUI.color = new Color(0.02f, 0.05f, 0.1f, 0.95f);
        GUI.DrawTexture(new Rect(center.x - size * 0.5f - 6f,
            center.y - size * 0.5f - 6f, size + 12f, size + 12f), circle);
        GUI.color = color;
        GUI.DrawTexture(new Rect(center.x - size * 0.5f,
            center.y - size * 0.5f, size, size), circle);
        Texture2D icon = GetNodeIconTexture(iconType);
        if (icon != null)
        {
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(center.x - size * 0.5f + 10f,
                center.y - size * 0.5f + 10f, size - 20f, size - 20f),
                icon, ScaleMode.ScaleToFit);
        }
        GUI.color = previousColor;
    }

    private Texture2D GetNodeIconTexture(int iconType)
    {
        if (iconType == 0)
        {
            if (nodeBuildingTexture == null)
                nodeBuildingTexture = Resources.Load<Texture2D>("StageMap/NodeBuilding");
            return nodeBuildingTexture;
        }

        if (iconType == 1)
        {
            if (nodeNatureTexture == null)
                nodeNatureTexture = Resources.Load<Texture2D>("StageMap/NodeNature");
            return nodeNatureTexture;
        }

        if (nodeMonsterTexture == null)
            nodeMonsterTexture = Resources.Load<Texture2D>("StageMap/NodeMonster");
        return nodeMonsterTexture;
    }

    private Sprite GetNodeIconSprite(int iconType)
    {
        if (iconType == 0)
        {
            if (nodeBuildingSprite == null)
            {
                Texture2D texture = GetNodeIconTexture(0);
                if (texture != null)
                    nodeBuildingSprite = Sprite.Create(texture,
                        new Rect(0f, 0f, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f), 100f);
            }

            return nodeBuildingSprite;
        }

        if (iconType == 1)
        {
            if (nodeNatureSprite == null)
            {
                Texture2D texture = GetNodeIconTexture(1);
                if (texture != null)
                    nodeNatureSprite = Sprite.Create(texture,
                        new Rect(0f, 0f, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f), 100f);
            }

            return nodeNatureSprite;
        }

        if (nodeMonsterSprite == null)
        {
            Texture2D texture = GetNodeIconTexture(2);
            if (texture != null)
                nodeMonsterSprite = Sprite.Create(texture,
                    new Rect(0f, 0f, texture.width, texture.height),
                    new Vector2(0.5f, 0.5f), 100f);
        }

        return nodeMonsterSprite;
    }

    private Sprite GetMapCircleSprite()
    {
        if (mapCircleSprite == null)
        {
            Texture2D texture = GetMapCircleTexture();
            mapCircleSprite = Sprite.Create(texture,
                new Rect(0f, 0f, texture.width, texture.height),
                new Vector2(0.5f, 0.5f), 100f);
        }

        return mapCircleSprite;
    }

    private Texture2D GetMapCircleTexture()
    {
        if (mapCircleTexture != null) return mapCircleTexture;

        mapCircleTexture = new Texture2D(64, 64, TextureFormat.RGBA32, false);
        mapCircleTexture.hideFlags = HideFlags.HideAndDontSave;
        for (int y = 0; y < 64; y++)
        {
            for (int x = 0; x < 64; x++)
            {
                float distance = Vector2.Distance(new Vector2(x, y), new Vector2(31.5f, 31.5f));
                mapCircleTexture.SetPixel(x, y,
                    distance <= 31.5f ? Color.white : Color.clear);
            }
        }
        mapCircleTexture.Apply();
        return mapCircleTexture;
    }

    private void DrawBattleHud()
    {
        GUIStyle hud = new GUIStyle(GUI.skin.label)
        {
            fontSize = 30,
            alignment = TextAnchor.UpperLeft
        };
        hud.normal.textColor = Color.white;

        const float coinPanelWidth = 220f;

        DrawHudPanel(new Rect(12f, 10f, coinPanelWidth, 64f));
        DrawExperienceBar();

        DrawCoinCounter(new Rect(20f, 16f, coinPanelWidth - 30f, 48f), hud);
        DrawCharacterHealthBars();

        DrawMonsterHealthBars();
    }

    private void DrawExperienceBar()
    {
        float panelWidth = Mathf.Min(620f, Screen.width - 260f);
        const float panelHeight = 140f;
        float panelX = (Screen.width - panelWidth) * 0.5f;

        DrawHudPanel(new Rect(panelX, 12f, panelWidth, panelHeight));

        GUIStyle experienceStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 36,
            alignment = TextAnchor.UpperCenter,
            fontStyle = FontStyle.Bold
        };
        experienceStyle.normal.textColor = Color.white;
        GUI.Label(new Rect(panelX, 14f, panelWidth, 44f),
            $"経験値  {experience} / {ExperienceToNextLevel}", experienceStyle);
        DrawBar(new Rect(panelX + 14f, 62f, panelWidth - 28f, 30f),
            (float)experience / ExperienceToNextLevel,
            new Color(0.25f, 0.85f, 1f));

        GUIStyle skillStyle = new GUIStyle(GUI.skin.label)
        {
            fontSize = 24,
            alignment = TextAnchor.UpperCenter,
            fontStyle = FontStyle.Bold
        };
        skillStyle.normal.textColor = experience >= WitchSkillExperienceCost
            ? new Color(0.65f, 0.95f, 1f)
            : new Color(0.72f, 0.72f, 0.72f);
        GUI.Label(new Rect(panelX, 100f, panelWidth, 32f),
            $"E  魔女スキル  ({WitchSkillExperienceCost}経験値)", skillStyle);
    }

    private void DrawHudPanel(Rect rect)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.32f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawCharacterHealthBars()
    {
        Camera gameCamera = Camera.main;
        if (gameCamera == null) return;

        if (witch != null)
        {
            DrawCharacterHealthBar(gameCamera, witch.transform, "魔女",
                witch.Health, witch.MaxHealth,
                new Color(0.95f, 0.28f, 0.35f), 0f);
        }

        if (hero != null)
        {
            // Lift the hero label slightly so the two character bars remain
            // readable even when the hero is standing next to the witch.
            DrawCharacterHealthBar(gameCamera, hero.transform, "ヒーロー",
                hero.Health, hero.MaxHealth,
                new Color(0.25f, 0.75f, 1f), 0.42f);
        }
    }

    private void DrawCharacterHealthBar(Camera gameCamera, Transform character,
        string label, int health, int maxHealth, Color fillColor,
        float additionalHeight)
    {
        if (character == null) return;

        float characterTop = character.position.y;
        SpriteRenderer[] renderers = character.GetComponentsInChildren<SpriteRenderer>();
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null && renderers[i].enabled)
                characterTop = Mathf.Max(characterTop, renderers[i].bounds.max.y);
        }

        Vector3 worldPosition = new Vector3(
            character.position.x,
            characterTop + 0.16f + additionalHeight,
            character.position.z);
        Vector3 screenPosition = gameCamera.WorldToScreenPoint(worldPosition);
        if (screenPosition.z <= 0f) return;

        const float barWidth = 180f;
        const float barHeight = 20f;
        const float panelHeight = 32f;
        float x = Mathf.Clamp(screenPosition.x - barWidth * 0.5f,
            8f, Screen.width - barWidth - 8f);
        float y = Screen.height - screenPosition.y - panelHeight;
        if (y + panelHeight < 0f || y > Screen.height) return;

        Color previousColor = GUI.color;
        GUI.color = new Color(0.01f, 0.02f, 0.03f, 0.76f);
        GUI.DrawTexture(new Rect(x - 6f, y, barWidth + 12f, panelHeight),
            Texture2D.whiteTexture);
        GUI.color = previousColor;

        // Keep the bars above the characters without adding a text label.
        // The color and position identify the owner while preserving the
        // play-field visibility requested for the battle HUD.
        DrawBar(new Rect(x, y + 6f, barWidth, barHeight),
            (float)health / Mathf.Max(1, maxHealth), fillColor);
    }

    private void DrawBar(Rect rect, float ratio, Color fillColor)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.8f);
        GUI.DrawTexture(rect, Texture2D.whiteTexture);

        ratio = Mathf.Clamp01(ratio);
        if (ratio > 0f)
        {
            GUI.color = fillColor;
            GUI.DrawTexture(new Rect(rect.x, rect.y, rect.width * ratio, rect.height),
                Texture2D.whiteTexture);
        }

        GUI.color = previousColor;
    }

    private void DrawMonsterHealthBars()
    {
        Camera gameCamera = Camera.main;
        if (gameCamera == null) return;

        for (int i = 0; i < spawnedMonsters.Count; i++)
        {
            Monster monster = spawnedMonsters[i];
            if (monster == null || monster.IsDead) continue;

            // スプライトのフレームごとの大きさに影響されない固定位置に表示する。
            Vector3 worldBarPosition = monster.transform.position +
                Vector3.up * MonsterHealthBarYOffset;
            Vector3 screenPosition = gameCamera.WorldToScreenPoint(worldBarPosition);
            if (screenPosition.z <= 0f) continue;

            const float barWidth = 64f;
            const float barHeight = 9f;
            if (screenPosition.x < -barWidth || screenPosition.x > Screen.width + barWidth ||
                screenPosition.y < -20f || screenPosition.y > Screen.height + 20f)
                continue;

            float x = screenPosition.x - barWidth * 0.5f;
            float y = Screen.height - screenPosition.y - barHeight;
            if (x + barWidth < 0f || x > Screen.width ||
                y + barHeight < 0f || y > Screen.height)
                continue;

            DrawBar(new Rect(x, y, barWidth, barHeight), monster.HealthRatio,
                new Color(0.95f, 0.8f, 0.18f));
        }
    }

    private void DrawResult(Rect panel)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0f, 0f, 0f, 0.58f);
        GUI.DrawTexture(new Rect(0f, 0f, Screen.width, Screen.height),
            Texture2D.whiteTexture);
        GUI.color = new Color(0.04f, 0.11f, 0.16f, 0.98f);
        GUI.DrawTexture(panel, Texture2D.whiteTexture);
        GUI.color = new Color(0.95f, 0.78f, 0.25f, 0.9f);
        GUI.DrawTexture(new Rect(panel.x + 14f, panel.y + 14f,
            panel.width - 28f, 5f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(panel.x + 14f, panel.yMax - 19f,
            panel.width - 28f, 5f), Texture2D.whiteTexture);
        GUI.color = previousColor;

        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 48,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle text = new GUIStyle(GUI.skin.label)
        {
            fontSize = 25,
            alignment = TextAnchor.MiddleCenter
        };

        GUI.Label(new Rect(panel.x + 20f, panel.y + 36f, panel.width - 40f, 72f),
            won ? "勝利!" : "敗北...", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 112f, panel.width - 40f, 48f),
            won ? "モンスターをすべて倒しました" : GetDefeatMessage(), text);
        DrawCoinCounter(new Rect(panel.x + panel.width * 0.5f - 120f,
            panel.y + 168f, 240f, 44f), text);

        float buttonWidth = panel.width - 100f;
        float buttonX = panel.x + 35f;
        const float resultButtonHeight = 74f;
        const float resultButtonGap = 84f;
        GUIStyle resultButtonStyle = CreateHoverButtonStyle(24, FontStyle.Bold);
        float buttonY = 220f;
        int nextStageId;
        if (TryGetNextStageId(out nextStageId))
        {
            if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
                "次のステージへ", resultButtonStyle))
                OpenNextStageInfo();
            buttonY += resultButtonGap;
        }

        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "強化画面", resultButtonStyle))
            OpenUpgradeMenu();
        buttonY += resultButtonGap;
        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "もう一度プレイ", resultButtonStyle))
        {
            PlayConfirmSound();
            StartStage(selectedStage);
        }
        buttonY += resultButtonGap;
        if (GUI.Button(new Rect(buttonX, panel.y + buttonY, buttonWidth, resultButtonHeight),
            "ステージ選択へ", resultButtonStyle))
            ReturnToMenu();
    }

    private void DrawUpgrade(Rect panel)
    {
        GUIStyle title = new GUIStyle(GUI.skin.label)
        {
            fontSize = 32,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        GUIStyle text = new GUIStyle(GUI.skin.label)
        {
            fontSize = 16,
            alignment = TextAnchor.MiddleCenter
        };

        GUI.Label(new Rect(panel.x + 20f, panel.y + 20f, panel.width - 40f, 46f),
            "強化", title);
        GUI.Label(new Rect(panel.x + 20f, panel.y + 67f, panel.width - 40f, 28f),
            "集めたコインで魔女とヒーローを強化できます", text);
        DrawCoinCounter(new Rect(panel.x + panel.width - 205f,
            panel.y + 24f, 180f, 32f), text);

        GUIStyle hint = new GUIStyle(GUI.skin.label)
        {
            fontSize = 12,
            alignment = TextAnchor.MiddleCenter
        };
        hint.normal.textColor = new Color(0.72f, 0.82f, 0.88f);
        GUIStyle legend = new GUIStyle(GUI.skin.label)
        {
            fontSize = 13,
            alignment = TextAnchor.MiddleCenter,
            fontStyle = FontStyle.Bold
        };
        legend.normal.textColor = new Color(0.93f, 0.9f, 0.72f, 1f);
        GUI.Label(new Rect(panel.x + 30f, panel.y + 99f, panel.width - 60f, 24f),
            "剣 斬撃攻撃力　／　体 ヒーロー体力　／　魔 魔女体力　／　速 歩く速度　／　貫 斬撃貫通　／　連 攻撃速度",
            legend);
        Rect viewport = GetSkillTreeViewport(panel);
        DrawSkillTreeViewportSurface(viewport);
        // Keep the transparent Canvas hit rectangles in the same coordinate
        // system and size as the visible IMGUI nodes. This also repairs their
        // position after a Game view resize before the next pointer event.
        ConfigureSkillTreePanOverlayGeometry();
        UpdateSkillTreeEventInput(Event.current, viewport);
        UpdateSkillTreePanNodeButtons();

        Rect navigationBar = new Rect(panel.x + 28f, panel.y + 575f,
            285f, 95f);
        Color previousGuiColor = GUI.color;
        GUI.color = new Color(0.012f, 0.03f, 0.05f, 0.94f);
        GUI.DrawTexture(navigationBar, Texture2D.whiteTexture);
        GUI.color = previousGuiColor;

        float buttonWidth = 251f;
        float buttonX = panel.x + 45f;
        GUIStyle navigationStyle = CreateHoverButtonStyle(18, FontStyle.Bold);
        if (GUI.Button(new Rect(buttonX, panel.y + 590f, buttonWidth, 44f),
            "ステージ選択へ", navigationStyle))
            ReturnToMenu();

        GUIStyle resetStyle = CreateHoverButtonStyle(14);
        resetStyle.normal.textColor = resetProgressConfirm
            ? new Color(1f, 0.55f, 0.45f)
            : new Color(0.82f, 0.86f, 0.9f);
        string resetLabel = resetProgressConfirm
            ? "本当にリセットする（もう一度押す）"
            : "コイン・強化をリセット";
        if (GUI.Button(new Rect(buttonX, panel.y + 640f, buttonWidth, 25f),
            resetLabel, resetStyle))
        {
            if (resetProgressConfirm)
                ResetSavedProgress();
            else
                RequestProgressReset();
        }

        // Keep the tree inside its own clipped viewport. Dragging can still
        // move the content, but nodes can never paint over the header, coin
        // counter, or the navigation buttons outside this rectangle.
        GUI.BeginGroup(viewport);
        Vector2 treeCenter = new Vector2(
            viewport.width * 0.5f, viewport.height * 0.5f) +
            SkillTreeCenterOffset + skillTreePan;
        Vector2 rootPosition = treeCenter + SkillTreeRootOffset;
        int nodeCount = GetSkillNodeCount();
        Vector2[] nodePositions = new Vector2[nodeCount];
        for (int i = 0; i < nodeCount; i++)
        {
            nodePositions[i] = GetSkillTreeNodePosition(treeCenter, i);
        }

        for (int i = 0; i < nodeCount; i++)
        {
            int prerequisite = GetSkillNodePrerequisite(i);
            // Entry nodes branch from the small origin node above the grid;
            // later nodes connect only to their immediate predecessor below.
            Vector2 lineStart = prerequisite >= 0
                ? nodePositions[prerequisite]
                : rootPosition;
            string upgradeKey = SkillUpgradeKeys[GetSkillBranchIndex(i)];
            int levelIndex = GetSkillLevelIndex(i);
            bool purchased = IsSkillNodePurchased(i);
            bool unlocked = IsSkillNodeUnlocked(i);
            bool affordable = coins >= GetUpgradeCostForLevel(upgradeKey, levelIndex);
            Color lineColor = purchased
                ? new Color(0.42f, 0.75f, 0.34f, 0.95f)
                : unlocked && affordable
                    ? new Color(0.95f, 0.72f, 0.22f, 0.95f)
                    : new Color(0.38f, 0.43f, 0.48f, 0.9f);
            DrawSkillTreeLine(lineStart, nodePositions[i], lineColor, 4f);
        }

        DrawSkillTreeNode(rootPosition, 82f,
            new Color(0.35f, 0.23f, 0.12f, 1f),
            new Color(1f, 0.78f, 0.24f, 1f),
            "起", "原点", "START", "ここから分岐");

        int hoveredSkillNodeIndex = GetHoveredSkillTreeNodeIndex(nodePositions,
            viewport.position, viewport);
        for (int i = 0; i < nodePositions.Length; i++)
        {
            int branchIndex = GetSkillBranchIndex(i);
            int levelIndex = GetSkillLevelIndex(i);
            string upgradeKey = SkillUpgradeKeys[branchIndex];
            bool purchased = IsSkillNodePurchased(i);
            bool unlocked = IsSkillNodeUnlocked(i);
            int cost = GetUpgradeCostForLevel(upgradeKey, levelIndex);
            bool canBuy = unlocked && !purchased && coins >= cost;
            float nodeHalfSize = SkillTreeNodeSize * 0.5f;
            Rect nodeRect = new Rect(nodePositions[i].x - nodeHalfSize,
                nodePositions[i].y - nodeHalfSize,
                SkillTreeNodeSize, SkillTreeNodeSize);
            bool hovered = i == hoveredSkillNodeIndex;
            Color nodeColor = purchased
                ? new Color(0.38f, 0.52f, 0.24f, 1f)
                : unlocked
                    ? new Color(0.16f, 0.48f, 0.62f, 1f)
                    : new Color(0.20f, 0.24f, 0.28f, 1f);
            if (hovered)
                nodeColor = Color.Lerp(nodeColor, new Color(1f, 0.84f, 0.36f), 0.42f);

            string nodeStatus = purchased
                ? "取得済み"
                : unlocked
                    ? $"コイン {cost}"
                    : branchIndex == 5
                        ? $"他ノード {AttackSpeedUnlockRequiredNodes}個で解放"
                        : "ロック";
            DrawSkillTreeNode(nodePositions[i], SkillTreeNodeSize, nodeColor,
                GetSkillBranchAccent(branchIndex),
                GetSkillBranchIcon(branchIndex),
                SkillUpgradeNames[branchIndex],
                GetSkillEffectText(branchIndex),
                nodeStatus);

            GUI.enabled = canBuy && !skillTreeSuppressNodeClick;
            if (GUI.Button(nodeRect, GUIContent.none, GUIStyle.none))
            {
                TryBuySkillNode(i);
                RequestEditorRepaint();
            }
            GUI.enabled = true;
        }
        GUI.EndGroup();
        DrawSkillTreeViewportFrame(viewport);
        GUI.Label(new Rect(viewport.x, panel.y + 126f, viewport.width, 18f),
            "強化ノードを選択　／　ドラッグ・ホイール・WASDでツリーを移動", hint);
    }

    private void DrawSkillTreeViewportSurface(Rect viewport)
    {
        Color previousColor = GUI.color;
        GUI.color = new Color(0.015f, 0.04f, 0.065f, 0.62f);
        GUI.DrawTexture(viewport, Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private void DrawSkillTreeViewportFrame(Rect viewport)
    {
        Color previousColor = GUI.color;
        const float outerThickness = 3f;
        const float innerThickness = 1f;

        // Draw after the clipped group so the boundary stays visible even
        // when a node is dragged against an edge. The four sides are the
        // exact point where the tree stops being visible.
        GUI.color = new Color(0.95f, 0.72f, 0.22f, 0.95f);
        GUI.DrawTexture(new Rect(viewport.x, viewport.y,
            viewport.width, outerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x, viewport.yMax - outerThickness,
            viewport.width, outerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x, viewport.y,
            outerThickness, viewport.height), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.xMax - outerThickness, viewport.y,
            outerThickness, viewport.height), Texture2D.whiteTexture);

        GUI.color = new Color(1f, 0.9f, 0.52f, 0.48f);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness, viewport.y + outerThickness,
            viewport.width - outerThickness * 2f, innerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness,
            viewport.yMax - outerThickness - innerThickness,
            viewport.width - outerThickness * 2f, innerThickness), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.x + outerThickness, viewport.y + outerThickness,
            innerThickness, viewport.height - outerThickness * 2f), Texture2D.whiteTexture);
        GUI.DrawTexture(new Rect(viewport.xMax - outerThickness - innerThickness,
            viewport.y + outerThickness, innerThickness,
            viewport.height - outerThickness * 2f), Texture2D.whiteTexture);
        GUI.color = previousColor;
    }

    private string GetDefeatMessage()
    {
        return defeatReason == DefeatReason.HeroDefeated
            ? "ヒーローが倒されました"
            : "魔女が倒されました";
    }
}
