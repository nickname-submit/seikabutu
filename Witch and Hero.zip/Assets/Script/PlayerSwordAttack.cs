using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerSwordAttack : MonoBehaviour
{
    [SerializeField] private GameObject swordPrefab;
    [SerializeField] private float attackDelay = 0.25f;

    private Vector2 lastDirection = Vector2.down;
    private float nextAttackTime;
    private bool isAttacking;
    private Hero hero;

    private void Awake()
    {
        hero = GetComponent<Hero>();
    }

    private void Update()
    {
        if (hero != null && hero.IsDead)
        {
            if (isAttacking)
            {
                StopAllCoroutines();
                isAttacking = false;
            }
            return;
        }

        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed)
            lastDirection = Vector2.up;
        else if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed)
            lastDirection = Vector2.down;
        else if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed)
            lastDirection = Vector2.left;
        else if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed)
            lastDirection = Vector2.right;

        if (!keyboard.spaceKey.wasPressedThisFrame)
            return;

        if (isAttacking || Time.time < nextAttackTime)
            return;

        if (swordPrefab == null)
        {
            Debug.LogError("Sword Prefab が設定されていません。", this);
            return;
        }

        StartCoroutine(AttackAfterDelay());
    }

    public void ResetForStage()
    {
        StopAllCoroutines();
        isAttacking = false;
        nextAttackTime = 0f;
        enabled = true;
    }

    public void StopForDeath()
    {
        StopAllCoroutines();
        isAttacking = false;
        enabled = false;

        SwordProjectile[] projectiles = FindObjectsByType<SwordProjectile>(FindObjectsInactive.Include);
        for (int i = 0; i < projectiles.Length; i++)
            Destroy(projectiles[i].gameObject);
    }

    private IEnumerator AttackAfterDelay()
    {
        isAttacking = true;
        nextAttackTime = Time.time + GameFlow.GetHeroAttackInterval();

        Vector2 attackDirection = lastDirection;

        yield return new WaitForSeconds(attackDelay);

        GameObject sword = Instantiate(
            swordPrefab,
            transform.position,
            Quaternion.identity
        );

        SwordProjectile projectile =
            sword.GetComponent<SwordProjectile>();

        if (projectile != null)
        {
            projectile.SetDamage(GameFlow.GetHeroSlashDamage());
            projectile.SetPiercingHits(GameFlow.GetSlashPiercingHits());
            projectile.Launch(attackDirection);
        }
        else
        {
            Debug.LogError("SwordProjectile が見つかりません。", sword);
            Destroy(sword);
        }

        isAttacking = false;
    }
}
