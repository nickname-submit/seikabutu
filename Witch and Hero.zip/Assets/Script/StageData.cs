using UnityEngine;

[CreateAssetMenu(fileName = "StageData", menuName = "Game/Stage Data")]
public class StageData : ScriptableObject
{
    public int stageId;
    public MonsterSpawnData[] monsters;
}

[System.Serializable]
public class MonsterSpawnData
{
    public int monsterId;
    public Vector2 position;
}