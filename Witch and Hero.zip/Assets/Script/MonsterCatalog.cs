using UnityEngine;

[CreateAssetMenu(fileName = "MonsterCatalog", menuName = "Game/Monster Catalog")]
public class MonsterCatalog : ScriptableObject
{
    [Tooltip("StageWaveのmonsterIdと一致する定義を並べます。ステージごとの出現数はStageCatalog側で設定します。")]
    public MonsterDefinition[] monsters;

    public MonsterDefinition GetMonster(int monsterId)
    {
        if (monsters == null) return null;

        for (int i = 0; i < monsters.Length; i++)
        {
            MonsterDefinition definition = monsters[i];
            if (definition != null && definition.monsterId == monsterId)
                return definition;
        }

        return null;
    }
}

[System.Serializable]
public class MonsterDefinition
{
    [Tooltip("StageWave.monsterIdと同じ値にします。")]
    public int monsterId;

    public string displayName = "スライム";

    [Header("ステータス")]
    [Min(1)] public int maxHealth = 3;
    [Min(0f)] public float moveSpeed = 0.9f;
    [Min(1)] public int heroContactDamage = 1;
    [Min(0.01f)] public float heroContactDamageInterval = 0.35f;
    [Min(0.01f)] public float heroKnockbackInterval = 0.35f;
    [Min(0f)] public float knockbackDistance = 1f;
    [Min(0f)] public float attackAnimationDuration = 0.45f;
    [Min(0f)] public float deathAnimationDuration = 0.5f;

    [Header("見た目")]
    [Tooltip("色違い・別モンスターを作るときはここを変更します。animationSheetを設定すると4x4の行別アニメーションを使います。")]
    public Color tint = Color.white;
    [Tooltip("右へ移動するときにスプライトを左右反転します。元画像が左向きのキャラクターだけ有効にします。")]
    public bool flipXWhenMovingRight;
    public Sprite idleSprite;
    public RuntimeAnimatorController animatorController;
    [Tooltip("静止画だけを使う大型ボスなど、元プレハブのAnimatorを止めます。")]
    public bool disableAnimator;
    [Tooltip("通常モンスターを大型化したミニボスの表示倍率です。1が通常サイズです。")]
    [Min(0.1f)] public float visualScale = 1f;
    [Tooltip("通常種よりノックバックに強いエリート／ボス系として扱います。")]
    public bool isElite;

    [Header("カスタムアニメーション（任意）")]
    [Tooltip("4列×4行。上から Idle / Walk / Attack / Death の順で指定します。")]
    public Texture2D animationSheet;
    [Min(1)] public int animationColumns = 4;
    [Min(1)] public int animationRows = 4;
    [Min(1f)] public float animationFrameRate = 10f;
}
