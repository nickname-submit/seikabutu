using System.Collections.Generic;
using UnityEngine;

public class SwordProjectile : MonoBehaviour
{
    [SerializeField] private float speed = 8f;
    [SerializeField] private float lifetime = 1.5f;
    [SerializeField] private int hitsToDestroy = 1;
    [SerializeField] private int damage = 3;

    private GameObject[] swords;
    private Vector2 direction;
    private bool launched;
    private int hitCount;
    private HashSet<Monster> hitMonsters = new HashSet<Monster>();
    
    private void Awake()
    {
        swords = new GameObject[4];

        swords[0] = transform.Find("SwordUp").gameObject;
        swords[1] = transform.Find("SwordDown").gameObject;
        swords[2] = transform.Find("SwordLeft").gameObject;
        swords[3] = transform.Find("SwordRight").gameObject;

        SetActiveSword(-1);
    }

    public void Launch(Vector2 dir)
    {
        if (dir.sqrMagnitude == 0f)
        {
            Destroy(gameObject);
            return;
        }

        direction = dir.normalized;

        int index;

        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
            index = direction.x > 0 ? 3 : 2;
        else
            index = direction.y > 0 ? 0 : 1;

        SetActiveSword(index);

        launched = true;
        Destroy(gameObject, lifetime);
    }

    public void SetDamage(int value)
    {
        damage = Mathf.Max(1, value);
    }

    public void SetPiercingHits(int value)
    {
        // Each monster is counted only once by hitMonsters. This lets the
        // slash pass through different monsters without repeatedly damaging
        // the same monster while the projectile overlaps it.
        hitsToDestroy = Mathf.Max(1, value);
    }

    private void SetActiveSword(int activeIndex)
    {
        for (int i = 0; i < swords.Length; i++)
        {
            if (swords[i] != null)
                swords[i].SetActive(i == activeIndex);
        }
    }

    private void Update()
    {
        if (!launched) return;

        transform.position +=
            (Vector3)(direction * speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Monster"))
            return;

        Monster monster = other.GetComponentInParent<Monster>();

        if (monster == null || hitMonsters.Contains(monster))
            return;

        hitMonsters.Add(monster);

        monster.TakeSwordHit(direction, damage);

        hitCount++;

        if (hitCount >= Mathf.Max(1, hitsToDestroy))
        {
            Destroy(gameObject);
        }
    }
}
