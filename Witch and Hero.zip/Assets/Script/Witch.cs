using UnityEngine;

public class Witch : MonoBehaviour
{
    [SerializeField] private int maxHealth = 10;
    [SerializeField] private float damageInterval = 0.5f;
    private int health;
    private bool isDead;
    private float nextDamageTime;
    private SpriteRenderer placeholderRenderer;
    private BoxCollider2D bodyCollider;
    private GameObject worldVisualObject;
    private SpriteRenderer worldVisualRenderer;
    private static Sprite cachedWorldSprite;

    public bool IsDead => isDead;
    public int Health => health;
    public int MaxHealth => Mathf.Max(1, maxHealth);

    private void Start()
    {
        EnsureWorldVisual();
        ResetForStage(transform.position);
    }

    private void Awake()
    {
        placeholderRenderer = GetComponent<SpriteRenderer>();
        bodyCollider = GetComponent<BoxCollider2D>();
        ConfigureCollisionBounds();
        EnsureWorldVisual();
    }

    private void ConfigureCollisionBounds()
    {
        if (bodyCollider == null)
            bodyCollider = gameObject.AddComponent<BoxCollider2D>();

        bodyCollider.isTrigger = false;

        // The battle portrait is created at runtime, so a fixed collider was
        // drifting away from the visible pixels whenever the portrait size
        // changed. Fit the collider to the non-transparent pixels instead.
        if (worldVisualRenderer != null && worldVisualRenderer.sprite != null)
        {
            Texture2D texture = worldVisualRenderer.sprite.texture;
            if (texture != null && texture.isReadable)
            {
                Color32[] pixels = texture.GetPixels32();
                int minX = texture.width;
                int minY = texture.height;
                int maxX = -1;
                int maxY = -1;

                for (int y = 0; y < texture.height; y++)
                {
                    for (int x = 0; x < texture.width; x++)
                    {
                        if (pixels[y * texture.width + x].a < 8)
                            continue;

                        minX = Mathf.Min(minX, x);
                        minY = Mathf.Min(minY, y);
                        maxX = Mathf.Max(maxX, x);
                        maxY = Mathf.Max(maxY, y);
                    }
                }

                if (maxX >= minX && maxY >= minY)
                {
                    float pixelsPerUnit = worldVisualRenderer.sprite.pixelsPerUnit;
                    float visualScale = Mathf.Abs(
                        worldVisualRenderer.transform.localScale.x);
                    Vector2 pixelSize = new Vector2(
                        maxX - minX + 1,
                        maxY - minY + 1);
                    Vector2 pixelCenter = new Vector2(
                        (minX + maxX + 1) * 0.5f,
                        (minY + maxY + 1) * 0.5f);
                    Vector2 textureCenter = new Vector2(
                        texture.width * 0.5f,
                        texture.height * 0.5f);

                    bodyCollider.size = pixelSize / pixelsPerUnit * visualScale;
                    bodyCollider.offset = (Vector2)worldVisualRenderer
                        .transform.localPosition +
                        (pixelCenter - textureCenter) /
                        pixelsPerUnit * visualScale;
                    return;
                }
            }
        }

        // Fallback for a missing or non-readable battle sprite.
        bodyCollider.size = new Vector2(1.05f, 1.55f);
        bodyCollider.offset = new Vector2(0f, 0.1f);
    }

    private void EnsureWorldVisual()
    {
        if (cachedWorldSprite == null)
        {
            Texture2D texture = Resources.Load<Texture2D>("Witch/WitchBattleSprite");
            if (texture != null)
            {
                cachedWorldSprite = Sprite.Create(
                    texture,
                    new Rect(0f, 0f, texture.width, texture.height),
                    new Vector2(0.5f, 0.5f),
                    100f);
                cachedWorldSprite.name = "RuntimeWitchWorldSprite";
            }
        }

        // Keep the original placeholder visible as a safe fallback if the
        // resource is missing. Never leave the witch invisible during play.
        if (cachedWorldSprite == null)
            return;

        if (worldVisualObject == null)
        {
            if (placeholderRenderer != null)
            {
                placeholderRenderer.sprite = null;
                placeholderRenderer.enabled = false;
            }

            worldVisualObject = new GameObject("WitchWorldVisual");
            worldVisualObject.transform.SetParent(transform, false);
            worldVisualObject.transform.localPosition = new Vector3(0f, 0.22f, -0.05f);
            worldVisualObject.transform.localScale = Vector3.one * 0.17f;
            worldVisualRenderer = worldVisualObject.AddComponent<SpriteRenderer>();
            worldVisualRenderer.sortingOrder = 2;
            worldVisualRenderer.color = Color.white;
        }

        if (worldVisualRenderer == null)
            worldVisualRenderer = worldVisualObject.GetComponent<SpriteRenderer>();

        if (worldVisualRenderer != null)
        {
            worldVisualRenderer.sprite = cachedWorldSprite;
            ConfigureCollisionBounds();
        }
    }

    public void ResetForStage(Vector3 startPosition)
    {
        maxHealth = GameFlow.GetWitchMaxHealth();
        transform.position = startPosition;
        health = maxHealth;
        isDead = false;
        nextDamageTime = 0f;
    }

    public void TakeDamage(int damage)
    {
        if (isDead) return;

        health -= Mathf.Max(1, damage);
        if (health <= 0)
        {
            health = 0;
            isDead = true;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Monster") || Time.time < nextDamageTime)
            return;

        nextDamageTime = Time.time + damageInterval;
        TakeDamage(1);
    }
}
