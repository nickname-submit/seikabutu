using UnityEngine;

public class ExperienceOrb : MonoBehaviour
{
    [SerializeField] private int experienceValue = 10;
    // Match the enlarged visual pickup size so the interaction feels natural.
    [SerializeField] private float pickupDistance = 0.75f;
    [SerializeField] private float bobHeight = 0.08f;
    [SerializeField] private float bobSpeed = 4f;

    private GameFlow gameFlow;
    private Transform hero;
    private Vector3 startPosition;
    private bool collected;

    public void Initialize(GameFlow owner, Transform heroTarget, int value)
    {
        gameFlow = owner;
        hero = heroTarget;
        experienceValue = Mathf.Max(1, value);
        startPosition = transform.position;
    }

    private void Awake()
    {
        startPosition = transform.position;
    }

    private void Update()
    {
        if (collected) return;

        float bobOffset = Mathf.Sin(Time.time * bobSpeed) * bobHeight;
        transform.position = startPosition + Vector3.up * bobOffset;

        if (hero == null)
        {
            Hero heroComponent = FindAnyObjectByType<Hero>();
            if (heroComponent != null) hero = heroComponent.transform;
        }

        if (hero != null && !hero.gameObject.activeInHierarchy) return;
        if (hero != null && Vector2.Distance(transform.position, hero.position) <= pickupDistance)
            Collect();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Hero"))
            Collect();
    }

    private void Collect()
    {
        if (collected) return;

        collected = true;
        if (gameFlow == null)
            gameFlow = FindAnyObjectByType<GameFlow>();
        if (gameFlow != null)
            gameFlow.CollectExperience(experienceValue);

        Destroy(gameObject);
    }

    public void CollectImmediately()
    {
        Collect();
    }
}
