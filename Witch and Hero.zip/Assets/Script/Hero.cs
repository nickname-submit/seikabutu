using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

public class Hero : MonoBehaviour
{
    private bool isPause;
    private bool isDead;
    private int hitCount;
    [SerializeField] private int maxHits = 10;
    [SerializeField] private float hitInvulnerabilityDuration = 0.5f;
    private float nextHitTime;
    [SerializeField] private float heroKnockbackInterval = 0.16f;
    private float nextHeroKnockbackTime;
    private Coroutine heroKnockbackRoutine;

    private bool isInputLocked;

    private Animator animator;
    private Rigidbody2D body;
    private Collider2D bodyCollider;
    private Vector2 lastDirection = Vector2.down;
    private bool deathAnimationFrozen;
    [SerializeField, Range(0.1f, 1f)]
    private float idleAnimationSpeed = 0.55f;
    private static readonly int DeathStateHash = Animator.StringToHash("Base Layer.death Blend Tree");
    private static readonly int AttackStateHash = Animator.StringToHash("Base Layer.attack Blend Tree");

    public bool IsDead => isDead;
    public int Health => Mathf.Max(0, maxHits - hitCount);
    public int MaxHealth => Mathf.Max(1, maxHits);

    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
        bodyCollider = GetComponent<Collider2D>();
        ConfigurePhysicsBody();
        animator = GetComponent<Animator>();
        if (animator == null)
            Debug.LogError("HeroにAnimatorが設定されていません。", this);
    }

    private void ConfigurePhysicsBody()
    {
        if (body == null) return;

        // Let the Hero use its real collider for wall contacts. The prefab was
        // originally a trigger, which made the witch impossible to treat as a
        // physical wall.
        body.bodyType = RigidbodyType2D.Dynamic;
        body.useFullKinematicContacts = false;
        body.gravityScale = 0f;
        body.linearDamping = 0f;
        body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        body.constraints = RigidbodyConstraints2D.FreezeRotation;
        body.linearVelocity = Vector2.zero;
        body.angularVelocity = 0f;
        if (bodyCollider != null)
            bodyCollider.isTrigger = false;
    }

    public void ResetForStage(Vector3 startPosition)
    {
        maxHits = GameFlow.GetHeroMaxHealth();
        transform.position = startPosition;
        isDead = false;
        isPause = false;
        isInputLocked = false;
        hitCount = 0;
        nextHitTime = 0f;
        nextHeroKnockbackTime = 0f;
        heroKnockbackRoutine = null;
        lastDirection = Vector2.down;
        deathAnimationFrozen = false;
        animator = GetComponent<Animator>();
        body = GetComponent<Rigidbody2D>();
        bodyCollider = GetComponent<Collider2D>();
        ConfigurePhysicsBody();

        if (animator != null)
        {
            animator.speed = Mathf.Clamp(idleAnimationSpeed, 0.1f, 1f);
            animator.Rebind();
            animator.Update(0f);
            animator.ResetTrigger("Attack");
            animator.ResetTrigger("Death");
            animator.SetBool("IsDead", false);
        }

        PlayerSwordAttack swordAttack = GetComponent<PlayerSwordAttack>();
        if (swordAttack != null)
            swordAttack.ResetForStage();
    }

    private void Update()
    {
        if (isDead)
        {
            UpdateDeathAnimation();
            return;
        }

        if (isPause || isInputLocked)
        {
            if (body != null)
                body.linearVelocity = Vector2.zero;
            return;
        }

        Vector2 movement = Vector2.zero;
        Keyboard keyboard = Keyboard.current;
        if (keyboard != null)
        {
            // Keep held movement, but also accept a press that lasts less than
            // one rendered frame. This matters in the editor Game view and
            // makes a single keyboard press move the hero predictably.
            if (keyboard.aKey.isPressed || keyboard.aKey.wasPressedThisFrame ||
                keyboard.leftArrowKey.isPressed || keyboard.leftArrowKey.wasPressedThisFrame)
                movement.x -= 1;
            if (keyboard.dKey.isPressed || keyboard.dKey.wasPressedThisFrame ||
                keyboard.rightArrowKey.isPressed || keyboard.rightArrowKey.wasPressedThisFrame)
                movement.x += 1;
            if (keyboard.wKey.isPressed || keyboard.wKey.wasPressedThisFrame ||
                keyboard.upArrowKey.isPressed || keyboard.upArrowKey.wasPressedThisFrame)
                movement.y += 1;
            if (keyboard.sKey.isPressed || keyboard.sKey.wasPressedThisFrame ||
                keyboard.downArrowKey.isPressed || keyboard.downArrowKey.wasPressedThisFrame)
                movement.y -= 1;
        }

        if (movement != Vector2.zero)
        {
            movement.Normalize();
            if (body != null)
            {
                // Give the physics body a velocity. The non-trigger Hero
                // collider is then stopped by the witch collider itself.
                body.linearVelocity = movement * GameFlow.GetHeroMoveSpeed();
            }
            else
            {
                transform.position += new Vector3(movement.x, movement.y, 0) *
                    GameFlow.GetHeroMoveSpeed() * Time.deltaTime;
            }

            if (Mathf.Abs(movement.x) > Mathf.Abs(movement.y))
                lastDirection = new Vector2(Mathf.Sign(movement.x), 0);
            else
                lastDirection = new Vector2(0, Mathf.Sign(movement.y));
        }
        else if (body != null)
        {
            body.linearVelocity = Vector2.zero;
        }

        if (animator != null)
        {
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
            animator.SetBool("IsMoving", movement != Vector2.zero);
            // The idle sheet is intentionally slower than the action sheets.
            // This keeps the standing pose readable and avoids a strobing or
            // afterimage-like impression while leaving walk/attack at 1x.
            animator.speed = movement != Vector2.zero
                ? 1f
                : Mathf.Clamp(idleAnimationSpeed, 0.1f, 1f);
        }

        if (Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame)
            Attack();
    }

    private void LateUpdate()
    {
        if (!isDead || animator == null || deathAnimationFrozen)
            return;

        // Animator transitions are evaluated after Update. Re-assert death in
        // LateUpdate so an already queued Attack transition cannot be rendered
        // for one frame after the fatal hit.
        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.fullPathHash != DeathStateHash)
        {
            animator.ResetTrigger("Attack");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
        }
    }

    private void Attack()
    {
        if (isDead || animator == null) return;

        isInputLocked = true;
        animator.SetBool("IsMoving", false);
        animator.ResetTrigger("Attack");
        animator.speed = 1f;
        animator.Play(AttackStateHash, 0, 0f);
        StartCoroutine(UnlockInput(GameFlow.GetHeroAttackInterval()));
    }

    private IEnumerator UnlockInput(float duration)
    {
        yield return new WaitForSeconds(duration);
        if (!isDead) isInputLocked = false;
    }

    private void Die()
    {
        if (isDead) return;

        isDead = true;
        isPause = false;
        StopAllCoroutines();
        heroKnockbackRoutine = null;
        CancelInvoke();

        PlayerSwordAttack swordAttack = GetComponent<PlayerSwordAttack>();
        if (swordAttack != null)
            swordAttack.StopForDeath();

        if (animator != null)
        {
            animator.ResetTrigger("Attack");
            animator.ResetTrigger("Death");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.speed = 1f;
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
        }
    }

    private void UpdateDeathAnimation()
    {
        if (animator == null || deathAnimationFrozen) return;

        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        if (stateInfo.fullPathHash != DeathStateHash)
        {
            // An attack transition may already have been queued at the exact
            // frame the fatal collision happened. Always force death back in
            // front before checking the end of the clip.
            animator.ResetTrigger("Attack");
            animator.SetBool("IsMoving", false);
            animator.SetBool("IsDead", true);
            animator.Play(DeathStateHash, 0, 0f);
            animator.Update(0f);
            stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        }

        if (stateInfo.fullPathHash == DeathStateHash && stateInfo.normalizedTime >= 1f)
        {
            animator.speed = 0f;
            deathAnimationFrozen = true;
        }
    }

    private void Pause()
    {
        isPause = true;
        Invoke(nameof(Resume), 0.1f);
    }

    private void Resume()
    {
        if (!isDead) isPause = false;
    }

    private IEnumerator MoveToPosition(Vector3 target)
    {
        Vector3 start = transform.position;
        float time = 0f;
        const float duration = 0.1f;

        while (time < duration)
        {
            time += Time.deltaTime;
            Vector3 nextPosition = Vector3.Lerp(start, target, time / duration);
            if (body != null)
                body.MovePosition(nextPosition);
            else
                transform.position = nextPosition;
            yield return null;
        }
        if (body != null)
            body.MovePosition(target);
        else
            transform.position = target;
        heroKnockbackRoutine = null;
    }

    public void StopForResult()
    {
        isPause = true;
        isInputLocked = true;
        StopHeroKnockback();
        CancelInvoke();

        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
        }

        if (!isDead && animator != null)
        {
            animator.SetBool("IsMoving", false);
            animator.SetFloat("X", lastDirection.x);
            animator.SetFloat("Y", lastDirection.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TryHitByMonster(collision.gameObject);
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        TryHitByMonster(collision.gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Witch")) return;
        TryHitByMonster(other.gameObject);
    }

    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Witch")) return;
        TryHitByMonster(other.gameObject);
    }

    private void TryHitByMonster(GameObject monsterObject)
    {
        if (isDead || !monsterObject.CompareTag("Monster")) return;

        Monster monster = monsterObject.GetComponent<Monster>();
        if (monster != null && monster.IsDead)
            return;

        if (monster != null)
        {
            monster.TakeHeroContactHit();
        }

        // Damage invulnerability must not suppress the hero's knockback.
        // Otherwise the monster can be knocked back while the hero keeps
        // being pushed through it during the damage cooldown.
        if (Time.time >= nextHeroKnockbackTime)
        {
            nextHeroKnockbackTime = Time.time + heroKnockbackInterval;
            Pause();
            StopHeroKnockback();
            heroKnockbackRoutine = StartCoroutine(MoveToPosition(
                transform.position + (transform.position - monsterObject.transform.position).normalized));
        }

        if (Time.time < nextHitTime) return;

        nextHitTime = Time.time + hitInvulnerabilityDuration;
        hitCount++;
        if (hitCount >= maxHits)
        {
            Die();
            return;
        }

    }

    private void StopHeroKnockback()
    {
        if (heroKnockbackRoutine == null) return;

        StopCoroutine(heroKnockbackRoutine);
        heroKnockbackRoutine = null;
    }
}
